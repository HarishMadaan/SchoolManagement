﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;
using System.Security.Cryptography;

namespace CareSmartzPaymentService
{
    public class BLL
    {
        #region Common

        public static String FromDatabaseSLF { get; set; }
        public static void WriteTextLog(Exception ee, string message)
        {

            try
            {
                StringBuilder _str = new StringBuilder();
                if (ee != null)
                {
                    if (!String.IsNullOrEmpty(ee.Source))
                        _str.AppendLine("Source :" + ee.Source.ToString() + "<br/>");
                    if (!String.IsNullOrEmpty(ee.Message))
                        _str.AppendLine("Message :" + ee.Message.ToString() + "<br/>");
                    if (!String.IsNullOrEmpty(ee.StackTrace))
                        _str.AppendLine("StackTrace :" + ee.StackTrace.ToString() + "<br/>");
                }
                _str.AppendLine(message);
                message = _str.ToString();

                string ErrorLogPath = System.IO.Path.GetDirectoryName(new System.Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).LocalPath);
                string sFileName = ErrorLogPath + "\\ErrorLog\\" + DateTime.UtcNow.Month.ToString() + "_" + DateTime.UtcNow.Day.ToString() + "_" + DateTime.UtcNow.Year.ToString();
                if (!Directory.Exists(sFileName))
                    Directory.CreateDirectory(sFileName);

                sFileName += "\\ErrorLog.txt";
                System.IO.FileInfo objFileInfo = new System.IO.FileInfo(sFileName);
                if (!objFileInfo.Exists)
                    objFileInfo.Create();


                System.IO.FileStream objFileStream = objFileInfo.Open(System.IO.FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
                System.IO.StreamWriter objWriter = new System.IO.StreamWriter(objFileStream);
                objWriter.BaseStream.Seek(0, System.IO.SeekOrigin.End);
                if (ee != null)
                {
                    objWriter.WriteLine("Error Occured at " + DateTime.Now.ToLongDateString() + " : " + DateTime.Now.ToLongTimeString());
                }
                objWriter.WriteLine(message);
                objWriter.WriteLine("----------------------------------------------------------------------");
                objWriter.Close();
            }
            catch (Exception)
            {
            }
        }

        public static void WriteTextLog(string message)
        {
            try
            {
                string ErrorLogPath = System.IO.Path.GetDirectoryName(new System.Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).LocalPath);
                string sFileName = ErrorLogPath + "\\ErrorLog\\" + DateTime.UtcNow.Month.ToString() + "_" + DateTime.UtcNow.Day.ToString() + "_" + DateTime.UtcNow.Year.ToString();
                if (!Directory.Exists(sFileName))
                    Directory.CreateDirectory(sFileName);

                sFileName += "\\ErrorLog.txt";
                System.IO.FileInfo objFileInfo = new System.IO.FileInfo(sFileName);
                if (!objFileInfo.Exists)
                    objFileInfo.Create();

                System.IO.FileStream objFileStream = objFileInfo.Open(System.IO.FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
                System.IO.StreamWriter objWriter = new System.IO.StreamWriter(objFileStream);
                objWriter.BaseStream.Seek(0, System.IO.SeekOrigin.End);
                objWriter.WriteLine(message);
                objWriter.Close();
                objFileStream.Close();
                objFileStream.Dispose();
                objWriter.Dispose();
            }
            catch (Exception)
            {
            }
        }


        #endregion

        #region [Search]
        public static DataTable GetTicketSupportStatus(string FromDatabase)
        {
            try
            {
                DataSet dsTT = new DataSet();

                dsTT = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SvcGetSupportTicketDetailForEscalation", FromDatabase);
                return dsTT.Tables[0];
            }
            catch (Exception ex)
            {
                WriteTextLog("SvcGetSupportTicketDetailForEscalation :" + ex.Message);
                return null;
            }
        }

        public static int GetLeadSalesCycleUpdateStatus(string FromDatabase)
        {
            int resultValue = 0;
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("svcGetLeadsInquiryToSetSalesCycle", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //SqlParameter parameter = new SqlParameter("ReturnResult", SqlDbType.Int);
                //parameter.Direction = ParameterDirection.Output;
                //objCmd.Parameters.Add(parameter);
                //objCmd.ExecuteNonQuery();
                //resultValue = (parameter.Value != null) ? Convert.ToInt32(parameter.Value.ToString()) : 0;

                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}

                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@ReturnResult", SqlDbType.Int);

                resultValue = SqlHelper.ExecuteNonQuery("svcGetLeadsInquiryToSetSalesCycle", "", FromDatabase, arrParam);

                return resultValue;
            }
            catch (Exception ex)
            {
                WriteTextLog("svcGetLeadsInquiryToSetSalesCycle :" + ex.Message);
                return 0;
            }
        }

        public static int GetLeadImportedStatusOnInsert(string FromDatabase)
        {
            int resultValue = 0;
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("svcInsertImportedLead", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //SqlParameter parameter = new SqlParameter("ReturnResult", SqlDbType.Int);
                //parameter.Direction = ParameterDirection.Output;
                //objCmd.Parameters.Add(parameter);
                //objCmd.ExecuteNonQuery();
                //resultValue = (parameter.Value != null) ? Convert.ToInt32(parameter.Value.ToString()) : 0;

                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@ReturnResult", SqlDbType.Int);

                resultValue = SqlHelper.ExecuteNonQuery("svcInsertImportedLead", "", FromDatabase, arrParam);
                return resultValue;
            }
            catch (Exception ex)
            {
                WriteTextLog("svcInsertImportedLead :" + ex.Message);
                return 0;
            }
        }
        public static int GetBrokerImportedStatusOnInsert(string FromDatabase)
        {
            int resultValue = 0;
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("svcInsertImportedBrokers", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //SqlParameter parameter = new SqlParameter("ReturnResult", SqlDbType.Int);
                //parameter.Direction = ParameterDirection.Output;
                //objCmd.Parameters.Add(parameter);
                //objCmd.ExecuteNonQuery();
                //resultValue = (parameter.Value != null) ? Convert.ToInt32(parameter.Value.ToString()) : 0;

                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@ReturnResult", SqlDbType.Int);

                SqlHelper.ExecuteNonQuery("svcInsertImportedBrokers", "", FromDatabase, arrParam);
                return resultValue;

            }
            catch (Exception ex)
            {
                WriteTextLog("svcInsertImportedBrokers :" + ex.Message);
                return 0;
            }
        }
        public static int GetClientInquiryImportedStatusOnInsert(string FromDatabase)
        {
            int resultValue = 0;
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("svcInsertImportedClientInquiry", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //SqlParameter parameter = new SqlParameter("ReturnResult", SqlDbType.Int);
                //parameter.Direction = ParameterDirection.Output;
                //objCmd.Parameters.Add(parameter);
                //objCmd.ExecuteNonQuery();
                //resultValue = (parameter.Value != null) ? Convert.ToInt32(parameter.Value.ToString()) : 0;

                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@ReturnResult", SqlDbType.Int);

                resultValue = SqlHelper.ExecuteNonQuery("svcInsertImportedClientInquiry", "", FromDatabase, arrParam);
                return resultValue;
            }
            catch (Exception ex)
            {
                WriteTextLog("svcInsertImportedClientInquiry :" + ex.Message);
                return 0;
            }
        }


        #endregion

        #region [EmailBody]

        public static string CreateEmailBody(string strBody, DataRow drTT)
        {
            try
            {
                string strCreateBody = string.Empty;
                strCreateBody = @"This is to inform you that your search has been added up with following:<br/>";
                strCreateBody += drTT["stFirstName"].ToString() + "\t" + drTT["stLastName"].ToString() + "\t" + drTT["StPrimaryEmail"].ToString();
                try
                {
                    strBody = strBody.Replace("[EmailAlertBody]", strCreateBody.ToString());
                }
                catch (Exception) { }

                return strBody;
            }
            catch (Exception ex)
            {
                WriteTextLog("CreateEmailBody(" + drTT["intSaveSearchId"] + ") :" + ex.Message);
                return strBody;
            }
        }
        #endregion

        #region Top Story Get data"

        /// <summary>
        /// Written By Sandeep Jain
        /// </summary>
        /// <returns></returns>
        public static DataTable GetBeforeTopExpireUser(string FromDatabase)
        {
            try
            {

                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("FecthUserEmailForTopStoreExpiratiON", FromDatabase, 1);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                WriteTextLog("FecthUserEmailForTopStoreExpiratiON :" + ex.Message);
                return null;
            }
        }

        public static DataTable GetAfterTopExpireUser(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("FecthUserEmailForTopStoreExpiratiON", FromDatabase, 2);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                WriteTextLog("FecthUserEmailForTopStoreExpiratiON :" + ex.Message);
                return null;
            }
        }

        public static Dictionary<string, string> GetTemplateByTemplateTypeByTempalteId(Guid templateID, string FromDatabase)
        {
            Dictionary<string, string> Dict = new Dictionary<string, string>();
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetTemplatbyType", FromDatabase, new Guid(Convert.ToString(templateID)));
                DataTable RowTemp = dsTSExpire.Tables[0];
                foreach (DataRow Item in RowTemp.Rows)
                {
                    Dict.Add("Description", Item["Description"].ToString());
                    Dict.Add("Subject", Item["Subject"].ToString());

                }

                return Dict;
            }
            catch (Exception ex)
            {
                WriteTextLog("GetTemplateByTemplateTypeByTempalteId :" + ex.Message);
                return Dict;
            }
        }

        #region "Auto Archive Top Story"

        public static void AutoArchiveTopStory(string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_AutoArchiveTopStory", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();

                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}


                SqlHelper.ExecuteNonQuery("SVC_AutoArchiveTopStory", "", FromDatabase);
            }
            catch (Exception ex)
            {
                WriteTextLog("svcGetLeadsInquiryToSetSalesCycle :" + ex.Message);
            }
        }

        #endregion
        #endregion

        #region "Digital Library Document expiration"
        /// <summary>
        /// Written By Sandeep Jain
        /// Date 26Dec_2012
        /// </summary>
        /// <returns></returns>
        public static DataTable GetBeforeDigitalLibraryDocExpirationUserEmail(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_FectchDigitalLibraryDocumentExpiration", FromDatabase, 1);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("SVC_FectchDigitalLibraryDocumentExpiration-Before", DateTime.Now, ex.Message, FromDatabase);
                // WriteTextLog("SVC_FectchDigitalLibraryDocumentExpiration :" + ex.Message);
                return null;
            }
        }

        public static DataTable GetAfterDigitalLibraryDocExpirationUsersEmail(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_FectchDigitalLibraryDocumentExpiration", FromDatabase, 2);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("SVC_FectchDigitalLibraryDocumentExpiration_After", DateTime.Now, ex.Message, FromDatabase);
                // WriteTextLog("SVC_FectchDigitalLibraryDocumentExpiration :" + ex.Message);
                return null;
            }
        }

        public static DataTable GetDLDocExpirationTemplate(string TemplateType, string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetTemplatbyType", FromDatabase, TemplateType);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                WriteTextLog("GetTemplatbyType :" + ex.Message);
                return null;
            }
        }


        #endregion

        #region "FDD"

        #region FDD Expiration
        /// <summary>
        /// This Function is used to Fethch the expiartion fdd with the user email to whome alert mail need to send.
        /// Writtn By Sandeep Jain 27 Dec_2012
        /// </summary>
        /// <param name="mode">1-Before,2- After</param>
        /// <returns>Datattable with the FDD deatils and  user email</returns>

        public static DataTable SendEmailExpirationDateOfFDD(int mode, string FromDatabase)
        {
            try
            {
                DataSet objDS = new DataSet();

                objDS = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_FetchFDDExpiration", FromDatabase, mode);
                return objDS.Tables[0];

            }
            catch (Exception ex)
            {

                WriteTextLog("SVC_FetchFDDExpiration :" + ex.Message);
                return null;
            }
        }

        #endregion

        #region "Auto Archive Alert"

        public static void AutoArchiveAlert(string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_AutoArchiveAlert", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}


                SqlHelper.ExecuteNonQuery("SVC_AutoArchiveAlert", "", FromDatabase);
            }
            catch (Exception ex)
            {
                WriteTextLog("svcGetLeadsInquiryToSetSalesCycle :" + ex.Message);
            }


        }

        #endregion
        #endregion

        #region "Ticket Escalation"

        #region "Sent Alert"

        public static DataTable GeUserEmailTosentTicketAlerts(int mode, string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_Ticketescalation", FromDatabase, mode);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                WriteTextLog("SVC_Ticketescalation:" + ex.Message);
                return null;
            }
        }

        public static void UpdateSupportTicket(int mode, Guid TicketID, Guid? userId, int level, string FromDatabase)
        {
            try
            {

                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_UpdateTicketbyTicketID", objconnection);
                //SqlParameter parameter = new SqlParameter("@mode", SqlDbType.Int);
                //parameter.Value = mode;
                //SqlParameter parameter1 = new SqlParameter("@TicketID", SqlDbType.UniqueIdentifier);
                //parameter1.Value = TicketID;
                //SqlParameter parameter2 = new SqlParameter("@UserID", SqlDbType.UniqueIdentifier);
                //parameter2.Value = userId;
                //SqlParameter parameter3 = new SqlParameter("@Level", SqlDbType.Int);
                //parameter3.Value = level;

                ////parameter.Direction = ParameterDirection.Output;
                //objCmd.Parameters.Add(parameter);
                //objCmd.Parameters.Add(parameter1);
                //objCmd.Parameters.Add(parameter2);
                //objCmd.Parameters.Add(parameter3);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[4];
                arrParam[0] = new SqlParameter("@mode", mode);
                arrParam[1] = new SqlParameter("@TicketID", TicketID);
                arrParam[2] = new SqlParameter("@UserID", userId);
                arrParam[3] = new SqlParameter("@Level", level);
                arrParam[0].Direction = ParameterDirection.Output;
                arrParam[0].Value = mode;

                SqlHelper.ExecuteNonQuery("SVC_UpdateTicketbyTicketID", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {
                WriteTextLog("SVC_UpdateTicketbyTicketID:" + ex.Message);

            }
        }

        #endregion

        #region Assigned the Ticket to higher level

        public static DataTable GetSuperiorUserEmailTOAssignTicket(int mode, string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_AssignedTicketToLevelBylevel", FromDatabase, mode);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                WriteTextLog("SVC_AssignedTicketToLevelBylevel" + ex.Message);
                return null;
            }
        }

        #endregion


        #endregion

        #region "Franchise Task Updation"
        public static DataTable GetFranchiseTaskToOverdue(int mode, string FromDatabase)
        {
            try
            {
                DataSet objDS = new DataSet();

                objDS = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_FetchFranchiseTaskToOverdue", FromDatabase, mode);
                return objDS.Tables[0];

            }
            catch (Exception ex)
            {

                WriteTextLog("SVC_FetchFranchiseTaskToOverdue :" + ex.Message);
                return null;
            }
        }

        public static void UpdateTaskstausToOverdue(Guid Status, string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_UpdateFranchiseTask", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //SqlParameter parameter = new SqlParameter("@FranchiseeCheckListItemId", SqlDbType.UniqueIdentifier);
                //parameter.Value = Status;
                //objCmd.Parameters.Add(parameter);
                //objCmd.ExecuteNonQuery();
                ////resultValue = (parameter.Value != null) ? Convert.ToInt32(parameter.Value.ToString()) : 0;
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@FranchiseeCheckListItemId", Status);

                SqlHelper.ExecuteNonQuery("SVC_UpdateFranchiseTask", "", FromDatabase, arrParam);

            }
            catch (Exception ex)
            {
                WriteTextLog("SVC_UpdateFranchiseTask :" + ex.Message);
            }
        }

        #endregion

        #region "Save for Service request"

        public static void AddToSVCTable(string servicename, DateTime time, String ErrorMsg, string FromDatabase)
        {
            try
            {

                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_InsertIntoTB_SVC", objconnection);
                //SqlParameter parameter = new SqlParameter("@serviceName", SqlDbType.NVarChar);
                //parameter.Value = servicename;
                //SqlParameter parameter1 = new SqlParameter("@date", SqlDbType.DateTime);
                //parameter1.Value = Convert.ToDateTime(time);
                //SqlParameter parameter2 = new SqlParameter("@ErrorMsg", SqlDbType.NVarChar);
                //parameter2.Value = ErrorMsg;
                ////parameter.Direction = ParameterDirection.Output;
                //objCmd.Parameters.Add(parameter);
                //objCmd.Parameters.Add(parameter1);
                //objCmd.Parameters.Add(parameter2);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[3];
                arrParam[0] = new SqlParameter("@serviceName", SqlDbType.NVarChar);
                arrParam[1] = new SqlParameter("@date", time);
                arrParam[2] = new SqlParameter("@ErrorMsg", ErrorMsg);
                arrParam[0].Value = servicename;
                arrParam[0].Direction = ParameterDirection.Output;

                SqlHelper.ExecuteNonQuery("SVC_InsertIntoTB_SVC", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {
                WriteTextLog("SVC_InsertIntoTB_SVC" + ex.Message);

            }

        }
        //SVC_InsertIntoTB_SVC
        #endregion

        #region "Update the ticket send"
        /// <summary>
        /// Written by Sandeep Jain  22 JAn_2012
        /// Update the alert has been sent absis on the mode
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Sent"></param>
        /// <param name="mode"></param>
        public static void UpdateTicketSend(Guid ID, int Sent, int mode, string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_SetAlertStatus", objconnection);
                //SqlParameter parameter = new SqlParameter("@mode", SqlDbType.Int);
                //parameter.Value = mode;
                //SqlParameter parameter1 = new SqlParameter("@sent", SqlDbType.Int);
                //parameter1.Value = Sent;
                //SqlParameter parameter2 = new SqlParameter("@id", SqlDbType.UniqueIdentifier);
                //parameter2.Value = ID;

                ////parameter.Direction = ParameterDirection.Output;
                //objCmd.Parameters.Add(parameter);
                //objCmd.Parameters.Add(parameter1);
                //objCmd.Parameters.Add(parameter2);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[3];
                arrParam[0] = new SqlParameter("@mode", mode);
                arrParam[1] = new SqlParameter("@sent", Sent);
                arrParam[2] = new SqlParameter("@id", ID);
                arrParam[0].Direction = ParameterDirection.Output;

                SqlHelper.ExecuteNonQuery("SVC_SetAlertStatus", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {
                AddToSVCTable("UpdateTicketSent", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("UpdateTicketSent:" + ex.Message);
            }
        }
        #endregion

        #region "Franchsie"

        #region "Franchsie Checklist Item TraningUpdate"
        public static void FranchsieTrainigUpdate(string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("svc_Franchisestatus", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}


                SqlHelper.ExecuteNonQuery("svc_Franchisestatus", "", FromDatabase);
            }
            catch (Exception ex)
            {
                WriteTextLog("svc_Franchisestatus :" + ex.Message);
            }


        }


        #endregion

        #region "Franchsie Checklist Document Status Update"
        public static void FranchsieCheckListDocumentStatusUpdate(string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_FranchiseChecklistDocumentStatusUpdate", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}


                SqlHelper.ExecuteNonQuery("SVC_FranchiseChecklistDocumentStatusUpdate", "", FromDatabase);
            }
            catch (Exception ex)
            {
                AddToSVCTable("SVC_FranchiseChecklistDocumentStatusUpdate", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("SVC_FranchiseChecklistDocumentStatusUpdate :" + ex.Message);
            }


        }

        #endregion

        #region "FRANCHIHSE CHECKLIST ITEM ALERTS"
        /// <summary>
        /// This fucntion is used to sent the alerts for checklist item before the no of days  and after the no of days to the franchise owner
        /// Written By Sandeep jain 
        /// </summary>
        /// <param name="mode">Used for Before and After</param>
        /// <returns>List of the franchsie user with email deatils </returns>
        public static DataTable FranchsieChecklistItemAlert(int mode, string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_FranchsieChecklistItemScheduleAlert", FromDatabase, mode);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                WriteTextLog("SVC_FranchsieChecklistItemScheduleAlert :" + ex.Message);
                return null;
            }


        }

        #endregion

        #region "Update franchsie Alert"
        public static void UpdateFranchsieEmailAert(int mode, Guid FCLItemID, string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_UpdateFranchiseAlertEmail", objconnection);
                //SqlParameter parameter = new SqlParameter("@mode", SqlDbType.Int);
                //parameter.Value = mode;
                //SqlParameter parameter1 = new SqlParameter("@ID", SqlDbType.UniqueIdentifier);
                //parameter1.Value = FCLItemID;
                //objCmd.Parameters.Add(parameter);
                //objCmd.Parameters.Add(parameter1);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[2];
                arrParam[0] = new SqlParameter("@mode", mode);
                arrParam[1] = new SqlParameter("@ID", FCLItemID);


                SqlHelper.ExecuteNonQuery("SVC_UpdateFranchiseAlertEmail", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {

                AddToSVCTable("UpdateFranchsieEmailAert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("UpdateFranchsieEmailAert:" + ex.Message);
            }
        }

        //

        #endregion

        #region "FRANCHISE TERMINATION ALERT"

        public static DataTable FranchiseTrminationLAert(int mode, string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_FranchsieTerminationAlert", FromDatabase, mode);
                return dsTSExpire.Tables[0];

            }
            catch (Exception ex)
            {
                AddToSVCTable("SendFranchiseTrminationLAert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("SVC_FranchsieTerminationAlert :" + ex.Message);
                return null;
            }
        }

        #endregion

        #region "Franchsie termination"
        public static void FranchsieTermination(string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_TerminateFranchise", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}


                SqlHelper.ExecuteNonQuery("SVC_TerminateFranchise", "", FromDatabase);
            }
            catch (Exception ex)
            {
                WriteTextLog("svc_Franchisestatus :" + ex.Message);
                AddToSVCTable("SVC_FranchiseChecklistDocumentStatusUpdate", DateTime.Now, ex.Message, FromDatabase);
            }


        }
        #endregion
        #endregion

        #region "DELETE EVENT SLOTS ON TEMP"
        public static void DeleteEventTemlSlot(string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_DeleetEventtemlSlot", objconnection);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}

                SqlHelper.ExecuteNonQuery("SVC_DeleetEventtemlSlot", "", FromDatabase);
            }
            catch (Exception ex)
            {
                AddToSVCTable("SVC_FranchiseChecklistDocumentStatusUpdate", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("svc_Franchisestatus :" + ex.Message);
            }
        }

        #endregion

        #region "Abc Email CapaignID"

        public static DataTable AbcEmailCampaign(string FromDatabase)
        {
            try
            {

                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_EMAILCAMPAGIN", FromDatabase);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("AbcEmailCampaign", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("AbcEmailCampaign :" + ex.Message);
                return null;
            }
        }


        public static void UpdateCapaginRun(Guid CampaignRunID, Guid Entityid, string Entitytype, Guid? Groupid, string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_InsertIntoCampaginRunContact", objconnection);
                //SqlParameter parameter = new SqlParameter("@CampaignRunID", SqlDbType.UniqueIdentifier);
                //parameter.Value = CampaignRunID;
                //SqlParameter parameter2 = new SqlParameter("@Entityid", SqlDbType.UniqueIdentifier);
                //parameter2.Value = Entityid;
                //SqlParameter parameter3 = new SqlParameter("@Entitytype", SqlDbType.VarChar);
                //parameter3.Value = Entitytype;
                //SqlParameter parameter4 = new SqlParameter("@Groupid", SqlDbType.UniqueIdentifier);
                //parameter4.Value = Groupid;
                //objCmd.Parameters.Add(parameter);
                //objCmd.Parameters.Add(parameter2);
                //objCmd.Parameters.Add(parameter3);
                //if (Groupid != null)
                //    objCmd.Parameters.Add(parameter4);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[4];
                arrParam[0] = new SqlParameter("@CampaignRunID", CampaignRunID);
                arrParam[1] = new SqlParameter("@Entityid", Entityid);
                arrParam[2] = new SqlParameter("@Entitytype", Entitytype);
                if (Groupid != null)
                    arrParam[3] = new SqlParameter("@Groupid", Groupid);

                SqlHelper.ExecuteNonQuery("SVC_InsertIntoCampaginRunContact", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {

                AddToSVCTable("UpdateCapaginRun", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("UpdateCapaginRun:" + ex.Message);
            }
        }


        public static void UpdateCapaginStatus(Guid CapaignID, string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_UpdateCampaginStatus", objconnection);
                //SqlParameter parameter = new SqlParameter("@CapaignID", SqlDbType.UniqueIdentifier);
                //parameter.Value = CapaignID;
                //objCmd.Parameters.Add(parameter);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@CapaignID", CapaignID);


                SqlHelper.ExecuteNonQuery("SVC_UpdateCampaginStatus", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {

                AddToSVCTable("UpdateCapaginRun", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("UpdateCapaginRun:" + ex.Message);
            }
        }



        #endregion

        #region "Agreement Expiration alert"
        #region "Franchise Agreement Expiration alert"

        public static DataTable FranchiseAgreementExpirationAlert(int mode, string FromDatabase)
        {
            try
            {

                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_FranchiseSetupAgreeMent", FromDatabase, mode);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("FranchiseAgreementExpirationAlert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("FranchiseAgreementExpirationAlert :" + ex.Message);
                return null;
            }
        }

        #endregion

        #region "AR Agreement Expiration alert"

        public static DataTable ARAgreementExpirationAlert(int mode, string FromDatabase)
        {
            try
            {

                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_ARAgreementExpiration", FromDatabase, mode);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("[SVC_ARAgreementExpiration]", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("[SVC_ARAgreementExpiration] :" + ex.Message);
                return null;
            }
        }

        #endregion


        #region "Update Alert"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="mode"></param>
        public static void UpdateAgreementExpirationAlert(Guid ID, int mode, string FromDatabase)
        {
            try
            {

                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_UpadteARAgreementExpiration", objconnection);
                //SqlParameter parameter = new SqlParameter("@Id", SqlDbType.UniqueIdentifier);
                //SqlParameter parameter1 = new SqlParameter("@MODE", SqlDbType.Int);
                //parameter.Value = ID;
                //parameter1.Value = mode;
                //objCmd.Parameters.Add(parameter);
                //objCmd.Parameters.Add(parameter1);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[2];
                arrParam[1] = new SqlParameter("@Id", ID);
                arrParam[0] = new SqlParameter("@MODE", mode);

                SqlHelper.ExecuteNonQuery("SVC_UpadteARAgreementExpiration", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {
                AddToSVCTable("UpdateAgreementExpirationAlert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("UpdateAgreementExpirationAlert" + ex.Message);
            }
        }

        #endregion
        #endregion

        #region "Template Alerts"
        /// <summary>
        /// Fetching the caregiver email id  that is not check-in on the schedile time after 5 Mins 
        /// Sandeep jain 19Apr_2013
        /// </summary>
        /// <returns></returns>
        public static DataTable TelephonyALerts(int mode, string FromDatabase)
        {
            try
            {

                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_TelephonyAlerts", FromDatabase, mode);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("SVC_TelephonyAlerts", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("SVC_TelephonyAlerts" + ex.Message);
                return null;
            }
        }
        /// <summary>
        /// Update the Telephone record that alert will be sent only once 
        /// </summary>
        /// <param name="ID"></param>
        public static void UpdateTelephonyAlert(Guid ID, int Mode, string FromDatabase)
        {
            try
            {
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("SVC_TelephonyAlertUpdate", objconnection);
                //SqlParameter parameter = new SqlParameter("@Id", SqlDbType.UniqueIdentifier);
                //SqlParameter parameter1 = new SqlParameter("@MODE", SqlDbType.Int);
                //parameter.Value = ID;
                //parameter1.Value = Mode;
                //objCmd.Parameters.Add(parameter);
                //objCmd.Parameters.Add(parameter1);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}

                SqlParameter[] arrParam = new SqlParameter[2];
                arrParam[0] = new SqlParameter("@Id", ID);
                arrParam[1] = new SqlParameter("@MODE", Mode);

                SqlHelper.ExecuteNonQuery("SVC_TelephonyAlertUpdate", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        #endregion

        #region  "TimeZone"

        public static DateTime ConvertFromTUC(DateTime curDate, Guid userID, string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SP_ConvertFromUTC", FromDatabase, userID, curDate);
                return Convert.ToDateTime(dsTSExpire.Tables[0].Rows[0]["NewDateTime"]);
            }
            catch (Exception ex)
            {
                WriteTextLog("SP_ConvertFromUTC" + ex.Message);
                return DateTime.UtcNow;
            }
        }

        #endregion

        #region "lead Creation"

        public static DataTable GetLeadCreationDataforEmail(string FromDatabase)
        {
            DataSet EmailRecepient = new DataSet();

            EmailRecepient = CareSmartzPaymentService.SqlHelper.ExecuteDataset("FetchLeadListingForCreationEmail", FromDatabase);
            return EmailRecepient.Tables[0];
        }

        public static void UpdateLeadPrimaryInformationafterEmailSuccess(Guid LeadPrimaryInformationId, string FromDatabase)
        {
            //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
            SqlConnection objconnection = new SqlConnection() { ConnectionString = FromDatabase };
            objconnection.Open();
            SqlCommand objCmd = new SqlCommand("UPDATE LeadPrimaryInformation SET IsLeadCreationEmailSent=1 WHERE LeadPrimaryInformationId='" + Convert.ToString(LeadPrimaryInformationId) + "'", objconnection);
            objCmd.CommandType = CommandType.Text;
            objCmd.ExecuteNonQuery();
            if (objconnection.State != ConnectionState.Closed)
            {
                objconnection.Close();
            }

        }

        public static DataTable GetConsumerLeadCreationDataforEmail(string FromDatabase)
        {
            DataSet EmailRecepient = new DataSet();

            EmailRecepient = CareSmartzPaymentService.SqlHelper.ExecuteDataset("FetchClientInquiryListingForCreationEmail", FromDatabase);
            return EmailRecepient.Tables[0];
        }

        public static DataTable GetSLFLeadCreationDataforEmail(string FromDatabase)
        {
            DataSet EmailRecepient = new DataSet();

            EmailRecepient = CareSmartzPaymentService.SqlHelper.ExecuteDataset("FetchSLFListingForCreationEmail", FromDatabase);
            return EmailRecepient.Tables[0];
        }


        public static void UpdateClientCallerInformationafterEmailSuccess(Guid ClientCallerinformationId, string FromDatabase)
        {
            //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["ABCSvcConnectionString"].ConnectionString };
            SqlConnection objconnection = new SqlConnection() { ConnectionString = FromDatabase };
            objconnection.Open();
            string qur = "UPDATE ClientCallerInformation SET IsMailSent=1 WHERE ClientCallerinformationId='" + Convert.ToString(ClientCallerinformationId) + "'";
            SqlCommand objCmd = new SqlCommand("UPDATE ClientCallerInformation SET IsMailSent=1 WHERE ClientCallerinformationId='" + Convert.ToString(ClientCallerinformationId) + "'", objconnection);
            objCmd.CommandType = CommandType.Text;
            objCmd.ExecuteNonQuery();
            if (objconnection.State != ConnectionState.Closed)
            {
                objconnection.Close();
            }
        }

        #endregion

        #region "Geust USerExpiration Alert"

        public static DataTable GuestUserExpirationAlert(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_GuestUserExpiration", FromDatabase);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {

                AddToSVCTable("[SVC_GuestUserExpiration_GuestUserExpirationAlert]", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("[SVC_GuestUserExpiration_GuestUserExpirationAlert] :" + ex.Message);
                return null;
            }
        }
        #endregion

        #region "Training Expiration Alert"
        /// <summary>
        /// Sandeep jain 24 June_2013
        /// </summary>
        /// <returns></returns>
        public static DataTable TrainingExpirationAlert(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_TraininExpirationAlert", FromDatabase);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {

                AddToSVCTable("[SVC_TraininExpirationAlert_TrainingExpirationAlert]", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("[SVC_TraininExpirationAlert_TrainingExpirationAlert]:" + ex.Message);
                return null;
            }
        }
        #endregion

        #region "Client Document Expiartion Alert"
        /// <summary>
        /// Written By Sandeep jain 
        /// </summary>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static DataTable ClientDocExpirationALert(int mode, string FromDatabase)
        {
            try
            {

                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("SVC_ClientDocumentExpirationALert", FromDatabase, mode);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("BeforeClientDocExpirationALert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("BeforeClientDocExpirationALert :" + ex.Message);
                return null;
            }
        }
        #endregion


        #region "Franchsie Renewal Expiration Alert Service"
        public static DataTable FranchiseReneWalAlert(int mode, string FromDatabase)
        {
            try
            {

                DataSet dsTSExpire = new DataSet();

                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("[svc_FranchiseRenwealAlert]", FromDatabase, mode);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("FranchiseReneWalAlert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("FranchiseReneWalAlert :" + ex.Message);
                return null;
            }
        }
        #endregion
        #region "Caregiver Comming 24 hours schedule Alert(s)"
        public static DataTable CaregiverScheduleAlert(string FromDatabase)
        {
            try
            {

                DataSet dsCaregiverAndScheduleInfo = new DataSet();

                dsCaregiverAndScheduleInfo = CareSmartzPaymentService.SqlHelper.ExecuteDataset("[svc_CaregiverScheduleAlert]", FromDatabase);
                return dsCaregiverAndScheduleInfo.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("CaregiverScheduleAlert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("CaregiverScheduleAlert :" + ex.Message);
                return null;
            }
        }

        public static DataTable GetScheduleDetailsByScheduleId(Guid? gdScheduleSlotID, string FromDatabase)
        {
            try
            {

                DataSet dsScheduleDetail = new DataSet();

                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@scheduleslotid", gdScheduleSlotID);

                dsScheduleDetail = CareSmartzPaymentService.SqlHelper.ExecuteDataset("[svc_CaregiverScheduleDetail]", FromDatabase, arrParam);
                return dsScheduleDetail.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("GetScheduleDetailsByScheduleId", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("GetScheduleDetailsByScheduleId :" + ex.Message);
                return null;
            }
        }

        public static DataTable GetScheduleTaskDetailsByScheduleTaskId(Guid? gdScheduleTaskID, string FromDatabase)
        {
            try
            {

                DataSet dsScheduleTaskDetail = new DataSet();

                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@scheduletaskid", gdScheduleTaskID);

                dsScheduleTaskDetail = CareSmartzPaymentService.SqlHelper.ExecuteDataset("[svc_ScheduleTaskDetail]", FromDatabase, arrParam);
                return dsScheduleTaskDetail.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("GetScheduleTaskDetailsByScheduleTaskId", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("GetScheduleTaskDetailsByScheduleTaskId :" + ex.Message);
                return null;
            }
        }


        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Sent"></param>
        public static void UpdateScheduleEventsSlotsFlagForCaregiverNotify(Guid ID, int Sent, string FromDatabase)
        {
            try
            {
                SqlParameter[] arrParam = new SqlParameter[2];
                arrParam[0] = new SqlParameter("@ID", ID);
                arrParam[1] = new SqlParameter("@sent", Sent);

                SqlHelper.ExecuteNonQuery("Svc_setScheduleEventsSlotsFlagForCaregiverNotification", "", FromDatabase, arrParam);
            }
            catch (Exception ex)
            {
                AddToSVCTable("UpdateScheduleEventsSlotsFlagForCaregiverNotify", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("UpdateScheduleEventsSlotsFlagForCaregiverNotify:" + ex.Message);
            }
        }

        public static String getUserIdByUsername(String Username, string FromDatabase)
        {
            try
            {
                String UserId = String.Empty;
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@Username", Username);

                var dataset = CareSmartzPaymentService.SqlHelper.ExecuteDataset("[getUserIdByUsername]", FromDatabase, arrParam);
                DataTable dt = dataset.Tables[0];
                UserId = Convert.ToString(dt.Rows[0]["UserId"]);
                return UserId;
            }
            catch (Exception ex)
            {
                AddToSVCTable("getUserIdByUsername", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("getUserIdByUsername:" + ex.Message);
                return String.Empty;
            }
        }

        #endregion


        #region SLF Property Alert

        public static DataTable SLFPropertyAlert(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();
                SqlHelper.FromDatabaseSLF = FromDatabaseSLF;
                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteSLFDataset("PropertyEmailAlert", FromDatabase);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {

                AddToSVCTable("[PropertyEmailAlert]", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("[PropertyEmailAlert] :" + ex.Message);
                return null;
            }
        }

        public static void UpdatePropertyAlert(Guid ID, Int32 Days, string FromDatabase)
        {
            try
            {

                //SqlConnection objconnection = new SqlConnection() { ConnectionString = ConfigurationManager.ConnectionStrings["SeniorLivingFinderEntities"].ConnectionString };
                //objconnection.Open();
                //SqlCommand objCmd = new SqlCommand("UpdatePropertyAlert", objconnection);
                //SqlParameter parameter = new SqlParameter("@PropertyId", SqlDbType.UniqueIdentifier);
                //SqlParameter parameter1 = new SqlParameter("@Days", SqlDbType.Int);
                //parameter.Value = ID;
                //parameter1.Value = Days;
                //objCmd.Parameters.Add(parameter);
                //objCmd.Parameters.Add(parameter1);
                //objCmd.CommandType = CommandType.StoredProcedure;
                //objCmd.ExecuteNonQuery();
                //if (objconnection.State != ConnectionState.Closed)
                //{
                //    objconnection.Close();
                //}
                SqlParameter[] arrParam = new SqlParameter[2];
                arrParam[0] = new SqlParameter("@PropertyId", ID);
                arrParam[1] = new SqlParameter("@Days", Days);

                SqlHelper.ExecuteNonQuery("UpdatePropertyAlert", "", FromDatabase, arrParam);

            }
            catch (Exception ex)
            {
                AddToSVCTable("UpdatePropertyAlert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("UpdatePropertyAlert" + ex.Message);
            }
        }
        public static DataTable GetDbConnections(Int16 ServerId, string FromDatabase)
        {
            try
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@ServerId", ServerId);
                ds = SqlHelper.ExecuteDataset("Sp_GetDBConnections", FromDatabase, arrParam);
                if (ds.Tables.Count > 0)
                    return ds.Tables[0];
                else
                    return null;
            }
            catch (Exception ex)
            {
                AddToSVCTable("GetDbConnections", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("GetDbConnections" + ex.Message);
                return null;
            }
        }

        #endregion

        #region Caregiver Schedule Reminder

        /// <summary>
        /// fetch caregiver schedule reminder
        /// Navjot Singh 16/09/2016
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <returns></returns>
        public static DataTable CaregiverScheduleReminder(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@Entity", "Email");
                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("fetchCaregiverScheduleReminderList", FromDatabase, arrParam);
                return dsTSExpire.Tables[0];

            }
            catch (Exception ex)
            {
                AddToSVCTable("CaregiverScheduleReminder", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("CaregiverScheduleReminder :" + ex.Message);
                return null;
            }
        }
        /// <summary>
        /// CLIENT AUTHORIZATION MAIL
        /// Mandeep Singh 09/11/2018
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <returns></returns>
        public static DataTable ClientAuthorizationReminder(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();
                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetClientAuthorizationEmailData", FromDatabase);
                return dsTSExpire.Tables[0];

            }
            catch (Exception ex)
            {
                AddToSVCTable("ClientAuthorizationReminder", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("ClientAuthorizationReminder :" + ex.Message);
                return null;
            }
        }

        /// <summary>
        /// COMPLAINCE EXPIRATION MAIL
        /// Mandeep Singh 10/18/2018
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <returns></returns>
        public static DataTable CaregiverComplianceReminder(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();
                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetCaregiverComplianceEmailData", FromDatabase);
                return dsTSExpire.Tables[0];

            }
            catch (Exception ex)
            {
                AddToSVCTable("GetCaregiverComplianceEmailData", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("GetCaregiverComplianceEmailData :" + ex.Message);
                return null;
            }
        }

        /// <summary>              
        /// Successful Check-In/Out E-Mail
        /// Dharmender Kumar 10/26/2018
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <returns></returns>
        public static DataTable SuccessfulCheckInOutReminder(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();
                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetSuccessfulCheckInoutEmailData", FromDatabase);
                return dsTSExpire.Tables[0];

            }
            catch (Exception ex)
            {
                AddToSVCTable("GetSuccessfulCheckInoutEmailData", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("GetSuccessfulCheckInoutEmailData :" + ex.Message);
                return null;
            }
        }


        /// <summary>
        /// update schedule for sending email alert to caregiver
        /// Navjot Singh 16/09/2016
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="FromDatabase"></param>
        public static void updateCaregiverScheduleReminderNotification(Guid ID, String FromDatabase)
        {
            try
            {
                SqlConnection objconnection = new SqlConnection() { ConnectionString = FromDatabase };
                objconnection.Open();
                SqlCommand objCmd = new SqlCommand("UpdateCaregiverScheduleReminderAlert", objconnection);
                SqlParameter parameter = new SqlParameter("@ID", SqlDbType.UniqueIdentifier);
                parameter.Value = ID;
                objCmd.Parameters.Add(parameter);
                SqlParameter parameter1 = new SqlParameter("@Entity", SqlDbType.NVarChar);
                parameter1.Value = "Email";
                objCmd.Parameters.Add(parameter1);
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.ExecuteNonQuery();
                if (objconnection.State != ConnectionState.Closed)
                {
                    objconnection.Close();
                }
            }
            catch (Exception ex)
            {
                AddToSVCTable("updateCaregiverScheduleReminderNotification", DateTime.Now, ex.Message, FromDatabase);
            }
        }
        #endregion
        #region SEND REMINDER MAIL OF TASK COMMUNICATION
        /// <summary>
        /// <summary>
        ///SEND TASK REMINDER MAIL MAIL
        /// MANDEEP SINGH 02/01/2019
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <returns></returns>
        public static DataTable SendTaskCommuniationReminderAlert(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();
                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetTaskCommunicationReminderData", FromDatabase);
                return dsTSExpire.Tables[0];

            }
            catch (Exception ex)
            {
                AddToSVCTable("GetTaskCommunicationReminderData", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("GetTaskCommunicationReminderData :" + ex.Message);
                return null;
            }
        }
        #endregion
        #region SEND REMINDER MAIL OF SUBMIT INJURY
        /// <summary>
        /// <summary>
        ///SEND INJURY MAIL
        /// MANDEEP SINGH 04/18/2019
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <returns></returns>
        public static DataTable SendSubmitInjuryAlert(string FromDatabase)
        {
            try
            {
                DataSet dsTSExpire = new DataSet();
                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetCaregiverInjuryEmailData", FromDatabase);
                return dsTSExpire.Tables[0];

            }
            catch (Exception ex)
            {
                AddToSVCTable("GetCaregiverInjuryEmailData", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("GetCaregiverInjuryEmailData :" + ex.Message);
                return null;
            }
        }
        #endregion

        #region Balance Due Reminder

        public static DataTable BalanceDueAlert(string FromDatabase)
        {
            try
            {

                DataSet dsCaregiverAndScheduleInfo = new DataSet();

                dsCaregiverAndScheduleInfo = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetInvDueNotificationSenderEmailData", FromDatabase);
                return dsCaregiverAndScheduleInfo.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("InvoiceDueAlert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("InvoiceDueAlert :" + ex.Message);
                return null;
            }
        }

        #endregion

        #region Care Plan Update Reminder
        public static DataTable CarePlanUpdateAlert(string FromDatabase)
        {
            try
            {

                DataSet dsCarePlanUpdateInfo = new DataSet();

                dsCarePlanUpdateInfo = CareSmartzPaymentService.SqlHelper.ExecuteDataset("GetCarePlanUpdateNotificationSenderEmailData", FromDatabase);
                return dsCarePlanUpdateInfo.Tables[0];
            }
            catch (Exception ex)
            {
                AddToSVCTable("CarePlanUpdateAlert", DateTime.Now, ex.Message, FromDatabase);
                WriteTextLog("CarePlanUpdateAlert :" + ex.Message);
                return null;
            }
        }

        #endregion


        public static void EmailLog(String strEmailTo, String strEmailFrom, String strEntityType, Guid? gdEntityId,
            String strEntityEvent, String strBody, String strSubject, String FromDatabase)
        {
            try
            {

                #region Save EmailsLog
                SqlParameter[] arrParam = new SqlParameter[15];
                arrParam[0] = new SqlParameter("@EmailTo", strEmailTo);
                arrParam[1] = new SqlParameter("@EmailFrom", strEmailFrom);
                arrParam[2] = new SqlParameter("@EntityType", strEntityType);
                arrParam[3] = new SqlParameter("@EntityId", gdEntityId);
                arrParam[4] = new SqlParameter("@EntityEvent", strEntityEvent);
                arrParam[5] = new SqlParameter("@FromUserId", gdEntityId);
                arrParam[6] = new SqlParameter("@CreatedOn", DateTime.UtcNow);
                arrParam[7] = new SqlParameter("@CreatedBy", gdEntityId);
                arrParam[8] = new SqlParameter("@ModifiedOn", DateTime.UtcNow);
                arrParam[9] = new SqlParameter("@ModifiedBy", gdEntityId);
                arrParam[10] = new SqlParameter("@Body", strBody);
                arrParam[11] = new SqlParameter("@Subject", strSubject);
                arrParam[12] = new SqlParameter("@IsActive", true);
                arrParam[13] = new SqlParameter("@IsArchived", false);
                arrParam[14] = new SqlParameter("@Status", "");
                arrParam[14].Direction = ParameterDirection.Output;
                arrParam[14].Value = "";
                SqlHelper.ExecuteNonQuery("SVC_SaveEmailLog", "", FromDatabase, arrParam);
                #endregion

            }
            catch (Exception ex)
            {
                WriteTextLog("EmailLog:" + ex.Message);

            }
        }
        public static DataTable getEmailFrom(Int32 AgencyId)
        {
            try
            {

                DataSet dsTSExpire = new DataSet();
                String FromDatabase = ConfigurationManager.ConnectionStrings["HMCConnectionString"].ConnectionString;
                dsTSExpire = CareSmartzPaymentService.SqlHelper.ExecuteDataset("getEmailFromDetailsByAgencyId", FromDatabase, AgencyId);
                return dsTSExpire.Tables[0];
            }
            catch (Exception ex)
            {
                WriteTextLog("getEmailFrom :" + ex.Message);
                return null;
            }
        }

    }
    public class SecurityClass
    {
        private static string key = "29xdVi33L5W32SL2";

        public static string Encrypt(string toEncrypt)
        {
            byte[] keyArray = UTF8Encoding.UTF8.GetBytes(key);
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(NullPadString(toEncrypt));
            RijndaelManaged rDel = new RijndaelManaged();

            rDel.Key = keyArray;
            rDel.Mode = CipherMode.ECB; // http://msdn.microsoft.com/en-us/library/system.security.cryptography.ciphermode.aspx
            rDel.Padding = PaddingMode.None; // better lang support

            ICryptoTransform cTransform = rDel.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            string base64Data = Convert.ToBase64String(resultArray, 0, resultArray.Length);

            return SpecialCharterEncrypt(base64Data);
        }

        public static string Decrypt(string toDecrypt)
        {
            toDecrypt = SpecialCharterDecrypt(toDecrypt);

            byte[] keyArray = UTF8Encoding.UTF8.GetBytes(key); // AES-256 key
            byte[] toEncryptArray = Convert.FromBase64String(toDecrypt);
            RijndaelManaged rDel = new RijndaelManaged();

            rDel.Key = keyArray;
            rDel.Mode = CipherMode.ECB; // http://msdn.microsoft.com/en-us/library/system.security.cryptography.ciphermode.aspx
            rDel.Padding = PaddingMode.None;  //.PKCS7; // better lang support

            ICryptoTransform cTransform = rDel.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            //return SpecialCharterDecrypt(UTF8Encoding.UTF8.GetString(resultArray));
            return SpecialCharterDecrypt(UTF8Encoding.UTF8.GetString(resultArray));
        }

        static string SpecialCharterDecrypt(string text)
        {
            string strText = text.Replace("%26", "&")
                                    .Replace("%2B", "+")
                                    .Replace("%2C", ",")
                                    .Replace("%2F", "/")
                                    .Replace("%3A", ":")
                                    .Replace("%3B", ";")
                                    .Replace("%3D", "=")
                                    .Replace("%3F", "?")
                                    .Replace("%40", "@")
                                    .Replace("%20", " ")
                                    .Replace("%09", "\t")
                                    .Replace("%23", "#")
                                    .Replace("%3C", "<")
                                    .Replace("%3E", ">")
                                    .Replace("%22", "\"")
                                    .Replace("%0A", "\n")
                                    .Replace("\0", "");
            return strText;
        }

        static string SpecialCharterEncrypt(string text)
        {
            string strText = text.Replace("&", "%26")
                                    .Replace("+", "%2B")
                                    .Replace(",", "%2C")
                                    .Replace("/", "%2F")
                                    .Replace(":", "%3A")
                                    .Replace(";", "%3B")
                                    .Replace("=", "%3D")
                                    .Replace("?", "%3F")
                                    .Replace("@", "%40")
                                    .Replace(" ", "%20")
                                    .Replace("\t", "%09")
                                    .Replace("#", "%23")
                                    .Replace("<", "%3C")
                                    .Replace(">", "%3E")
                                    .Replace("\"", "%22")
                                    .Replace("\n", "%0A");
            return strText;
        }

        static String NullPadString(String original)
        {
            String output = original;
            int remain = output.Length % 16;

            if (remain != 0)
            {
                remain = 16 - remain;
                for (int i = 0; i < remain; i++)
                    output += (char)0;
            }
            return output;
        }
    }
}