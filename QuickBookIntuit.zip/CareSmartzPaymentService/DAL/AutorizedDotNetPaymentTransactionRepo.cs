﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CareSmartzPaymentService.Shared;
using System.Data.SqlClient;
using Dapper;
using System.Data;

namespace CareSmartzPaymentService.DAL
{
    public class AutorizedDotNetPaymentTransactionRepo
    {
        public CreditCardTransactionModelList GetAutorizedDotNetPaymentTransactionList(int cszp_at_top, String FromDatabase, Guid GatewayType, Guid PaymentType)
        {
            CreditCardTransactionModelList response = new CreditCardTransactionModelList();

            try
            {
                
                using (IDbConnection db = new SqlConnection(FromDatabase))
                {
                    response.success = true;
                    response.message = "success";
                    //response.responseData = db.Query<CreditCardTransactionModel>("Select top " + cszp_at_top + " * From CreditCardTransaction", commandTimeout: 0, buffered: true)
                    //  .ToList();
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@GatewayType", GatewayType);
                    param.Add("@PaymentType", PaymentType);

                    response.responseData = db.Query<CreditCardTransactionModel>("SP_GetUpdatedTransactions", param, commandType: CommandType.StoredProcedure, commandTimeout: 0, buffered: true)
                        .ToList();

                    db.Close();
                }
                return response;

            }
            catch (Exception ex)
            {
                response.success = false;
                response.message = ex.Message;
                return response;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="CreditCardTransactionId"></param>
        /// <param name="TransactionId"></param>
        /// <param name="TransactionType"></param>
        /// <param name="TransactionStatus"></param>
        /// <param name="AuthAmount"></param>
        /// <param name="SettleAmount"></param>
        /// <param name="ResultCode"></param>
        /// <param name="MessageCode"></param>
        /// <param name="MessageText" is used for FranchiseID></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public Guid SaveAuthorizedDotNetTransactionTrackHistory(Guid CreditCardTransactionId, string TransactionId, Guid InvoiceId, string TransactionType, string TransactionStatus, string TransactionStatusType,
            decimal AuthAmount, decimal SettleAmount, string ResultCode, string MessageCode, string MessageText, string UserID, String FromDatabase)
        {
            Guid RetVal = Guid.Empty;
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@CreditCardTransactionId", CreditCardTransactionId);
                    parameters.Add("@TransactionId", TransactionId);
                    parameters.Add("@InvoiceId", InvoiceId); 
                    parameters.Add("@TransactionType", TransactionType);
                    parameters.Add("@TransactionStatus", TransactionStatus);
                    parameters.Add("@TransactionStatusType", TransactionStatusType); 
                    parameters.Add("@AuthAmount", AuthAmount);
                    parameters.Add("@SettleAmount", SettleAmount);
                    parameters.Add("@ResultCode", ResultCode);
                    parameters.Add("@MessageCode", MessageCode);
                    parameters.Add("@MessageText", MessageText);
                    parameters.Add("@UserID", UserID);
                    parameters.Add("@IdRet", dbType: DbType.Guid, direction: ParameterDirection.Output);
                    dbConnection.Query<Guid>("PrAuthorizedDotNet_SaveTransactionTrackHistory", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                    RetVal = parameters.Get<Guid>("@IdRet");

                    return RetVal;
                }
            }
            catch (Exception ex)
            {
                return Guid.Empty;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="CreditCardTransactionId"></param>
        /// <param name="TransactionId"></param>
        /// <param name="TransactionType"></param>
        /// <param name="TransactionStatus"></param>
        /// <param name="AuthAmount"></param>
        /// <param name="SettleAmount"></param>
        /// <param name="ResultCode"></param>
        /// <param name="MessageCode"></param>
        /// <param name="MessageText" is used for FranchiseID></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public int SaveAuthorizedDotNetErrorLog_Payment(string PageName, string MethodEvent, string MessageInfo,
            string ProcesStatus, String FromDatabase)
        {
            Guid RetVal = Guid.Empty;
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@PageName", PageName);
                    parameters.Add("@MethodEvent", MethodEvent);
                    parameters.Add("@MessageInfo", MessageInfo);
                    parameters.Add("@ProcesStatus", ProcesStatus);
                    parameters.Add("@InvoiceID", null);
                    parameters.Add("@UserID", null);
                    dbConnection.Query<Guid>("PrRecordErrorLog_Payment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                    return 1;
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public OfficePaymentGateWayKey GetPaymentGateWayApiKey(String FromDatabase)
        {
            OfficePaymentGateWayKey returnValue = new OfficePaymentGateWayKey();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    returnValue = dbConnection.Query<OfficePaymentGateWayKey>("USP_GetOfficePaymentGateWayKeys", commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception ex) { throw; }
            return returnValue;
        }

        public System.Data.DataSet SendPaymentReceived(Guid? CLientID, Guid? InvoiceHeaderId, decimal ReceivedAmount, string FromDatabase)
        {
            System.Data.DataSet dt = new System.Data.DataSet();
            try
            {
                System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(FromDatabase);

                SqlParameter[] param = new SqlParameter[5];

                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("FetchPaymentReceiveInvoiceData");
                param[0] = cmd.Parameters.Add("@Entity", SqlDbType.NVarChar);
                param[0].Value = "SMS";

                param[1] = cmd.Parameters.Add("@CLientID", SqlDbType.UniqueIdentifier);
                param[1].Value = CLientID;

                param[2] = cmd.Parameters.Add("@InvoiceHeaderId", SqlDbType.UniqueIdentifier);
                param[2].Value = InvoiceHeaderId;
                param[3] = cmd.Parameters.Add("@ReceivedAmount", SqlDbType.NVarChar);
                param[3].Value = ReceivedAmount;

                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 1200;
                System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter(cmd);

                try
                {
                    conn.Open();
                    da.AcceptChangesDuringFill = true;
                    da.Fill(dt, "FetchPaymentReceiveInvoiceData");


                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    conn.Close();
                    cmd.Dispose();
                    da.Dispose();
                }



                return dt;
            }
            catch (Exception ex)
            {
                return dt;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CreditCardId"></param>
        /// <returns></returns>
        public int UpdateCreditCardSendToSMSStatus(Guid CreditCardId, String FromDatabase)
        {
            Int32 _Result = 0;
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@CreditCardId", CreditCardId);
                    parameters.Add("@Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
                    dbConnection.Query<Guid>("USP_UpdateCreditCardSendToSMS", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                    _Result = parameters.Get<Int32>("@Result");

                    return _Result;

                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }


    }
}
