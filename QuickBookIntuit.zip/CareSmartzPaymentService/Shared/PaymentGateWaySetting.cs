﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartzPaymentService.Shared
{
    public class PaymentGateWaySetting
    {
        public Guid FranchiseId { get; set; }

        public Guid GatewayType { get; set; }

        public string APIId { get; set; }

        public string TransactionKey { get; set; }
    }
}
