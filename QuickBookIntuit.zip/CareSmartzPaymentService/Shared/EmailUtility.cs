﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Net;
using System.Net.Mail;

namespace CareSmartzPaymentService.Shared
{
    public static class EmailUtility
    {
        private static readonly log4net.ILog logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public static string SMTPServer = Convert.ToString(WebConfigurationManager.AppSettings.Get("SMTPServer"));
        public static int SMTPPort = Convert.ToInt32(WebConfigurationManager.AppSettings.Get("SMTPPort"));
        public static int SMTPTimeout = Convert.ToInt32(WebConfigurationManager.AppSettings.Get("SMTPTimeout"));
        public static string FromEmail = Convert.ToString(WebConfigurationManager.AppSettings.Get("FromEmail"));
        public static string EmailDisplayName = Convert.ToString(WebConfigurationManager.AppSettings.Get("EmailDisplayName"));
        public static string FromPassword = Convert.ToString(WebConfigurationManager.AppSettings.Get("FromPassword"));
        public static int EmailRetryAttempt = Convert.ToInt32(WebConfigurationManager.AppSettings.Get("EmailRetryAttempt"));
        public static string EmailServer_Url = Convert.ToString(WebConfigurationManager.AppSettings.Get("EmailServer_Url"));

        public static string EmailAutorizedDotNetPaymentTransactionSystem()
        {
            string result = string.Empty;

            try
            {

                using (SmtpClient client = new SmtpClient(SMTPServer))
                {
                    System.Net.Mail.AlternateView htmlView = null;
                    client.Credentials = new NetworkCredential(FromEmail, FromPassword);
                    client.Port = SMTPPort;
                    client.EnableSsl = true;
                    client.Timeout = SMTPTimeout;
                    using (MailMessage mail = new MailMessage())
                    {
                        mail.To.Add("harish.madaan@netsmartz.net");
                        string[] SAPSupportEmail = WebConfigurationManager.AppSettings.Get("SAPSupportEmail").Split(',');
                        for (int val = 0; val < SAPSupportEmail.Length; val++)
                        {
                            mail.CC.Add(SAPSupportEmail[val]);
                        }

                        mail.From = new MailAddress(FromEmail, "CareSmartz Payment Transaction");
                        string BodyText = "Hi Team,<br><br> We are getting Error in <b>" + Convert.ToString(EmailServer_Url) + "</b> in the interface <b>AutorizedDotNetPaymentTransaction System</b>, Please verify <br><br>Thanks & Regards<br><br>CareSmartz Management";
                        htmlView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(BodyText, null, "text/html");
                        mail.Subject = "CareSmartz Payment Transaction Issue in " + Convert.ToString(EmailServer_Url);
                        //mail.Body = Body;
                        mail.AlternateViews.Add(htmlView);
                        mail.IsBodyHtml = true;

                        client.Send(mail);
                        result = "success";
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("Error in EmailUtility.EmailAutorizedDotNetPaymentTransactionSystem", ex);
                result = ex.Message;
            }

            return result;
        }

    }
}
