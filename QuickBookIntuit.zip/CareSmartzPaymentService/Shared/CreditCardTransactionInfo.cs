﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartzPaymentService.Shared
{
    public class CreditCardTransactionModel
    {
        public Guid Id { get; set; }
        
        public string TransactionId { get; set; }
        public Guid CreditCardId { get; set; }
        public decimal? Amount { get; set; }

        public string ClientPaymentRegisterId { get; set; }
        public string ClientId { get; set; }
        public string InvoiceId { get; set; }
        public DateTime CreatedOn { get; set; }

        public string CreatedBy { get; set; }
        
        public DateTime ModifiedOn { get; set; }
        public string ModifiedBy { get; set; }
        public Guid PaymentType { get; set; }
        public Guid GatewayType { get; set; }
        public Int32 SendToSMS { get; set; }


    }

    public class CreditCardTransactionModelList : IDisposable
    {
        public bool success { get; set; }
        public string message { get; set; }
        public List<CreditCardTransactionModel> responseData { get; set; }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }

}
