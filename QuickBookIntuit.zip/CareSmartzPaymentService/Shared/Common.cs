﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace CareSmartzPaymentService.Shared
{
    public static class Common
    {
        private static readonly log4net.ILog logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

    }

    public static class ResponseMessage
    {
        public static string NetworkIssue = "Please check your network and try again after some time.";
        public static string InvalidInput = "Invalid input data.";
        public static string InvalidUser = "Invalid user.";
        public static string ErrorOccured = "Error occured.";
        public static string InvalidCredentials = "Invalid Username or Password.";
        public static string NoData = "No data available at this moment.";
        public static string InvalidMobileorOTP = "Invalid Mobile Number or Invalid OTP or OTP Expired";
        public static string InvalidPreEnquiry = "Invalid Pre Enquiry.";
        public static string InvalidChasisNo = "Please enter valid Chassis Number.";
        public static string InvalidCustomer = "This chasis number is not billed to this customer.";
        public static string InvalidSparePart = "Part No. not available in your stock.";
        public static string Unauthorized = "You are not authorized to do this operation.";
    }

    public static class SQLViewName
    {

        public static string EnquirySaleConvertionRatioFinal_View = "vw_rpt_GetEnquirySaleConvertionRatioFinal";
        public static string EnquirySaleLoyaltyHitRatioFinal_View = "vw_rpt_GetEnquirySaleLoyaltyHitRatioFinal";
        public static string DealerCustomerTractorSaleFinal_View = "vw_rpt_DealerCustomerTractorSaleFinal";
        public static string Average_Jobcard_Closing_Time_View = "vw_rpt_Average_Jobcard_Closing_Time";
        public static string JobCardComplaintRatioService_View = "vw_rpt_JobCardComplaintRatioService";
        public static string DealerStockTractor_View = "vw_rpt_DealerStockTractor";
        public static string DealerMasterDetail_View = "vw_rpt_DealerMasterDetail";
        public static string HOPDIReportDetail_View = "vw_rpt_HO_PDIReport";

    }

    public static class SQLProcedureName
    {

        public static string Update_EnquirySaleConvertionRatioFinal = "usp_sap_upd_EnquirySaleConvertionRatioFinal";
        public static string Update_EnquirySaleLoyaltyHitRatioFinal = "usp_sap_upd_EnquirySaleLoyaltyHitRatioFinal";
        public static string Update_DealerCustomerTractorSaleFinal = "usp_sap_upd_DealerCustomerTractorSaleFinal";
        public static string Update_AverageJobcardClosingTime = "usp_sap_upd_AverageJobcardClosingTime";
        public static string Update_JobCardComplaintRatioService = "usp_sap_upd_JobCardComplaintRatioService";
        public static string Update_DealerStockTractor = "usp_sap_upd_DealerStockTractor";
        public static string Update_DealerMasterDetail = "usp_sap_upd_DealerMasterDetail";
        public static string Update_HOPDIReport = "usp_sap_upd_HOPDIReport";

    }

    public static class Account_Receivables_Payment_Type
    {
        public const string Check = "707A7387-31A0-E211-8BDF-00155D0A1911";
        public const string Cash = "BCF0C68F-31A0-E211-8BDF-00155D0A1911";
        public const string Credit_Card_Offline = "AC96D53F-32A0-E211-8BDF-00155D0A1911";
        public const string Credit_Card_Processing = "7A90CB30-17C6-48D2-8341-4B6A9864A6B2";
        public const string Bank_Account = "A8F32951-9D9B-4095-8205-9B80A7E7333A";
        public const string Credit_Card = "CCD66B58-32A0-E211-8BDF-00155D0A1911";
        public const string Heartland_Payment = "142F0202-5CF6-43CC-BB7F-93BF1E34092C";
    }

    public static class Gateway_Type
    {
        public const String Authorizenet = "E0E69F11-FB5B-4BF2-B773-5558FB3D4A7D";
        public const String HPSHeartlandPaymentSystem = "142F0202-5CF6-43CC-BB7F-93BF1E34092C";
        public const String TransnationalGateway = "6F7FAA49-9832-44A9-955D-211991BDB6F3";
    }

    public static class InvoiceStatus
    {
        public const String Transfered = "10B1219D-897A-4B0B-9631-11C5338BFA6D";
        public const String PartiallyPaid = "F69792B3-DDAE-4F38-8726-210133469852";
        public const String NotPaid = "CD417660-4F72-4AB7-9F2F-42432C67A990";
        public const String Adjusted = "EB0693DA-96B0-45E1-84B8-BF9EF72D533B";
        public const String OverPaid = "1932ECFF-D0F4-42AD-B850-CFC10321B101";
        public const String FullyPaid = "C9A0304F-CC5C-4D79-9062-ECFE904C6B3A";

        public const String Voided = "C4870627-C5DD-46E5-84D8-0BFF69A83F62";
        public const String ApprovedReview = "B289E0DA-8CD7-44BD-8D42-078620AADC71";
        public const String HeldforReview = "88707164-75F4-4929-B88F-18EE6C6F2F6C";
        public const String RefundPendingSettlement = "3B672FA5-6AF0-4C0F-90D6-22CB1D18DE7A";
        public const String FDSPendingReview = "CA120B39-A2C6-4F0E-B7AE-3882D90429AD";
        public const String Declined = "BEA4C249-26E4-4116-A260-45D640338B1A";
        public const String CapturedPendingSettlement = "63116AEE-6F79-4D60-A17A-4996F7B93770";
        public const String Refund = "516A68BC-4ED9-4FDB-B16A-84FDC788B670";
        public const String UnderReview = "722924CB-D2EA-4E17-8405-D6E2FE3C87F6";
        public const String SettledSuccessfully = "A0FC49CF-0DDB-425B-967C-DD761D804693";
        public const string WaitingConfirmation = "27CC11EB-B3EF-491C-95E7-3DB8992D8364";
        public const string UnKnown = "6493423C-962A-425F-B13C-436E643F07A1";
        public const String Error = "B77FBC49-164C-4FBE-9C89-47F6BB26AB9D";
        public const String OrderNotComplete = "36E94396-8E77-4325-96CC-8B0A0CC5D8D2";
        public const String Expired = "D764963D-BCDA-402D-8401-CC4D55D0648B";
        //public const String CapturedPendingSettlement = "63116AEE-6F79-4D60-A17A-4996F7B93770";


    }

}
