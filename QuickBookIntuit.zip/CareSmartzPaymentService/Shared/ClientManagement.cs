﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

using System.Text;

using System.Web;
using System.Threading.Tasks;
using System.Threading;

using System.Configuration;
using System.Data.SqlClient;
using System.Data;

using Dapper;



// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ClientManagement" in code, svc and config file together.
namespace CareSmartzPaymentService.Shared
{
    public class ClientManagementClient : System.IDisposable
    {

        

    }


    }
}
