﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Threading;
using CareSmartzPaymentService.Shared;
using AuthorizeNet.Api.Contracts.V1;
using AuthorizeNet.Api.Controllers;
using AuthorizeNet.Api.Controllers.Bases;
using CareSmartzPaymentService.DAL;
using RestSharp;
using System.Data.SqlClient;
using Dapper;
using Newtonsoft.Json;


[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace CareSmartzPaymentService
{
    public partial class Service1 : ServiceBase
    {
        #region "Property"

        private static readonly log4net.ILog logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        System.Timers.Timer timer = new System.Timers.Timer();
        DataTable DT = new DataTable();
        static bool isRunning = false;
        Guid campaignID = new Guid();
        int totCount = 0;
        string strBody = string.Empty;
        string strSubject = string.Empty;
        string url = string.Empty;
        Dictionary<string, string> Dict = new Dictionary<string, string>();
        Dictionary<string, string> DictCreate = new Dictionary<string, string>();
        public string ConnectionString { get { return ConfigurationManager.AppSettings["CommonConnectionString"].ToString(); } }
        public String HCMConnectionString { get { return ConfigurationManager.ConnectionStrings["HMCConnectionString"].ToString(); } }

        string _datetime = string.Empty;
                
        AutorizedDotNetPaymentTransactionRepo objModel = new AutorizedDotNetPaymentTransactionRepo();

        private static int TransactionErrorCount = 0;

        // App mode to Gateway local/server settings
        private string app_mode = Convert.ToString(ConfigurationManager.AppSettings["APP_Mode"]).ToUpper();

        // CSZP to Gateway push enable/disable settings
        private string cszp_at_push = Convert.ToString(ConfigurationManager.AppSettings["cszp_at_Push"]);

        // Authorized.net Transaction Schedule Settings
        private Timer cszp_at_timer;
        private string cszp_at_mode = Convert.ToString(ConfigurationManager.AppSettings["CSZP_AT_Mode"]).ToUpper();
        private int cszp_at_interval = Convert.ToInt32(ConfigurationManager.AppSettings["CSZP_AT_Interval"]);
        private int cszp_at_hour = Convert.ToInt32(ConfigurationManager.AppSettings["CSZP_AT_Hour"]);
        private string cszp_at_time = Convert.ToString(ConfigurationManager.AppSettings["CSZP_AT_Time"]);
        private string cszp_at_end_time = Convert.ToString(ConfigurationManager.AppSettings["CSZP_AT_End_Time"]);
        private int cszp_at_top = Convert.ToInt32(ConfigurationManager.AppSettings["CSZP_AT_Top"]);
        private int cszp_at_mail_error = Convert.ToInt32(ConfigurationManager.AppSettings["CSZP_AT_Mail_Error"]);

        // Authorized Dot Net Details
        private string ApiLoginID = Convert.ToString(ConfigurationManager.AppSettings["ApiLoginID"]);
        private string ApiTransactionKey = Convert.ToString(ConfigurationManager.AppSettings["ApiTransactionKey"]);
        private string TransNationalApiLoginID = Convert.ToString(ConfigurationManager.AppSettings["TransNationalApiLoginID"]);

        #endregion

        #region Translation

        public static string TNPBaseURL = Convert.ToString(ConfigurationManager.AppSettings["TransNationUrl"]);/*"https://sandbox.gotnpgateway.com/api/transaction/##TransactionID##";*/

        #endregion

        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {

                if (cszp_at_push == "1")
                {
                    // Code to push data for the Enquiry Sale Convertion Ratio
                    AutorizedDotNetPaymentTransactionSchedule();
                }

                // Code to get data from the AutorizedDotNetPaymentTransaction System
                //AutorizedDotNetPaymentTransactionSystem();
                //PaymentCallMethod();
                
            }
            catch (Exception ex)
            {
                logger.Error(string.Format("Service Start Error : {0}", ex.Message), ex);
                //Stop the Windows Service.
                //StopService();
            }
        }

        public void OnDebug()
        {
            OnStart(null);
        }

        protected override void OnStop()
        {
            logger.Info("Stop CareSmartzPaymentService Service ...................");
        }

        public void AutorizedDotNetPaymentTransactionSchedule()
        {
            try
            {
                cszp_at_timer = new Timer(new TimerCallback(AutorizedDotNetPaymentTransactionScheduleCallback));
                logger.Info(string.Format("AutorizedDotNetPaymentTransaction schedule Mode: {0}", cszp_at_mode));
                //Set the Default Time.
                DateTime scheduledTime = DateTime.MinValue;
                DateTime scheduledEndTime = DateTime.MinValue;
                int hr = DateTime.Now.Hour;
                string timeNow = DateTime.Now.ToString("HHtt");
                if (timeNow == "08AM" || timeNow == "04PM")
                {
                    // Call your method to perform 
                }

                if (cszp_at_mode == "I")//if schedule is for minutes interval
                {                    
                    scheduledTime = DateTime.Now.AddMinutes(cszp_at_interval);

                    if (DateTime.Now > scheduledTime)
                    {
                        scheduledTime = DateTime.Now.AddMinutes(cszp_at_interval);
                    }
                }
                else if (cszp_at_mode == "T")//if schedule is for between specific time every day
                {
                    scheduledTime = DateTime.Parse(cszp_at_time);
                    scheduledEndTime = DateTime.Parse(cszp_at_end_time);

                    if (DateTime.Now > scheduledTime)
                    {
                        //If Scheduled Time is passed set Schedule for the next hours.
                        scheduledTime = DateTime.Now.AddHours(cszp_at_hour);
                    }
                    else if (DateTime.Now.Hour < scheduledEndTime.Hour)
                    {
                        //If Scheduled Time is passed set Schedule for the next hours.
                        scheduledTime = DateTime.Now.AddHours(cszp_at_hour);
                    }
                    if (DateTime.Now.Hour == scheduledEndTime.Hour)
                    {
                        //If Scheduled Time is passed set Schedule for the next 12 hours.
                        scheduledTime = DateTime.Now.AddHours(12);
                    }
                }
                else if (cszp_at_mode == "D")//if schedule is for a specific time on every day
                {
                    scheduledTime = DateTime.Parse(cszp_at_time);
                    if (DateTime.Now > scheduledTime)
                    {
                        //If Scheduled Time is passed set Schedule for the next day.
                        scheduledTime = scheduledTime.AddDays(1);
                    }
                }

                TimeSpan timeSpan = scheduledTime.Subtract(DateTime.Now);
                string schedule = string.Format("{0} day(s) {1} hour(s) {2} minute(s) {3} seconds(s)", timeSpan.Days, timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);
                logger.Info(string.Format("AutorizedDotNetPaymentTransaction scheduled to run after: {0}", schedule));

                //Get the difference in Minutes between the Scheduled and Current Time.
                int dueTime = Convert.ToInt32(timeSpan.TotalMilliseconds);

                //Change the Timer's Due Time.
                cszp_at_timer.Change(dueTime, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                logger.Error(string.Format("AutorizedDotNetPaymentTransaction schedule Error : {0}", ex.Message), ex);
                //Stop the Windows Service.
                //StopService();
            }
        }

        private void AutorizedDotNetPaymentTransactionScheduleCallback(object e)
        {

            // call the payment method
            PaymentCallMethod();
            
            if (TransactionErrorCount == cszp_at_mail_error)
            {
                string message = string.Empty;
                message = "success";// EmailUtility.SentEnquirySaleConvertionRatioEmail();
                if (message == "success")
                {
                    logger.Info("AutorizedDotNetPaymentTransaction schedule email sent successfully! ...............");
                }
            }
            this.AutorizedDotNetPaymentTransactionSchedule();

        }

        public CreditCardTransactionModelList AutorizedDotNetPaymentTransactionSystem(String FromDatabase, String DomainURL, String DBName, Int32 AgencyId)
        {
            logger.Info("AutorizedDotNetPaymentTransactionSystem function starts: ");

            CreditCardTransactionModelList response = new CreditCardTransactionModelList();
            bool error = false;
            string message = string.Empty;
            //string encrypted_request = xml_request;//PGPEncryption.SignAndEncrypt(xml_request, ref error, ref message, true);
            ANetApiResponse authorized_response = new ANetApiResponse();
            string xml_response = string.Empty;

            try
            {
                Guid AuthorizeGatewayType = new Guid(Gateway_Type.Authorizenet);
                Guid TransnationalGatewayType = new Guid(Gateway_Type.TransnationalGateway);
                Guid PaymentType = new Guid(Account_Receivables_Payment_Type.Bank_Account);
                
                logger.Info("call to function SP_GetUpdatedTransactions to get the latest credit card transactions: ");
                // code to get data from the EnquirySaleConvertionRatioFinal view
                response = objModel.GetAutorizedDotNetPaymentTransactionList(cszp_at_top, FromDatabase, AuthorizeGatewayType, PaymentType);

                /// Logs
                objModel.SaveAuthorizedDotNetErrorLog_Payment("CareSmart Payment Window Service", "AutorizedDotNetPaymentTransactionSystem", "call to function SP_GetUpdatedTransactions to get the latest credit card transactions", "Transaction Status", FromDatabase);

                if (response.success == true)
                {
                    List<CreditCardTransactionModel> EnquiryList = new List<CreditCardTransactionModel>();

                    if (response.responseData != null && response.responseData.Any())
                    {
                        foreach (var result in response.responseData)
                        {
                            if (result.TransactionId != null)
                            {
                                string transactionId = Convert.ToString(result.TransactionId);
                                Guid InvoiceId = new Guid(result.InvoiceId);
                                Guid ClientId = new Guid(result.ClientId);
                                Int32 SendToSMS = Convert.ToInt32(result.SendToSMS);
                                
                                if (result.GatewayType.ToString().ToUpper() == Gateway_Type.Authorizenet.ToString().ToUpper())
                                {
                                    logger.Info("call to authorized dot net function to get the latest status of transactions: ");

                                    OfficePaymentGateWayKey resultKey = new OfficePaymentGateWayKey();
                                    
                                    resultKey = objModel.GetPaymentGateWayApiKey(FromDatabase);

                                    if (resultKey != null)
                                    {
                                        if (resultKey.APIId != null || resultKey.APIId != "0" || resultKey.APIId != "")
                                        {
                                            if (resultKey.GatewayType.ToString().ToUpper() == Gateway_Type.Authorizenet.ToString().ToUpper())
                                            {
                                                // push the encrypted request to the SAP spare order in bound URL configured in config file
                                                authorized_response = GetAuthorizedNetTransactionStatus(resultKey.APIId, resultKey.TransactionKey, transactionId, InvoiceId, ClientId, AgencyId, SendToSMS, result.Id, app_mode, FromDatabase); //Common.CallWebService(SAP_GetEnquirySaleConvertionRatio_Url, encrypted_request, require_credentials: true, username: Common.SAP_UserName, password: Common.SAP_Password);
                                            }
                                        }
                                    }

                                    if (authorized_response != null)
                                    {
                                        //logger.Info(string.Format("AutorizedDotNetPaymentTransactionSystem Authorizeddotnet WebService Response: {0}, {1}", authorized_response.messages.message[0].code, authorized_response.messages.message[0].text));
                                    }
                                }
                                else if (result.GatewayType.ToString().ToUpper() == Gateway_Type.TransnationalGateway.ToString().ToUpper())
                                {
                                    OfficePaymentGateWayKey resultKey = new OfficePaymentGateWayKey();

                                    resultKey = objModel.GetPaymentGateWayApiKey(FromDatabase);

                                    if (resultKey != null)
                                    {
                                        if (resultKey.APIId != null || resultKey.APIId != "0" || resultKey.APIId != "")
                                        {
                                            if (resultKey.GatewayType.ToString().ToUpper() == Gateway_Type.TransnationalGateway.ToString().ToUpper())
                                            {
                                                string Err = "";
                                                GetTransNationalTransactionStatus(resultKey.APIId, resultKey.TransactionKey, transactionId, InvoiceId, ClientId, AgencyId, SendToSMS, result.Id, FromDatabase);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {

                    }
                }

                logger.Info("AutorizedDotNetPaymentTransactionSystem function end: ");

                return response;

            }
            catch (Exception ex)
            {
                TransactionErrorCount++;

                logger.Error(string.Format("EnquirySaleConvertionRatioFinal Error : {0}", ex.Message), ex);

                response.success = false;
                response.message = ex.Message;
                return response;
            }
        }

        public static ANetApiResponse GetAuthorizedNetTransactionStatus(string ApiLoginID, string ApiTransactionKey, string transactionId, Guid InvoiceId, Guid ClientId, Int32 AgencyId, Int32 SendToSMS, Guid CreditCardId, string app_mode, string FromDatabase)
        {
            try
            {
                logger.Info(string.Format("Run function start to get detail of transactions id: {0}", transactionId));
                AutorizedDotNetPaymentTransactionRepo objModel = new AutorizedDotNetPaymentTransactionRepo();

                /// Logs
                //objModel.SaveAuthorizedDotNetErrorLog_Payment("CareSmart Payment Window Service", "AuthorisezDotNet Run Start", "function is used to get the updated status of transaction id: " + transactionId, "Transaction Status");
                if (app_mode == "0")
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else if (app_mode == "1")
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }
                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = ApiLoginID,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = ApiTransactionKey,
                };

                var request = new getTransactionDetailsRequest();
                request.transId = transactionId;

                // instantiate the controller that will call the service
                var controller = new getTransactionDetailsController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                var response = controller.GetApiResponse();

                if (response != null && response.messages.resultCode == messageTypeEnum.Ok)
                {
                    if (response.transaction == null)
                        return response;

                    string TransactionStatusType = ReturnInvoiceStatus(response.transaction.transactionStatus);
                    
                    logger.Info(string.Format("Start call to function/procedure GetAuthorizedNetTransactionStatus to update the status of transaction id: {0}", transactionId));

                    Guid newId = Guid.Empty;
                    newId = objModel.SaveAuthorizedDotNetTransactionTrackHistory(
                      CreditCardId
                    , transactionId
                    , InvoiceId
                    , response.transaction.transactionType
                    , response.transaction.transactionStatus
                    , TransactionStatusType
                    , response.transaction.authAmount
                    , response.transaction.settleAmount
                    , response.messages.resultCode.ToString()
                    , response.messages.message[0].code
                    , response.messages.message[0].text
                    , "1", FromDatabase);

                    logger.Info(string.Format("End call to function/procedure GetAuthorizedNetTransactionStatus to update the status of transaction id: {0}", transactionId));

                    /// Logs
                    objModel.SaveAuthorizedDotNetErrorLog_Payment("CareSmart Payment Window Service", "AuthorisezDotNet Run Start", "function is used to get the updated status of transaction id: " + transactionId, "Transaction Status", FromDatabase);

                    if (TransactionStatusType == InvoiceStatus.SettledSuccessfully && SendToSMS == 0)
                    {
                        logger.Info(string.Format("Send SMS for transaction Id: {0}", transactionId));

                        SendPaymentSMS(ClientId, InvoiceId, Convert.ToDecimal(response.transaction.settleAmount), AgencyId, FromDatabase);

                        Int32 _Result = objModel.UpdateCreditCardSendToSMSStatus(CreditCardId, FromDatabase);

                        /// Logs
                        objModel.SaveAuthorizedDotNetErrorLog_Payment("CareSmart Payment Window Service Send SMS", "AuthorisezDotNet Send SMS", "function is used to Send SMS: ", "Done", FromDatabase);
                        
                    }
                }
                else if (response != null)
                {
                    logger.Info(string.Format("Transaction Error Code and status: {0}, {1}", response.messages.message[0].code, response.messages.message[0].text));

                    /// Logs
                    objModel.SaveAuthorizedDotNetErrorLog_Payment("CareSmart Payment Window Service Error", "AuthorisezDotNet Run function error", "function is used to get the updated status of transaction id: " + transactionId, "Transaction Status Error", FromDatabase);
                }

                return response;
            }
            catch (Exception ex)
            {
                TransactionErrorCount++;

                logger.Error(string.Format("AuthorisezDotNet Run function error : {0}", ex.Message), ex);
                return null;
            }
        }

        public void PaymentCallMethod()
        {
            try
            {
                if (isRunning == false)
                {
                    logger.Info("Start CallMethod: " + isRunning);

                    isRunning = true;
                    
                    DataTable dt = BLL.GetDbConnections(Convert.ToInt16(readConfig("ServerId")), HCMConnectionString);
                    logger.Info("Start CallMethod dt.Rows: " + dt.Rows.Count.ToString());
                    foreach (DataRow item in dt.Rows)
                    {
                        String FromDatabase = ConnectionString.Replace("$Databasename$", Convert.ToString(item["DBName"]))
                            .Replace("$DataSource$", SecurityClass.Decrypt(Convert.ToString(item["DataSource"]))).Replace("$UserName$", SecurityClass.Decrypt(Convert.ToString(item["Username"]))).Replace("$Password$", SecurityClass.Decrypt(Convert.ToString(item["Password"])));
                        String DomainURL = Convert.ToString(item["DomainURL"]);
                        String DBName = Convert.ToString(item["DBName"]);
                        Int32 AgencyId = Convert.ToInt32(item["AgencyId"]);
                        
                        //if (DBName == "CS360_Localbranchmerge")
                        //if (DBName == "india_caresmart360")                        
                        //{
                            AutorizedDotNetPaymentTransactionSystem(FromDatabase, DomainURL, DBName, AgencyId);
                        //}
                        
                    }
                    //Task.WaitAll(tasks.ToArray(),-1);
                }
                isRunning = false;

            }
            catch (Exception ex)
            {                
                logger.Info(string.Format("Error in CallMethod method: {0}" + ex.Message+" INTERNAL"+ex.InnerException +"  TRACE"+ ex.StackTrace));
                isRunning = false;
                timer.Start();
            }

        }

        public string GetTransNationalTransactionStatus(string TransNationalApiLoginID, string ApiTransactionKey, string transactionId, Guid InvoiceId, Guid ClientId, Int32 AgencyId, Int32 SendToSMS, Guid CreditCardId, string FromDatabase)
        {
            try
            {
                //string api_key= GetApiKey(franchise_id, agency_id);
                var url = string.Concat(TNPBaseURL).Replace("##TransactionID##", transactionId);

                var client = new RestClient(url);
                var request = new RestRequest(Method.GET);
                request.AddHeader("content-type", "application/json");
                request.AddHeader("authorization", TransNationalApiLoginID);
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                IRestResponse response = client.Execute(request);
                string content = response.Content;
                
                if (!string.IsNullOrEmpty(content))
                {
                    RootObject jsonResponse = JsonConvert.DeserializeObject<RootObject>(content);

                    string st = jsonResponse.data.status;

                    string TransactionStatusType = ReturnInvoiceStatus(st);

                    logger.Info(string.Format("Start call to function/procedure GetTransNationalTransactionStatus to update the status of transaction id: {0}", transactionId));

                    Guid newId = Guid.Empty;
                    newId = objModel.SaveAuthorizedDotNetTransactionTrackHistory(
                      CreditCardId
                    , transactionId
                    , InvoiceId
                    , jsonResponse.data.payment_type
                    , jsonResponse.data.status
                    , TransactionStatusType
                    , jsonResponse.data.amount
                    , jsonResponse.data.amount_settled
                    , jsonResponse.data.response_code.ToString()
                    , jsonResponse.data.response_code.ToString()
                    , jsonResponse.data.response
                    , "1", FromDatabase);

                    logger.Info(string.Format("End call to function/procedure GetTransNationalTransactionStatus to update the status of transaction id: {0}", transactionId));

                    /// Logs
                    objModel.SaveAuthorizedDotNetErrorLog_Payment("CareSmart Payment Window Service", "TransNational Run Start", "function is used to get the updated status of transaction id: " + transactionId, "Transaction Status", FromDatabase);

                    if (TransactionStatusType == InvoiceStatus.SettledSuccessfully && SendToSMS == 0)
                    {
                        logger.Info(string.Format("Transnation Send SMS for transaction Id: {0}", transactionId));

                        decimal Amount = Convert.ToDecimal(jsonResponse.data.amount_settled)/100;

                        SendPaymentSMS(ClientId, InvoiceId, Amount, AgencyId, FromDatabase);

                        Int32 _Result = objModel.UpdateCreditCardSendToSMSStatus(CreditCardId, FromDatabase);

                        /// Logs
                        objModel.SaveAuthorizedDotNetErrorLog_Payment("Transnation CareSmart Payment Window Service Send SMS", "TransNational Send SMS", "function is used to Send SMS: ", "Done", FromDatabase);

                    }
                    return content;
                }
                else
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        //public string GetApiKey(string strFranchiseId,int agency_id)
        //{
            
        //    try
        //    {
        //        using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
        //        {
        //            dbConnection.Open();
        //            DynamicParameters parameters = new DynamicParameters();
        //            parameters.Add("@FranchiseId", new Guid(strFranchiseId));
        //            returnValue = dbConnection.Query<string>("TNP_GetAPIKeyByFranchiseId", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
        //        }
        //    }
        //    catch (Exception ex) { throw; }
        //    return returnValue;
        //}

        public string readConfig(string strKey)
        {
            var key = Convert.ToString(ConfigurationManager.AppSettings[strKey]);
            if (String.IsNullOrEmpty(key))
                key = "false";
            return key;
        }

        public static DataTable GetLeadCreationDataforEmail(string FromDatabase)
        {
            DataSet EmailRecepient = new DataSet();

            EmailRecepient = CareSmartzPaymentService.SqlHelper.ExecuteDataset("FetchLeadListingForCreationEmail", FromDatabase);
            return EmailRecepient.Tables[0];
        }

        public static string ReturnInvoiceStatus(string Status)
        {
            string ReturnStatus = "";

            switch (Status.ToLower())
            {
                case "transfered":
                    ReturnStatus = InvoiceStatus.Transfered;
                    break;
                case "partiallypaid":
                    ReturnStatus = InvoiceStatus.PartiallyPaid;
                    break;
                case "notpaid":
                    ReturnStatus = InvoiceStatus.NotPaid;
                    break;
                case "adjusted":
                    ReturnStatus = InvoiceStatus.Adjusted;
                    break;
                case "overpaid":
                    ReturnStatus = InvoiceStatus.OverPaid;
                    break;
                case "fullypaid":
                    ReturnStatus = InvoiceStatus.FullyPaid;
                    break;
                case "voided":
                    ReturnStatus = InvoiceStatus.Voided;
                    break;
                case "approvedreview":
                    ReturnStatus = InvoiceStatus.ApprovedReview;
                    break;
                case "heldforreview":
                    ReturnStatus = InvoiceStatus.HeldforReview;
                    break;
                case "refundpendingsettlement":
                    ReturnStatus = InvoiceStatus.RefundPendingSettlement;
                    break;
                case "fdspendingreview":
                    ReturnStatus = InvoiceStatus.FDSPendingReview;
                    break;
                case "declined":
                    ReturnStatus = InvoiceStatus.Declined;
                    break;
                case "settledsuccessfully":
                case "settled":
                    ReturnStatus = InvoiceStatus.SettledSuccessfully;
                    break;
                case "capturedpendingsettlement":
                    ReturnStatus = InvoiceStatus.CapturedPendingSettlement;
                    break;
                case "pendingsettlement":
                    ReturnStatus = InvoiceStatus.CapturedPendingSettlement;
                    break;
                default:
                    ReturnStatus = InvoiceStatus.WaitingConfirmation;
                    break;
            }

            return ReturnStatus;
        }

        public static void SendPaymentSMS(Guid ClientID, Guid InvoiceId, decimal Amount, Int32 AgencyId, string FromDatabase)
        {
            #region "Send SMS"
            /// Incase of bank do not send message

            try
            {

                logger.Info(string.Format("Error in Send SMS: {0}, {1}, {2} ", ClientID, InvoiceId, AgencyId));

                AutorizedDotNetPaymentTransactionRepo objModelTransactionRepo = new AutorizedDotNetPaymentTransactionRepo();

                List<SMSService.EntitySMS> objList = new List<SMSService.EntitySMS>();
                System.Data.DataSet dtReceivedSMS = objModelTransactionRepo.SendPaymentReceived(ClientID, InvoiceId, Amount, FromDatabase);

                for (int i = 0; i < dtReceivedSMS.Tables[0].Rows.Count; i++)
                {
                    SMSService.EntitySMS objEntitySMS = new SMSService.EntitySMS();
                    objEntitySMS.EntityId = Guid.Parse(dtReceivedSMS.Tables[0].Rows[i]["ID"].ToString());
                    objEntitySMS.Message = dtReceivedSMS.Tables[0].Rows[i]["Content"].ToString();
                    objEntitySMS.Number = dtReceivedSMS.Tables[0].Rows[i]["SendTo"].ToString();
                    objList.Add(objEntitySMS);
                }

                //Start SMS

                SMSService.SMSServiceClient objSendMessage = new SMSService.SMSServiceClient();
                SMSService.MulitpleEntitySMS objMultipleSMSEntities = new SMSService.MulitpleEntitySMS();

                var list = objList;
                if (list != null && list.Count() > 0)
                {
                    objMultipleSMSEntities.AgencyId = Convert.ToInt32(AgencyId);
                    objMultipleSMSEntities.EntityList = list.Select(x => new SMSService.EntitySMS { EntityId = x.EntityId, Message = x.Message, EntityType = "Client", Number = x.Number }).ToArray();
                    objMultipleSMSEntities.SentBy = Guid.Parse("AEBA1E8A-F89A-E311-9EDA-00155D0A1914");
                    objMultipleSMSEntities.SentByEntity = "user";
                    objMultipleSMSEntities.Type = "M";
                    objMultipleSMSEntities.Service = "Payment Receive";
                    objSendMessage.sendMultipleEntitySMS(objMultipleSMSEntities);
                    //End SMS

                }

                
            }
            catch (Exception ex)
            {

                logger.Info(string.Format("Error in Send SMS: {0}", ex.Message));

                /// Logs
                //objModel.SaveAuthorizedDotNetErrorLog_Payment("CareSmart Payment Window Service Send SMS", "AuthorisezDotNet Send SMS", ex.Message.ToString(), "Send SMS Error", FromDatabase);

                /// Logs
                //MethodToLogMessageInfo("Payment Register by Payer", "Send SMS Receive Payment", Convert.ToString("Exception: " + Convert.ToString(ex)), "Error", null);
            }
            #endregion

        }


    }
}
