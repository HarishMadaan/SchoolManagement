﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using TNPGatewaysAPI.Models.ViewModel;
using TNPGatewaysAPI.Models.ViewModel.CreateCustomer;
using TNPGatewaysAPI.Models.ViewModel.Transaction;
using TNPGatewaysAPI.Models.ViewModel.UpdateCustomer;

namespace AuthorizeGateway
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ITransnationService" in both code and config file together.
    [ServiceContract]
    public interface ITransnationService
    {

        [OperationContract]
        string MakeTransaction(string transaction, string franchise_id, int agency_id, ref string service_response);

        [OperationContract]
        string CreateCustomer(string info, string franchise_id, int agency_id, ref string service_response);

        [OperationContract]
        string UpdateCustomer(string info, string franchise_id, int agency_id, string customer_id, ref string service_response);

        [OperationContract]
        string UpdateCustomerAddress(string customer_id, string address_id, string franchise_id, int agency_id, char address_type, ref string service_response);

        [OperationContract]
        string UpdateSpecificTokenAddress(string customer_id, string payment_id, string card_number, string expiration_date, string franchise_id, int agency_id, ref string service_response);

        [OperationContract]
        string GetSpecificCustomer(string customer_id, string franchise_id, int agency_id, ref string service_response);

        [OperationContract]
        string DeleteSpecificCustomer(string customer_id, string franchise_id, int agency_id, ref string service_response);

        [OperationContract]
        string GetTransactionStatus(string transaction_id, string franchise_id, int agency_id, ref string service_response);

    }
    
}
