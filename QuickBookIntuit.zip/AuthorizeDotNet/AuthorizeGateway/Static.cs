﻿/*
 * Class to encrypt and decrypt string values 
 * Navjot Singh 03/11/2016
 * CareSmartz360
 */
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AuthorizeGateway
{
    public static class Static
    {
        #region Encrypt Decrypt

        private static string key = "29xdVi33L5W32SL2";

        public static string Encrypt(string toEncrypt)
        {
            byte[] keyArray = UTF8Encoding.UTF8.GetBytes(key);
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(NullPadString(toEncrypt));
            RijndaelManaged rDel = new RijndaelManaged();

            rDel.Key = keyArray;
            rDel.Mode = CipherMode.ECB; // http://msdn.microsoft.com/en-us/library/system.security.cryptography.ciphermode.aspx
            rDel.Padding = PaddingMode.None; // better lang support

            ICryptoTransform cTransform = rDel.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            string base64Data = Convert.ToBase64String(resultArray, 0, resultArray.Length);

            return SpecialCharterEncrypt(base64Data);
        }

        public static string Decrypt(string toDecrypt)
        {
            toDecrypt = SpecialCharterDecrypt(toDecrypt);

            byte[] keyArray = UTF8Encoding.UTF8.GetBytes(key); // AES-256 key
            byte[] toEncryptArray = Convert.FromBase64String(toDecrypt);
            RijndaelManaged rDel = new RijndaelManaged();

            rDel.Key = keyArray;
            rDel.Mode = CipherMode.ECB; // http://msdn.microsoft.com/en-us/library/system.security.cryptography.ciphermode.aspx
            rDel.Padding = PaddingMode.None;  //.PKCS7; // better lang support

            ICryptoTransform cTransform = rDel.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            //return SpecialCharterDecrypt(UTF8Encoding.UTF8.GetString(resultArray));
            return SpecialCharterDecrypt(UTF8Encoding.UTF8.GetString(resultArray));
        }

        static string SpecialCharterDecrypt(string text)
        {
            string strText = text.Replace("%26", "&")
                                    .Replace("%2B", "+")
                                    .Replace("%2C", ",")
                                    .Replace("%2F", "/")
                                    .Replace("%3A", ":")
                                    .Replace("%3B", ";")
                                    .Replace("%3D", "=")
                                    .Replace("%3F", "?")
                                    .Replace("%40", "@")
                                    .Replace("%20", " ")
                                    .Replace("%09", "\t")
                                    .Replace("%23", "#")
                                    .Replace("%3C", "<")
                                    .Replace("%3E", ">")
                                    .Replace("%22", "\"")
                                    .Replace("%0A", "\n")
                                    .Replace("\0", "");
            return strText;
        }

        static string SpecialCharterEncrypt(string text)
        {
            string strText = text.Replace("&", "%26")
                                    .Replace("+", "%2B")
                                    .Replace(",", "%2C")
                                    .Replace("/", "%2F")
                                    .Replace(":", "%3A")
                                    .Replace(";", "%3B")
                                    .Replace("=", "%3D")
                                    .Replace("?", "%3F")
                                    .Replace("@", "%40")
                                    .Replace(" ", "%20")
                                    .Replace("\t", "%09")
                                    .Replace("#", "%23")
                                    .Replace("<", "%3C")
                                    .Replace(">", "%3E")
                                    .Replace("\"", "%22")
                                    .Replace("\n", "%0A");
            return strText;
        }

        static String NullPadString(String original)
        {
            String output = original;
            int remain = output.Length % 16;

            if (remain != 0)
            {
                remain = 16 - remain;
                for (int i = 0; i < remain; i++)
                    output += (char)0;
            }
            return output;
        }

        #endregion

    }
}
