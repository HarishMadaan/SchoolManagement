﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using TNPGatewaysAPI.Models;
using TNPGatewaysAPI.Models.ViewModel;
using TNPGatewaysAPI.Models.ViewModel.CreateCustomer;
using TNPGatewaysAPI.Models.ViewModel.Transaction;
using TNPGatewaysAPI.Models.ViewModel.UpdateCustomer;

namespace AuthorizeGateway
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "TransnationService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select TransnationService.svc or TransnationService.svc.cs at the Solution Explorer and start debugging.
    public class TransnationService : ITransnationService
    {

        public string CreateCustomer(string info, string franchise_id, int agency_id, ref string service_response)
        {
            return new CustomerOperation().CreateCustomer(info, franchise_id, agency_id, ref service_response);
        }

        public string DeleteSpecificCustomer(string customer_id, string franchise_id, int agency_id, ref string service_response)
        {
            return new CustomerOperation().DeleteSpecificCustomer(customer_id, franchise_id, agency_id, ref service_response);
        }

        public string GetSpecificCustomer(string customer_id, string franchise_id, int agency_id, ref string service_response)
        {
            return new CustomerOperation().GetSpecificCustomer(customer_id, franchise_id, agency_id, ref service_response);
        }

        public string UpdateCustomer(string info, string franchise_id, int agency_id, string customer_id, ref string service_response)
        {
            return new CustomerOperation().UpdateCustomer(info, franchise_id, agency_id, customer_id, ref service_response);
        }

        public string UpdateCustomerAddress(string customer_id, string address_id, string franchise_id, int agency_id, char address_type, ref string service_response)
        {
            return new CustomerOperation().UpdateCustomerAddress(customer_id, address_id, franchise_id, agency_id, address_type, ref service_response);
        }

        public string UpdateSpecificTokenAddress(string customer_id, string payment_id, string card_number, string expiration_date, string franchise_id, int agency_id, ref string service_response)
        {
            return new CustomerOperation().UpdateSpecificTokenAddress(customer_id, payment_id, card_number, expiration_date, franchise_id, agency_id, ref service_response);
        }

        public string MakeTransaction(string transaction, string franchise_id, int agency_id, ref string service_response)
        {
            return new TransactionProcess().MakeTransaction(transaction, franchise_id, agency_id, ref service_response);
        }

        public string GetTransactionStatus(string transaction_id, string franchise_id, int agency_id, ref string service_response)
        {
            return new TransactionProcess().GetTransactionStatus(transaction_id, franchise_id, agency_id, ref service_response);
        }
    }
}
