﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AuthorizeGateway
{
    public class CIMAuthorizeDAL : IDisposable
    {

        public string ConnectionString
        {
            get
            {
                //return "data source=$DataSource$;initial catalog=$Databasename$;user id=$UserName$;password=$Password$";//ConfigurationManager.AppSettings["CommonConnectionString"].ToString(); 
                return ConfigurationManager.AppSettings["CommonConnectionString"].ToString(); 
            }
        }
        public string FromDatabase { get; set; }

        /// <summary>
        /// method to get connection string based on agencyid
        /// Dharmender Kumar
        /// 04/16/2019
        /// </summary>
        /// <param name="AgencyId"></param>
        public CIMAuthorizeDAL(Int32 AgencyId)
        {
            try
            {
                //string stConnection = ConfigurationManager.ConnectionStrings["CSConnectionString"].ConnectionString;
                //SqlConnection objconnection = new SqlConnection() { ConnectionString = Convert.ToString("Data Source=192.168.15.4\\CS360LOCAL;Initial Catalog=NTZCareSmartz360;Persist Security Info=True;User ID=cs360;Password=Brow@8689") };
                SqlConnection objconnection = new SqlConnection() { ConnectionString = Convert.ToString(ConfigurationManager.ConnectionStrings["CSConnectionString"].ConnectionString) };
                objconnection.Open();
                SqlCommand objCmd = new SqlCommand("SELECT TOP 1 * FROM DBConnectionDetails WHERE AgencyId = " + AgencyId, objconnection);
                objCmd.CommandType = CommandType.Text;
                SqlDataReader dr = objCmd.ExecuteReader();
                while (dr.Read())
                {
                    FromDatabase = ConnectionString.Replace("$Databasename$", Convert.ToString(dr["DBName"]))
                                   .Replace("$DataSource$", Static.Decrypt(Convert.ToString(dr["DataSource"]))).Replace("$UserName$", Static.Decrypt(Convert.ToString(dr["Username"]))).Replace("$Password$", Static.Decrypt(Convert.ToString(dr["Password"])));
                }
                if (objconnection.State != ConnectionState.Closed)
                {
                    objconnection.Close();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public string GetCustomerProfileIdByMerchantId(string strMerchantId)
        {
            string returnValue = "0";
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@CardName", strMerchantId);
                    returnValue = dbConnection.Query<string>("GetCustomerProfileIdByMerchantId", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception ex) { throw; }


            return returnValue;
        }

        public string GetCustomerPaymentProfileIdByMerchantIdAndCardNumber(string strMerchantId, string strCardNumber)
        {
            string returnValue = "0";
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@CardName", strMerchantId);
                    parameters.Add("@CardNumber", strCardNumber);
                    returnValue = dbConnection.Query("GetCustomerPaymentProfileIdByMerchantIdAndCardNumber", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception ex) { throw; }


            return returnValue;
        }

        public string AuthorizePaymentLog(string strFunctionName, string strErrorCode, string strErrorText, string strDescription, string strExceptionDetail, string strUserId)
        {
            string returnValue = "0";
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@FunctionName", strFunctionName);
                    parameters.Add("@ResponseCode", strErrorCode);
                    parameters.Add("@ResponseText", strErrorText);
                    parameters.Add("@Description", strDescription);
                    parameters.Add("@ExceptionDetail", strExceptionDetail);
                    parameters.Add("@UserID", strUserId);
                    dbConnection.Query("GenerateAuthorizePaymentLog", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex) { throw; }


            return returnValue;
        }

        public GetAPIIdAndTransactionKeyByFranchiseId_Result GetApiAndTransactionKey(string strFranchiseId)
        {
            GetAPIIdAndTransactionKeyByFranchiseId_Result returnValue = new GetAPIIdAndTransactionKeyByFranchiseId_Result();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@FranchiseId", strFranchiseId);
                    returnValue = dbConnection.Query<GetAPIIdAndTransactionKeyByFranchiseId_Result>("GetAPIIdAndTransactionKeyByFranchiseId", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception ex) { throw; }
            return returnValue;
        }
        public void Dispose() { }
    }
}