﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AuthorizeWebService;
namespace AuthorizeGateway
{
    public class CIMAuthorizeBLL : IDisposable
    {
        public static string strAPIId { get; set; }
        public static string strTransactionKey { get; set; }
        public long CreateCustomerProfile(CreditCardInfo cardinfo, string LoggedInUserId, out string strErrorCode, out string strErrorText)
        {
            long customerProfileId = 0;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {

                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(cardinfo.FranchiseId, cardinfo.AgencyId);
                    customerProfileId = obj.CreateCustomerProfile(cardinfo.merchantCustomerId, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);
                    if (customerProfileId == 0)
                    {
                        if (strErrorCode.ToLower() == "E00039".ToLower())//means need to get customerProfileId from database because profile already exists on Authorize.net
                        {
                            using (CIMAuthorizeDAL objDLL = new CIMAuthorizeDAL(cardinfo.AgencyId))
                            {
                                customerProfileId = Convert.ToInt64(objDLL.GetCustomerProfileIdByMerchantId(cardinfo.merchantCustomerId));
                                if (customerProfileId > 0)
                                {
                                    strErrorText = "I00001";
                                    strErrorText = "Successful";
                                }
                            }
                        }
                    }
                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateCustomerProfile", strErrorCode, strErrorText, "CustomerProfileId >> " + Convert.ToString(customerProfileId), null, LoggedInUserId, cardinfo.AgencyId);
                }

            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateCustomerProfile", strErrorCode, strErrorText, "CustomerProfileId >> " + Convert.ToString(customerProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, cardinfo.AgencyId);
            };

            return customerProfileId;
        }

        public long CreateCustomerPaymentProfile(string profileId, string strAuthorizationFlag, string LoggedInUserId, CreditCardInfo cardinfo, out string strErrorCode, out string strErrorText)
        {
            long customerPayerProfileId = 0;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {

                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(cardinfo.FranchiseId, cardinfo.AgencyId);
                    customerPayerProfileId = obj.CreateCustomerPaymentProfile(profileId, cardinfo, strAuthorizationFlag, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);
                    if (customerPayerProfileId == 0)
                    {
                        if (strErrorCode.ToLower() == "E00039".ToLower())//means need to get customerPayerProfileId from database because profile already exists on Authorize.net
                        {
                            using (CIMAuthorizeDAL objDLL = new CIMAuthorizeDAL(cardinfo.AgencyId))
                            {
                                if (!string.IsNullOrEmpty(cardinfo.merchantCustomerId) && !string.IsNullOrEmpty(cardinfo.CardNumber))
                                    customerPayerProfileId = Convert.ToInt64(objDLL.GetCustomerPaymentProfileIdByMerchantIdAndCardNumber(cardinfo.merchantCustomerId, cardinfo.CardNumber));
                            }
                        }
                    }
                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateCustomerPaymentProfile", strErrorCode, strErrorText, "customerPaymentProfileId >> " + Convert.ToString(customerPayerProfileId), null, LoggedInUserId, cardinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateCustomerPaymentProfile", strErrorCode, strErrorText, "CustomerProfileId >> " + Convert.ToString(customerPayerProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, cardinfo.AgencyId);
            };

            return customerPayerProfileId;
        }


        public bool UpdateCustomerPaymentProfile(string profileId, string paymentProfileId, string strAuthorizationFlag, string LoggedInUserId, CreditCardInfo cardinfo, out string strErrorCode, out string strErrorText)
        {
            bool returnValue = false;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {

                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(cardinfo.FranchiseId, cardinfo.AgencyId);
                    returnValue = obj.UpdateCustomerPaymentProfile(profileId, paymentProfileId, cardinfo, strAuthorizationFlag, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> UpdateCustomerPaymentProfile", strErrorCode, strErrorText, "customerProfileId >> " + Convert.ToString(profileId) + "    customerPaymentProfileId >> " + Convert.ToString(paymentProfileId), null, LoggedInUserId, cardinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> UpdateCustomerPaymentProfile", strErrorCode, strErrorText, "CustomerProfileId >> " + Convert.ToString(profileId) + " CustomerPaymentProfileId >> " + Convert.ToString(paymentProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, cardinfo.AgencyId);
            };

            return returnValue;
        }
        public string CreateTransaction(string profileId, string paymentProfileId, string LoggedInUserId, CreditCardInfo cardinfo, out string strErrorCode, out string strErrorText)
        {
            string returnValue = string.Empty;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {
                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(cardinfo.FranchiseId, cardinfo.AgencyId);
                    returnValue = obj.CreateTransaction(profileId, paymentProfileId, cardinfo, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateTransaction", strErrorCode, strErrorText, "TransactionId >> " + returnValue + "   customerProfileId >> " + Convert.ToString(profileId) + "    customerPaymentProfileId >> " + Convert.ToString(paymentProfileId), null, LoggedInUserId, cardinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateTransaction", strErrorCode, strErrorText, "TransactionId >> " + returnValue + "   CustomerProfileId >> " + Convert.ToString(profileId) + " CustomerPaymentProfileId >> " + Convert.ToString(paymentProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, cardinfo.AgencyId);
            };

            return returnValue;
        }

        public bool DeleteCustomerProfile(string profileId, string LoggedInUserId, CreditCardInfo cardinfo, out string strErrorCode, out string strErrorText)
        {
            bool returnValue = false;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {
                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(cardinfo.FranchiseId, cardinfo.AgencyId);
                    returnValue = obj.DeleteCustomerProfile(profileId, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> DeleteCustomerProfile", strErrorCode, strErrorText, "Customer Profile deleted status >>" + Convert.ToString(returnValue), null, LoggedInUserId, cardinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> DeleteCustomerProfile", strErrorCode, strErrorText, "Customer Profile deleted status >>" + Convert.ToString(returnValue),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, cardinfo.AgencyId);
            };

            return returnValue;
        }

        public bool DeleteCustomerPaymentProfile(string profileId, string paymentProfileId, string LoggedInUserId, CreditCardInfo cardinfo, out string strErrorCode, out string strErrorText)
        {
            bool returnValue = false;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {
                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(cardinfo.FranchiseId, cardinfo.AgencyId);
                    returnValue = obj.DeleteCustomerPaymentProfile(profileId, paymentProfileId, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> DeleteCustomerPaymentProfile", strErrorCode, strErrorText, "Customer Payment Profile deleted status >>" + Convert.ToString(returnValue), null, LoggedInUserId, cardinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> DeleteCustomerPaymentProfile", strErrorCode, strErrorText, "Customer Payment Profile deleted status >>" + Convert.ToString(returnValue),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, cardinfo.AgencyId);
            };

            return returnValue;
        }



        public CreditCardInfo GetCardInfoFromDC(CreditCardInfo_DC contract)
        {
            return new CreditCardInfo
            {
                Id = contract.Id,
                merchantCustomerId = contract.merchantCustomerId,
                email = contract.email,
                description = contract.description,
                CardNumber = contract.CardNumber,
                ExpiryYear = contract.ExpiryYear,
                ExpiryMonth = contract.ExpiryMonth,
                CVV = contract.CVV,
                Amount = contract.Amount,
                accountNumber = contract.accountNumber,
                routingNumber = contract.routingNumber,
                FirstName = contract.FirstName,
                LastName = contract.LastName,
                Address = contract.Address,
                ZipCode = contract.ZipCode,
                City = contract.City,
                OfficeName = contract.OfficeName,
                Country = contract.Country,
                State = contract.State,
                company = contract.company,
                phoneNumber = contract.phoneNumber,
                faxNumber = contract.faxNumber,
                IsPrimary = contract.IsPrimary,
                FranchiseId = contract.FranchiseId,
                AgencyId = contract.AgencyId,
                InvoiceNumber = contract.InvoiceNumber
            };
        }


        #region Bank Account Info

        public long CreateCustomerBankProfile(BankAccountInfo bankinfo, string LoggedInUserId, out string strErrorCode, out string strErrorText)
        {
            long customerProfileId = 0;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {

                using (AuthorizeWebService.AuthorizeClientBank obj = new AuthorizeWebService.AuthorizeClientBank())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(bankinfo.FranchiseId, bankinfo.AgencyId);
                    customerProfileId = obj.CreateCustomerBankProfile(bankinfo.PayerDisplayId, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);
                    if (customerProfileId == 0)
                    {
                        if (strErrorCode.ToLower() == "E00039".ToLower())//means need to get customerProfileId from database because profile already exists on Authorize.net
                        {
                            using (CIMAuthorizeDAL objDLL = new CIMAuthorizeDAL(bankinfo.AgencyId))
                            {
                                customerProfileId = Convert.ToInt64(objDLL.GetCustomerProfileIdByMerchantId(bankinfo.merchantCustomerId));
                            }
                        }
                    }
                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateCustomerBankProfile", strErrorCode, strErrorText, "CustomerBankProfileId >> " + Convert.ToString(customerProfileId), null, LoggedInUserId, bankinfo.AgencyId);
                }

            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateCustomerBankProfile", strErrorCode, strErrorText, "CustomerBankProfileId >> " + Convert.ToString(customerProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, bankinfo.AgencyId);
            };

            return customerProfileId;
        }


        public long CreateCustomerPaymentBankProfile(string profileId, string strAuthorizationFlag, string LoggedInUserId, BankAccountInfo bankinfo, out string strErrorCode, out string strErrorText)
        {
            long customerPayerProfileId = 0;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {

                using (AuthorizeWebService.AuthorizeClientBank obj = new AuthorizeWebService.AuthorizeClientBank())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(bankinfo.FranchiseId, bankinfo.AgencyId);
                    customerPayerProfileId = obj.CreateCustomerPaymentBankProfile(profileId, bankinfo, strAuthorizationFlag, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);
                    if (customerPayerProfileId == 0)
                    {
                        if (strErrorCode.ToLower() == "E00039".ToLower())//means need to get customerPayerProfileId from database because profile already exists on Authorize.net
                        {
                            using (CIMAuthorizeDAL objDLL = new CIMAuthorizeDAL(bankinfo.AgencyId))
                            {
                                if (!string.IsNullOrEmpty(bankinfo.merchantCustomerId) && !string.IsNullOrEmpty(bankinfo.AccountNumber))
                                    customerPayerProfileId = Convert.ToInt64(objDLL.GetCustomerPaymentProfileIdByMerchantIdAndCardNumber(bankinfo.merchantCustomerId, bankinfo.AccountNumber));
                            }
                        }
                    }
                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateCustomerPaymentBankProfile", strErrorCode, strErrorText, "customerPaymentBankProfileId >> " + Convert.ToString(customerPayerProfileId), null, LoggedInUserId, bankinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateCustomerPaymentBankProfile", strErrorCode, strErrorText, "CustomerPaymentBankProfileId >> " + Convert.ToString(customerPayerProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, bankinfo.AgencyId);
            };

            return customerPayerProfileId;
        }

        public string CreateBankTransaction(string profileId, string paymentProfileId, string LoggedInUserId, BankAccountInfo bankinfo, string ReferenceId, out string strErrorCode, out string strErrorText)
        {
            string returnValue = string.Empty;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {
                using (AuthorizeWebService.AuthorizeClientBank obj = new AuthorizeWebService.AuthorizeClientBank())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(bankinfo.FranchiseId, bankinfo.AgencyId);
                    returnValue = obj.CreateBankTransaction(profileId, paymentProfileId, bankinfo, strAPIId, strTransactionKey, ReferenceId, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateBankTransaction", strErrorCode, strErrorText, "TransactionId >> " + returnValue + "   customerBankProfileId >> " + Convert.ToString(profileId) + "    customerPaymentBankProfileId >> " + Convert.ToString(paymentProfileId), null, LoggedInUserId, bankinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> CreateBankTransaction", strErrorCode, strErrorText, "TransactionId >> " + returnValue + "   CustomerBankProfileId >> " + Convert.ToString(profileId) + " CustomerPaymentBankProfileId >> " + Convert.ToString(paymentProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, bankinfo.AgencyId);
            };

            return returnValue;
        }

        public bool DeleteCustomerBankProfile(string profileId, string LoggedInUserId, BankAccountInfo bankinfo, out string strErrorCode, out string strErrorText)
        {
            bool returnValue = false;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {
                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(bankinfo.FranchiseId, bankinfo.AgencyId);
                    returnValue = obj.DeleteCustomerProfile(profileId, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> DeleteCustomerBankProfile", strErrorCode, strErrorText, "Customer Profile deleted status >>" + Convert.ToString(returnValue), null, LoggedInUserId, bankinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> DeleteCustomerBankProfile", strErrorCode, strErrorText, "Customer Bank Profile deleted status >>" + Convert.ToString(returnValue),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, bankinfo.AgencyId);
            };

            return returnValue;
        }

        public bool DeleteCustomerPaymentBankProfile(string profileId, string paymentProfileId, string LoggedInUserId, BankAccountInfo bankinfo, out string strErrorCode, out string strErrorText)
        {
            bool returnValue = false;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {
                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(bankinfo.FranchiseId, bankinfo.AgencyId);
                    returnValue = obj.DeleteCustomerPaymentProfile(profileId, paymentProfileId, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> DeleteCustomerPaymentBankProfile", strErrorCode, strErrorText, "Customer Payment Bank Profile deleted status >>" + Convert.ToString(returnValue), null, LoggedInUserId, bankinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> DeleteCustomerPaymentBankProfile", strErrorCode, strErrorText, "Customer Payment Bank Profile deleted status >>" + Convert.ToString(returnValue),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, bankinfo.AgencyId);
            };

            return returnValue;
        }

        public bool UpdateCustomerPaymentBankProfile(string profileId, string paymentProfileId, string strAuthorizationFlag, string LoggedInUserId, BankAccountInfo bankinfo, out string strErrorCode, out string strErrorText)
        {
            bool returnValue = false;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {

                using (AuthorizeWebService.AuthorizeClientBank obj = new AuthorizeWebService.AuthorizeClientBank())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(bankinfo.FranchiseId, bankinfo.AgencyId);
                    returnValue = obj.UpdateCustomerPaymentProfile(profileId, paymentProfileId, bankinfo, strAuthorizationFlag, strAPIId, strTransactionKey, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> UpdateCustomerPaymentBankProfile", strErrorCode, strErrorText, "customerBankProfileId >> " + Convert.ToString(profileId) + "    customerPaymentBankProfileId >> " + Convert.ToString(paymentProfileId), null, LoggedInUserId, bankinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> UpdateCustomerPaymentBankProfile", strErrorCode, strErrorText, "CustomerBankProfileId >> " + Convert.ToString(profileId) + " CustomerPaymentBankProfileId >> " + Convert.ToString(paymentProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, bankinfo.AgencyId);
            };

            return returnValue;
        }

        public string ReceiveBankAdvancePayment(string profileId, string paymentProfileId, string LoggedInUserId, BankAccountInfo bankinfo, string ReferenceId, out string strErrorCode, out string strErrorText)
        {
            string returnValue = string.Empty;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {
                using (AuthorizeWebService.AuthorizeClientBank obj = new AuthorizeWebService.AuthorizeClientBank())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(bankinfo.FranchiseId, bankinfo.AgencyId);
                    returnValue = obj.ReceiveBankAdvancePayment(profileId, paymentProfileId, bankinfo, strAPIId, strTransactionKey, ReferenceId, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> ReceiveBankAdvancePayment", strErrorCode, strErrorText, "TransactionId >> " + returnValue + "   customerBankProfileId >> " + Convert.ToString(profileId) + "    customerPaymentBankProfileId >> " + Convert.ToString(paymentProfileId), null, LoggedInUserId, bankinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> ReceiveBankAdvancePayment", strErrorCode, strErrorText, "TransactionId >> " + returnValue + "   CustomerBankProfileId >> " + Convert.ToString(profileId) + " CustomerPaymentBankProfileId >> " + Convert.ToString(paymentProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, bankinfo.AgencyId);
            };

            return returnValue;
        }

        public string ReceiveCreditAdvancePayment(string profileId, string paymentProfileId, string LoggedInUserId, CreditCardInfo creditCardinfo, string ReferenceId, out string strErrorCode, out string strErrorText)
        {
            string returnValue = string.Empty;
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            try
            {
                using (AuthorizeWebService.AuthorizeClient obj = new AuthorizeWebService.AuthorizeClient())
                {
                    GetApiIdAndTransactionKeyByFranchiseId(creditCardinfo.FranchiseId, creditCardinfo.AgencyId);
                    returnValue = obj.ReceiveCreditAdvancePayment(profileId, paymentProfileId, creditCardinfo, strAPIId, strTransactionKey, ReferenceId, out strErrorCode, out strErrorText);

                    AuthorizePaymentLog("CIMAuthorizeBLL.cs >> ReceiveBankAdvancePayment", strErrorCode, strErrorText, "TransactionId >> " + returnValue + "   customerBankProfileId >> " + Convert.ToString(profileId) + "    customerPaymentBankProfileId >> " + Convert.ToString(paymentProfileId), null, LoggedInUserId, creditCardinfo.AgencyId);
                }
            }
            catch (Exception ex)
            {
                AuthorizePaymentLog("CIMAuthorizeBLL.cs >> ReceiveBankAdvancePayment", strErrorCode, strErrorText, "TransactionId >> " + returnValue + "   CustomerBankProfileId >> " + Convert.ToString(profileId) + " CustomerPaymentBankProfileId >> " + Convert.ToString(paymentProfileId),
                    "INNER EXCEPTION >> " + ex.InnerException + "  EXCEPTION MESSAGE >> " + ex.Message, LoggedInUserId, creditCardinfo.AgencyId);
            };

            return returnValue;
        }

        public BankAccountInfo GetBankAccountInfoFromDC(BankAccountInfo_DC contract)
        {
            return new BankAccountInfo
            {
                BankId = contract.BankId,
                merchantCustomerId = contract.merchantCustomerId,
                email = contract.email,
                description = contract.description,
                AccountNumber = contract.AccountNumber,
                RoutingNumber = contract.RoutingNumber,
                BankName = contract.BankName,
                NameOnAccount = contract.NameOnAccount,
                AccountType = contract.AccountType,
                AuthorizationType = contract.AuthorizationType,
                CheckNumber = contract.CheckNumber,
                Amount = contract.Amount,
                FirstName = contract.FirstName,
                LastName = contract.LastName,
                Address = contract.Address,
                ZipCode = contract.ZipCode,
                City = contract.City,
                OfficeName = contract.OfficeName,
                Country = contract.Country,
                State = contract.State,
                company = contract.company,
                phoneNumber = contract.phoneNumber,
                faxNumber = contract.faxNumber,
                IsPrimary = contract.IsPrimary,
                FranchiseId = contract.FranchiseId,
                AgencyId = contract.AgencyId,
                InvoiceNumber = contract.InvoiceNumber,
                ACustomerProfileId = contract.ACustomerProfileId,
                ACustomerPaymentProfileId = contract.ACustomerPaymentProfileId,
                PayerDisplayId = contract.PayerDisplayId
            };
        }

        #endregion

        public void GetApiIdAndTransactionKeyByFranchiseId(string strFranchiseId, int intAgencyId)
        {
            try
            {
                using (CIMAuthorizeDAL objDLL = new CIMAuthorizeDAL(intAgencyId))
                {
                    GetAPIIdAndTransactionKeyByFranchiseId_Result obj = objDLL.GetApiAndTransactionKey(strFranchiseId);
                    if (obj != null)
                    {
                        strAPIId = obj.APIId;
                        strTransactionKey = obj.TransactionKey;
                    }
                }
            }
            catch (Exception ex) { }
        }

        public void AuthorizePaymentLog(string strFunctionName, string strErrorCode, string strErrorText, string strDescription,
            string strExceptionDetail, string strUserId, int intAgencyId)
        {
            using (CIMAuthorizeDAL objDLL = new CIMAuthorizeDAL(intAgencyId))
            {
                objDLL.AuthorizePaymentLog(strFunctionName, strErrorCode, strErrorText, strDescription, strExceptionDetail, strUserId);
            }
        }

        public void Dispose() { }
    }
}