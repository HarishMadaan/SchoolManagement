﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace AuthorizeGateway
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICIMAuthorizeService" in both code and config file together.
    [ServiceContract]
    public interface ICIMAuthorizeService
    {
        /// <summary>
        /// Function will hit Authorize.net API and create a customer profile and return numeric customer profile id created on authorize.net
        /// </summary>
        /// <param name="cardinfo"></param>
        /// <param name="strLoggedInUserId"></param>
        /// <param name="strErrorCode"></param>
        /// <param name="strErrorText"></param>
        /// <returns></returns>
        [OperationContract]
        long CreateCustomerProfile(CreditCardInfo_DC cardinfo, string strLoggedInUserId, out string strErrorCode, out string strErrorText);

        /// <summary>
        /// Fuction will create Payment profile for passed profileid (numeric customer profile id) on Authorize.net
        /// </summary>
        /// <param name="profileId"></param>
        /// <param name="strAuthorizationFlag"></param>
        /// <param name="strLoggedInUserId"></param>
        /// <param name="cardinfo"></param>
        /// <param name="strErrorCode"></param>
        /// <param name="strErrorText"></param>
        /// <returns></returns>
        [OperationContract]
        long CreateCustomerPaymentProfile(string profileId, string strAuthorizationFlag, string strLoggedInUserId, CreditCardInfo_DC cardinfo, out string strErrorCode, out string strErrorText);

        /// <summary>
        /// Function will Update Customer Payment Profile info on Authorize.net
        /// </summary>
        /// <param name="profileId"></param>
        /// <param name="paymentProfileId"></param>
        /// <param name="strAuthorizationFlag"></param>
        /// <param name="strLoggedInUserId"></param>
        /// <param name="cardinfo"></param>
        /// <param name="strErrorCode"></param>
        /// <param name="strErrorText"></param>
        /// <returns></returns>
        [OperationContract]
        bool UpdateCustomerPaymentProfile(string profileId, string paymentProfileId, string strAuthorizationFlag, string strLoggedInUserId, CreditCardInfo_DC cardinfo, out string strErrorCode, out string strErrorText);

        /// <summary>
        /// Function will Create a Transaction for paymentprofileid on Authorize.net
        /// </summary>
        /// <param name="profileId"></param>
        /// <param name="paymentProfileId"></param>
        /// <param name="LoggedInUserId"></param>
        /// <param name="cardinfo"></param>
        /// <param name="strErrorCode"></param>
        /// <param name="strErrorText"></param>
        /// <returns></returns>
        [OperationContract]
        string CreateTransaction(string profileId, string paymentProfileId, string LoggedInUserId, CreditCardInfo_DC cardinfo, out string strErrorCode, out string strErrorText);
        [OperationContract]
        bool DeleteCustomerProfile(string profileId, string LoggedInUserId, CreditCardInfo_DC cardinfo, out string strErrorCode, out string strErrorText);
        [OperationContract]
        bool DeleteCustomerPaymentProfile(string profileId, string paymentProfileId, string LoggedInUserId, CreditCardInfo_DC cardinfo, out string strErrorCode, out string strErrorText);

        /// <summary>
        /// Function will hit Authorize.net API and create a bank customer profile and return numeric customer profile id created on authorize.net
        /// </summary>
        /// <param name="bankinfo"></param>
        /// <param name="strLoggedInUserId"></param>
        /// <param name="strErrorCode"></param>
        /// <param name="strErrorText"></param>
        /// <returns></returns>
        [OperationContract]
        long CreateCustomerBankProfile(BankAccountInfo_DC bankinfo, string strLoggedInUserId, out string strErrorCode, out string strErrorText);

        /// <summary>
        /// Fuction will create Payment profile for passed profileid (numeric customer profile id) on Authorize.net
        /// </summary>
        /// <param name="profileId"></param>
        /// <param name="strAuthorizationFlag"></param>
        /// <param name="strLoggedInUserId"></param>
        /// <param name="bankinfo"></param>
        /// <param name="strErrorCode"></param>
        /// <param name="strErrorText"></param>
        /// <returns></returns>
        [OperationContract]
        long CreateCustomerPaymentBankProfile(string profileId, string strAuthorizationFlag, string strLoggedInUserId, BankAccountInfo_DC bankinfo, out string strErrorCode, out string strErrorText);

        /// <summary>
        /// Function will Update Customer Payment Profile info on Authorize.net
        /// </summary>
        /// <param name="profileId"></param>
        /// <param name="paymentProfileId"></param>
        /// <param name="strAuthorizationFlag"></param>
        /// <param name="strLoggedInUserId"></param>
        /// <param name="bankinfo"></param>
        /// <param name="strErrorCode"></param>
        /// <param name="strErrorText"></param>
        /// <returns></returns>
        [OperationContract]
        bool UpdateCustomerPaymentBankProfile(string profileId, string paymentProfileId, string strAuthorizationFlag, string strLoggedInUserId, BankAccountInfo_DC bankinfo, out string strErrorCode, out string strErrorText);

        /// <summary>
        /// Function will Create a Transaction for paymentprofileid on Authorize.net
        /// </summary>
        /// <param name="profileId"></param>
        /// <param name="paymentProfileId"></param>
        /// <param name="LoggedInUserId"></param>
        /// <param name="bankinfo"></param>
        /// <param name="strErrorCode"></param>
        /// <param name="strErrorText"></param>
        /// <returns></returns>
        [OperationContract]
        string CreateBankTransaction(string profileId, string paymentProfileId, string LoggedInUserId, BankAccountInfo_DC bankinfoDC, string ReferenceId, out string strErrorCode, out string strErrorText);
        [OperationContract]
        bool DeleteCustomerBankProfile(string profileId, string LoggedInUserId, BankAccountInfo_DC bankinfo, out string strErrorCode, out string strErrorText);
        [OperationContract]
        bool DeleteCustomerPaymentBankProfile(string profileId, string paymentProfileId, string LoggedInUserId, BankAccountInfo_DC bankinfo, out string strErrorCode, out string strErrorText);
        [OperationContract]
        string ReceiveCreditAdvancePayment(string profileId, string paymentProfileId, string strLoggedInUserId, CreditCardInfo_DC CreditCardInfo, string ReferenceId, out string ErrorCode, out string ErrorText);
        [OperationContract]
        string ReceiveBankAdvancePayment(string profileId, string paymentProfileId, string strLoggedInUserId, BankAccountInfo_DC bankinfo, string ReferenceId, out string strErrorCode, out string strErrorText);
        

    }
    #region Data Contracts
    /// <summary>
    /// Summary description for CreditCardInfo
    /// </summary>
    [DataContract]
    public class CreditCardInfo_DC
    {
        [DataMember]
        public Guid Id { get; set; }
        // create customer profile
        [DataMember]
        public string merchantCustomerId { get; set; }
        [DataMember]
        public string email { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public string CardNumber { get; set; }//comparsery field for customer payment profile
        [DataMember]
        public string ExpiryYear { get; set; }
        [DataMember]
        public string ExpiryMonth { get; set; }
        [DataMember]
        public string CVV { get; set; }
        [DataMember]
        public decimal? Amount { get; set; }
        //comparsery field for customer payment profile
        [DataMember]
        public string accountNumber { get; set; }
        [DataMember]
        public string routingNumber { get; set; }
        //comparsery field for customer payment profile
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string ZipCode { get; set; }
        [DataMember]
        public string City { get; set; }
        [DataMember]
        public string OfficeName { get; set; }
        [DataMember]
        public string Country { get; set; }
        [DataMember]
        public string State { get; set; }
        [DataMember]
        public string company { get; set; }
        [DataMember]
        public string phoneNumber { get; set; }
        [DataMember]
        public string faxNumber { get; set; }
        [DataMember]
        public bool IsPrimary { get; set; }
        [DataMember]
        public string FranchiseId { get; set; }
        [DataMember]
        public int AgencyId { get; set; }
        [DataMember]
        public string InvoiceNumber { get; set; }
    }

    
    public class BankAccountInfo_DC
    {
        [DataMember]
        public Guid BankId { get; set; }
        // create customer profile
        [DataMember]
        public string merchantCustomerId { get; set; }
        [DataMember]
        public string AccountNumber { get; set; }
        [DataMember]
        public string RoutingNumber { get; set; }
        [DataMember]
        public string BankName { get; set; }
        [DataMember]
        public string NameOnAccount { get; set; }
        [DataMember]
        public decimal? Amount { get; set; }
        [DataMember]
        public string FranchiseId { get; set; }
        [DataMember]
        public int AgencyId { get; set; }
        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public string AccountType { get; set; }
        [DataMember]
        public string AuthorizationType { get; set; }
        [DataMember]
        public string CheckNumber { get; set; }
        [DataMember]
        public Int32 ACustomerProfileId { get; set; }
        [DataMember]
        public Int32 ACustomerPaymentProfileId { get; set; }
        [DataMember]
        public bool IsDefault { get; set; }
        [DataMember]
        public bool IsPrimary { get; set; }
        [DataMember]
        public DateTime CreatedOn { get; set; }
        [DataMember]
        public Guid CreatedBy { get; set; }
        [DataMember]
        public DateTime ModifiedOn { get; set; }
        [DataMember]
        public Guid ModifiedBy { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public bool IsArchived { get; set; }
        [DataMember]
        public Guid PayerId { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string ZipCode { get; set; }
        [DataMember]
        public string City { get; set; }
        [DataMember]
        public string OfficeName { get; set; }
        [DataMember]
        public string Country { get; set; }
        [DataMember]
        public string State { get; set; }
        [DataMember]
        public string company { get; set; }
        [DataMember]
        public string email { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public string phoneNumber { get; set; }
        [DataMember]
        public string faxNumber { get; set; }
        [DataMember]
        public Guid PaymentType { get; set; }
        [DataMember]
        public string PayerDisplayId { get; set; }

    }

    public class GetAPIIdAndTransactionKeyByFranchiseId_Result
    {
        public Guid? FranchiseId { get; set; }
        public string APIId { get; set; }
        public string TransactionKey { get; set; }

    }

    #endregion

}
