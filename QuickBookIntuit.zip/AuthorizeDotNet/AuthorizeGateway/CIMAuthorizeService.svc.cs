﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using AuthorizeWebService;

namespace AuthorizeGateway
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CIMAuthorizeService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select CIMAuthorizeService.svc or CIMAuthorizeService.svc.cs at the Solution Explorer and start debugging.
    public class CIMAuthorizeService : ICIMAuthorizeService
    {

        public long CreateCustomerProfile(CreditCardInfo_DC cardinfoDC, string strLoggedInUserId, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var creditCardInfo = obj.GetCardInfoFromDC(cardinfoDC);
                return obj.CreateCustomerProfile(creditCardInfo, strLoggedInUserId, out strErrorCode, out strErrorText);
            }

        }

        public long CreateCustomerPaymentProfile(string profileId, string strAuthorizationFlag, string strLoggedInUserId, CreditCardInfo_DC cardinfoDC, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var creditCardInfo = obj.GetCardInfoFromDC(cardinfoDC);
                return obj.CreateCustomerPaymentProfile(profileId, strAuthorizationFlag, strLoggedInUserId, creditCardInfo, out strErrorCode, out strErrorText);
            }
        }

        public bool UpdateCustomerPaymentProfile(string profileId, string paymentProfileId, string strAuthorizationFlag, string strLoggedInUserId, CreditCardInfo_DC cardinfoDC, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var creditCardInfo = obj.GetCardInfoFromDC(cardinfoDC);
                return obj.UpdateCustomerPaymentProfile(profileId, paymentProfileId, strAuthorizationFlag, strLoggedInUserId, creditCardInfo, out strErrorCode, out strErrorText);
            }

        }

        public string CreateTransaction(string profileId, string paymentProfileId, string LoggedInUserId, CreditCardInfo_DC cardinfoDC, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var creditCardInfo = obj.GetCardInfoFromDC(cardinfoDC);
                return obj.CreateTransaction(profileId, paymentProfileId, LoggedInUserId, creditCardInfo, out strErrorCode, out strErrorText);
            }
        }

        public bool DeleteCustomerProfile(string profileId, string LoggedInUserId, CreditCardInfo_DC cardinfoDC, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var creditCardInfo = obj.GetCardInfoFromDC(cardinfoDC);
                return obj.DeleteCustomerProfile(profileId, LoggedInUserId, creditCardInfo, out strErrorCode, out strErrorText);
            }
        }

        public bool DeleteCustomerPaymentProfile(string profileId, string paymentProfileId, string LoggedInUserId, CreditCardInfo_DC cardinfoDC, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var creditCardInfo = obj.GetCardInfoFromDC(cardinfoDC);
                return obj.DeleteCustomerPaymentProfile(profileId, paymentProfileId, LoggedInUserId, creditCardInfo, out strErrorCode, out strErrorText);
            }
        }

        public long CreateCustomerBankProfile(BankAccountInfo_DC bankinfoDC, string strLoggedInUserId, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var bankAccountInfo = obj.GetBankAccountInfoFromDC(bankinfoDC);
                return obj.CreateCustomerBankProfile(bankAccountInfo, strLoggedInUserId, out strErrorCode, out strErrorText);
            }

        }


        public long CreateCustomerPaymentBankProfile(string profileId, string strAuthorizationFlag, string strLoggedInUserId, BankAccountInfo_DC bankinfoDC, out string strErrorCode, out string strErrorText)
        {
            // summary
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var bankAccountInfo = obj.GetBankAccountInfoFromDC(bankinfoDC);
                return obj.CreateCustomerPaymentBankProfile(profileId, strAuthorizationFlag, strLoggedInUserId, bankAccountInfo, out strErrorCode, out strErrorText);
            }
        }

        public bool UpdateCustomerPaymentBankProfile(string profileId, string paymentProfileId, string strAuthorizationFlag, string strLoggedInUserId, BankAccountInfo_DC bankinfoDC, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var bankAccountInfo = obj.GetBankAccountInfoFromDC(bankinfoDC);
                return obj.UpdateCustomerPaymentBankProfile(profileId, paymentProfileId, strAuthorizationFlag, strLoggedInUserId, bankAccountInfo, out strErrorCode, out strErrorText);
            }

        }

        public string CreateBankTransaction(string profileId, string paymentProfileId, string LoggedInUserId, BankAccountInfo_DC bankinfoDC, string ReferenceId, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var bankAccountInfo = obj.GetBankAccountInfoFromDC(bankinfoDC);
                return obj.CreateBankTransaction(profileId, paymentProfileId, LoggedInUserId, bankAccountInfo, ReferenceId, out strErrorCode, out strErrorText);
            }
        }

        public bool DeleteCustomerBankProfile(string profileId, string LoggedInUserId, BankAccountInfo_DC bankinfoDC, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var bankAccountInfo = obj.GetBankAccountInfoFromDC(bankinfoDC);
                return obj.DeleteCustomerBankProfile(profileId, LoggedInUserId, bankAccountInfo, out strErrorCode, out strErrorText);
            }
        }

        public bool DeleteCustomerPaymentBankProfile(string profileId, string paymentProfileId, string LoggedInUserId, BankAccountInfo_DC bankinfoDC, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var bankAccountInfo = obj.GetBankAccountInfoFromDC(bankinfoDC);
                return obj.DeleteCustomerPaymentBankProfile(profileId, paymentProfileId, LoggedInUserId, bankAccountInfo, out strErrorCode, out strErrorText);
            }
        }

        public string ReceiveBankAdvancePayment(string profileId, string paymentProfileId, string LoggedInUserId, BankAccountInfo_DC bankinfoDC, string ReferenceId, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var bankAccountInfo = obj.GetBankAccountInfoFromDC(bankinfoDC);
                return obj.ReceiveBankAdvancePayment(profileId, paymentProfileId, LoggedInUserId, bankAccountInfo, ReferenceId, out strErrorCode, out strErrorText);
            }
        }

        public string ReceiveCreditAdvancePayment(string profileId, string paymentProfileId, string LoggedInUserId, CreditCardInfo_DC creditinfoDC, string ReferenceId, out string strErrorCode, out string strErrorText)
        {
            strErrorCode = string.Empty;
            strErrorText = string.Empty;
            using (CIMAuthorizeBLL obj = new CIMAuthorizeBLL())
            {
                var creditCardAccountInfo = obj.GetCardInfoFromDC(creditinfoDC);
                return obj.ReceiveCreditAdvancePayment(profileId, paymentProfileId, LoggedInUserId, creditCardAccountInfo, ReferenceId, out strErrorCode, out strErrorText);
            }
        }

    }
}
