﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TNPGatewaysAPI.Models;
using TNPGatewaysAPI.Models.ViewModel;

namespace AuthorizeWebServiceTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            //  p.CreateCustomerProfile();
            p.TransnationService();
        }


        public void TransnationService()
        {
            ServiceReference1.TransnationServiceClient serviceClient = new ServiceReference1.TransnationServiceClient();
            string response = serviceClient.MakeTransaction(JsonConvert.SerializeObject(new PaymentInitialize().GetTransactionInfo(PaymentMode.CARD)), "8F7B7B3-77D0-422A-AD5B-CBEE055776FF", 16);
            Console.Write(response);
            Console.ReadKey();
            // serviceClient.MakeTransaction()
        }

        public long CreateCustomerProfile()
        {
            long customerProfileId = 0;
            bool testVal = true;
            string st = Convert.ToString(testVal);
            string strCode = string.Empty;
            string strText = string.Empty;

            using (AuthorizeGatewayClient.CIMAuthorizeServiceClient cimServiceObj = new AuthorizeGatewayClient.CIMAuthorizeServiceClient())
            {
                #region Object prop info need to send to create customer profile
                //AuthorizeGatewayClient.CreditCardInfo_DC creditObj = new AuthorizeGatewayClient.CreditCardInfo_DC();
                //creditObj.FranchiseId = "38F7B7B3-77D0-422A-AD5B-CBEE055776FF";
                //creditObj.AgencyId = 16;
                //creditObj.merchantCustomerId = "675STRK765";
                //cimServiceObj.CreateCustomerProfile(creditObj, "44ED7BD6-91EB-E211-BAAC-00155D0A1914", out strCode, out strText);
                #endregion

                #region delete customer profile
                //AuthorizeGatewayClient.CreditCardInfo_DC creditObj = new AuthorizeGatewayClient.CreditCardInfo_DC();
                //creditObj.FranchiseId = "38F7B7B3-77D0-422A-AD5B-CBEE055776FF";
                //creditObj.AgencyId = 16;
                //cimServiceObj.DeleteCustomerProfile("1919019024", "44ED7BD6-91EB-E211-BAAC-00155D0A1914", creditObj, out strCode, out strText);
                #endregion

                #region Object prop info need to send to create customer payment profile
                AuthorizeGatewayClient.CreditCardInfo_DC creditObj = new AuthorizeGatewayClient.CreditCardInfo_DC();
                creditObj.FranchiseId = "38F7B7B3-77D0-422A-AD5B-CBEE055776FF";
                creditObj.AgencyId = 16;
                creditObj.CardNumber = "370000000000002";
                creditObj.ExpiryYear = "20";
                creditObj.ExpiryMonth = "05";
                creditObj.CVV = "145";
                creditObj.FirstName = "Dharmender";
                creditObj.LastName = "Kumar";
                creditObj.Address = "#23432 test address for test credit card";
                creditObj.City = "Chandigarh";
                creditObj.State = "Panjab";
                creditObj.ZipCode = "46203";
                creditObj.Country = "India";
                cimServiceObj.CreateCustomerPaymentProfile("1919019081", "0", "44ED7BD6-91EB-E211-BAAC-00155D0A1914", creditObj, out strCode, out strText);
                #endregion

                #region Object prop info need to send to Update customer payment profile
                //AuthorizeGatewayClient.CreditCardInfo_DC creditObj = new AuthorizeGatewayClient.CreditCardInfo_DC();
                //creditObj.FranchiseId = "38F7B7B3-77D0-422A-AD5B-CBEE055776FF";
                //creditObj.AgencyId = 16;
                //creditObj.CardNumber = "370000000000002";
                //creditObj.ExpiryYear = "20";
                //creditObj.ExpiryMonth = "05";
                //creditObj.CVV = "145";
                //creditObj.FirstName = "Navjot";
                //creditObj.LastName = "Singh";
                //creditObj.Address = "#657 CHD";
                //creditObj.City = "Chandigarh";
                //creditObj.State = "Panjab";
                //creditObj.ZipCode = "46203";
                //creditObj.Country = "India";
                //cimServiceObj.UpdateCustomerPaymentProfile("1919019081", "1832021683", "0", "44ED7BD6-91EB-E211-BAAC-00155D0A1914", creditObj, out strCode, out strText);
                #endregion
                #region Object prop info need to send to Update customer payment profile
                //AuthorizeGatewayClient.CreditCardInfo_DC creditObj = new AuthorizeGatewayClient.CreditCardInfo_DC();
                //creditObj.FranchiseId = "38F7B7B3-77D0-422A-AD5B-CBEE055776FF";
                //creditObj.AgencyId = 16;
                //creditObj.InvoiceNumber = "INV1098";
                //creditObj.Amount = Convert.ToDecimal("1.1");
                //cimServiceObj.CreateTransaction("1919019081", "1832021683", "44ED7BD6-91EB-E211-BAAC-00155D0A1914", creditObj, out strCode, out strText);
                #endregion
            }

            return customerProfileId;
        }
    }
}
