﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TNPGatewaysAPI.Models.ViewModel;
using TNPGatewaysAPI.Models.ViewModel.Transaction;
using System.Data;

namespace TNPGatewaysAPI.Models
{
    public class PaymentInitialize
    {

        public Transaction GetTransactionInfo(PaymentMode mode,DataSet ds=null)
        {
            try
            {
                Transaction transaction = new Transaction();
                transaction.type = "sale";
                transaction.amount = 1112;
                transaction.tax_amount = 100;
                transaction.shipping_amount = 100;
                transaction.currency = "USD";
                transaction.description = "test transaction";
                transaction.order_id = new Random().Next().ToString();
                transaction.po_number = new Random().Next().ToString();
                transaction.ip_address = "4.2.2.2";
                transaction.email_address = "user@home.com";
                transaction.create_vault_record = true;
                transaction.payment_method = GetPaymentMethodsInfo(mode, null);
                transaction.billing_address = GetBillingAddressInfo();
                transaction.shipping_address = GetShippingAddressInfo();
                return transaction;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Dictionary<string, object> GetPaymentMethodsInfo(PaymentMode paymentMode, DataTable table = null)
        {
            Dictionary<string, object> keyValues = new Dictionary<string, object>();
            try
            {
                if (paymentMode == PaymentMode.CARD)
                {
                    Card card = new Card();
                    card.entry_type = "keyed";
                    card.number = "4012000098765439";
                    card.expiration_date = "12/20";
                    card.cvc = "999";
                    //  card.cardholder_authentication = new CardholderAuthentication() { condition = "", eci = "", cavv = "", xid = "" };
                    keyValues.Add("Card", card);
                }
                else if (paymentMode == PaymentMode.ACH)
                {
                    ACH ach = new ACH();
                    ach.routing_number = "490000018";
                    ach.account_number = "999999";
                    ach.sec_code = "ccd";
                    ach.account_type = "checking";
                    ach.check_number = "1223";
                    ach.accountholder_authentication = new AccountholderAuthentication() { dl_state = "IL", dl_number = "r500123123" };
                    keyValues.Add("ach", ach);
                }
                else if (paymentMode == PaymentMode.TERMINAL)
                {
                    Terminal terminal = new Terminal();
                    terminal.id = "<terminal id>";
                    terminal.expiration_date = "12/20";
                    terminal.cvc = "999";
                    terminal.print_receipt = "both";
                    terminal.signature_required = true;
                    keyValues.Add("terminal", terminal);
                }
                else if (paymentMode == PaymentMode.CUSTOMER)
                {
                    Customer customer = new Customer();
                    customer.id = "b798ls2q9qq646ksu070";
                    customer.payment_method_type = "card";
                    customer.payment_method_id = "b798ls2q9qq646ksu080";
                    customer.billing_address_id = "b798ls2q9qq646ksu07g";
                    customer.shipping_address_id = "b798ls2q9qq646ksu07g";
                    keyValues.Add("customer", customer);
                }
                else if (paymentMode == PaymentMode.TOKEN)
                {
                    Token token = new Token();
                    token.token = "<tokenizer token goes here>";
                    keyValues.Add("token", token);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return keyValues;
        }

        public BillingAddress GetBillingAddressInfo(DataTable table = null)
        {
            try
            {
                BillingAddress billingAddress = new BillingAddress();
                billingAddress.first_name = "John";
                billingAddress.last_name = "Smith";
                billingAddress.company = "Test Company";
                billingAddress.address_line_1 = "123 Some St";
                billingAddress.city = "Wheaton";
                billingAddress.state = "IL";
                billingAddress.postal_code = "60187";
                billingAddress.country = "US";
                billingAddress.phone = "5555555555";
                billingAddress.fax = "5555555555";
                billingAddress.email = "help@website.com";
                return billingAddress;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ShippingAddress GetShippingAddressInfo(DataTable table = null)
        {
            try
            {
                ShippingAddress shippingAddress = new ShippingAddress();
                shippingAddress.first_name = "John";
                shippingAddress.last_name = "Smith";
                shippingAddress.company = "Test Company";
                shippingAddress.address_line_1 = "123 Some St";
                shippingAddress.city = "Wheaton";
                shippingAddress.state = "IL";
                shippingAddress.postal_code = "60187";
                shippingAddress.country = "US";
                shippingAddress.phone = "5555555555";
                shippingAddress.fax = "5555555555";
                shippingAddress.email = "help@website.com";
                return shippingAddress;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}