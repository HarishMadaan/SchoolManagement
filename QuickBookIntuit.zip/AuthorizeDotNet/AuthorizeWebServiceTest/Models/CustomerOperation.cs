﻿using Newtonsoft.Json;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using TNPGatewaysAPI.Models.ViewModel;
using TNPGatewaysAPI.Models.ViewModel.CreateCustomer;
using TNPGatewaysAPI.Models.ViewModel.CreateCustomerResponse;
using TNPGatewaysAPI.Models.ViewModel.UpdateCustomer;
using TNPGatewaysAPI.Models.ViewModel.UpdateCustomerResponse;
using TransnationalPaymentGateway;

namespace TNPGatewaysAPI.Models
{
    public class CustomerOperation : IDisposable
    {
        #region Create New Customer
        /// <summary>
        /// This endpoint creates a new customer token
        /// </summary>
        /// <param name="card_number"></param>
        /// <param name="expiration_date"></param>
        /// <param name="api_key"></param>
        public string CreateCustomer(CreateCustomer info, string franchise_id, int agency_id)
        {
            try
            {
                using (TNPBLL tnpbll = new TNPBLL())
                {
                    tnpbll.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPTransactionEndpoint);

                    var http = (HttpWebRequest)WebRequest.Create(new Uri(url));
                    http.Accept = "application/json";
                    http.ContentType = "application/json";

                    http.Headers.Add("Authorization", tnpbll.api_key);
                    http.Method = "POST";

                    //Customer info = new CustomerInitialize().GetCustomerInfo(new DataSet(), card_number, expiration_date);

                    string parsedContent = JsonConvert.SerializeObject(info);

                    ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] bytes = encoding.GetBytes(parsedContent);

                    Stream newStream = http.GetRequestStream();
                    newStream.Write(bytes, 0, bytes.Length);
                    newStream.Close();

                    var response = http.GetResponse();

                    var stream = response.GetResponseStream();
                    var sr = new StreamReader(stream);
                    var content = sr.ReadToEnd();

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);

                    return JsonConvert.SerializeObject(customer_response);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        #region Update Customer
        /// <summary>
        /// This endpoint updates a specific customer token.
        /// </summary>
        /// <param name="customer_id"></param>
        /// <param name="api_key"></param>
       // public void UpdateCustomer(string customer_id)
        public string UpdateCustomer(UpdateCustomer info, string franchise_id, int agency_id, string customer_id)
        {
            try
            {
                using (TNPBLL tnpbll = new TNPBLL())
                {
                    tnpbll.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPUpdateSpecificCustomer).Replace("##CustomerID##", customer_id);

                    var http = (HttpWebRequest)WebRequest.Create(new Uri(url));
                    http.Accept = "application/json";
                    http.ContentType = "application/json";

                    http.Headers.Add("Authorization", tnpbll.api_key);
                    http.Method = "POST";

                    //UpdateCustomer info = new CustomerInitialize().GetSpecificCustomerToUpdate(new DataSet());

                    string parsedContent = JsonConvert.SerializeObject(info);

                    ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] bytes = encoding.GetBytes(parsedContent);

                    Stream newStream = http.GetRequestStream();
                    newStream.Write(bytes, 0, bytes.Length);
                    newStream.Close();

                    var response = http.GetResponse();

                    var stream = response.GetResponseStream();
                    var sr = new StreamReader(stream);
                    var content = sr.ReadToEnd();

                    UpdateCustomerResponse customer_response = JsonConvert.DeserializeObject<UpdateCustomerResponse>(content);

                    return JsonConvert.SerializeObject(customer_response);
                }
            }
            //  data
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        #region Update CustomerAddress
        /// <summary>
        /// This endpoint updates a specific address token
        /// </summary>
        /// <param name="customer_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="address_type"> 'B' For Billing Address And 'S' For Shipping Address</param>
        /// <summary>
        public string UpdateCustomerAddress(string customer_id, string address_id, string franchise_id, int agency_id, char address_type = 'B')
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPUpdateCustomerAddress).Replace("##CustomerID##", customer_id).Replace("##AddressID##", address_id);

                    var http = (HttpWebRequest)WebRequest.Create(new Uri(url));
                    http.Accept = "application/json";
                    http.ContentType = "application/json";

                    http.Headers.Add("Authorization", objBLL.api_key);
                    http.Method = "POST";
                    string parsedContent = JsonConvert.SerializeObject(objBLL.GetCustomerBillingShippingAddress(customer_id, address_type, agency_id));

                    ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] bytes = encoding.GetBytes(parsedContent);

                    Stream newStream = http.GetRequestStream();
                    newStream.Write(bytes, 0, bytes.Length);
                    newStream.Close();

                    var response = http.GetResponse();

                    var stream = response.GetResponseStream();
                    var sr = new StreamReader(stream);
                    var content = sr.ReadToEnd();

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);

                    return JsonConvert.SerializeObject(customer_response);
                }            
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        #region update specific payment token
        /// <summary>
        /// This endpoint updates a specific payment token.
        /// </summary>
        /// <param name="customer_id"></param>
        /// <param name="payment_id"></param>
        /// <param name="card_number"></param>
        /// <param name="expiration_date"></param>
        /// <param name="api_key"></param>
        public string UpdateSpecificTokenAddress(string customer_id, string payment_id, string card_number, string expiration_date, string franchise_id, int agency_id)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPUpdateSpecificPaymentToken).Replace("##CustomerID##", customer_id).Replace("##PaymentID##", payment_id);

                    var http = (HttpWebRequest)WebRequest.Create(new Uri(url));
                    http.Accept = "application/json";
                    http.ContentType = "application/json";

                    http.Headers.Add("Authorization", objBLL.api_key);
                    http.Method = "POST";
                    string parsedContent = string.Empty;

                    parsedContent = JsonConvert.SerializeObject(new CustomerInitialize().CreateNewPaymentTokenObject(card_number, expiration_date));

                    ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] bytes = encoding.GetBytes(parsedContent);

                    Stream newStream = http.GetRequestStream();
                    newStream.Write(bytes, 0, bytes.Length);
                    newStream.Close();

                    var response = http.GetResponse();

                    var stream = response.GetResponseStream();
                    var sr = new StreamReader(stream);
                    var content = sr.ReadToEnd();

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);

                    return JsonConvert.SerializeObject(customer_response);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        #region Get Specific customer
        /// <summary>
        /// This endpoint retrieves a specific customer.
        /// </summary>
        /// <param name="customer_id"></param>
        /// <param name="api_key"></param>
        public string GetSpecificCustomer(string customer_id, string franchise_id, int agency_id)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPGetSpecificCustomer).Replace("##CustomerID##", customer_id);

                    var http = (HttpWebRequest)WebRequest.Create(new Uri(url));
                    http.Accept = "application/json";
                    http.ContentType = "application/json";

                    http.Headers.Add("Authorization", objBLL.api_key);
                    http.Method = "GET";
                    string parsedContent = string.Empty;

                    var response = http.GetResponse();

                    var stream = response.GetResponseStream();
                    var sr = new StreamReader(stream);
                    var content = sr.ReadToEnd();

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);
                   
                    return JsonConvert.SerializeObject(customer_response);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        #region Delete Specific customer
        public string DeleteSpecificCustomer(string customer_id, string franchise_id, int agency_id)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPGetSpecificCustomer).Replace("##CustomerID##", customer_id);

                    var http = (HttpWebRequest)WebRequest.Create(new Uri(url));
                    http.Accept = "application/json";
                    http.ContentType = "application/json";

                    http.Headers.Add("Authorization", objBLL.api_key);
                    http.Method = "DELETE";
                    string parsedContent = string.Empty;

                    var response = http.GetResponse();

                    var stream = response.GetResponseStream();
                    var sr = new StreamReader(stream);
                    var content = sr.ReadToEnd();

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);
                    
                    return JsonConvert.SerializeObject(customer_response);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}