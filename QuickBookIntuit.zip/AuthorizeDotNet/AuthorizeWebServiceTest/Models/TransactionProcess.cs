﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Text;
using TNPGatewaysAPI.Models.ViewModel;
using TNPGatewaysAPI.Models.ViewModel.CardResponse;
using System.Data;
using TNPGatewaysAPI.Models.ViewModel.ACHResponse;
using TNPGatewaysAPI.Models.ViewModel.TerminalResponse;
using TNPGatewaysAPI.Models.ViewModel.Transaction;
using TransnationalPaymentGateway;

namespace TNPGatewaysAPI.Models
{
    public class TransactionProcess
    {
        //   public void MakeTransaction(string somevalue, PaymentMode mode, string api_key = "api_1KLMMWqPru4clgseE2sHSKKMBdR")
        public string MakeTransaction(Transaction transaction, PaymentMode mode, string franchise_id, int agency_id)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);

                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPTransactionEndpoint);

                    var http = (HttpWebRequest)WebRequest.Create(new Uri(url));
                    http.Accept = "application/json";
                    http.ContentType = "application/json";

                    http.Headers.Add("Authorization", objBLL.api_key);
                    http.Method = "POST";

                    //Payment mode comes from database
                    // mode = PaymentMode.CARD;
                    //DataSet ds = null; // dataset comes from database
                    //  Transaction transaction = new PaymentInitialize().GetTransactionInfo(mode, ds);

                    //Transaction transaction = new PaymentInitialize().GetTransactionInfo(mode, ds);

                    string parsedContent = JsonConvert.SerializeObject(transaction);

                    ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] bytes = encoding.GetBytes(parsedContent);

                    Stream newStream = http.GetRequestStream();
                    newStream.Write(bytes, 0, bytes.Length);
                    newStream.Close();

                    var response = http.GetResponse();

                    var stream = response.GetResponseStream();

                    var sr = new StreamReader(stream);
                    var content = sr.ReadToEnd();

                    return JsonConvert.SerializeObject(content);

                    //if (mode == PaymentMode.CARD)
                    //{
                    //    CardRootObject cardResponse = JsonConvert.DeserializeObject<CardRootObject>(content);
                    //}
                    //else if (mode == PaymentMode.ACH)
                    //{
                    //    ACHRootObject cardResponse = JsonConvert.DeserializeObject<ACHRootObject>(content);
                    //}
                    //else if (mode == PaymentMode.TERMINAL)
                    //{
                    //    TerminalRootObject cardResponse = JsonConvert.DeserializeObject<TerminalRootObject>(content);
                    //}
                    //else if (mode == PaymentMode.CUSTOMER)
                    //{
                    //    CardRootObject cardResponse = JsonConvert.DeserializeObject<CardRootObject>(content);
                    //}
                    //else if (mode == PaymentMode.TOKEN)
                    //{
                    //    //implement later
                    //}
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

       
    }
}