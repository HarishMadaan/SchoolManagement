﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TNPGatewaysAPI.Models.ViewModel.UpdateCustomer
{
    public class UpdateCustomer
    {
        public string description { get; set; }
        public string payment_method { get; set; }
        public string payment_method_id { get; set; }
        public string billing_address_id { get; set; }
        public string shipping_address_id { get; set; }
    }
}