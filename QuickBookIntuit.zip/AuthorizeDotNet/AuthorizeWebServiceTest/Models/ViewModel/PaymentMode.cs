﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TNPGatewaysAPI.Models.ViewModel
{
    public enum PaymentMode
    {
        CARD = 1,
        ACH = 2,
        CUSTOMER = 3,
        TERMINAL = 4,
        TOKEN = 5
    }
}