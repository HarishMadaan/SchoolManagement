﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TNPGatewaysAPI.Models.ViewModel.TNPResponseCode
{
    public enum TNPResponseCode
    {
        /// <summary>
        /// Unknown
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Approved
        /// </summary>
        Approved = 100,

        /// <summary>
        /// Partial approval
        /// </summary>
        PartialApproval = 110,

        /// <summary>
        /// Approved, pending customer approval
        /// </summary>
        ApprovedPendingCustomerApproval = 101,

        /// <summary>
        /// Decline
        /// </summary>
        Decline = 200,

        /// <summary>
        /// Do not honor
        /// </summary>
        DoNotHonor = 201,

        /// <summary>
        /// Insufficient funds
        /// </summary>
        InsufficientFunds = 202,

        /// <summary>
        /// Excededs withdrawl limit
        /// </summary>
        ExcededsWithdrawlLimit = 203,

        /// <summary>
        /// Invalid Transaction

        /// </summary>
        InvalidTransaction = 204,

        /// <summary>
        /// Invalid Amount
        /// </summary>
        InvalidAmount = 220,

        /// <summary>
        /// No such Issuer
        /// </summary>
        NoSuchIssuer = 221,

        /// <summary>
        /// No credit Acct
        /// </summary>
        NoCreditAcct = 222,

        /// <summary>
        /// Expired Card
        /// </summary>
        ExpiredCard = 223,

        /// <summary>
        /// Invalid CVC
        /// </summary>
        InvalidCVC = 225,

        /// <summary>
        /// Cannot Verify Pin
        /// </summary>
        CannotVerifyPin = 226,

        /// <summary>
        /// Refer to issuer
        /// </summary>
        ReferToIssuer = 240,

        /// <summary>
        /// Pick up card (no fraud)
        /// </summary>
        PickUpCard = 250,

        /// <summary>
        /// Lost card, pick up (fraud account)
        /// </summary>
        LostCardPickUp = 251,

        /// <summary>
        /// Stolen card, pick up (fraud account)
        /// </summary>
        StolenCardPickUp = 252,

        /// <summary>
        /// Pick up card, special condition
        /// </summary>
        PickUpCardSpecialCondition = 253,

        /// <summary>
        /// Stop recurring
        /// </summary>
        StopRecurring = 261,

        /// <summary>
        /// Stop recurring
        /// </summary>
        StopRecurring1 = 262,

        /// <summary>
        /// Gateway Decline
        /// </summary>
        GatewayDecline = 300,

        /// <summary>
        /// Gateway Decline - Rule Engine
        /// </summary>
        GatewayDeclineRuleEngine = 310,

        /// <summary>
        /// Transaction error returned by processor
        /// </summary>
        TransactionErrorReturnedByProcessor = 400,

        /// <summary>
        /// Invalid merchant configuration
        /// </summary>
        InvalidMerchantConfiguration = 410,

        /// <summary>
        /// Communication error with processor
        /// </summary>
        CommunicationErrorWithProcessor = 421,

        /// <summary>
        /// Duplicate transaction at processo
        /// </summary>
        DuplicateTransactionAtProcessor = 430,

        /// <summary>
        /// Processor Format error
        /// </summary>
        ProcessorFormatError = 440
    }
}