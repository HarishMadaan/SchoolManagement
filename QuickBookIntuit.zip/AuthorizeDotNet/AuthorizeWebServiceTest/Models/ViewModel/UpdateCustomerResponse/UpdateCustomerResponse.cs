﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TNPGatewaysAPI.Models.ViewModel.UpdateCustomerResponse
{
    public class UpdateCustomerResponse
    {
        public string status { get; set; }
        public string msg { get; set; }
        public object data { get; set; }
    }
}