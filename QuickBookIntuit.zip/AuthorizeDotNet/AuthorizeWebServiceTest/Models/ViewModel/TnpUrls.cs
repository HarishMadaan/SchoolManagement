﻿using System.Configuration;

namespace TNPGatewaysAPI.Models.ViewModel
{
    public class TnpUrls
    {
        public static string TNPBaseURL = ConfigurationManager.AppSettings["TNPBaseURL"];
        public static string TNPTransactionEndpoint = ConfigurationManager.AppSettings["TNPTransactionEndPointURL"];
        public static string TNPCreateNewCustomer = ConfigurationManager.AppSettings["TNPCustomerCreate"];
        public static string TNPGetSpecificCustomer = ConfigurationManager.AppSettings["TNPGetSpecificCustomer"];
        public static string TNPUpdateSpecificCustomer = ConfigurationManager.AppSettings["TNPUpdateSpecificCustomer"];
        public static string TNPUpdateCustomerAddress = ConfigurationManager.AppSettings["TNPUpdateCustomerAddress"];
        public static string TNPUpdateSpecificPaymentToken = ConfigurationManager.AppSettings["TNPUpdateSpecificPaymentToken"];
        public static string TNPDeleteSpecificCustomer = ConfigurationManager.AppSettings["TNPDeleteSpecificCustomer"];

    }
}