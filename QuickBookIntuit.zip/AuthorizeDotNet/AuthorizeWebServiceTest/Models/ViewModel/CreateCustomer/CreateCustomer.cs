﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TNPGatewaysAPI.Models.ViewModel.CreateCustomer
{
    public class Card
    {
        public string card_number { get; set; }
        public string expiration_date { get; set; }
    }

    public class PaymentMethod
    {
        public Card card { get; set; }
    }

    public class CreateCustomer
    {
        public string description { get; set; }
        public PaymentMethod payment_method { get; set; }
        public BillingAddress billing_address { get; set; }
        public ShippingAddress shipping_address { get; set; }
    }
}