﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TNPGatewaysAPI.Models.ViewModel.ACHResponse
{
    public class ProcessorSpecific
    {
        public List<string> result_codes { get; set; }
        public List<string> type_codes { get; set; }
    }

    public class Ach
    {
        public string id { get; set; }
        public string sec_code { get; set; }
        public string account_type { get; set; }
        public string masked_account_number { get; set; }
        public string routing_number { get; set; }
        public string auth_code { get; set; }
        public string response { get; set; }
        public int response_code { get; set; }
        public string processor_response_code { get; set; }
        public string processor_response_text { get; set; }
        public string processor_type { get; set; }
        public string processor_id { get; set; }
        public ProcessorSpecific processor_specific { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
    }

    public class ResponseBody
    {
        public Ach ach { get; set; }
    }

  
    public class Data
    {
        public string id { get; set; }
        public string user_id { get; set; }
        public string user_name { get; set; }
        public string idempotency_key { get; set; }
        public int idempotency_time { get; set; }
        public string type { get; set; }
        public int amount { get; set; }
        public int amount_authorized { get; set; }
        public int amount_captured { get; set; }
        public int amount_settled { get; set; }
        public int tip_amount { get; set; }
        public string processor_id { get; set; }
        public string processor_type { get; set; }
        public string processor_name { get; set; }
        public string payment_method { get; set; }
        public string payment_type { get; set; }
        public int tax_amount { get; set; }
        public bool tax_exempt { get; set; }
        public int shipping_amount { get; set; }
        public int discount_amount { get; set; }
        public string payment_adjustment_type { get; set; }
        public int payment_adjustment_value { get; set; }
        public string currency { get; set; }
        public string description { get; set; }
        public string order_id { get; set; }
        public string po_number { get; set; }
        public string ip_address { get; set; }
        public string transaction_source { get; set; }
        public bool email_receipt { get; set; }
        public string email_address { get; set; }
        public string customer_id { get; set; }
        public string referenced_transaction_id { get; set; }
        public ResponseBody response_body { get; set; }
        public string status { get; set; }
        public string response { get; set; }
        public int response_code { get; set; }
        public BillingAddress billing_address { get; set; }
        public ShippingAddress shipping_address { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
        public object captured_at { get; set; }
        public object settled_at { get; set; }
    }

    public class ACHRootObject
    {
        public string status { get; set; }
        public string msg { get; set; }
        public Data data { get; set; }
    }
}