﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace TNPGatewaysAPI.Models.ViewModel.Transaction
{
    [DataContract]
    public class Transaction
    {
        [DataMember]
        /// <summary>
        /// Sale, Authorize, Credit 
        /// </summary>
        public string type { get; set; }

        [DataMember]
        /// <summary>
        /// Processed Amount in cents. 1299 = $12.99
        /// </summary>
        public int amount { get; set; }

        [DataMember]
        /// <summary>
        /// Tax Amount in cents.
        /// </summary>    
        public int tax_amount { get; set; }

        [DataMember]
        /// <summary>
        /// Shipping Amount in cents. (Should be included in Amount)
        /// </summary>
        public int shipping_amount { get; set; }

        [DataMember]
        /// <summary>
        /// ISO 4217 currency. Ex USD
        /// </summary>
        public string currency { get; set; }

        [DataMember]
        /// <summary>
        /// Text field, 0-255 characters
        /// </summary>
        public string description { get; set; }

        [DataMember]
        /// <summary>
        /// Order id
        /// </summary>
        public string order_id { get; set; }

        [DataMember]
        /// <summary>
        /// po number
        /// </summary>
        public string po_number { get; set; }

        [DataMember]
        /// <summary>
        /// IPv4 or IPv6 value of the end user
        /// </summary>
        public string ip_address { get; set; }

        [DataMember]
        /// <summary>
        /// Bool value to trigger sending of an email recept if an email was provided.
        /// </summary>
        public bool email_receipt { get; set; }

        [DataMember]
        /// <summary>
        /// email address  of customer
        /// </summary>
        public string email_address { get; set; }

        [DataMember]
        /// <summary>
        /// Bool value to trigger the creation of a customer vault record, if the transaction is successful
        /// </summary>
        public bool create_vault_record { get; set; }

        // public PaymentMethod payment_method { get; set; } 
        [DataMember]
        public Dictionary<string, object> payment_method { get; set; }
        [DataMember]
        public BillingAddress billing_address { get; set; }
        [DataMember]
        public ShippingAddress shipping_address { get; set; }
    }

    [DataContract]
    public class Card
    {
        [DataMember]
        public string entry_type { get; set; }
        [DataMember]
        public string number { get; set; }
        [DataMember]
        public string expiration_date { get; set; }
        [DataMember]
        public string cvc { get; set; }
        // public CardholderAuthentication cardholder_authentication { get; set; }
    }

    [DataContract]
    public class ACH
    {
        [DataMember]
        public string routing_number { get; set; }

        [DataMember]
        public string account_number { get; set; }

        [DataMember]
        public string sec_code { get; set; }

        [DataMember]
        public string account_type { get; set; }

        [DataMember]
        public string check_number { get; set; }

        [DataMember]
        public AccountholderAuthentication accountholder_authentication { get; set; }
    }

    [DataContract]
    public class Customer
    {
        [DataMember]
        public string id { get; set; }
        [DataMember]
        public string payment_method_type { get; set; }
        [DataMember]
        public string payment_method_id { get; set; }
        [DataMember]
        public string billing_address_id { get; set; }
        [DataMember]
        public string shipping_address_id { get; set; }
    }

    [DataContract]
    public class Terminal
    {
        [DataMember]
        public string id { get; set; }
        [DataMember]
        public string expiration_date { get; set; }
        [DataMember]
        public string cvc { get; set; }
        [DataMember]
        public string print_receipt { get; set; }
        [DataMember]
        public bool signature_required { get; set; }
    }

    [DataContract]
    public class Token
    {
        [DataMember]
        public string token { get; set; }
    }

    [DataContract]
    public class AccountholderAuthentication
    {
        [DataMember]
        public string dl_state { get; set; }
        [DataMember]
        public string dl_number { get; set; }
    }

    [DataContract]
    public class CardholderAuthentication
    {
        [DataMember]
        public string condition { get; set; }
        [DataMember]
        public string eci { get; set; }
        [DataMember]
        public string cavv { get; set; }
        [DataMember]
        public string xid { get; set; }
    }
}