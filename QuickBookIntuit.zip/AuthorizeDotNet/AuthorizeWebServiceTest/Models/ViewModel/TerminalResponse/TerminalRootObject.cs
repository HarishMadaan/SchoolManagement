﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TNPGatewaysAPI.Models.ViewModel.TerminalResponse
{
    public class ProcessorSpecific
    {
        public string BatchNum { get; set; }
        public string CashBack { get; set; }
        public string ClerkID { get; set; }
        public string DISC { get; set; }
        public string EBTCashAvailBalance { get; set; }
        public string EBTCashBeginBalance { get; set; }
        public string EBTCashLedgerBalance { get; set; }
        public string EBTFSAvailBalance { get; set; }
        public string EBTFSBeginBalance { get; set; }
        public string EBTFSLedgerBalance { get; set; }
        public string Fee { get; set; }
        public string InvNum { get; set; }
        public string Language { get; set; }
        public string ProcessData { get; set; }
        public string RefNo { get; set; }
        public string RewardCode { get; set; }
        public string RewardQR { get; set; }
        public string RwdBalance { get; set; }
        public string RwdIssued { get; set; }
        public string RwdPoints { get; set; }
        public string SHFee { get; set; }
        public string SVC { get; set; }
        public string TableNum { get; set; }
        public string TicketNum { get; set; }
        public string Tip { get; set; }
        public string TotalAmt { get; set; }
    }

    public class Terminal
    {
        public string id { get; set; }
        public string card_type { get; set; }
        public string payment_type { get; set; }
        public string entry_type { get; set; }
        public string first_four { get; set; }
        public string last_four { get; set; }
        public string masked_card { get; set; }
        public string cardholder_name { get; set; }
        public string auth_code { get; set; }
        public int response_code { get; set; }
        public string processor_response_text { get; set; }
        public ProcessorSpecific processor_specific { get; set; }
        public string emv_aid { get; set; }
        public string emv_app_name { get; set; }
        public string emv_tvr { get; set; }
        public string emv_tsi { get; set; }
        public string signature_data { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
    }

    public class ResponseBody
    {
        public Terminal terminal { get; set; }
    }

    public class Data
    {
        public string id { get; set; }
        public string user_id { get; set; }
        public string idempotency_key { get; set; }
        public int idempotency_time { get; set; }
        public string type { get; set; }
        public int amount { get; set; }
        public int amount_authorized { get; set; }
        public int amount_captured { get; set; }
        public int amount_settled { get; set; }
        public string processor_id { get; set; }
        public string processor_type { get; set; }
        public string payment_method { get; set; }
        public string payment_type { get; set; }
        public int tax_amount { get; set; }
        public bool tax_exempt { get; set; }
        public int shipping_amount { get; set; }
        public int discount_amount { get; set; }
        public string payment_adjustment_type { get; set; }
        public int payment_adjustment_value { get; set; }
        public string currency { get; set; }
        public string description { get; set; }
        public string order_id { get; set; }
        public string po_number { get; set; }
        public string ip_address { get; set; }
        public string transaction_source { get; set; }
        public bool email_receipt { get; set; }
        public string customer_id { get; set; }
        public string referenced_transaction_id { get; set; }
        public ResponseBody response_body { get; set; }
        public string status { get; set; }
        public string response { get; set; }
        public int response_code { get; set; }
        public BillingAddress billing_address { get; set; }
        public ShippingAddress shipping_address { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
        public DateTime captured_at { get; set; }
        public object settled_at { get; set; }
    }

    public class TerminalRootObject
    {
        public string status { get; set; }
        public string msg { get; set; }
        public Data data { get; set; }
    }
}