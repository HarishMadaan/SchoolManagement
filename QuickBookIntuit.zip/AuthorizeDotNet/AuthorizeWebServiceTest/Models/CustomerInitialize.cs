﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using TNPGatewaysAPI.Models.ViewModel;
using TNPGatewaysAPI.Models.ViewModel.CreateCustomer;
using TNPGatewaysAPI.Models.ViewModel.UpdateCustomer;

namespace TNPGatewaysAPI.Models
{
    public class CustomerInitialize:IDisposable
    {
        #region create new customer
        //public Customer GetCustomerInfo(DataSet ds, string card_number, string expiration_date)
        public CreateCustomer GetCustomerInfo(CreateCustomer info)
        {
            CreateCustomer customer = new CreateCustomer();
            customer.description = "test description";
            // customer.payment_method = GetCustomerPaymentMethod(card, expiration_date);
            customer.payment_method = GetCustomerPaymentMethod(info.payment_method.card.card_number, info.payment_method.card.expiration_date);
            customer.billing_address = info.billing_address;
            customer.shipping_address = info.shipping_address;
            return customer;
        }

        public PaymentMethod GetCustomerPaymentMethod(string card_number, string expiration_date)
        {
            Card card = new Card();
            card.card_number = card_number;
            card.expiration_date = expiration_date;
            PaymentMethod payment = new PaymentMethod();
            payment.card = card;
            return payment;
        }

        public BillingAddress GetBillingAddressInfo(DataTable table = null)
        {
            try
            {
                BillingAddress billingAddress = new BillingAddress();
                billingAddress.first_name = "John";
                billingAddress.last_name = "Smith";
                billingAddress.company = "Test Company";
                billingAddress.address_line_1 = "123 Some St";
                billingAddress.city = "Wheaton";
                billingAddress.state = "IL";
                billingAddress.postal_code = "60187";
                billingAddress.country = "US";
                billingAddress.phone = "5555555555";
                billingAddress.fax = "5555555555";
                billingAddress.email = "help@website.com";
                return billingAddress;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ShippingAddress GetShippingAddressInfo(DataTable table = null)
        {
            try
            {
                ShippingAddress shippingAddress = new ShippingAddress();
                shippingAddress.first_name = "John";
                shippingAddress.last_name = "Smith";
                shippingAddress.company = "Test Company";
                shippingAddress.address_line_1 = "123 Some St";
                shippingAddress.city = "Wheaton";
                shippingAddress.state = "IL";
                shippingAddress.postal_code = "60187";
                shippingAddress.country = "US";
                shippingAddress.phone = "5555555555";
                shippingAddress.fax = "5555555555";
                shippingAddress.email = "help@website.com";
                return shippingAddress;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region update specific customer
        public UpdateCustomer GetSpecificCustomerToUpdate(DataSet ds)
        {
            UpdateCustomer customer = new UpdateCustomer();
            customer.description = "test description";
            customer.payment_method = "credit_card";
            customer.payment_method_id = "b798ls2q9qq646ksu080";
            customer.billing_address_id = "b798ls2q9qq646ksu07g";
            customer.shipping_address_id = "b798ls2q9qq646ksu07g";
            return customer;
        }
        #endregion

        #region Create new Customer address
        public object GetCustomerAddressType(char address_type, DataTable table)
        {
            try
            {
                if (address_type == 'B')
                {
                    return GetBillingAddressInfo(table);
                }
                else
                {
                    return GetShippingAddressInfo(table);
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Create New Payment TokenObject
        public Card CreateNewPaymentTokenObject(string card_number, string expiration_date)
        {
            Card card = new Card();
            card.card_number = card_number;
            card.expiration_date = expiration_date;
            return card;
        }
        #endregion

        public void Dispose()
        {
        }

    }
}