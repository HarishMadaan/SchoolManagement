﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AuthorizeNet.Api.Controllers;
using AuthorizeNet.Api.Contracts.V1;
using AuthorizeNet.Api.Controllers.Bases;
using System.Text.RegularExpressions;
using System.Configuration;

namespace AuthorizeWebService
{
    public class AuthorizeClient : IDisposable
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="strKey"></param>
        /// <returns></returns>
        private string readConfig(string strKey)
        {
            return ConfigurationManager.AppSettings[strKey].ToString();
        }

        public long CreateCustomerProfile(string strMerchantCustomerId, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            long out_id = 0; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                customerProfileType customerProfile = new customerProfileType();
                customerProfile.merchantCustomerId = strMerchantCustomerId;

                var request = new createCustomerProfileRequest { profile = customerProfile, validationMode = validationModeEnum.none };

                // instantiate the controller that will call the service
                var controller = new createCustomerProfileController(request);

                controller.Execute();

                // get the response from the service (errors contained if any)
                createCustomerProfileResponse response = controller.GetApiResponse();


                // validate response 
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response.messages.message != null)//Customer Profile Creation Success.
                            out_id = Convert.ToInt64(response.customerProfileId);
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = "Successful";
                    }
                    else //Customer Profile Creation Failed.
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;

                        var regex = new Regex("^A duplicate record with ID (?<profileId>[0-9]+) already exists.$", RegexOptions.ExplicitCapture);
                        Match match = regex.Match(response.messages.message[0].text);
                        if (match.Success)
                        {
                            out_id = long.Parse(match.Groups["profileId"].Value);
                            ErrorCode = response.messages.message[0].code;
                            ErrorText = "Successful";
                        }
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Bad Response From Authrize.net";
                    }


                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return out_id;
        }

        public long CreateCustomerPaymentProfile(string profileId, CreditCardInfo cardInfo, string strAuthorizationFlag, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            long out_id = 0; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };


                var creditCard = new creditCardType
                {
                    cardNumber = cardInfo.CardNumber,
                    expirationDate = cardInfo.ExpiryYear + "-" + cardInfo.ExpiryMonth,
                    cardCode = cardInfo.CVV
                };
                var billTo = new customerAddressType
                {
                    firstName = cardInfo.FirstName,
                    lastName = cardInfo.LastName,
                    address = cardInfo.Address,
                    city = cardInfo.City,
                    state = cardInfo.State,
                    zip = cardInfo.ZipCode,
                    country = cardInfo.Country
                };

                customerPaymentProfileType customerPaymentProfileType = new customerPaymentProfileType();
                paymentType new_payment = new paymentType();
                new_payment.Item = creditCard;


                customerPaymentProfileType.payment = new_payment;
                customerPaymentProfileType.billTo = billTo;

                var request = new createCustomerPaymentProfileRequest { customerProfileId = profileId, paymentProfile = customerPaymentProfileType, validationMode = strAuthorizationFlag == "0" ? validationModeEnum.testMode : validationModeEnum.liveMode };

                // instantiate the controller that will call the service
                var controller = new createCustomerPaymentProfileController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                createCustomerPaymentProfileResponse response = controller.GetApiResponse();


                // validate response 
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response.messages.message != null)//Customer Profile Creation Success.
                            out_id = Convert.ToInt64(response.customerPaymentProfileId);
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = "Successful";
                    }
                    else //Customer Profile Creation Failed.
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Bad Response From Authrize.net";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return out_id;
        }

        public bool UpdateCustomerPaymentProfile(string profileId, string paymentProfileId, CreditCardInfo cardInfo, string strAuthorizationFlag, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            bool returnVal = false; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                var creditCard = new creditCardType
                {
                    cardNumber = cardInfo.CardNumber,
                    expirationDate = cardInfo.ExpiryYear + "-" + cardInfo.ExpiryMonth,
                    cardCode = cardInfo.CVV
                };

                var paymentType = new paymentType { Item = creditCard };

                var paymentProfile = new customerPaymentProfileExType
                {
                    billTo = new customerAddressType
                    {
                        // change information as required for billing
                        firstName = cardInfo.FirstName,
                        lastName = cardInfo.LastName,
                        address = cardInfo.Address,
                        city = cardInfo.City,
                        state = cardInfo.State,
                        zip = cardInfo.ZipCode,
                        country = cardInfo.Country,
                        phoneNumber = cardInfo.phoneNumber,
                    },
                    payment = paymentType,
                    customerPaymentProfileId = paymentProfileId
                };


                var request = new updateCustomerPaymentProfileRequest { customerProfileId = profileId, paymentProfile = paymentProfile, validationMode = strAuthorizationFlag == "0" ? validationModeEnum.testMode : validationModeEnum.liveMode };

                // instantiate the controller that will call the service
                var controller = new updateCustomerPaymentProfileController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                updateCustomerPaymentProfileResponse response = controller.GetApiResponse();


                // validate response 
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        returnVal = true;
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = "Successful";
                    }
                    else //Customer Profile Updation Failed.
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Bad Response From Authrize.net";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public string CreateTransaction(string profileId, string paymentProfileId, CreditCardInfo cardInfo, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            string returnVal = "0"; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                //create a customer payment profile
                customerProfilePaymentType profileToCharge = new customerProfilePaymentType();
                profileToCharge.customerProfileId = profileId;
                profileToCharge.paymentProfile = new paymentProfile { paymentProfileId = paymentProfileId };

                var orderExType = new orderExType
                {
                    invoiceNumber = cardInfo.InvoiceNumber
                };

                var transactionRequest = new transactionRequestType
                {
                    transactionType = transactionTypeEnum.authCaptureTransaction.ToString(),    // refund type
                    amount = Convert.ToDecimal(cardInfo.Amount),
                    order = orderExType,
                    profile = profileToCharge
                };

                var request = new createTransactionRequest { transactionRequest = transactionRequest };

                // instantiate the collector that will call the service
                var controller = new createTransactionController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                var response = controller.GetApiResponse();

                // validate response
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response.transactionResponse.messages != null && response.transactionResponse.transId != null)
                        {
                            returnVal = response.transactionResponse.transId;
                            ErrorCode = response.messages.message[0].code;
                            ErrorText = "Successful";
                        }
                        else
                        {
                            //Transaction Failed
                            if (response.transactionResponse.errors != null)
                            {
                                ErrorCode = response.transactionResponse.errors[0].errorCode;
                                ErrorText = response.transactionResponse.errors[0].errorText;
                            }
                        }
                    }
                    else
                    {
                        //transaction failed
                        if (response.transactionResponse != null && response.transactionResponse.errors != null)
                        {
                            ErrorCode = response.transactionResponse.errors[0].errorCode;
                            ErrorText = response.transactionResponse.errors[0].errorText;

                        }
                        else
                        {
                            ErrorCode = response.messages.message[0].code;
                            ErrorText = response.messages.message[0].text;
                        }
                    }
                }
                else
                {
                    ErrorCode = "null";
                    ErrorText = "Bad Response From Authrize.net";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public customerProfileMaskedType GetCustomerProfile(string profileId, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            customerProfileMaskedType returnVal = null; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                var request = new getCustomerProfileRequest();
                request.customerProfileId = profileId;



                // instantiate the controller that will call the service
                var controller = new getCustomerProfileController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                var response = controller.GetApiResponse();


                if (response != null)
                {
                    if (response != null && response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        returnVal = response.profile;
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = "Successful";
                    }
                    else if (response != null)
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Bad Response From Authrize.net";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public bool DeleteCustomerProfile(string profileId, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            bool returnVal = false; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                //please update the subscriptionId according to your sandbox credentials
                var request = new deleteCustomerProfileRequest
                {
                    customerProfileId = profileId
                };

                //Prepare Request
                var controller = new deleteCustomerProfileController(request);
                controller.Execute();

                //Send Request to EndPoint
                deleteCustomerProfileResponse response = controller.GetApiResponse();

                if (response != null)
                {
                    if (response != null && response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response != null && response.messages.message != null)
                        {
                            returnVal = true;
                            ErrorCode = response.messages.message[0].code;
                            ErrorText = "Successful";
                        }
                    }
                    else if (response != null && response.messages.message != null)
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Bad Response From Authrize.net";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public bool DeleteCustomerPaymentProfile(string profileId, string paymentProfileId, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            bool returnVal = false; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                //please update the subscriptionId according to your sandbox credentials
                var request = new deleteCustomerPaymentProfileRequest
                {
                    customerProfileId = profileId,
                    customerPaymentProfileId = paymentProfileId
                };

                //Prepare Request
                var controller = new deleteCustomerPaymentProfileController(request);
                controller.Execute();

                //Send Request to EndPoint
                deleteCustomerPaymentProfileResponse response = controller.GetApiResponse();
                if (response != null)
                {
                    if (response != null && response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response != null && response.messages.message != null)
                        {
                            returnVal = true;
                            ErrorCode = response.messages.message[0].code;
                            ErrorText = "Successful";
                        }
                    }
                    else if (response != null && response.messages.message != null)
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Bad Response From Authrize.net";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public string ReceiveCreditAdvancePayment(string profileId, string paymentProfileId, CreditCardInfo bankInfo, string strAPIId, string strTransactionKey, string ReferenceId, out string ErrorCode, out string ErrorText)
        {
            string returnVal = ""; ErrorCode = ""; ErrorText = "";

            try
            {

                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                //create a customer payment profile
                customerProfilePaymentType profileToCharge = new customerProfilePaymentType();
                profileToCharge.customerProfileId = Convert.ToString(profileId);
                profileToCharge.paymentProfile = new paymentProfile { paymentProfileId = Convert.ToString(paymentProfileId) };

                var transactionRequest = new transactionRequestType
                {
                    transactionType = transactionTypeEnum.authCaptureTransaction.ToString(),    // refund type            
                    amount = Convert.ToDecimal(bankInfo.Amount),
                    order = new orderType
                    {
                        invoiceNumber = bankInfo.InvoiceNumber,
                        description = bankInfo.description
                    },
                    profile = profileToCharge
                };

                var request = new createTransactionRequest { transactionRequest = transactionRequest, refId = ReferenceId };

                // instantiate the collector that will call the service
                var controller = new createTransactionController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                var response = controller.GetApiResponse();

                // validate response
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response.transactionResponse != null)
                        {
                            if (response.transactionResponse.messages != null && response.transactionResponse.transId != null)//transaction success
                            {
                                returnVal = response.transactionResponse.transId;
                                ErrorCode = response.messages.message[0].code;
                                ErrorText = "Successful";
                            }
                            else
                            {
                                if (response.transactionResponse.errors != null)//transaction fail
                                {
                                    ErrorCode = response.transactionResponse.errors[0].errorCode;
                                    ErrorText = response.transactionResponse.errors[0].errorText;
                                }
                            }
                        }
                        else
                        {
                            ErrorCode = response.messages.message[0].code;
                            //ErrorText = response.directResponse;
                        }
                    }
                    else
                    {
                        if (response.transactionResponse != null && response.transactionResponse.errors != null)//transaction fail
                        {
                            ErrorCode = response.transactionResponse.errors[0].errorCode;
                            ErrorText = response.transactionResponse.errors[0].errorText;
                        }
                        else
                        {
                            ErrorCode = response.messages.message[0].code;
                            ErrorText = response.messages.message[0].text;
                        }
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Null Response";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public void Dispose() { }
    }
}
