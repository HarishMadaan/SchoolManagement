﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AuthorizeNet.Api.Controllers;
using AuthorizeNet.Api.Contracts.V1;
using AuthorizeNet.Api.Controllers.Bases;
using System.Text.RegularExpressions;
using System.Configuration;

namespace AuthorizeWebService
{
    public class AuthorizeClientBank : IDisposable
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="strKey"></param>
        /// <returns></returns>
        private string readConfig(string strKey)
        {
            return ConfigurationManager.AppSettings[strKey].ToString();
        }

        public long CreateCustomerBankProfile(string PayerDisplayId, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            long out_id = 0; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                //String timeStamp = GetTimestamp(DateTime.Now);

                customerProfileType customerProfile = new customerProfileType();
                customerProfile.merchantCustomerId = PayerDisplayId;

                var request = new createCustomerProfileRequest { profile = customerProfile, validationMode = validationModeEnum.none };

                // instantiate the controller that will call the service
                var controller = new createCustomerProfileController(request);

                controller.Execute();

                // get the response from the service (errors contained if any)
                createCustomerProfileResponse response = controller.GetApiResponse();

                // validate response 
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response.messages.message != null)//Customer Profile Creation Success.
                            out_id = Convert.ToInt64(response.customerProfileId);
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = "Successful";
                    }
                    else //Customer Profile Creation Failed.
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;

                        var regex = new Regex("^A duplicate record with ID (?<profileId>[0-9]+) already exists.$", RegexOptions.ExplicitCapture);
                        Match match = regex.Match(response.messages.message[0].text);
                        if (match.Success)
                            out_id = long.Parse(match.Groups["profileId"].Value);
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Null Response";
                    }


                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return out_id;
        }


        public long CreateCustomerPaymentBankProfile(string profileId, BankAccountInfo bankinfo, string strAuthorizationFlag, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            long out_id = 0; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };


                bankAccountType bankAccount = new bankAccountType();
                bankAccount.accountNumber = bankinfo.AccountNumber;
                bankAccount.routingNumber = bankinfo.RoutingNumber;

                switch (bankinfo.AccountType.ToUpper())
                {
                    case AuthorizeWebService.Bank_Account_Account_Type.Business_Checking:
                        bankAccount.accountType = bankAccountTypeEnum.businessChecking;
                        break;
                    case AuthorizeWebService.Bank_Account_Account_Type.Checking:
                        bankAccount.accountType = bankAccountTypeEnum.checking;
                        break;
                    case AuthorizeWebService.Bank_Account_Account_Type.Savings:
                        bankAccount.accountType = bankAccountTypeEnum.savings;
                        break;
                }

                switch (bankinfo.AuthorizationType.ToUpper())
                {
                    case AuthorizeWebService.Bank_Account_Authorization_Type.WEB:
                        bankAccount.echeckType = echeckTypeEnum.WEB;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.TEL:
                        bankAccount.echeckType = echeckTypeEnum.TEL;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.PPD:
                        bankAccount.echeckType = echeckTypeEnum.PPD;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.CCD:
                        bankAccount.echeckType = echeckTypeEnum.CCD;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.ARC:
                        bankAccount.echeckType = echeckTypeEnum.ARC;
                        bankAccount.checkNumber = bankinfo.CheckNumber;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.BOC:
                        bankAccount.echeckType = echeckTypeEnum.BOC;
                        bankAccount.checkNumber = bankinfo.CheckNumber;
                        break;
                }

                bankAccount.nameOnAccount = bankinfo.NameOnAccount;
                bankAccount.bankName = bankinfo.BankName;

                paymentType echeck = new paymentType { Item = bankAccount };

                var billTo = new customerAddressType
                {
                    firstName = bankinfo.FirstName,
                    lastName = bankinfo.LastName,
                    address = bankinfo.Address,
                    city = bankinfo.City,
                    state = bankinfo.State,
                    zip = bankinfo.ZipCode,
                    country = bankinfo.Country

                };


                customerPaymentProfileType echeckPaymentProfile = new customerPaymentProfileType();
                echeckPaymentProfile.payment = echeck;
                echeckPaymentProfile.billTo = billTo;

                var request = new createCustomerPaymentProfileRequest
                {
                    customerProfileId = profileId.ToString(),
                    paymentProfile = echeckPaymentProfile,
                    validationMode = strAuthorizationFlag == "0" ? validationModeEnum.testMode : validationModeEnum.liveMode
                };

                // instantiate the controller that will call the service
                var controller = new createCustomerPaymentProfileController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                createCustomerPaymentProfileResponse response = controller.GetApiResponse();

                // validate response 
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response.messages.message != null)//Customer Profile Creation Success.
                            out_id = Convert.ToInt64(response.customerPaymentProfileId);
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = "Successful";
                    }
                    else //Customer Profile Creation Failed.
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Null Response";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return out_id;
        }


        public string CreateBankTransaction(string profileId, string paymentProfileId, BankAccountInfo bankInfo, string strAPIId, string strTransactionKey, string ReferenceId, out string ErrorCode, out string ErrorText)
        {
            string returnVal = ""; ErrorCode = ""; ErrorText = "";

            try
            {

                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                //create a customer payment profile
                customerProfilePaymentType profileToCharge = new customerProfilePaymentType();
                profileToCharge.customerProfileId = Convert.ToString(profileId);
                profileToCharge.paymentProfile = new paymentProfile { paymentProfileId = Convert.ToString(paymentProfileId) };

                var transactionRequest = new transactionRequestType
                {
                    transactionType = transactionTypeEnum.authCaptureTransaction.ToString(),    // refund type            
                    amount = Convert.ToDecimal(bankInfo.Amount),
                    order = new orderType
                    {
                        invoiceNumber = bankInfo.InvoiceNumber,
                        description = bankInfo.description
                    },
                    profile = profileToCharge
                };

                var request = new createTransactionRequest { transactionRequest = transactionRequest, refId = ReferenceId };

                // instantiate the collector that will call the service
                var controller = new createTransactionController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                var response = controller.GetApiResponse();

                // validate response 
                // validate response
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response.transactionResponse != null)
                        {
                            if (response.transactionResponse.messages != null && response.transactionResponse.transId != null)//transaction success
                            {
                                returnVal = response.transactionResponse.transId + "," + response.transactionResponse.responseCode;

                                //returnVal = response.transactionResponse.transId;
                                ErrorCode = response.messages.message[0].code;
                                ErrorText = "Successful";
                            }
                            else
                            {
                                if (response.transactionResponse.errors != null)//transaction fail
                                {
                                    ErrorCode = response.transactionResponse.errors[0].errorCode;
                                    ErrorText = response.transactionResponse.errors[0].errorText;
                                }
                            }
                        }
                        else
                        {
                            ErrorCode = response.messages.message[0].code;
                            //ErrorText = response.directResponse;
                        }
                    }
                    else
                    {
                        if (response.transactionResponse != null && response.transactionResponse.errors != null)//transaction fail
                        {
                            ErrorCode = response.transactionResponse.errors[0].errorCode;
                            ErrorText = response.transactionResponse.errors[0].errorText;
                        }
                        else
                        {
                            ErrorCode = response.messages.message[0].code;
                            ErrorText = response.messages.message[0].text;
                        }
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Null Response";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public bool UpdateCustomerPaymentProfile(string profileId, string paymentProfileId, BankAccountInfo bankinfo, string strAuthorizationFlag, string strAPIId, string strTransactionKey, out string ErrorCode, out string ErrorText)
        {
            bool returnVal = false; ErrorCode = ""; ErrorText = "";

            try
            {
                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                bankAccountType bankAccount = new bankAccountType();
                bankAccount.accountNumber = bankinfo.AccountNumber;
                bankAccount.routingNumber = bankinfo.RoutingNumber;

                switch (bankinfo.AccountType.ToUpper())
                {
                    case AuthorizeWebService.Bank_Account_Account_Type.Business_Checking:
                        bankAccount.accountType = bankAccountTypeEnum.businessChecking;
                        break;
                    case AuthorizeWebService.Bank_Account_Account_Type.Checking:
                        bankAccount.accountType = bankAccountTypeEnum.checking;
                        break;
                    case AuthorizeWebService.Bank_Account_Account_Type.Savings:
                        bankAccount.accountType = bankAccountTypeEnum.savings;
                        break;
                }

                switch (bankinfo.AuthorizationType.ToUpper())
                {
                    case AuthorizeWebService.Bank_Account_Authorization_Type.WEB:
                        bankAccount.echeckType = echeckTypeEnum.WEB;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.TEL:
                        bankAccount.echeckType = echeckTypeEnum.TEL;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.PPD:
                        bankAccount.echeckType = echeckTypeEnum.PPD;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.CCD:
                        bankAccount.echeckType = echeckTypeEnum.CCD;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.ARC:
                        bankAccount.echeckType = echeckTypeEnum.ARC;
                        bankAccount.checkNumber = bankinfo.CheckNumber;
                        break;
                    case AuthorizeWebService.Bank_Account_Authorization_Type.BOC:
                        bankAccount.echeckType = echeckTypeEnum.BOC;
                        bankAccount.checkNumber = bankinfo.CheckNumber;
                        break;
                }

                bankAccount.nameOnAccount = bankinfo.NameOnAccount;
                bankAccount.bankName = bankinfo.BankName;

                paymentType echeck = new paymentType { Item = bankAccount };

                var billTo = new customerAddressType
                {
                    firstName = bankinfo.FirstName,
                    lastName = bankinfo.LastName,
                    address = bankinfo.Address,
                    city = bankinfo.City,
                    state = bankinfo.State,
                    zip = bankinfo.ZipCode,
                    country = bankinfo.Country

                };


                customerPaymentProfileExType echeckPaymentProfile = new customerPaymentProfileExType();
                echeckPaymentProfile.payment = echeck;
                echeckPaymentProfile.billTo = billTo;

                var request = new updateCustomerPaymentProfileRequest
                {
                    customerProfileId = profileId.ToString(),
                    paymentProfile = echeckPaymentProfile,
                    validationMode = strAuthorizationFlag == "0" ? validationModeEnum.testMode : validationModeEnum.liveMode
                };

                // instantiate the controller that will call the service
                var controller = new updateCustomerPaymentProfileController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                updateCustomerPaymentProfileResponse response = controller.GetApiResponse();


                // validate response 
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        returnVal = true;
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = "Successful";
                    }
                    else //Customer Profile Updation Failed.
                    {
                        ErrorCode = response.messages.message[0].code;
                        ErrorText = response.messages.message[0].text;
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Null Response";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public string ReceiveBankAdvancePayment(string profileId, string paymentProfileId, BankAccountInfo bankInfo, string strAPIId, string strTransactionKey, string ReferenceId, out string ErrorCode, out string ErrorText)
        {
            string returnVal = ""; ErrorCode = ""; ErrorText = "";

            try
            {

                // set whether to use the sandbox environment, or production enviornment
                if (Convert.ToInt16(readConfig("APIFlag")) == 0)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                }
                else
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;
                }

                // define the merchant information (authentication / transaction id)
                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                {
                    name = strAPIId,
                    ItemElementName = ItemChoiceType.transactionKey,
                    Item = strTransactionKey,
                };

                //create a customer payment profile
                customerProfilePaymentType profileToCharge = new customerProfilePaymentType();
                profileToCharge.customerProfileId = Convert.ToString(profileId);
                profileToCharge.paymentProfile = new paymentProfile { paymentProfileId = Convert.ToString(paymentProfileId) };

                var transactionRequest = new transactionRequestType
                {
                    transactionType = transactionTypeEnum.authCaptureTransaction.ToString(),    // refund type            
                    amount = Convert.ToDecimal(bankInfo.Amount),
                    order = new orderType
                    {
                        invoiceNumber = bankInfo.InvoiceNumber,
                        description = bankInfo.description
                    },
                    profile = profileToCharge
                };

                var request = new createTransactionRequest { transactionRequest = transactionRequest, refId = ReferenceId };

                // instantiate the collector that will call the service
                var controller = new createTransactionController(request);
                controller.Execute();

                // get the response from the service (errors contained if any)
                var response = controller.GetApiResponse();

                // validate response
                if (response != null)
                {
                    if (response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response.transactionResponse != null)
                        {
                            if (response.transactionResponse.messages != null && response.transactionResponse.transId != null)//transaction success
                            {
                                returnVal = response.transactionResponse.transId;
                                ErrorCode = response.messages.message[0].code;
                                ErrorText = "Successful";
                            }
                            else
                            {
                                if (response.transactionResponse.errors != null)//transaction fail
                                {
                                    ErrorCode = response.transactionResponse.errors[0].errorCode;
                                    ErrorText = response.transactionResponse.errors[0].errorText;
                                }
                            }
                        }
                        else
                        {
                            ErrorCode = response.messages.message[0].code;
                            //ErrorText = response.directResponse;
                        }
                    }
                    else
                    {
                        if (response.transactionResponse != null && response.transactionResponse.errors != null)//transaction fail
                        {
                            ErrorCode = response.transactionResponse.errors[0].errorCode;
                            ErrorText = response.transactionResponse.errors[0].errorText;
                        }
                        else
                        {
                            ErrorCode = response.messages.message[0].code;
                            ErrorText = response.messages.message[0].text;
                        }
                    }
                }
                else
                {
                    if (controller.GetErrorResponse().messages.message.Length > 0)
                    {
                        ErrorCode = controller.GetErrorResponse().messages.message[0].code;
                        ErrorText = controller.GetErrorResponse().messages.message[0].text;

                    }
                    else
                    {
                        ErrorCode = "null";
                        ErrorText = "Null Response";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnVal;
        }

        public static String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmssffff");
        }

        public void Dispose() { }
    }
}
