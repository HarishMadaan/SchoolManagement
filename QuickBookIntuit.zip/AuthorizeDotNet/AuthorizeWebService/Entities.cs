﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthorizeWebService
{

    public class CreditCardInfo
    {
        public Guid Id { get; set; }
        // create customer profile
        public string merchantCustomerId { get; set; }
        public string email { get; set; }
        public string description { get; set; }
        public string CardNumber { get; set; }//comparsery field for customer payment profile
        public string ExpiryYear { get; set; }
        public string ExpiryMonth { get; set; }
        public string CVV { get; set; }
        public decimal? Amount { get; set; }
        //comparsery field for customer payment profile
        public string accountNumber { get; set; }
        public string routingNumber { get; set; }
        //comparsery field for customer payment profile
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string OfficeName { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string company { get; set; }
        public string phoneNumber { get; set; }
        public string faxNumber { get; set; }
        public bool IsPrimary { get; set; }
        public string FranchiseId { get; set; }
        public int AgencyId { get; set; }
        public string InvoiceNumber { get; set; }
    }

    public class BankAccountInfo
    {
        public Guid BankId { get; set; }
        public string merchantCustomerId { get; set; }
        public string AccountNumber { get; set; }
        public string RoutingNumber { get; set; }
        public string BankName { get; set; }
        public string NameOnAccount { get; set; }
        public decimal? Amount { get; set; }
        public string FranchiseId { get; set; }
        public int AgencyId { get; set; }
        public string InvoiceNumber { get; set; }
        public string AccountType { get; set; }
        public string AuthorizationType { get; set; }
        public string CheckNumber { get; set; }
        public Int32 ACustomerProfileId { get; set; }
        public Int32 ACustomerPaymentProfileId { get; set; }
        public bool IsDefault { get; set; }
        public bool IsPrimary { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
        public Guid ModifiedBy { get; set; }
        public bool IsActive { get; set; }
        public bool IsArchived { get; set; }
        public Guid PayerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string OfficeName { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string company { get; set; }
        public string email { get; set; }
        public string description { get; set; }
        public string phoneNumber { get; set; }
        public string faxNumber { get; set; }
        public Guid PaymentType { get; set; }
        public string PayerDisplayId { get; set; }
    }

    public static class Bank_Account_Account_Type
    {
        public const string Business_Checking = "10DE6151-B2D8-4395-B9C4-0C9625CE2F0E";
        public const string Checking = "C66633DE-547E-4B5B-8712-C83F0A09AEFD";
        public const string Savings = "413F4D80-09E2-4B9B-BA0A-B8630CA0722C";
    }

    public static class Bank_Account_Authorization_Type
    {
        public const string ARC = "9C89281D-24DC-4EFA-8C39-70865DE4CF1A";
        public const string BOC = "3762B14A-8DC6-4BEC-A1F0-F22D5AC720C0";
        public const string CCD = "81C2531D-ABF9-40B2-8444-FB157B05A9F7";
        public const string PPD = "BB73D146-9126-4BCB-8A04-5941A33C62E9";
        public const string TEL = "9BF8FD9A-1A07-4F14-AB0B-16C9150DB1B4";
        public const string WEB = "3E189AE7-B88F-497E-A05A-E7F7D898600B";
    }

}
