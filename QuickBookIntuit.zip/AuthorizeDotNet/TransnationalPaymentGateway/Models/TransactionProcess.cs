﻿using Newtonsoft.Json;
using System;
using TNPGatewaysAPI.Models.ViewModel;
using TNPGatewaysAPI.Models.ViewModel.CardResponse;
using TransnationalPaymentGateway;
using RestSharp;

namespace TNPGatewaysAPI.Models
{
    public class TransactionProcess
    {
        /// <summary>
        /// This endpoint used to make transaction 
        /// </summary>
        /// <param name="transaction"></param>
        /// <param name="franchise_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="service_response"></param>
        /// <returns>string</returns>
        public string MakeTransaction(string transaction, string franchise_id, int agency_id, ref string service_response)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);

                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPTransactionEndpoint);

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name, url, franchise_id, agency_id, objBLL.api_key);

                    if (string.IsNullOrEmpty(objBLL.api_key))
                    {
                        service_response = "Fail";
                        return "Transnational Api key not found for this agency";
                    }

                    var client = new RestClient(url);
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("content-type", "application/json");
                    request.AddHeader("authorization", objBLL.api_key);
                    request.AddParameter("application/json", transaction, ParameterType.RequestBody);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    IRestResponse response = client.Execute(request);

                    //Logging
                    new Logger().LogServiceResponse(System.Reflection.MethodBase.GetCurrentMethod().Name, response, franchise_id, agency_id);

                    var content = response.Content;

                    //content is blank or null we are returnig error message here
                    if (string.IsNullOrEmpty(content))
                    {
                        service_response = "Fail";
                        return "StatusCode=" + response.StatusCode + ", ErrorMessage=" + response.ErrorMessage;
                    }

                    //now deserializing the content
                    CardRootObject card_response = JsonConvert.DeserializeObject<CardRootObject>(content);

                    if (string.Equals(card_response.status, "success", StringComparison.CurrentCultureIgnoreCase))
                    {
                        service_response = "OK";
                        return content;
                    }
                    else
                    {
                        service_response = "Fail";
                        return Convert.ToString(card_response.msg);
                    }
                }
            }
            catch (Exception ex)
            {
                new Logger().LogException(ex.Message, ex.ToString(), franchise_id, agency_id);

                service_response = "Fail";
                return (service_response = ex.ToString());
            }
        }

        /// <summary>
        /// Used to Get Transaction Status
        /// </summary>
        /// <param name="transaction_id"></param>
        /// <param name="franchise_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="service_response"></param>
        /// <returns>string</returns>
        public string GetTransactionStatus(string transaction_id, string franchise_id, int agency_id, ref string service_response)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);

                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPGetTransactionStatus).Replace("##TransactionID##", transaction_id);

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name, url, franchise_id, agency_id, objBLL.api_key);

                    if (string.IsNullOrEmpty(objBLL.api_key))
                    {
                        service_response = "Fail";
                        return "Transnational Api key not found for this agency";
                    }

                    var client = new RestClient(url);
                    var request = new RestRequest(Method.GET);
                    request.AddHeader("content-type", "application/json");
                    request.AddHeader("authorization", objBLL.api_key);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    IRestResponse response = client.Execute(request);

                    //Logging
                    new Logger().LogServiceResponse(System.Reflection.MethodBase.GetCurrentMethod().Name, response, franchise_id, agency_id);

                    string content = response.Content;

                    //content is blank or null we are returnig error message here
                    if (string.IsNullOrEmpty(content))
                    {
                        service_response = "Fail";
                        return "StatusCode=" + response.StatusCode + ", ErrorMessage=" + response.ErrorMessage;
                    }

                    if (!string.IsNullOrEmpty(content))
                    {
                        service_response = "OK";
                        return content;
                    }
                    else
                    {
                        service_response = "Fail";
                        return "";
                    }
                }
            }
            catch (Exception ex)
            {
                new Logger().LogException(ex.Message, ex.ToString(), franchise_id, agency_id);

                service_response = "Fail";
                return service_response;
            }
        }

    }
}
