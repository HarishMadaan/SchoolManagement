﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using TNPGatewaysAPI.Models.ViewModel;
using TNPGatewaysAPI.Models.ViewModel.CreateCustomer;
using TNPGatewaysAPI.Models.ViewModel.CreateCustomerResponse;
using TNPGatewaysAPI.Models.ViewModel.UpdateCustomer;
using TNPGatewaysAPI.Models.ViewModel.UpdateCustomerResponse;
using TransnationalPaymentGateway;

namespace TNPGatewaysAPI.Models
{
    public class CustomerOperation : IDisposable
    {
        #region Create New Customer
        /// <summary>
        /// This endpoint creates a new customer token
        /// </summary>
        /// <param name="info"></param>
        /// <param name="franchise_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="service_response"></param>
        /// <returns></returns>
        public string CreateCustomer(string info, string franchise_id, int agency_id, ref string service_response)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {

                    if(info.Contains("card_number")&& info.Contains("expiration_date") && info.Contains("card") && info.Contains("payment_method"))
                    {
                        CreateCustomer createCustomer = JsonConvert.DeserializeObject<CreateCustomer>(info);
                        if (createCustomer.billing_address != null)
                        {
                            createCustomer.shipping_address = new ViewModel.ShippingAddress();
                            createCustomer.shipping_address.address_line_1 = createCustomer.billing_address.address_line_1;
                            createCustomer.shipping_address.address_line_2 = createCustomer.billing_address.address_line_2;
                            createCustomer.shipping_address.city = createCustomer.billing_address.city;
                            createCustomer.shipping_address.company = createCustomer.billing_address.company;
                            createCustomer.shipping_address.country = createCustomer.billing_address.country;
                            createCustomer.shipping_address.email = createCustomer.billing_address.email;
                            createCustomer.shipping_address.first_name = createCustomer.billing_address.first_name;
                            createCustomer.shipping_address.last_name = createCustomer.billing_address.last_name;
                            createCustomer.shipping_address.phone = createCustomer.billing_address.phone;
                            createCustomer.shipping_address.postal_code = createCustomer.billing_address.postal_code;
                            createCustomer.shipping_address.state = createCustomer.billing_address.state;
                            createCustomer.shipping_address.fax = createCustomer.billing_address.fax;

                            info = JsonConvert.SerializeObject(createCustomer);
                        }
                    }

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name, "Customer info:"+ info, franchise_id, agency_id, objBLL.api_key);


                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPCreateNewCustomer);

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,url, franchise_id, agency_id, objBLL.api_key);

                    if (string.IsNullOrEmpty(objBLL.api_key))
                    {
                        service_response = "Fail";
                        return "Transnational Api key not found for this agency";
                    }

                    var client = new RestClient(url);
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("content-type", "application/json");
                    request.AddHeader("authorization", objBLL.api_key);
                    request.AddParameter("application/json", info, ParameterType.RequestBody);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    IRestResponse response = client.Execute(request);

                    new Logger().LogServiceResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,response, franchise_id, agency_id);

                    var content = response.Content;
                    
                    //content is blank or null we are returnig error message here
                    if (string.IsNullOrEmpty(content))
                    {
                        service_response = "Fail";
                        return "StatusCode=" + response.StatusCode+ ", ErrorMessage=" + response.ErrorMessage;
                    }

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);

                    if (string.Equals(customer_response.status, "success", StringComparison.CurrentCultureIgnoreCase))
                    {
                        service_response = "OK";
                        return content;
                    }
                    else
                    {
                        service_response = "Fail";
                        return Convert.ToString(customer_response.msg);
                    }
                    //return "OK";
                }
            }
            catch (Exception ex)
            {
                new Logger().LogException(ex.Message, ex.ToString(), franchise_id, agency_id);

                service_response = "Fail";
                return (service_response = ex.ToString());
            }
        }
        #endregion

        #region Update Customer
        /// <summary>
        /// This endpoint updates a specific customer token.
        /// </summary>
        /// <param name="info"></param>
        /// <param name="franchise_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="customer_id"></param>
        /// <param name="service_response"></param>
        /// <returns>string</returns>
        public string UpdateCustomer(string info, string franchise_id, int agency_id, string customer_id, ref string service_response)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPUpdateSpecificCustomer).Replace("##CustomerID##", customer_id);
                    var http = (HttpWebRequest)WebRequest.Create(new Uri(url));

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,url, franchise_id, agency_id, objBLL.api_key);

                    if (string.IsNullOrEmpty(objBLL.api_key))
                    {
                        service_response = "Fail";
                        return "Transnational Api key not found for this agency";
                    }

                    var client = new RestClient(url);
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("content-type", "application/json");
                    request.AddHeader("authorization", objBLL.api_key);
                    request.AddParameter("application/json", info, ParameterType.RequestBody);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    IRestResponse response = client.Execute(request);

                    new Logger().LogServiceResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,response, franchise_id, agency_id);

                    var content = response.Content;
                    
                    //content is blank or null we are returnig error message here
                    if (string.IsNullOrEmpty(content))
                    {
                        service_response = "Fail";
                        return "StatusCode=" + response.StatusCode + ", ErrorMessage=" + response.ErrorMessage;
                    }

                    UpdateCustomerResponse customer_response = JsonConvert.DeserializeObject<UpdateCustomerResponse>(content);
                    
                    if (string.Equals(customer_response.status, "success", StringComparison.CurrentCultureIgnoreCase))
                    {
                        service_response = "OK";
                        return JsonConvert.SerializeObject(customer_response);
                    }
                    else
                    {
                        service_response = "Fail";
                        return Convert.ToString(customer_response.msg);
                    }
                }
            }
            catch (Exception ex)
            {
                new Logger().LogException(ex.Message, ex.ToString(), franchise_id, agency_id);

                service_response = "Fail";
                return (service_response = ex.ToString());
            }
        }
        #endregion

        #region Update CustomerAddress
        /// <summary>
        /// This endpoint updates a specific address token
        /// </summary>
        /// <param name="customer_id"></param>
        /// <param name="address_id"></param>
        /// <param name="franchise_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="address_type">'B' For Billing Address And 'S' For Shipping Address</param>
        /// <param name="service_response"></param>
        /// <returns>string</returns>
        public string UpdateCustomerAddress(string customer_id, string address_id, string franchise_id, int agency_id, char address_type, ref string service_response)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPUpdateCustomerAddress).Replace("##CustomerID##", customer_id).Replace("##AddressID##", address_id);

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,url, franchise_id, agency_id, objBLL.api_key);

                    if (string.IsNullOrEmpty(objBLL.api_key))
                    {
                        service_response = "Fail";
                        return "Transnational Api key not found for this agency";
                    }

                    var client = new RestClient(url);
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("content-type", "application/json");
                    request.AddHeader("authorization", objBLL.api_key);
                    request.AddParameter("application/json", JsonConvert.SerializeObject(objBLL.GetCustomerBillingShippingAddress(customer_id, address_type, agency_id)), ParameterType.RequestBody);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    IRestResponse response = client.Execute(request);

                    new Logger().LogServiceResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,response, franchise_id, agency_id);

                    var content = response.Content;

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);
                    
                    //content is blank or null we are returnig error message here
                    if (string.IsNullOrEmpty(content))
                    {
                        service_response = "Fail";
                        return "StatusCode=" + response.StatusCode + ", ErrorMessage=" + response.ErrorMessage;
                    }

                    if (string.Equals(customer_response.status, "success", StringComparison.CurrentCultureIgnoreCase))
                    {
                        service_response = "OK";
                        return JsonConvert.SerializeObject(customer_response);
                    }
                    else
                    {
                        service_response = "Fail";
                        return Convert.ToString(customer_response.msg);
                    }
                }
            }
            catch (Exception ex)
            {
                new Logger().LogException(ex.Message, ex.ToString(), franchise_id, agency_id);

                service_response = "Fail";
                return (service_response = ex.ToString());
            }
        }
        #endregion

        #region update specific payment token
        /// <summary>
        /// This endpoint updates a specific payment token.
        /// </summary>
        /// <param name="customer_id"></param>
        /// <param name="payment_id"></param>
        /// <param name="card_number"></param>
        /// <param name="expiration_date"></param>
        /// <param name="franchise_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="service_response"></param>
        /// <returns>string</returns>
        public string UpdateSpecificTokenAddress(string customer_id, string payment_id, string card_number, string expiration_date, string franchise_id, int agency_id, ref string service_response)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);

                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPUpdateSpecificPaymentToken).Replace("##CustomerID##", customer_id).Replace("##PaymentID##", payment_id);

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,url, franchise_id, agency_id, objBLL.api_key);

                    if (string.IsNullOrEmpty(objBLL.api_key))
                    {
                        service_response = "Fail";
                        return "Transnational Api key not found for this agency";
                    }

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
         
                    var client = new RestClient(url);
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("content-type", "application/json");
                    request.AddHeader("authorization", objBLL.api_key);
                    request.AddParameter("application/json", new CustomerInitialize().CreateNewPaymentTokenObject(card_number, expiration_date), ParameterType.RequestBody);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    IRestResponse response = client.Execute(request);

                    var content = response.Content;

                    //content is blank or null we are returnig error message here
                    if (string.IsNullOrEmpty(content))
                    {
                        service_response = "Fail";
                        return "StatusCode=" + response.StatusCode + ", ErrorMessage=" + response.ErrorMessage;
                    }

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);

                    objBLL.PaymentServiceLog("TNP", this.GetType().Name + "-" + System.Reflection.MethodBase.GetCurrentMethod().Name, string.Format("content={0}", "" + content), null, null, franchise_id, agency_id);
                    
                    if (string.Equals(customer_response.status, "success", StringComparison.CurrentCultureIgnoreCase))
                    {
                        service_response = "OK";
                        return JsonConvert.SerializeObject(customer_response);
                    }
                    else
                    {
                        service_response = "Fail";
                        return Convert.ToString(customer_response.msg);
                    }
                }
            }
            catch (Exception ex)
            {
                new Logger().LogException(ex.Message,ex.ToString(), franchise_id, agency_id);

                service_response = "Fail";
                return (service_response = ex.ToString());
            }
        }
        #endregion

        #region Get Specific customer
        /// <summary>
        /// This endpoint retrieves a specific customer.
        /// </summary>
        /// <param name="customer_id"></param>
        /// <param name="franchise_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="service_response"></param>
        /// <returns>string</returns>
        public string GetSpecificCustomer(string customer_id, string franchise_id, int agency_id, ref string service_response)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPGetSpecificCustomer).Replace("##CustomerID##", customer_id);

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,url, franchise_id, agency_id, objBLL.api_key);

                    if (string.IsNullOrEmpty(objBLL.api_key))
                    {
                        service_response = "Fail";
                        return "Transnational Api key not found for this agency";
                    }

                    var client = new RestClient(url);
                    var request = new RestRequest(Method.GET);
                    request.AddHeader("content-type", "application/json");
                    request.AddHeader("authorization", objBLL.api_key);
                    //request.AddParameter("application/json", JsonConvert.SerializeObject(objBLL.GetCustomerBillingShippingAddress(customer_id, address_type, agency_id)), ParameterType.RequestBody);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    IRestResponse response = client.Execute(request);

                    new Logger().LogServiceResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,response, franchise_id, agency_id);
                    
                    var content = response.Content;
                    
                    //content is blank or null we are returnig error message here
                    if (string.IsNullOrEmpty(content))
                    {
                        service_response = "Fail";
                        return "StatusCode=" + response.StatusCode + ", ErrorMessage=" + response.ErrorMessage;
                    }

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);
                    
                    if (string.Equals(customer_response.status, "success", StringComparison.CurrentCultureIgnoreCase))
                    {
                        service_response = "OK";
                        return JsonConvert.SerializeObject(customer_response);
                    }
                    else
                    {
                        service_response = "Fail";
                        return Convert.ToString(customer_response.msg);
                    }
                }
            }
            catch (Exception ex)
            {
                new Logger().LogException(ex.Message, ex.ToString(), franchise_id, agency_id);

                service_response = "Fail";
                return (service_response = ex.ToString());
            }
        }
        #endregion

        #region Delete Specific customer
        /// <summary>
        /// This endpoint used to delete specific customer
        /// </summary>
        /// <param name="customer_id"></param>
        /// <param name="franchise_id"></param>
        /// <param name="agency_id"></param>
        /// <param name="service_response"></param>
        /// <returns>string</returns>
        public string DeleteSpecificCustomer(string customer_id, string franchise_id, int agency_id, ref string service_response)
        {
            try
            {
                using (TNPBLL objBLL = new TNPBLL())
                {
                    objBLL.GetApiKeyByFranchiseId(franchise_id, agency_id);
                    var url = string.Concat(TnpUrls.TNPBaseURL, TnpUrls.TNPGetSpecificCustomer).Replace("##CustomerID##", customer_id);

                    //logging Request Parameter 
                    new Logger().LogRequestResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,url, franchise_id, agency_id, objBLL.api_key);

                    if (string.IsNullOrEmpty(objBLL.api_key))
                    {
                        service_response = "Fail";
                        return "Transnational Api key not found for this agency";
                    }

                    var client = new RestClient(url);
                    var request = new RestRequest(Method.DELETE);
                    request.AddHeader("content-type", "application/json");
                    request.AddHeader("authorization", objBLL.api_key);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                    
                    IRestResponse response = client.Execute(request);

                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                    new Logger().LogServiceResponse(System.Reflection.MethodBase.GetCurrentMethod().Name,response, franchise_id, agency_id);

                    var content = response.Content;
                    
                    //content is blank or null we are returnig error message here
                    if (string.IsNullOrEmpty(content))
                    {
                        service_response = "Fail";
                        return "StatusCode=" + response.StatusCode + ", ErrorMessage=" + response.ErrorMessage;
                    }

                    CreateCustomerResponse customer_response = JsonConvert.DeserializeObject<CreateCustomerResponse>(content);
                    
                    if (string.Equals(customer_response.status, "success", StringComparison.CurrentCultureIgnoreCase))
                    {
                        service_response = "OK";
                        return JsonConvert.SerializeObject(customer_response);
                    }
                    else
                    {
                        service_response = "Fail";
                        return Convert.ToString(customer_response.msg);
                    }
                }
            }
            catch (Exception ex)
            {
                new Logger().LogException(ex.Message, ex.ToString(), franchise_id, agency_id);

                service_response = "Fail";
                return (service_response = ex.ToString());
            }
        }
        #endregion
        
        public void Dispose()
        {

        }
    }
}