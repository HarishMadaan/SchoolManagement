﻿using System.Configuration;

namespace TNPGatewaysAPI.Models.ViewModel
{
    public class TnpUrls
    {
        //public static string TNPBaseURL = ConfigurationManager.AppSettings["TNPBaseURL"];
        //public static string TNPTransactionEndpoint = ConfigurationManager.AppSettings["TNPTransactionEndPointURL"];
        //public static string TNPCreateNewCustomer = ConfigurationManager.AppSettings["TNPCustomerCreate"];
        //public static string TNPGetSpecificCustomer = ConfigurationManager.AppSettings["TNPGetSpecificCustomer"];
        //public static string TNPUpdateSpecificCustomer = ConfigurationManager.AppSettings["TNPUpdateSpecificCustomer"];
        //public static string TNPUpdateCustomerAddress = ConfigurationManager.AppSettings["TNPUpdateCustomerAddress"];
        //public static string TNPUpdateSpecificPaymentToken = ConfigurationManager.AppSettings["TNPUpdateSpecificPaymentToken"];
        //public static string TNPDeleteSpecificCustomer = ConfigurationManager.AppSettings["TNPDeleteSpecificCustomer"];

        public static string TNPBaseURL = "https://sandbox.gotnpgateway.com/api/";
        public static string TNPTransactionEndpoint = "transaction";
        public static string TNPCreateNewCustomer = "customer";
        public static string TNPGetSpecificCustomer = "customer/##CustomerID##";
        public static string TNPUpdateSpecificCustomer = "customer/##CustomerID##";
        public static string TNPUpdateCustomerAddress = "customer/##CustomerID##/address/##AddressID##";
        public static string TNPUpdateSpecificPaymentToken = "customer/##CustomerID##/paymentmethod/card/##PaymentID##";
        public static string TNPDeleteSpecificCustomer = "customer/##CustomerID##";

    }
}