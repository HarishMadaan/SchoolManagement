﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransnationalPaymentGateway
{
    public class TNPBLL : IDisposable
    {
        public string api_key { get; set; }



        public void GetApiKeyByFranchiseId(string strFranchiseId, int intAgencyId)
        {
            try
            {
                using (TNPDAL objDal = new TNPDAL(intAgencyId))
                {
                    FranchiseTNPInfo obj = objDal.GetApiKey(strFranchiseId);
                    if (obj != null)
                    {
                        api_key = obj.api_key;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }


        public object GetCustomerBillingShippingAddress(string customer_id, char address_type, int intAgencyId)
        {
            try
            {
                using (TNPDAL objDal = new TNPDAL(intAgencyId))
                {
                    return objDal.GetCustomerBillingShippingAddress(customer_id, address_type);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void PaymentServiceLog(string payment_service_type, string method_name, string description, string exception_msg, string exception_source, string created_by, int agency_id)
        {
            try
            {
                using (TNPDAL objDal = new TNPDAL(agency_id))
                {
                    objDal.PaymentServiceLog(payment_service_type, method_name, description, exception_msg, exception_source, created_by);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void Dispose()
        {

        }
    }
}
