﻿
using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransnationalPaymentGateway
{
    public class TNPDAL : IDisposable
    {
        public string ConnectionString
        {
            get
            {
                return ConfigurationManager.AppSettings["CommonConnectionString"].ToString(); 
            }
        }
        public string FromDatabase { get; set; }

        /// <summary>
        /// method to get connection string based on agencyid
        /// Dharmender Kumar
        /// 04/16/2019
        /// </summary>
        /// <param name="AgencyId"></param>
        public TNPDAL(Int32 AgencyId)
        {
            try
            {
                //string stConnection = ConfigurationManager.ConnectionStrings["CSConnectionString"].ConnectionString;
                SqlConnection objconnection = new SqlConnection() { ConnectionString = Convert.ToString(ConfigurationManager.ConnectionStrings["CSConnectionString"].ConnectionString) };
                objconnection.Open();
                SqlCommand objCmd = new SqlCommand("SELECT TOP 1 * FROM DBConnectionDetails WHERE AgencyId = " + AgencyId, objconnection);
                objCmd.CommandType = CommandType.Text;
                SqlDataReader dr = objCmd.ExecuteReader();
                while (dr.Read())
                {
                    FromDatabase = ConnectionString.Replace("$Databasename$", Convert.ToString(dr["DBName"]))
                                   .Replace("$DataSource$", Static.Decrypt(Convert.ToString(dr["DataSource"]))).Replace("$UserName$", Static.Decrypt(Convert.ToString(dr["Username"]))).Replace("$Password$", Static.Decrypt(Convert.ToString(dr["Password"])));
                }
                if (objconnection.State != ConnectionState.Closed)
                {
                    objconnection.Close();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public string GetCustomerProfileIdByMerchantId(string strMerchantId)
        {
            string returnValue = "0";
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@CardName", strMerchantId);
                    returnValue = dbConnection.Query("GetCustomerProfileIdByMerchantId", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception ex) { throw; }
            return returnValue;
        }

        public string GetCustomerPaymentProfileIdByMerchantIdAndCardNumber(string strMerchantId, string strCardNumber)
        {
            string returnValue = "0";
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@CardName", strMerchantId);
                    parameters.Add("@CardNumber", strCardNumber);
                    returnValue = dbConnection.Query("GetCustomerPaymentProfileIdByMerchantIdAndCardNumber", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception ex) { throw; }


            return returnValue;
        }


        public void PaymentServiceLog(string payment_service_type, string method_name, string description, string exception_msg, string exception_source, string created_by)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@PaymentServiceType", payment_service_type);
                    parameters.Add("@MethodName", method_name);
                    parameters.Add("@Description", description);
                    parameters.Add("@ExceptionMsg", exception_msg);
                    parameters.Add("@ExceptionSource", exception_source);
                    parameters.Add("@CreatedBy", created_by);
                    dbConnection.Query("PrCSPaymentServiceLog", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception) { throw; }

        }

        public FranchiseTNPInfo GetApiKey(string strFranchiseId)
        {
            FranchiseTNPInfo returnValue = new FranchiseTNPInfo();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@FranchiseId", new Guid(strFranchiseId));
                    returnValue = dbConnection.Query<FranchiseTNPInfo>("TNP_GetAPIKeyByFranchiseId", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception ex) { throw; }
            return returnValue;
        }

        public object GetCustomerBillingShippingAddress(string customer_id, char address_type)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(FromDatabase))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@customer_id", customer_id);
                    parameters.Add("@address_type", address_type);
                    return dbConnection.Query<object>("TNP_GetCustomerBillingShippingAddress", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception) { throw; }
        }

        public void Dispose()
        {

        }
    }
}