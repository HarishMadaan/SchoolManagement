﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransnationalPaymentGateway
{
   public class FranchiseTNPInfo
    {
        public Guid? FranchiseId { get; set; }
        public string api_key { get; set; }
    }
}
