﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransnationalPaymentGateway
{
    public class Logger
    {
        public void LogRequestResponse(string endpoint_name,string url, string franchise_id, int agency_id, string api_key)
        {
            using (TNPBLL tnpbll = new TNPBLL())
            {
                string Log = string.Format("EndPointName={0}, URL={1}, FranchiseID={2}, AgencyID={3}, ApiKey={4} ",endpoint_name, url, franchise_id, agency_id, api_key);

                tnpbll.PaymentServiceLog("TNP", this.GetType().Name + "-" + System.Reflection.MethodBase.GetCurrentMethod().Name, Log, null, null, franchise_id, agency_id);
            }
        }

        public void LogServiceResponse(string endpoint_name,IRestResponse response, string franchise_id, int agency_id)
        {
            using (TNPBLL tnpbll = new TNPBLL())
            {
                if (response != null)
                {

                    string Log = string.Format("EndPointName={0}" +
                        ",  Content={1}" +
                        ", ContentEncoding={2}" +
                        ", ContentLength={3}" +
                        ", ContentType={4}" +
                        ", ErrorException={5}" +
                        ", ErrorMessage={6}" +
                        ", IsSuccessful={7}" +
                        ", ProtocolVersion={8}" +
                        ", ResponseStatus={9}" +
                        ", ResponseUri={10}" +
                        ", StatusCode={11}" +
                        ", StatusDescription={12}", endpoint_name, "" + response.Content
                        , "" + response.ContentEncoding
                        , "" + response.ContentLength
                        , "" + response.ContentType
                        , "" + response.ErrorException
                        , "" + response.ErrorMessage
                        , "" + response.IsSuccessful
                        , "" + response.ProtocolVersion
                        , "" + response.ResponseStatus
                        , "" + response.ResponseUri
                        , "" + response.StatusCode
                        , "" + response.StatusDescription
                    );

                    tnpbll.PaymentServiceLog("TNP", this.GetType().Name + "-" + System.Reflection.MethodBase.GetCurrentMethod().Name, Log, null, null, franchise_id, agency_id);

                }
            }
        }

        public void LogException(string exception_msg, string exception, string franchise_id, int agency_id)
        {
            using (TNPBLL tnpbll = new TNPBLL())
            {
                tnpbll.PaymentServiceLog("TNP", this.GetType().Name + "-" + System.Reflection.MethodBase.GetCurrentMethod().Name, "Exception", exception_msg, exception, franchise_id, agency_id);
            }
        }


    }
}
