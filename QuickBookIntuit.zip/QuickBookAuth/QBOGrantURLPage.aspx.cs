﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading.Tasks;
using IntuitQuickBooks;
using System.Configuration;
using Intuit.Ipp.OAuth2PlatformClient;

public partial class QuickBookAuth_QBOGrantURLPage : CompressViewState
{
    #region <<App Properties >>
    public static String REQUEST_TOKEN_URL = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("GET_REQUEST_TOKEN");
    public static String ACCESS_TOKEN_URL = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("GET_ACCESS_TOKEN");
    public static String AUTHORIZE_URL = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("AuthorizeUrl");
    public static String OAUTH_URL = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("OauthLink");


    public String consumerKey = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerKey");
    public String consumerSecret = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerSecret");

    public static String ClientId_QBO2 = "";// GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientId_QBO2");
    public static String ClientSecret_QBO2 = "";// GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientSecret_QBO2");

    public string strrequestToken = string.Empty;
    public string tokenSecret = string.Empty;
    public string oauth_callback_url = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("oauth_callback_url");
    public string GrantUrl = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("GrantUrl");

    public static string clientid = ConfigurationManager.AppSettings["clientid"];
    public static string clientsecret = ConfigurationManager.AppSettings["clientsecret"];
    public static string redirectUrl = ConfigurationManager.AppSettings["redirectUrl"];
    public static string environment = ConfigurationManager.AppSettings["appEnvironment"];

    public static OAuth2Client auth2ClientNew = new OAuth2Client(clientid, clientsecret, redirectUrl, environment);


    protected override void InitializeCulture()
    {
        AppConfig.SetCultureInfo();
    }

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["consumerKey"] == null && HttpContext.Current.Session["ConsumerSecret"] == null)
            GetKeysBasedOnOffice();

        //var tst = Test();


        if (string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["consumerKey"]).Trim()))
        {
            divDisconnect.Visible = true;
            lblDisconnect.Visible = true;
        }
        else
        {
            if (Request.QueryString.Count > 0)
            {

                List<string> queryKeys = new List<string>(Request.QueryString.AllKeys);

                if (queryKeys.Contains("code"))
                {
                    ReadToken_QBO2().Wait();
                }
                
            }
            else
            {
                if (HttpContext.Current.Session["accessToken"] == null && HttpContext.Current.Session["accessTokenSecret"] == null)
                {
                    lblDisconnect.Visible = false;
                    divDisconnect.Visible = false;
                }
                else
                {
                    divDisconnect.Visible = true;
                    lblDisconnect.Visible = true;
                }
            }
        }
    }


    public async Task ReadToken_QBO2()
    {
        try
        {
            //Sync the state info and update if it is not the same
            var state = Request.QueryString["state"];
            if (state.Equals(auth2ClientNew.CSRFToken, StringComparison.Ordinal))
            {
                ViewState["State"] = state + " (valid)";
            }
            else
            {
                ViewState["State"] = state + " (invalid)";
            }

            string code = Request.QueryString["code"] ?? "none";
            string realmId = Request.QueryString["realmId"] ?? "none";

            ViewState["Error"] = Request.QueryString["error"] ?? "none";

            await GetAuthTokensAsync(code, realmId);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Exchange Auth code with Auth Access and Refresh tokens and add them to Claim list
    /// </summary>
    private async Task GetAuthTokensAsync(string code, string realmId)
    {
        try
        {
            if (realmId != null)
            {
                Session["realmId"] = Convert.ToString(realmId);
            }
            if (code != null)
            {
                Session["Code_QBO2"] = Convert.ToString(code);
            }
            //Refresh token endpoint
            var tokenResponse = await auth2ClientNew.GetBearerTokenAsync(code);

            if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
            {
                Session["access_token"] = Convert.ToString(tokenResponse.AccessToken);
                Session["access_token_expires_at"] = Convert.ToString(DateTime.UtcNow.AddSeconds(tokenResponse.AccessTokenExpiresIn));
            }

            if (!string.IsNullOrWhiteSpace(tokenResponse.RefreshToken))
            {
                Session["refresh_token"] = Convert.ToString(tokenResponse.RefreshToken);
                Session["refresh_token_expires_at"] = Convert.ToString(DateTime.UtcNow.AddSeconds(tokenResponse.RefreshTokenExpiresIn));
                //claims.Add(new Claim("refresh_token", tokenResponse.RefreshToken));
                //claims.Add(new Claim("refresh_token_expires_at", (DateTime.Now.AddSeconds(tokenResponse.RefreshTokenExpiresIn)).ToString()));
            }

            if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
            {
                // update access tockens in table
                lblConnect.Visible = true;
                divConnect.Visible = true;

                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "RefreshParentPage();", true);

                UpdateAccess_RefreshTokenValueToDB_QBO2();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    /// <summary>
    /// 
    /// </summary>
    private int GetKeysBasedOnOffice()
    {
        int res = 0;
        consumerKey = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerKey");
        consumerSecret = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerSecret");
        HttpContext.Current.Session["consumerKey"] = consumerKey;
        HttpContext.Current.Session["consumerSecret"] = consumerSecret;

        //HttpContext.Current.Session["ClientId_QBO2"] = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientId_QBO2");
        //HttpContext.Current.Session["ClientSecret_QBO2"] = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientSecret_QBO2");

        res = 1;
        return res;

    }

    /// <summary>
    /// function used to update access and refresh token values
    /// </summary>
    protected void UpdateAccess_RefreshTokenValueToDB_QBO2()
    {
        Guid FranchiseID = new Guid(Convert.ToString(Session["QBFranc"]));
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            string accessToken_QBO2 = Convert.ToString(Session["access_token"]);
            DateTime access_token_expires_at_QBO2 = Convert.ToDateTime(Session["access_token_expires_at"]);
            string refresh_token_QBO2 = Convert.ToString(Session["refresh_token"]);
            DateTime refresh_token_expires_at_QBO2 = Convert.ToDateTime(Session["refresh_token_expires_at"]);
            string Companyrealm_QBO2 = Convert.ToString(Session["realmId"]);
            string Code_QBO2 = Convert.ToString(Session["Code_QBO2"]);

            int res = QbInst.UpdateAccessRelatedInfoByOffice_QBO2(FranchiseID, accessToken_QBO2, access_token_expires_at_QBO2, refresh_token_QBO2, refresh_token_expires_at_QBO2, Companyrealm_QBO2, Code_QBO2);

            if (res == 1)
            {
                Session.Remove("access_token");
                Session.Remove("refresh_token");
                Session.Remove("realmId");
                Session.Remove("Code_QBO2");
            }
        }
    }

}