﻿#region Using
using DevDefined.OAuth.Consumer;
using DevDefined.OAuth.Framework;
using IntuitQuickBooks;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Security.Claims;
using System.Threading.Tasks;

#endregion

public partial class GrantUrlPage : CompressViewState
{
    #region <<App Properties >>
    public static String REQUEST_TOKEN_URL = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("GET_REQUEST_TOKEN");
    public static String ACCESS_TOKEN_URL = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("GET_ACCESS_TOKEN");
    public static String AUTHORIZE_URL = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("AuthorizeUrl");
    public static String OAUTH_URL = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("OauthLink");


    public String consumerKey = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerKey");
    public String consumerSecret = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerSecret");

    public static String ClientId_QBO2 = ""; // GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientId_QBO2");
    public static String ClientSecret_QBO2 = ""; // GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientSecret_QBO2");

    public string strrequestToken = string.Empty;
    public string tokenSecret = string.Empty;
    public string oauth_callback_url = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("oauth_callback_url");
    public string GrantUrl = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("GrantUrl");

    public List<Claim> claims = new List<Claim>();

    #endregion

    protected override void InitializeCulture()
    {
        AppConfig.SetCultureInfo();
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        if (HttpContext.Current.Session["consumerKey"] == null && HttpContext.Current.Session["ConsumerSecret"] == null)
            GetKeysBasedOnOffice();

        //var tst = Test();


        if (string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["consumerKey"]).Trim()))
        {
            divDisconnect.Visible = true;
            lblDisconnect.Visible = true;
        }
        else
        {
            if (Request.QueryString.Count > 0)
            {

                List<string> queryKeys = new List<string>(Request.QueryString.AllKeys);

                //if (queryKeys.Contains("code"))
                //{
                //    ReadToken_QBO2().Wait();
                //}

                if (queryKeys.Contains("connect"))
                {
                    FireAuth();
                }
                if (queryKeys.Contains("oauth_token"))
                {
                    ReadToken();
                }
            }
            else
            {
                if (HttpContext.Current.Session["accessToken"] == null && HttpContext.Current.Session["accessTokenSecret"] == null)
                {
                    lblDisconnect.Visible = false;
                    divDisconnect.Visible = false;
                }
                else
                {
                    divDisconnect.Visible = true;
                    lblDisconnect.Visible = true;
                }
            }
        }
    }

    //public async Task ReadToken_QBO2()
    //{
    //    try
    //    {
    //        //Sync the state info and update if it is not the same
    //        var state = Request.QueryString["state"];
    //        if (state.Equals(QuickBookIntuit.auth2Client.CSRFToken, StringComparison.Ordinal))
    //        {
    //            ViewState["State"] = state + " (valid)";
    //        }
    //        else
    //        {
    //            ViewState["State"] = state + " (invalid)";
    //        }

    //        string code = Request.QueryString["code"] ?? "none";
    //        string realmId = Request.QueryString["realmId"] ?? "none";

    //        ViewState["Error"] = Request.QueryString["error"] ?? "none";

    //        await GetAuthTokensAsync(code, realmId);
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}

    /// <summary>
    /// Exchange Auth code with Auth Access and Refresh tokens and add them to Claim list
    /// </summary>
    //private async Task GetAuthTokensAsync(string code, string realmId)
    //{
    //    try
    //    {
    //        if (realmId != null)
    //        {
    //            Session["realmId"] = Convert.ToString(realmId);
    //        }
    //        if (code != null)
    //        {
    //            Session["Code_QBO2"] = Convert.ToString(code);
    //        }
    //        //Refresh token endpoint
    //        var tokenResponse = await QuickBookIntuit.auth2Client.GetBearerTokenAsync(code);
            
    //        if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
    //        {
    //            Session["access_token"] = Convert.ToString(tokenResponse.AccessToken);
    //            Session["access_token_expires_at"] = Convert.ToString(DateTime.UtcNow.AddSeconds(tokenResponse.AccessTokenExpiresIn));                
    //        }
            
    //        if (!string.IsNullOrWhiteSpace(tokenResponse.RefreshToken))
    //        {
    //            Session["refresh_token"] = Convert.ToString(tokenResponse.RefreshToken);
    //            Session["refresh_token_expires_at"] = Convert.ToString(DateTime.UtcNow.AddSeconds(tokenResponse.RefreshTokenExpiresIn));
    //            //claims.Add(new Claim("refresh_token", tokenResponse.RefreshToken));
    //            //claims.Add(new Claim("refresh_token_expires_at", (DateTime.Now.AddSeconds(tokenResponse.RefreshTokenExpiresIn)).ToString()));
    //        }

    //        if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
    //        {
    //            // update access tockens in table
    //            lblConnect.Visible = true;
    //            divConnect.Visible = true;

    //            Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "RefreshParentPage();", true);

    //            //UpdateAccessToken_QBO2();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}

    /// <summary>
    /// Initiate the ouath screen.
    /// </summary>
    private void FireAuth()
    {
        HttpContext.Current.Session["consumerKey"] = consumerKey;
        HttpContext.Current.Session["consumerSecret"] = consumerSecret;

        HttpContext.Current.Session["ClientId_QBO2"] = ClientId_QBO2;
        HttpContext.Current.Session["ClientSecret_QBO2"] = ClientSecret_QBO2;

        CreateAuthorization();
        IToken token = (IToken)HttpContext.Current.Session["requestToken"];
        tokenSecret = token.TokenSecret;
        strrequestToken = token.Token;
    }

    /// <summary>
    /// 
    /// </summary>
    protected void CreateAuthorization()
    {

        //Remember these for later.
        HttpContext.Current.Session["consumerKey"] = consumerKey;
        HttpContext.Current.Session["consumerSecret"] = consumerSecret;
        HttpContext.Current.Session["oauthLink"] = OAUTH_URL;
        //

        if (HttpContext.Current.Session["consumerKey"] != null && HttpContext.Current.Session["ConsumerSecret"] != null)
        {
            IOAuthSession session = CreateSession();
            IToken requestToken = session.GetRequestToken();
            HttpContext.Current.Session["requestToken"] = requestToken;
            tokenSecret = requestToken.TokenSecret;

            var authUrl = string.Format("{0}?oauth_token={1}&oauth_callback={2}", AUTHORIZE_URL, requestToken.Token, UriUtility.UrlEncode(Convert.ToString(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("oauth_callback_url"))));
            HttpContext.Current.Session["oauthLink"] = authUrl;
            Response.Redirect(authUrl);
        }
    }

    /// <summary>
    /// Create a session.
    /// </summary>
    /// <returns></returns>
    protected IOAuthSession CreateSession()
    {
        var consumerContext = new OAuthConsumerContext
        {
            ConsumerKey = HttpContext.Current.Session["consumerKey"].ToString(),
            ConsumerSecret = HttpContext.Current.Session["consumerSecret"].ToString(),
            SignatureMethod = SignatureMethod.HmacSha1
        };
        return new OAuthSession(consumerContext,
                                REQUEST_TOKEN_URL,
                                HttpContext.Current.Session["oauthLink"].ToString(),
                                ACCESS_TOKEN_URL);
    }

    /// <summary>
    /// Read the values from the query string.
    /// </summary>
    private void ReadToken()
    {
        HttpContext.Current.Session["oauthToken"] = Convert.ToString(Request.QueryString["oauth_token"]);

        HttpContext.Current.Session["oauthVerifyer"] = Convert.ToString(Request.QueryString["oauth_verifier"]);
        HttpContext.Current.Session["realm"] = Convert.ToString(Request.QueryString["realmId"]);
        HttpContext.Current.Session["dataSource"] = Convert.ToString(Request.QueryString["dataSource"]);

        //Stored in a session for demo purposes.
        //Production applications should securely store the Access Token
        if (HttpContext.Current.Session["accessToken"] == null && HttpContext.Current.Session["accessTokenSecret"] == null)
            getAccessToken();
    }

    /// <summary>
    /// Get Access token.
    /// </summary>
    private void getAccessToken()
    {
        IOAuthSession clientSession = CreateSession();

        IToken accessToken = clientSession.ExchangeRequestTokenForAccessToken((IToken)HttpContext.Current.Session["requestToken"], HttpContext.Current.Session["oauthVerifyer"].ToString());

        HttpContext.Current.Session["accessToken"] = accessToken.Token;
        HttpContext.Current.Session["accessTokenSecret"] = accessToken.TokenSecret;

        /// Update Other related Info
        UpdateAccessToken();
    }

    protected void btnDisconnect_Click(object sender, EventArgs e)
    {
        //Clearing all session data
        Disconnect();
    }

    private void Disconnect()
    {
        try
        {
            //Session.Clear();
            //Session.Abandon();
            HttpContext.Current.Session["accessToken"] = null;
            HttpContext.Current.Session["accessTokenSecret"] = null;
            HttpContext.Current.Session["realm"] = null;
            HttpContext.Current.Session["dataSource"] = null;
            lblDisconnect.Visible = true;
        }
        catch (Exception ex)
        {
            Response.Write(ex.InnerException);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private int GetKeysBasedOnOffice()
    {
        int res = 0;
        consumerKey = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerKey");
        consumerSecret = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerSecret");
        HttpContext.Current.Session["consumerKey"] = consumerKey;
        HttpContext.Current.Session["consumerSecret"] = consumerSecret;

        //HttpContext.Current.Session["ClientId_QBO2"] = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientId_QBO2");
        //HttpContext.Current.Session["ClientSecret_QBO2"] = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientSecret_QBO2");

        res = 1;
        return res;

        #region Commented Section
        //if (!string.IsNullOrEmpty(HdnOfficeID.Value.Trim()))
        //{
        //    Guid OfficeId = new Guid(Convert.ToString(HdnOfficeID.Value.Trim()));

        //    HttpContext.Current.Session["OfficeID"] = OfficeId;
        //    using (QuickBookIntuit QbInst = new QuickBookIntuit())
        //    {
        //        var qbd = QbInst.GetQBDataByOffice(OfficeId).ToList();
        //        if (qbd != null)
        //        {
        //            if (qbd.Count > 0)
        //            {
        //                consumerKey = qbd[0].ConsumerKey;
        //                consumerSecret = qbd[0].ConsumerSecret;
        //                HttpContext.Current.Session["consumerKey"] = consumerKey;
        //                HttpContext.Current.Session["consumerSecret"] = consumerSecret;
        //                res = 1;
        //            }
        //        }
        //    }
        //}
        //else
        //{
        //    consumerKey = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerKey");
        //    consumerSecret = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerSecret");
        //    HttpContext.Current.Session["consumerKey"] = consumerKey;
        //    HttpContext.Current.Session["consumerSecret"] = consumerSecret;
        //    res = 1;
        //}
        #endregion
    }

    /// <summary>
    /// 
    /// </summary>
    private void UpdateAccessToken()
    {
        if (HttpContext.Current.Session["QBFranc"] != null)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["QBFranc"])))
            {
                Guid FranchiseID = new Guid(Convert.ToString(HttpContext.Current.Session["QBFranc"]));
                using (QuickBookIntuit QbInst = new QuickBookIntuit())
                {
                    string straccessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
                    string straccessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
                    string stroauthToken = Convert.ToString(HttpContext.Current.Session["oauthToken"]);
                    string stroauthVerifyer = Convert.ToString(HttpContext.Current.Session["oauthVerifyer"]);
                    string strCompanyrealm = Convert.ToString(HttpContext.Current.Session["realm"]);

                    int res = QbInst.UpdateAccessRelatedInfoByOffice(FranchiseID, straccessToken, straccessTokenSecret,
                        stroauthToken, stroauthVerifyer, strCompanyrealm);

                    if (res == 1)
                    {
                        HttpContext.Current.Session.Remove("accessToken");
                        HttpContext.Current.Session.Remove("accessTokenSecret");
                    }


                    lblConnect.Visible = true;
                    divConnect.Visible = true;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "RefreshParentPage();", true);
                }
            }
        }
        else
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                string straccessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
                string straccessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
                string stroauthToken = Convert.ToString(HttpContext.Current.Session["oauthToken"]);
                string stroauthVerifyer = Convert.ToString(HttpContext.Current.Session["oauthVerifyer"]);
                string strCompanyrealm = Convert.ToString(HttpContext.Current.Session["realm"]);

                int res = QbInst.UpdateAccessRelatedInfoByOffice(null, straccessToken, straccessTokenSecret,
                    stroauthToken, stroauthVerifyer, strCompanyrealm);

                Response.Write("<script>window.close();</script>");
            }
        }
    }

    private void UpdateAccessToken_QBO2()
    {
        if (HttpContext.Current.Session["QBFranc"] != null)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["QBFranc"])))
            {
                //Guid FranchiseID = new Guid(Convert.ToString(Session["QBFranc"]));
                //using (QuickBookIntuit QbInst = new QuickBookIntuit())
                //{
                string accessToken_QBO2 = Convert.ToString(HttpContext.Current.Session["access_token"]);
                DateTime access_token_expires_at_QBO2 = Convert.ToDateTime(HttpContext.Current.Session["access_token_expires_at"]);
                string refresh_token_QBO2 = Convert.ToString(HttpContext.Current.Session["refresh_token"]);
                DateTime refresh_token_expires_at_QBO2 = Convert.ToDateTime(HttpContext.Current.Session["refresh_token_expires_at"]);
                string Companyrealm_QBO2 = Convert.ToString(HttpContext.Current.Session["realmId"]);

                lblConnect.Visible = true;
                divConnect.Visible = true;
                
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "RefreshParentPage();", true);

                //int res = QbInst.UpdateAccessRelatedInfoByOffice_QBO2(FranchiseID, accessToken_QBO2, Companyrealm_QBO2);

                //if (res == 1)
                //{
                //    Session.Remove("access_token");
                //    Session.Remove("refresh_token");
                //    Session.Remove("realmId");
                //}

                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "RefreshParentPage();", true);
                //}
            }
        }
        else
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                string straccessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
                string straccessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
                string stroauthToken = Convert.ToString(HttpContext.Current.Session["oauthToken"]);
                string stroauthVerifyer = Convert.ToString(HttpContext.Current.Session["oauthVerifyer"]);
                string strCompanyrealm = Convert.ToString(HttpContext.Current.Session["realm"]);

                int res = QbInst.UpdateAccessRelatedInfoByOffice(null, straccessToken, straccessTokenSecret,
                    stroauthToken, stroauthVerifyer, strCompanyrealm);

                Response.Write("<script>window.close();</script>");
            }
        }
    }

    /// <summary>
    /// Not required Now (16-Sep-2016)
    /// </summary>
    //private void CreateCustomer()
    //{
    //    using (QuickBookIntuit QbInst = new QuickBookIntuit())
    //    {
    //        var accessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
    //        var accessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
    //        var realmId = Convert.ToString(HttpContext.Current.Session["realm"]);
    //        var ClDis = Server.UrlDecode(HdnClDis.Value);

    //        string strMsg = QbInst.CreateCustomer(accessToken, accessTokenSecret, realmId, consumerKey, consumerSecret, ClDis);
    //        if (strMsg != "1")
    //        {
    //            JSMessage(strMsg);
    //        }
    //        else
    //            Response.Write("<script>window.close();</script>");
    //    }
    //}

    /// <summary>
    /// NOT IN USE
    /// </summary>
    //private void UpdateCustomer()
    //{
    //    using (QuickBookIntuit QbInst = new QuickBookIntuit())
    //    {
    //        var accessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
    //        var accessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
    //        var realmId = Convert.ToString(HttpContext.Current.Session["realm"]);
    //        var ClDis = Server.UrlDecode(HdnClDis.Value);

    //        string strMsg = QbInst.UpdateCustomerInfo(accessToken, accessTokenSecret, realmId, consumerKey, consumerSecret, ClDis);
    //        if (strMsg != "1")
    //        {
    //            JSMessage(strMsg);
    //        }
    //        else
    //            Response.Write("<script>window.close();</script>");
    //    }
    //}

    /// <summary>
    /// NOT IN USE
    /// </summary>
    //private void CreateCustomerInvoice()
    //{
    //    using (QuickBookIntuit QbInst = new QuickBookIntuit())
    //    {
    //        var accessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
    //        var accessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
    //        var realmId = Convert.ToString(HttpContext.Current.Session["realm"]);
    //        var InvID = Server.UrlDecode(HdnInvoiceID.Value);

    //        try
    //        {
    //            string strMsg = QbInst.CreateCustomerInvoice(accessToken, accessTokenSecret, realmId, consumerKey, consumerSecret, InvID);
    //            if (strMsg != "1")
    //            {
    //                JSMessage(strMsg);
    //            }
    //            else
    //                Response.Write("<script>window.close();</script>");
    //        }
    //        catch (Exception ex)
    //        {
    //            //// Include the Logic on how you want your app to handle the exception. This code writes fault messages to a console.
    //            JSMessage(ex.Message);
    //        }
    //    }
    //}

    /// <summary>
    /// NOT IN USE
    /// </summary>
    //private void CreateServiceType()
    //{
    //    using (QuickBookIntuit QbInst = new QuickBookIntuit())
    //    {
    //        var accessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
    //        var accessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
    //        var realmId = Convert.ToString(HttpContext.Current.Session["realm"]);
    //        var CallType = Server.UrlDecode(HdnCalltypes.Value);
    //        var ExpenseType = Server.UrlDecode(HdnExpense.Value);

    //        Guid OfficeId = new Guid(Convert.ToString(HdnOfficeID.Value.Trim()));

    //        string strMsg = string.Empty;

    //        if (!string.IsNullOrEmpty(CallType.Trim()))
    //            strMsg = QbInst.CreateServiceExpenseType(accessToken, accessTokenSecret, realmId, consumerKey, consumerSecret, CallType, OfficeId, 1);
    //        else if (!string.IsNullOrEmpty(ExpenseType.Trim()))
    //            strMsg = QbInst.CreateServiceExpenseType(accessToken, accessTokenSecret, realmId, consumerKey, consumerSecret, ExpenseType, OfficeId, 2);

    //        if (strMsg != "1")
    //        {
    //            JSMessage(strMsg);
    //        }
    //        else
    //            Response.Write("<script>window.close();</script>");
    //    }
    //}

    /// <summary>
    /// NOT IN USE
    /// </summary>
    //private void UpdateServiceType()
    //{
    //    using (QuickBookIntuit QbInst = new QuickBookIntuit())
    //    {
    //        var accessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
    //        var accessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
    //        var realmId = Convert.ToString(HttpContext.Current.Session["realm"]);
    //        var CallType = Server.UrlDecode(HdnCalltypes.Value);
    //        var QBitm = Server.UrlDecode(hdnQbItmNum.Value);
    //        var ExpenseType = Server.UrlDecode(HdnExpense.Value);

    //        Guid OfficeId = new Guid(Convert.ToString(HdnOfficeID.Value.Trim()));

    //        string strMsg = string.Empty;

    //        if (!string.IsNullOrEmpty(CallType.Trim()))
    //            strMsg = QbInst.UpdateServiceExpenseType(accessToken, accessTokenSecret, realmId, consumerKey, consumerSecret, CallType, OfficeId, QBitm, 1);
    //        //else if (!string.IsNullOrEmpty(ExpenseType.Trim()))
    //        //    strMsg = QbInst.UpdateServiceExpenseType(accessToken, accessTokenSecret, realmId, consumerKey, consumerSecret, ExpenseType, OfficeId, 2);

    //        if (strMsg != "1")
    //        {
    //            JSMessage(strMsg);
    //        }
    //        else
    //            Response.Write("<script>window.close();</script>");
    //    }
    //}

    /// <summary>
    /// 
    /// </summary>
    /// <param name="strMessage"></param>
    protected void JSMessage(string strMessage)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), "alert('" + strMessage + "');window.close();", true);
    }

    /// <summary>
    /// Create Customer
    /// </summary>
    //private void CreateCustomer()
    //{
    //    Customer customer = new Customer();
    //    PhysicalAddress custAddres = new PhysicalAddress();
    //    TelephoneNumber custTel = new TelephoneNumber();
    //    EmailAddress CustEmail = new EmailAddress();

    //    try
    //    {
    //        var serviceType = IntuitServicesType.QBO;
    //        var accessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
    //        var accessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
    //        var realmId = Convert.ToString(HttpContext.Current.Session["realm"]);

    //        var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
    //        var context = new ServiceContext(realmId, serviceType, validator);

    //        context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo"); // "https://sandbox-quickbooks.api.intuit.com/";

    //        context.IppConfiguration.Message.Request.SerializationFormat = Intuit.Ipp.Core.Configuration.SerializationFormat.Json;
    //        context.IppConfiguration.Message.Response.SerializationFormat = Intuit.Ipp.Core.Configuration.SerializationFormat.Json;

    //        var service = new DataService(context);

    //        custAddres.Line1 = "1512 Hunter Glen";
    //        custAddres.City = "Plainsboro";
    //        custAddres.CountrySubDivisionCode = "NJ";
    //        custAddres.PostalCode = "08536";

    //        custTel.FreeFormNumber = "(123)-456-2983";
    //        CustEmail.Address = "pkprashar@netsmartz.com";

    //        customer.GivenName = "Tom_3";
    //        customer.FamilyName = "Rudy_4";
    //        customer.CompanyName = "Text Company";
    //        customer.DisplayName = "Tom_3, Chris_4";

    //        customer.BillAddr = custAddres;

    //        customer.PrimaryPhone = custTel;
    //        customer.PrimaryEmailAddr = CustEmail;

    //        var getResponse = service.Add(customer);
    //        if (getResponse != null)
    //        {
    //            string strGetData = Convert.ToString(getResponse.Id);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        //TODO: handle dupe or other....
    //        var returnMessage = string.Empty;
    //        var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
    //        if (innerException != null)
    //        {
    //            returnMessage = innerException.Message;
    //        }
    //    }
    //    finally
    //    {
    //        custAddres = null;
    //        custTel = null;
    //        CustEmail = null;
    //        customer = null;
    //    }
    //}

    //private void CreateEmployee()
    //{
    //    Employee emp = new Employee();
    //    PhysicalAddress empAddres = new PhysicalAddress();
    //    TelephoneNumber empTel = new TelephoneNumber();
    //    EmailAddress empEmail = new EmailAddress();

    //    try
    //    {
    //        var serviceType = IntuitServicesType.QBO;
    //        var accessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
    //        var accessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
    //        var realmId = Convert.ToString(HttpContext.Current.Session["realm"]);

    //        var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
    //        var context = new ServiceContext(realmId, serviceType, validator);
    //        context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo"); // "https://sandbox-quickbooks.api.intuit.com/";

    //        context.IppConfiguration.Message.Request.SerializationFormat = Intuit.Ipp.Core.Configuration.SerializationFormat.Json;
    //        context.IppConfiguration.Message.Response.SerializationFormat = Intuit.Ipp.Core.Configuration.SerializationFormat.Json;

    //        var service = new DataService(context);

    //        empAddres.Line1 = "1512 Hunter Glen";
    //        empAddres.City = "Plainsboro";
    //        empAddres.CountrySubDivisionCode = "NJ";
    //        empAddres.PostalCode = "08536";

    //        empTel.FreeFormNumber = "(123)-456-2983";
    //        empEmail.Address = "pkprashar@netsmartz.com";

    //        emp.GivenName = "Employee_67";
    //        emp.FamilyName = "Check";
    //        emp.CompanyName = "Text Company";
    //        emp.DisplayName = "Check, Employee_67";

    //        emp.PrimaryAddr = empAddres;

    //        emp.PrimaryPhone = empTel;
    //        emp.PrimaryEmailAddr = empEmail;

    //        var getResponse = service.Add(emp);
    //        if (getResponse != null)
    //        {
    //            string strGetData = Convert.ToString(getResponse.Id);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        //TODO: handle dupe or other....
    //        var returnMessage = string.Empty;
    //        var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
    //        if (innerException != null)
    //        {
    //            returnMessage = innerException.Message;
    //        }
    //    }
    //    finally
    //    {
    //        empAddres = null;
    //        empTel = null;
    //        empEmail = null;
    //        emp = null;
    //    }
    //}


    //private void CreateServiceType()
    //{
    //    Item itm = new Item();

    //    ReferenceType IncomeRef = new ReferenceType();
    //    IncomeRef.Value = "70";
    //    IncomeRef.name = "Cost";

    //    ReferenceType ExpRef = new ReferenceType();
    //    ExpRef.Value = "80";
    //    ExpRef.name = "Sales";

    //    try
    //    {
    //        var serviceType = IntuitServicesType.QBO;
    //        var accessToken = Convert.ToString(HttpContext.Current.Session["accessToken"]);
    //        var accessTokenSecret = Convert.ToString(HttpContext.Current.Session["accessTokenSecret"]);
    //        var realmId = Convert.ToString(HttpContext.Current.Session["realm"]);

    //        var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
    //        var context = new ServiceContext(realmId, serviceType, validator);
    //        context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo"); // "https://sandbox-quickbooks.api.intuit.com/";

    //        context.IppConfiguration.Message.Request.SerializationFormat = Intuit.Ipp.Core.Configuration.SerializationFormat.Json;
    //        context.IppConfiguration.Message.Response.SerializationFormat = Intuit.Ipp.Core.Configuration.SerializationFormat.Json;

    //        var service = new DataService(context);

    //        itm.Name = "Item1";
    //        itm.Description = "Hourly";
    //        itm.IncomeAccountRef = IncomeRef;
    //        itm.ExpenseAccountRef = ExpRef;
    //        itm.TrackQtyOnHand = false;

    //        var getResponse = service.Add(itm);
    //        if (getResponse != null)
    //        {
    //            string strGetData = Convert.ToString(getResponse.Id);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        //TODO: handle dupe or other....
    //        var returnMessage = string.Empty;
    //        var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
    //        if (innerException != null)
    //        {
    //            returnMessage = innerException.Message;
    //        }
    //    }
    //    finally
    //    {
    //        itm = null;
    //    }
    //}
}