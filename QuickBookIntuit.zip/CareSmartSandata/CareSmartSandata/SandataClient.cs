﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
using System.Xml.Linq;

/// <summary>
/// Author: Saveen Gurung
/// Purpose: For Client upload
/// </summary>
namespace CareSmartSandata
{
    public class SandataClient
    {

        #region Client
        /// <summary>
        /// Used to get Client json Data
        /// Single entry multiple exit function
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <param name="AgencyId"></param>
        /// <returns>string</returns>
        public void ClientUpload(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = new DataBaseOperation().GetData(FromDatabase, "PrCSSandataGetClients", new { AgencyID = AgencyId }, AgencyId);
                if (string.IsNullOrEmpty(JSONStr))
                {
                    return;
                }

                List<Client> ListClient = new JavaScriptSerializer().Deserialize<List<Client>>(JSONStr);
                if (ListClient.Count == 0)
                {
                    return;
                }

                List<string> ClientGUID = new List<string>();

                foreach (Client client in ListClient)
                {
                    ClientGUID.Add(client.ClientID);
                }

                string URL = SanDataConfigurationKeys.SanDataBaseURL + SanDataConfigurationKeys.SandataClientEndpoint;

                Tuple<string, string, string> credentials = new SandataCredentials().GetCredentials(FromDatabase);
                string AccountNo = credentials.Item1;
                string UserID = credentials.Item2;
                string Password = credentials.Item3;

                string JSONResponse = new SandataOperation().SandataService(URL, UserID, Password, AccountNo, JSONStr);

                long RefId=new DBLogger().Log(FromDatabase, new { APIPoint = URL, Request = JSONStr, Response = JSONResponse }, AgencyId);

                if (string.IsNullOrEmpty(JSONResponse))
                {
                    return;
                }

                SandataResponse ResponseSandata = new JavaScriptSerializer().Deserialize<SandataResponse>(JSONResponse);

                if (string.Equals(ResponseSandata.status, "SUCCESS", StringComparison.OrdinalIgnoreCase))
                {
                    var branchesXml = ClientGUID.Select(i => new XElement("client", new XAttribute("id", i)));

                    var bodyXml = new XMLOperation().GetElement(ClientGUID, "client");

                    new DataBaseOperation().UpdateProcessedData(FromDatabase, "PrSanData_UpdateProcessdateByClientID", bodyXml.ToString());

                    Logger.PrintLog(LogType.Info, bodyXml.ToString());
                }

            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
        }

        public void CheckClientUploadStatus(long RefId,string AccountNo,string UserID,string Password)
        {

        }
        
        #endregion
    }
}
