﻿using Dapper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartSandata
{
   public class DataBaseOperation
    {

        /// <summary>
        /// Common method to database operations
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <param name="ProcedureName"></param>
        /// <param name="Parameters"></param>
        /// <param name="AgencyId"></param>
        /// <returns>string</returns>
        public string GetData(string FromDatabase, string ProcedureName, object Parameters, int AgencyId)
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                using (IDbConnection con = new SqlConnection(FromDatabase))
                {
                    con.Open();

                    var Table = con.Query(ProcedureName, Parameters, commandType: CommandType.StoredProcedure);

                    builder.Append(JsonConvert.SerializeObject(Table, Formatting.Indented));
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
            return builder.ToString();
        }


        /// <summary>
        /// Method to update processed Client/Caregiver Data
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <param name="ProcedureName"></param>
        /// <param name="XElement"></param> 
        public void UpdateProcessedData(string FromDatabase, string ProcedureName, string XElement)
        {
            try
            {
                using (IDbConnection con = new SqlConnection(FromDatabase))
                {
                    con.Open();
                    IDataReader DataReader = con.ExecuteReader(ProcedureName, new { XMLDetail = XElement }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
        }
    }
}
