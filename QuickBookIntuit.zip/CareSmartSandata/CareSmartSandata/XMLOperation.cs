﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CareSmartSandata
{
    public class XMLOperation
    {
        public XElement GetElement(List<string> List, string XElementName)
        {
            var branchesXml = List.Select(i => new XElement(XElementName,
                                                  new XAttribute("id", i)));
            var bodyXml = new XElement("RootElement", branchesXml);

            return bodyXml;
        }
    }
}
