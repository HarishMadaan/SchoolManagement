﻿namespace CareSmartSandata.AltEVVModel
{
    public enum ServiceTypeEnum
    {
        Patient=0,
        DirectCaregiver=1,
        Visit=2
    }
}
