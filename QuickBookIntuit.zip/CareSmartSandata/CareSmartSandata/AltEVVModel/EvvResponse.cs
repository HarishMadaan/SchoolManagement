﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartSandata.AltEVVModel
{
    
    public class Data
    {
        public object GroupVisitIndicator { get; set; }
        public object GroupVisitCode { get; set; }
        public string Payer { get; set; }
        public string PayerProgram { get; set; }
        public object ProcedureCode { get; set; }
        public List<object> Calls { get; set; }
        public List<object> Tasks { get; set; }
        public object controlID { get; set; }
        public string BusinessEntityID { get; set; }
        public string BusinessEntityMedicaidIdentifier { get; set; }
        public string VisitOtherID { get; set; }
        public string SequenceID { get; set; }
        public string StaffOtherID { get; set; }
        public string PatientOtherID { get; set; }
        public string PatientMedicaidID { get; set; }
        public bool VisitCancelledIndicator { get; set; }
        public string TimeZone { get; set; }
        public string AdjInDateTime { get; set; }
        public string AdjOutDateTime { get; set; }
        public bool BillVisit { get; set; }
        public object HoursToBill { get; set; }
        public object VisitMemo { get; set; }
        public bool MemberVerifiedTimes { get; set; }
        public bool MemberVerifiedService { get; set; }
        public bool MemberSignatureAvailable { get; set; }
        public bool MemberVoiceRecording { get; set; }
        public List<object> VisitException { get; set; }
        public List<object> VisitChanges { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
    }

    public class EvvResponse
    {
        public string id { get; set; }
        public object status { get; set; }
        public object token { get; set; }
        public string messageSummary { get; set; }
        public object messageDetail { get; set; }
        public object errorMessage { get; set; }
        public int failedCount { get; set; }
        public int succeededCount { get; set; }
        public bool cached { get; set; }
        public object cachedDate { get; set; }
        public int totalRows { get; set; }
        public int page { get; set; }
        public int pageSize { get; set; }
        public object orderByColumn { get; set; }
        public object orderByDirection { get; set; }
        public object data { get; set; }
    }
}
