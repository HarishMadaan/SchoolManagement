﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartSandata.AltEVVModel
{
   public class CompanyConfigurationInfo
    {
        public int AgencyID { get; set; }
        public string FromDatabase { get; set; }
        public string EVVBusinessEntityID { get; set; }
        public string EVVBusinessEntityMedicaidIdentifier { get; set; }
        public string Phase2PostPatientURL { get; set; }
        public string Phase2GetPatientDataStatusURL { get; set; }
        public string Phase2PostStaffURL { get; set; }
        public string Phase2GetStaffDataStatusURL { get; set; }
        public string Phase2PostVisitURL { get; set; }
        public string Phase2GetVisitDataStatusURL { get; set; }
        public string EVVUserID { get; set; }
        public string EVVPassword { get; set; }
    }
}
