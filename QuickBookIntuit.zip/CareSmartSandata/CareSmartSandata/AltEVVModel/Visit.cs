﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CareSmartSandata.AltEVVModel
{
 
    public class Call
    {
        [JsonIgnore]
        public string SandataVisitIncId { get; set; }
        [JsonIgnore]
        public string ScheduleSlotId { get; set; }
        public string CallExternalID { get; set; }
        public DateTime CallDateTime { get; set; }
        public string CallAssignment { get; set; }
        public string CallType { get; set; }
        public string ProcedureCode { get; set; }
        public string PatientIdentifierOnCall { get; set; }
        public string MobileLogin { get; set; }
        public string CallLatitude { get; set; }
        public string CallLongitude { get; set; }
        public string TelephonyPIN { get; set; }
        public string OriginatingPhoneNumber { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }

    public class VisitException
    {
        public string ExceptionID { get; set; }
        public bool ExceptionAcknowledged { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }

    public class VisitChange
    {
        public string SequenceID { get; set; }
        public string ChangeMadeByEmail { get; set; }
        public string ChangeDateTime { get; set; }
        public string ReasonCode { get; set; }
        public string ChangeReasonMemo { get; set; }
        public string ResolutionCode { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }

    public class Visit
    {
        public string BusinessEntityID { get; set; }
        public string BusinessEntityMedicaidIdentifier { get; set; }
        [JsonIgnore]
        public string SandataVisitIncId { get; set; }
        [JsonIgnore]
        public string ScheduleSlotId { get; set; }

        public string VisitOtherID { get; set; }
        public string  SequenceID { get; set; }
        public string StaffOtherID { get; set; }
        public string PatientOtherID { get; set; }
        public string PatientMedicaidID { get; set; }
        public bool VisitCancelledIndicator { get; set; }
        public string Payer { get; set; }
        public string PayerProgram { get; set; }
        public string ProcedureCode { get; set; }
        public string TimeZone { get; set; }
        public string AdjInDateTime { get; set; }
        public string AdjOutDateTime { get; set; }
        public bool BillVisit { get; set; }
        public int HoursToBill { get; set; }
        public string VisitMemo { get; set; }
        public bool MemberVerifiedTimes { get; set; }
        public bool MemberVerifiedService { get; set; }
        public bool MemberSignatureAvailable { get; set; }
        public bool MemberVoiceRecording { get; set; }
        public List<Call> Calls { get; set; }
        public List<VisitException> VisitException { get; set; }
        public List<VisitChange> VisitChanges { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }
}
