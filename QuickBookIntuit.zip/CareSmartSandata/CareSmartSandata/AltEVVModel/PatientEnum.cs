﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartSandata.AltEVVModel
{
    enum PatientEnum
    {
        Patient=0,
        IndividualPayerInformation=1,
        Address=2,
        IndividualPhones=3,
        PatientResponsibleParty=4
    }
}
