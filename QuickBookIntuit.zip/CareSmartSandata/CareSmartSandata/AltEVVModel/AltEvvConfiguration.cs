﻿namespace CareSmartSandata.AltEVVModel
{
    public class AltEvvConfiguration
    {
        public string Phase2PostPatientURL { get; set; }
        public string Phase2GetPatientDataStatusURL { get; set; }
        public string Phase2PostStaffURL { get; set; }
        public string Phase2GetStaffDataStatusURL { get; set; }
        public string Phase2PostVisitURL { get; set; }
        public string Phase2GetVisitDataStatusURL { get; set; }
    }
}
