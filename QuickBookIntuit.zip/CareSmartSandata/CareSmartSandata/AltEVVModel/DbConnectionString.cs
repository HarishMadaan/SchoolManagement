﻿namespace CareSmartSandata.AltEVVModel
{
    public class DbConnectionString
    {
        public string AgencyId { get; set; }
        public string DBName { get; set; }
        public string DataSource { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string URL { get; set; }
        public string DomainURL { get; set; }
        public string EVVBusinessEntityID { get; set; }
        public string EVVBusinessEntityMedicaidIdentifier { get; set; }
        public string EVVUserID { get; set; }
        public string EvvPassword { get; set; }
    }
}
