﻿namespace CareSmartSandata.AltEVVModel
{
    public enum VisitEnum
    {
        Visit = 0,
        Calls=1,
        VisitException=2,
        VisitChanges=3
    }
}
