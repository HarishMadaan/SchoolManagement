﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartSandata.AltEVVModel
{
    public class KeyValueClass<T>
    {
        public string KeyName {get; set;}
        public T KeyValue { get; set; }
    }
}
