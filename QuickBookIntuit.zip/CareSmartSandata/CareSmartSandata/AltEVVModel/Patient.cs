﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CareSmartSandata.AltEVVModel
{

    public class IndividualPayerInformation
    {
        public string Payer { get; set; }
        public string PayerProgram { get; set; }
        public string ProcedureCode { get; set; }
        [JsonIgnore]
        public string PatientOtherID { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }

    public class Address
    {
        public string PatientAddressType { get; set; }
        public bool PatientAddressIsPrimary { get; set; }
        public string PatientAddressLine1 { get; set; }

        public string PatientAddressLine2 { get; set; }
        public string PatientCity { get; set; }
        public string PatientState { get; set; }
        public string PatientZip { get; set; }
        public string PatientLongitude { get; set; }
        public string PatientLatitude { get; set; }
        public string PatientTimezone { get; set; }
        [JsonIgnore]
        public string PatientOtherID { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }

    public class IndividualPhone
    {
        public string PatientPhoneType { get; set; }
        public string PatientPhoneNumber { get; set; }
        [JsonIgnore]
        public string PatientOtherID { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }

    public class PatientResponsibleParty
    {
        public string PatientResponsiblePartyLastName { get; set; }
        public string PatientResponsiblePartyFirstName { get; set; }
        [JsonIgnore]
        public string PatientOtherID { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }

    public class Patient
    {
        public string BusinessEntityID { get; set; }
        public string BusinessEntityMedicaidIdentifier { get; set; }
        public string PatientOtherID { get; set; }
        public string SequenceID { get; set; }
        public string PatientMedicaidID { get; set; }
        public string IsPatientNewborn { get; set; }
        public string PatientAlternateID { get; set; }
        public string PatientLastName { get; set; }
        public string PatientFirstName { get; set; }
        public string PatientTimezone { get; set; }
        public object IndividualPayerInformation { get; set; }
        public object Address { get; set; }
        public object IndividualPhones { get; set; }
        public object PatientResponsibleParty { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }


}