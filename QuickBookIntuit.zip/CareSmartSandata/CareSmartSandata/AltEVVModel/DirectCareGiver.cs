﻿using Newtonsoft.Json;

namespace CareSmartSandata.AltEVVModel
{
    public class DirectCaregiver
    {
        public string BusinessEntityID { get; set; }
        public string BusinessEntityMedicaidIdentifier { get; set; }
        public string StaffOtherID { get; set; }
        public string StaffFirstName { get; set; }
        public string StaffLastName { get; set; }
        public string StaffID { get; set; }
        public string StaffEmail { get; set; }
        public string StaffSSN { get; set; }
        public string StaffPosition { get; set; }
        public string SequenceID { get; set; }
        [JsonIgnore]
        public string ErrorCode { get; set; }
        [JsonIgnore]
        public string ErrorMessage { get; set; }
    }
}
