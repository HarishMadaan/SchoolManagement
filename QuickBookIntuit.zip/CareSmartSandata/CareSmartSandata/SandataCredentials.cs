﻿using Dapper;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace CareSmartSandata
{
    public class SandataCredentials
    {
        public Tuple<string, string, string> GetCredentials(string FromDatabase)
        {
            string AccountNo = string.Empty;
            string LoginID = string.Empty;
            string Password = string.Empty;

            StringBuilder builder = new StringBuilder();
            try
            {
                using (IDbConnection con = new SqlConnection(FromDatabase))
                {
                    con.Open();

                    var dr = con.ExecuteReader("PrGetSandataOfficeDetail", null, commandType: CommandType.StoredProcedure);
                    
                    if (dr != null)
                    {
                        while (dr.Read())
                        {
                            AccountNo = dr.GetString(0);
                            LoginID = dr.GetString(1);
                            Password = dr.GetString(2);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }

            return new Tuple<string, string, string>(AccountNo, LoginID, Password);

        }
    }
}
