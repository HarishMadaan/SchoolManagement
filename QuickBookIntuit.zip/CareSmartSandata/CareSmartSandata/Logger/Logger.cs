﻿using log4net;

/// <summary>
/// Created by:- Saveen Gurung
/// Date:- 23 May 2019
/// </summary>

namespace CareSmartSandata
{
    class Logger
    {
        private static readonly ILog Log =
             LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        /// <summary>
        /// Used to print log according to their type.
        /// </summary>
        /// <param name="Type"></param>
        /// <param name="LogInfo"></param>
        public static void PrintLog(LogType Type, string LogInfo)
        {

            switch (Type)
            {
                case LogType.Fatal:
                    Log.Fatal(LogInfo);
                    break;
                case LogType.Error:
                    Log.Error(LogInfo);
                    break;
                case LogType.Warn:
                    Log.Warn(LogInfo);
                    break;
                case LogType.Info:
                    Log.Info(LogInfo);
                    break;
                case LogType.Debug:
                    Log.Debug(LogInfo);
                    break;
            }
           
        }
    }
}
