﻿namespace CareSmartSandata
{
    /// <summary>
    /// Created by:- Saveen Gurung
    /// Date:- 23 May 2019
    /// </summary>

    public enum LogType
    {
        Fatal = 1,
        Error = 2,
        Warn = 3,
        Info = 4,
        Debug = 5
    }
}
