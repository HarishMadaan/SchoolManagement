﻿using Dapper;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace CareSmartSandata
{
    public class DBLogger
    {

        public long Log(string FromDatabase, object Parameters, int AgencyId)
        {
            long RegId = 0;
            StringBuilder builder = new StringBuilder();
            try
            {
                using (IDbConnection con = new SqlConnection(FromDatabase))
                {
                    con.Open();

                    //var Table = con.Query("PrSandataLog", Parameters, commandType: CommandType.StoredProcedure);
                     RegId = Convert.ToInt64(con.ExecuteScalar("PrSandataLog", Parameters, commandType: CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }
            return RegId;
        }


        public long LogEVVSandata(string FromDatabase, object Parameters)
        {
            long RegId = 0;
            StringBuilder builder = new StringBuilder();
            try
            {
                using (IDbConnection con = new SqlConnection(FromDatabase))
                {
                    con.Open();

                    //var Table = con.Query("PrSandataLog", Parameters, commandType: CommandType.StoredProcedure);
                    RegId = Convert.ToInt64(con.ExecuteScalar("PrInsEvvSandataAuditLog", Parameters, commandType: CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }
            return RegId;
        }
    }
}
