﻿using CareSmartSandata.AltEVV;
using CareSmartSandata.AltEVVModel;
using CareSmartSandata.CommonClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace CareSmartSandata
{
    class BusinessLogic
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ServerId"></param>
        /// <param name="FromDatabase"></param>
        /// <returns></returns>
        public static DataTable GetDbConnections(Int16 ServerId, string FromDatabase)
        {
            try
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@ServerId", ServerId);
                ds = SqlHelper.ExecuteDataset("PrCSGetSandataEnabledAgency", FromDatabase, arrParam);
                if (ds.Tables.Count > 0)
                    return ds.Tables[0];
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }
            return null;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="ServerId"></param>
        /// <param name="FromDatabase"></param>
        /// <returns></returns>
        public static Dictionary<string,object> GetDbAndConfiguration(int ServerId, string FromDatabase)
        {
            try
            {
                DataSet ds = new DataSet();
                Dictionary<string, object> listObject = new Dictionary<string, object>();
                SqlParameter[] arrParam = new SqlParameter[1];
                arrParam[0] = new SqlParameter("@ServerId", ServerId);
                ds = SqlHelper.ExecuteDataset("PrGetAllSandataDbAndConfiguration", FromDatabase, arrParam);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        List<DbConnectionString> dbConnections = ds.Tables[0].ToList<DbConnectionString>();
                        listObject.Add("DBConnections",dbConnections);
                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        Dictionary<string, string> dic = ds.Tables[1].GetDictionary();
                        AltEvvConfiguration configuration = new AltEvvConfiguration();
                        configuration.Phase2PostPatientURL = dic["Phase2PostPatientURL"];
                        configuration.Phase2GetPatientDataStatusURL = dic["Phase2GetPatientDataStatusURL"];
                        configuration.Phase2PostStaffURL = dic["Phase2PostStaffURL"];
                        configuration.Phase2GetStaffDataStatusURL = dic["Phase2GetStaffDataStatusURL"];
                        configuration.Phase2PostVisitURL = dic["Phase2PostVisitURL"];
                        configuration.Phase2GetVisitDataStatusURL = dic["Phase2GetVisitDataStatusURL"];
                        listObject.Add("EVVConfiguration",configuration);
                    }
                    return listObject;
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }
            return null;
        }


        #region Sandata Operations
        #endregion

    }

    /// <summary>
    /// 
    /// </summary>
    public class SecurityClass
    {
        private static readonly string key = "29xdVi33L5W32SL2";

        public static string Encrypt(string toEncrypt)
        {
            byte[] keyArray = UTF8Encoding.UTF8.GetBytes(key);
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(NullPadString(toEncrypt));
            RijndaelManaged rDel = new RijndaelManaged();

            rDel.Key = keyArray;
            rDel.Mode = CipherMode.ECB; // http://msdn.microsoft.com/en-us/library/system.security.cryptography.ciphermode.aspx
            rDel.Padding = PaddingMode.None; // better lang support

            ICryptoTransform cTransform = rDel.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            string base64Data = Convert.ToBase64String(resultArray, 0, resultArray.Length);

            return SpecialCharterEncrypt(base64Data);
        }

        public static string Decrypt(string toDecrypt)
        {
            toDecrypt = SpecialCharterDecrypt(toDecrypt);

            byte[] keyArray = UTF8Encoding.UTF8.GetBytes(key); // AES-256 key
            byte[] toEncryptArray = Convert.FromBase64String(toDecrypt);
            RijndaelManaged rDel = new RijndaelManaged();

            rDel.Key = keyArray;
            rDel.Mode = CipherMode.ECB; // http://msdn.microsoft.com/en-us/library/system.security.cryptography.ciphermode.aspx
            rDel.Padding = PaddingMode.None;  //.PKCS7; // better lang support

            ICryptoTransform cTransform = rDel.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            //return SpecialCharterDecrypt(UTF8Encoding.UTF8.GetString(resultArray));
            return SpecialCharterDecrypt(UTF8Encoding.UTF8.GetString(resultArray));
        }

        static string SpecialCharterDecrypt(string text)
        {
            string strText = text.Replace("%26", "&")
                                    .Replace("%2B", "+")
                                    .Replace("%2C", ",")
                                    .Replace("%2F", "/")
                                    .Replace("%3A", ":")
                                    .Replace("%3B", ";")
                                    .Replace("%3D", "=")
                                    .Replace("%3F", "?")
                                    .Replace("%40", "@")
                                    .Replace("%20", " ")
                                    .Replace("%09", "\t")
                                    .Replace("%23", "#")
                                    .Replace("%3C", "<")
                                    .Replace("%3E", ">")
                                    .Replace("%22", "\"")
                                    .Replace("%0A", "\n")
                                    .Replace("\0", "");
            return strText;
        }

        static string SpecialCharterEncrypt(string text)
        {
            string strText = text.Replace("&", "%26")
                                    .Replace("+", "%2B")
                                    .Replace(",", "%2C")
                                    .Replace("/", "%2F")
                                    .Replace(":", "%3A")
                                    .Replace(";", "%3B")
                                    .Replace("=", "%3D")
                                    .Replace("?", "%3F")
                                    .Replace("@", "%40")
                                    .Replace(" ", "%20")
                                    .Replace("\t", "%09")
                                    .Replace("#", "%23")
                                    .Replace("<", "%3C")
                                    .Replace(">", "%3E")
                                    .Replace("\"", "%22")
                                    .Replace("\n", "%0A");
            return strText;
        }

        static String NullPadString(String original)
        {
            String output = original;
            int remain = output.Length % 16;

            if (remain != 0)
            {
                remain = 16 - remain;
                for (int i = 0; i < remain; i++)
                    output += (char)0;
            }
            return output;
        }
    }
}
