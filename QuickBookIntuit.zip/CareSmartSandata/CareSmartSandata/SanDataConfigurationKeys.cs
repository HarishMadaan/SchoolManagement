﻿using System.ComponentModel;
using System.Configuration;

class SanDataConfigurationKeys
{
 
    public static string SanDataBaseURL {
        get
        {
            return ConfigurationManager.AppSettings["SandataBaseURL"];
        }
    }
    
    public static string SandataEmployeeEndpoint
    {
        get
        {
            return ConfigurationManager.AppSettings["SandataEmployeeEndpoint"];
        }
    }

    public static string SandataClientEndpoint
    {
        get
        {
            return ConfigurationManager.AppSettings["SandataClientEndpoint"];
        }
    }

    public static string SandataSchedulesEndpoint
    {
        get
        {
            return ConfigurationManager.AppSettings["SandataSchedulesEndpoint"];
        }
    }
    
}
