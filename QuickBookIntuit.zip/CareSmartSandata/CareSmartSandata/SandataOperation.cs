﻿using Dapper;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using System.Xml.Linq;

namespace CareSmartSandata
{
    public class SandataOperation
    {
        #region Client JSON
        /// <summary>
        /// Used to get Client json Data
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <param name="AgencyId"></param>
        /// <returns>string</returns>
        public void FetchClientJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataGetClients", new { AgencyID = AgencyId }, AgencyId);
                if (string.IsNullOrEmpty(JSONStr))
                {
                    return;
                }

                List<Client> ListClient = new JavaScriptSerializer().Deserialize<List<Client>>(JSONStr);
                if (ListClient.Count == 0)
                {
                    return;
                }

                List<string> ClientGUID = new List<string>();

                foreach (Client client in ListClient)
                {
                    ClientGUID.Add(client.ClientID);
                }

                string URL = SanDataConfigurationKeys.SanDataBaseURL + SanDataConfigurationKeys.SandataClientEndpoint;

                Tuple<string, string, string> credentials = new SandataCredentials().GetCredentials(FromDatabase);
                string AccountNo = credentials.Item1;
                string UserID = credentials.Item2;
                string Password = credentials.Item3;

                string JSONResponse = SandataService(URL, UserID, Password, AccountNo, JSONStr);

                new DBLogger().Log(FromDatabase, new { APIPoint = URL, Request = JSONStr, Response = JSONResponse }, AgencyId);

                if (string.IsNullOrEmpty(JSONResponse))
                {
                    return;
                }

                SandataResponse ResponseSandata = new JavaScriptSerializer().Deserialize<SandataResponse>(JSONResponse);

                if (string.Equals(ResponseSandata.status, "SUCCESS", StringComparison.OrdinalIgnoreCase))
                {
                    var branchesXml = ClientGUID.Select(i => new XElement("client", new XAttribute("id", i)));

                    var bodyXml = GetElement(ClientGUID, "client");

                    //UpdateProcessedData(FromDatabase, "PrSanData_UpdateProcessdateByClientID", bodyXml.ToString());

                    Logger.PrintLog(LogType.Info, bodyXml.ToString());
                }

            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
        }
        #endregion

        #region Caregiver JSON   
        /// <summary>
        /// Used to get Client json Data
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <param name="AgencyId"></param>
        /// <returns>string</returns>
        public void FetchCareGiverJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataGetCaregiver", new { AgencyID = AgencyId }, AgencyId);
                if (string.IsNullOrEmpty(JSONStr))
                {
                    return;
                }

                List<Caregiver> ListCaregiver = new JavaScriptSerializer().Deserialize<List<Caregiver>>(JSONStr);

                if (ListCaregiver.Count == 0)
                {
                    return;
                }

                List<string> CaregiverID = new List<string>();
                foreach (Caregiver Caregiver in ListCaregiver)
                {
                    CaregiverID.Add(Caregiver.EmployeeID);
                }

                string URL = SanDataConfigurationKeys.SanDataBaseURL + SanDataConfigurationKeys.SandataClientEndpoint;

                Tuple<string, string, string> credentials = new SandataCredentials().GetCredentials(FromDatabase);
                string AccountNo = credentials.Item1;
                string UserID = credentials.Item2;
                string Password = credentials.Item3;

                string JSONResponse = SandataService(URL, UserID, Password, AccountNo, JSONStr);

                new DBLogger().Log(FromDatabase, new { APIPoint = URL, Request = JSONStr, Response = JSONResponse }, AgencyId);

                if (string.IsNullOrEmpty(JSONResponse))
                {
                    return;
                }

                SandataResponse ResponseSandata = new JavaScriptSerializer().Deserialize<SandataResponse>(JSONResponse);

                if (string.Equals(ResponseSandata.status, "SUCCESS", StringComparison.OrdinalIgnoreCase))
                {
                    var branchesXml = CaregiverID.Select(i => new XElement("caregiver",
                                        new XAttribute("id", i)));
                    var bodyXml = GetElement(CaregiverID, "caregiver");

                    //UpdateProcessedData(FromDatabase, "PrSanData_UpdateProcessdateByCaregiverID", bodyXml.ToString());

                    Logger.PrintLog(LogType.Info, bodyXml.ToString());
                }

            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
        }
        #endregion

        #region Sandata XREF
        public void FetchXREFJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataXREF", new { AgencyID = AgencyId }, AgencyId);
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
        }
        #endregion

        #region Sandata Activity
        public void FetchActivityJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataActivity", new { AgencyID = AgencyId }, AgencyId);
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
        }
        #endregion

        #region Sandata Payer Information
        public void FetchPayerInformationJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataPayerInformation", new { AgencyID = AgencyId }, AgencyId);
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }

        }
        #endregion

        #region Sandata PhoneNbr
        public void FetchPhoneNbrJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataGetClientPhoneNo", new { AgencyID = AgencyId }, AgencyId);
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }

        }
        #endregion

        #region Sandata Client Address
        public void FetchClientAddressJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataGetClientAddress", new { AgencyID = AgencyId }, AgencyId);
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }

        }
        #endregion

        #region Sandata Telephony Activity
        public void FetchTelephonyActivityJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataGetTelephonyActivity", new { AgencyID = AgencyId }, AgencyId);
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }

        }
        #endregion

        #region Sandata Task
        public void FetchTaskJSONData(string FromDatabase, int AgencyId)
        {
            try
            {
                string JSONStr = GetData(FromDatabase, "PrCSSandataGetTask", new { AgencyID = AgencyId }, AgencyId);

                if (string.IsNullOrEmpty(JSONStr))
                {
                    return;
                }

                List<SandataTask> ListClient = new JavaScriptSerializer().Deserialize<List<SandataTask>>(JSONStr);
                if (ListClient.Count == 0)
                {
                    return;
                }

                List<string> TaskList = new List<string>();

                foreach (SandataTask task in ListClient)
                {
                    TaskList.Add(Convert.ToString(task.ScheduleID));
                }

                var bodyXml = GetElement(TaskList, "Schedule");

                UpdateProcessedData(FromDatabase, "PrSanData_UpdateProcessdateByClientID", bodyXml.ToString());

            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
        }
        #endregion

        /// <summary>
        /// Common method to database operations
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <param name="ProcedureName"></param>
        /// <param name="Parameters"></param>
        /// <param name="AgencyId"></param>
        /// <returns>string</returns>
        public string GetData(string FromDatabase, string ProcedureName, object Parameters, int AgencyId)
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                using (IDbConnection con = new SqlConnection(FromDatabase))
                {
                    con.Open();

                    var Table = con.Query(ProcedureName, Parameters, commandType: CommandType.StoredProcedure);

                    builder.Append(JsonConvert.SerializeObject(Table, Formatting.Indented));
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
            return builder.ToString();
        }

        /// <summary>
        /// Method to update processed Client/Caregiver Data
        /// </summary>
        /// <param name="FromDatabase"></param>
        /// <param name="ProcedureName"></param>
        /// <param name="XElement"></param> 
        public void UpdateProcessedData(string FromDatabase, string ProcedureName, string XElement)
        {
            try
            {
                using (IDbConnection con = new SqlConnection(FromDatabase))
                {
                    con.Open();
                    IDataReader DataReader = con.ExecuteReader(ProcedureName, new { XMLDetail = XElement }, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                throw;
            }
        }

        //Creating xml element 
        public XElement GetElement(List<string> List, string XElementName)
        {
            var branchesXml = List.Select(i => new XElement(XElementName,
                                                  new XAttribute("id", i)));
            var bodyXml = new XElement("RootElement", branchesXml);

            return bodyXml;
        }


        public string SandataService(string URL, string Userid, string Password, string AccountNo, string RequestBody)
        {
            try
            {
                string AuthorizationBasic = "Basic " + Base64Encode(Userid + ":" + Password);
                var client = new RestClient(URL);

                //var request = new RestRequest(Method.POST);
                //request.AddHeader("cache-control", "no-cache");
                //request.AddHeader("content-type", "application/json");
                //request.AddHeader("account", AccountNo);
                //request.AddHeader("authorization", AuthorizationBasic);
                //request.AddParameter("application/json", RequestBody, ParameterType.RequestBody);
                //IRestResponse response = client.Execute(request);
                //return response.Content;
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }
            return null;
        }


        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

    }

}
