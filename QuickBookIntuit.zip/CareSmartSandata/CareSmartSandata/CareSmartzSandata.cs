﻿using CareSmartSandata.AltEVV;
using CareSmartSandata.AltEVVModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.ServiceProcess;
using System.Timers;

namespace CareSmartSandata
{
    public partial class CareSmartzSandata : ServiceBase
    {

        #region "Property"
        Timer timer = new Timer();
        static bool isRunning = false;
        DataTable DT = new DataTable();
        // This is the object that we lock to control access
        private static object _intervalSync = new object();

        public string ConnectionString => ConfigurationManager.AppSettings["CommonConnectionString"].ToString();
        public string HCMConnectionString => ConfigurationManager.ConnectionStrings["HMCConnectionString"].ToString();

        #endregion


        public CareSmartzSandata()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
            //timer.Interval = (1000 * 10);  //(1000 * 10 * 60); //Minutes
            timer.Interval = (1000 * 30 ); //Minutes
            // timer.Interval = (1000 * 1 * 60)*60; //hours
            timer.Enabled = true;
        }

        protected override void OnStop()
        {
        }

        private void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            Logger.PrintLog(LogType.Info, "Service Started");
            GetDataDataMethod();
        }


        private void GetDataDataMethod()
        {
            try
            {
                if (isRunning == false)
                {
                    isRunning = true;
                    // DataTable dt = BusinessLogic.GetDbConnections(Convert.ToInt16(readConfig("ServerId")), HCMConnectionString);

                    Dictionary<string, object> dic = BusinessLogic.GetDbAndConfiguration(Convert.ToInt16(readConfig("ServerId")), HCMConnectionString);
                    if (dic == null)
                    {
                        return;
                    }
                    if (dic.ContainsKey("DBConnections"))
                    {
                        List<DbConnectionString> dbConnections = (List<DbConnectionString>)dic["DBConnections"];
                        foreach (DbConnectionString DbStr in dbConnections)
                        {
                            string FromDatabase = ConnectionString.Replace("$Databasename$", Convert.ToString(DbStr.DBName))
                                 .Replace("$DataSource$", SecurityClass.Decrypt(Convert.ToString(DbStr.DataSource))).Replace("$UserName$", SecurityClass.Decrypt(Convert.ToString(DbStr.Username))).Replace("$Password$", SecurityClass.Decrypt(Convert.ToString(DbStr.Password)));
                            int AgencyID = Convert.ToInt32(DbStr.AgencyId);

                            CompanyConfigurationInfo configurationInfo = new CompanyConfigurationInfo();
                            configurationInfo.AgencyID = AgencyID;
                            configurationInfo.FromDatabase = FromDatabase;
                            configurationInfo.EVVBusinessEntityID = DbStr.EVVBusinessEntityID;
                            configurationInfo.EVVBusinessEntityMedicaidIdentifier = DbStr.EVVBusinessEntityMedicaidIdentifier;
                            configurationInfo.EVVUserID = DbStr.EVVUserID;
                            configurationInfo.EVVPassword = DbStr.EvvPassword;


                            if (dic.ContainsKey("EVVConfiguration"))
                            {
                                AltEvvConfiguration dicConfiguration = (AltEvvConfiguration)dic["EVVConfiguration"];
                                configurationInfo.Phase2PostPatientURL = dicConfiguration.Phase2PostPatientURL;
                                configurationInfo.Phase2GetPatientDataStatusURL = dicConfiguration.Phase2GetPatientDataStatusURL;
                                configurationInfo.Phase2PostStaffURL = dicConfiguration.Phase2PostStaffURL;
                                configurationInfo.Phase2GetStaffDataStatusURL = dicConfiguration.Phase2GetStaffDataStatusURL;
                                configurationInfo.Phase2PostVisitURL = dicConfiguration.Phase2PostVisitURL;
                                configurationInfo.Phase2GetVisitDataStatusURL = dicConfiguration.Phase2GetVisitDataStatusURL;
                                
                                new PatientOperation().GetPatientData(configurationInfo);

                               new DirectCaregiverOperation().GetCaregiverData(configurationInfo);

                               new VisitOperation().GetVisitData(configurationInfo);
                            }
                        }
                    }


                    //foreach (DataRow item in dt.Rows)
                    //{
                    //    string FromDatabase = ConnectionString.Replace("$Databasename$", Convert.ToString(item["DBName"]))
                    //        .Replace("$DataSource$", SecurityClass.Decrypt(Convert.ToString(item["DataSource"]))).Replace("$UserName$", SecurityClass.Decrypt(Convert.ToString(item["Username"]))).Replace("$Password$", SecurityClass.Decrypt(Convert.ToString(item["Password"])));

                    //    string DomainURL = Convert.ToString(item["DomainURL"]);
                    //    string DBName = Convert.ToString(item["DBName"]);
                    //    int AgencyID = Convert.ToInt32(item["AgencyID"]);

                    //    new SandataOperation().FetchClientJSONData(FromDatabase, AgencyID);

                    //    new SandataOperation().FetchCareGiverJSONData(FromDatabase, AgencyID);

                    //    new SandataOperation().FetchActivityJSONData(FromDatabase, AgencyID);
                    //}
                }
                isRunning = false;
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                isRunning = false;
                timer.Start();
            }
        }

        #region Read Configuration Method
        private string readConfig(string strKey)
        {
            var key = Convert.ToString(ConfigurationManager.AppSettings[strKey]);
            if (string.IsNullOrEmpty(key))
                key = "false";
            return key;
        }
        #endregion
    }
}

