﻿public class Caregiver
{
    //public string Account { get; set; }
    //public string EmployeePIN { get; set; }
    //public string EmployeeLastName { get; set; }
    //public string EmployeeFirstName { get; set; }
    //public string EmployeeMiddleInitial { get; set; }
    //public string Department { get; set; }
    //public string EmployeeAPI { get; set; }
    //public string EmployeeType { get; set; }
    //public string Discipline { get; set; }
    //public string EmployeeEmailAddress { get; set; }
    //public string EmployeeAddress1 { get; set; }
    //public string EmployeeAddress2 { get; set; }
    //public string EmployeeCity { get; set; }
    //public string EmployeeState { get; set; }
    //public string EmployeeZipCode { get; set; }
    //public string EmployeePhone { get; set; }
    public string EmployeeID { get; set; }
    //public string EmployeeIDCustom1 { get; set; }
    //public string EmployeeIDCustom2 { get; set; }
    //public string EmployeeSocialSecurity { get; set; }
    //public string PayRate { get; set; }
    //public string EmployeeHireDate { get; set; }
    //public string EmployeeEndDate { get; set; }
    //public string EmployeeBirthDate { get; set; }
    //public string EmployeeGender { get; set; }
    //public string EmployeePrimaryLocation { get; set; }
    //public string Status { get; set; }
}

