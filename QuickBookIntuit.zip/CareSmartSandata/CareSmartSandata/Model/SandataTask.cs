﻿public class SandataTask
{
    public long ScheduleID { get; set; }
}

