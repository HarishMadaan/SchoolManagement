﻿public class SandataResponse
{
    public string id { get; set; }
    public string status { get; set; }
    public string token { get; set; }
    public string messageSummary { get; set; }
    public string messageDetail { get; set; }
    public string errorMessage { get; set; }
    public int failedCount { get; set; }
    public int succeededCount { get; set; }
    public bool cached { get; set; }
    public string cachedDate { get; set; }
    public int totalRows { get; set; }
    public int page { get; set; }
    public int pageSize { get; set; }
    public object orderByColumn { get; set; }
    public object orderByDirection { get; set; }
    public object data { get; set; }
}
