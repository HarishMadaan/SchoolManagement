﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartSandata.CommonClass
{
   public static class DatatableToList
    {
        public static List<T> ToList<T>(this DataTable table) where T : class, new()
        {
            try
            {
                List<T> list = new List<T>();

                foreach (var row in table.AsEnumerable())
                {
                    T obj = new T();

                    foreach (var prop in obj.GetType().GetProperties())
                    {
                        try
                        {
                            PropertyInfo propertyInfo = obj.GetType().GetProperty(prop.Name);
                            //  propertyInfo.SetValue(obj, Convert.ChangeType( row[prop.Name], propertyInfo.PropertyType), null);

                            object val = string.IsNullOrEmpty(row[prop.Name].ToString())?null: row[prop.Name];
                            propertyInfo.SetValue(obj, Convert.ChangeType(val, propertyInfo.PropertyType), null);
                        }
                        catch
                        {
                            continue;
                        }
                    }

                    list.Add(obj);
                }

                return list;
            }
            catch
            {
                return null;
            }
        }
    }
}
