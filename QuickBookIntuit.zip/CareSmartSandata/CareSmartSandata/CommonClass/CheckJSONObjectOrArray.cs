﻿using Newtonsoft.Json.Linq;
/// <summary>
/// Author: Saveen Gurung
/// Date : 19-Oct-2019
/// Usage : use to check data is Json Array Or Json Object
/// </summary>
namespace CareSmartSandata.CommonClass
{
    public class CheckJsonObjectOrArray
    {
        public static JsonType IsArrayOrObject(string data)
        {
            try
            {
                var token = JToken.Parse(data);
                if (token is JArray)
                {
                    return JsonType.Array;
                }
                else if (token is JObject)
                {
                    return JsonType.Object;
                }
            }
            catch (System.Exception)
            {
            }
            return JsonType.Undefined;
        }
    }

    public enum JsonType
    {
        Array = 0,
        Object = 1,
        Undefined = 3
    }
}
