﻿using RestSharp;
using System.Linq;

namespace CareSmartSandata.CommonClass
{
    public class RestSharpRequestResponse
    {
        public IRestSharpRequestResponseClass RequestLog(IRestRequest request, IRestResponse response)
        {
            try
            {

                IRestSharpRequestResponseClass restSharpRequestResponse = new IRestSharpRequestResponseClass();
                restSharpRequestResponse.IRequest = request;
                restSharpRequestResponse.IResponse = response;

                var requestToLog = new
                {
                    resource = request.Resource,
                    // Parameters are custom anonymous objects in order to have the parameter type as a nice string
                    // otherwise it will just show the enum value
                    parameters = request.Parameters.Select(parameter => new
                    {
                        name = parameter.Name,
                        value = parameter.Value,
                        type = parameter.Type.ToString()
                    }),
                    // ToString() here to have the method as a nice string otherwise it will just show the enum value
                    method = request.Method.ToString(),

                };
                restSharpRequestResponse.RequestLog = requestToLog;

                var responseToLog = new
                {
                    statusCode = response.StatusCode,
                    content = response.Content,
                    headers = response.Headers,
                    // The Uri that actually responded (could be different from the requestUri if a redirection occurred)
                    responseUri = response.ResponseUri,
                    errorMessage = response.ErrorMessage,
                };

                restSharpRequestResponse.ResponseLog = responseToLog;

                return restSharpRequestResponse;
            }
            catch (System.Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
                return null;
            }
            
        }
        
    }

    public class IRestSharpRequestResponseClass
    {
        public IRestRequest IRequest { get; set; }
        public IRestResponse IResponse { get; set; }

        public object RequestLog { get; set; }
        public object ResponseLog { get; set; }
    }
}
