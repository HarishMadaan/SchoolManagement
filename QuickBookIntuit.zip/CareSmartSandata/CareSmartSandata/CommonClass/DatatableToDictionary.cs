﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareSmartSandata.CommonClass
{
    public static class DatatableToDictionary
    {
        public static Dictionary<string, string> GetDictionary(this DataTable dt)
        {
            return dt.AsEnumerable()
              .ToDictionary(row => row.Field<string>(0),
                                        row => row.Field<string>(1));
        }
    }
}
