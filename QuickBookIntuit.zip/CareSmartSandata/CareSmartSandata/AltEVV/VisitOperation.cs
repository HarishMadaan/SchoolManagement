﻿using CareSmartSandata.AltEVVModel;
using CareSmartSandata.CommonClass;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace CareSmartSandata.AltEVV
{
    public class VisitOperation
    {
        public void GetVisitData(CompanyConfigurationInfo ConfigurationInfo)
        {
            List<SqlParameter> prm = new List<SqlParameter>()
                {
                    new SqlParameter("@AgencyID", SqlDbType.Int) {Value = ConfigurationInfo.AgencyID}
                };

            DataSet dataSet = new EvvDbOperation().GetData(ConfigurationInfo.FromDatabase, "Pr_AltEVV_GetVisits", prm.ToArray());

            if (dataSet != null && dataSet.Tables.Count > 0)
            {
                Dictionary<string, DataTable> dic = GetAllTables(dataSet);

                List<Visit> lisVisit = new List<Visit>();
                if (dic.ContainsKey(Enum.GetName(typeof(VisitEnum), VisitEnum.Visit)))
                    lisVisit = dic[Enum.GetName(typeof(VisitEnum), VisitEnum.Visit)].ToList<Visit>();

                List<Call> listCall = new List<Call>();
                if (dic.ContainsKey(Enum.GetName(typeof(VisitEnum), VisitEnum.Calls)))
                    listCall = dic[Enum.GetName(typeof(VisitEnum), VisitEnum.Calls)].ToList<Call>();

                List<VisitException> listException = new List<VisitException>();
                if (dic.ContainsKey(Enum.GetName(typeof(VisitEnum), VisitEnum.VisitException)))
                    listException = dic[Enum.GetName(typeof(VisitEnum), VisitEnum.VisitException)].ToList<VisitException>();

                List<VisitChange> listVisitChange = new List<VisitChange>();
                if (dic.ContainsKey(Enum.GetName(typeof(VisitEnum), VisitEnum.VisitChanges)))
                    listVisitChange = dic[Enum.GetName(typeof(VisitEnum), VisitEnum.VisitChanges)].ToList<VisitChange>();

                ArrayList ScheduleSlotIdArray = new ArrayList();

                List<Dictionary<string, object>> finalList = GetFinalVisitObject(lisVisit, listCall, listException, listVisitChange, ConfigurationInfo.EVVBusinessEntityID, ConfigurationInfo.EVVBusinessEntityMedicaidIdentifier, ref ScheduleSlotIdArray);

                if (finalList.Count > 0)
                {
                    string output = JsonConvert.SerializeObject(finalList);

                    UploadVisit(ConfigurationInfo, output, ScheduleSlotIdArray);
                }
                else
                {
                    TriggerGetPatientStatus(ConfigurationInfo);
                }
            }
            else
            {
                TriggerGetPatientStatus(ConfigurationInfo);
            }
        }

        public void TriggerGetPatientStatus(CompanyConfigurationInfo ConfigurationInfo)
        {
            ArrayList ScheduleSlotIdArray = new ArrayList();
            DataSet dataSetUnprocessedClient = new EvvDbOperation().GetData(ConfigurationInfo.FromDatabase, "PrGetUnProcessedVisits");
            if (dataSetUnprocessedClient != null && dataSetUnprocessedClient.Tables.Count > 0)
            {
                DataTable DTUnprocessedClient = dataSetUnprocessedClient.Tables[0];
                if (DTUnprocessedClient.Rows.Count > 0)
                {
                    ArrayList UUIDArray = new ArrayList();
                    foreach (DataRow row in DTUnprocessedClient.Rows)
                    {
                        ScheduleSlotIdArray.Add(Convert.ToString(row["ScheduleSlotId"]));
                        UUIDArray.Add(Convert.ToString(row["UUID"]));
                    }

                    foreach (string uuid in UUIDArray)
                    {
                        GetVisitStatus(ConfigurationInfo, uuid, ScheduleSlotIdArray);
                    }
                }
            }
        }



        public void UploadVisit(CompanyConfigurationInfo ConfigurationInfo, string ClientJson, ArrayList ScheduleSlotIdArray)
        {
            try
            {
                IRestSharpRequestResponseClass restSharpRequestResponse = new EVVEndpoint().POST(ConfigurationInfo.FromDatabase, ConfigurationInfo.Phase2PostVisitURL, ConfigurationInfo.EVVUserID, ConfigurationInfo.EVVPassword, ClientJson);

                Logger.PrintLog(LogType.Info, string.Format("Request:{0} /n Response:{1}", restSharpRequestResponse.RequestLog, restSharpRequestResponse.ResponseLog));

                if (null != restSharpRequestResponse)
                {
                    if (string.IsNullOrEmpty(restSharpRequestResponse.IResponse.Content))
                    {
                        return;
                    }

                    EvvResponse evvResponse = JsonConvert.DeserializeObject<EvvResponse>(restSharpRequestResponse.IResponse.Content);

                    new DBLogger().LogEVVSandata(ConfigurationInfo.FromDatabase, new
                    {
                        APIEndPoint = ConfigurationInfo.Phase2PostVisitURL,
                        Request = JsonConvert.SerializeObject(restSharpRequestResponse.RequestLog),
                        Response = JsonConvert.SerializeObject(restSharpRequestResponse.ResponseLog),
                        UUID = evvResponse.id
                    });

                    // if status is BAD_REQUEST no need to proceed further
                    if (null != evvResponse.status && Equals(evvResponse.status, "BAD_REQUEST") || evvResponse.errorMessage != null)
                    {
                        return;
                    }

                    List<SqlParameter> prm = new List<SqlParameter>()
                    {
                        new SqlParameter("@ScheduleSlotId", SqlDbType.VarChar) {Value = string.Join(",", ScheduleSlotIdArray.ToArray())},
                        new SqlParameter("@UUID", SqlDbType.VarChar) {Value =  evvResponse.id},
                        new SqlParameter("@Mode", SqlDbType.Bit) {Value =  true}
                    };

                    new EvvDbOperation().GetData(ConfigurationInfo.FromDatabase, "PrUpdateSandataVisit", prm.ToArray());

                    if (string.IsNullOrEmpty(evvResponse.id))
                        return;

                    GetVisitStatus(ConfigurationInfo, evvResponse.id, ScheduleSlotIdArray);

                }
            }
            catch (Exception)
            {
                throw;
            }
        }


        public void GetVisitStatus(CompanyConfigurationInfo configurationInfo, string UUID, ArrayList ScheduleSlotIdArray)
        {
            configurationInfo.Phase2GetVisitDataStatusURL = configurationInfo.Phase2GetVisitDataStatusURL.Replace("##uuid##", UUID);

            IRestSharpRequestResponseClass restSharpRequestResponse = new EVVEndpoint().GET(configurationInfo.FromDatabase, configurationInfo.Phase2GetVisitDataStatusURL, configurationInfo.EVVUserID, configurationInfo.EVVPassword);

            Logger.PrintLog(LogType.Info, string.Format("Request:{0} /n Response:{1}", restSharpRequestResponse.RequestLog, restSharpRequestResponse.ResponseLog));

            if (null != restSharpRequestResponse)
            {

                if (string.IsNullOrEmpty(restSharpRequestResponse.IResponse.Content))
                {
                    return;
                }

                EvvResponse evvResponse = JsonConvert.DeserializeObject<EvvResponse>(restSharpRequestResponse.IResponse.Content);

                new DBLogger().LogEVVSandata(configurationInfo.FromDatabase, new
                {
                    APIEndPoint = configurationInfo.Phase2GetVisitDataStatusURL,
                    Request = JsonConvert.SerializeObject(restSharpRequestResponse.RequestLog),
                    Response = JsonConvert.SerializeObject(restSharpRequestResponse.ResponseLog),
                    UUID = evvResponse.id
                });

                string data = Convert.ToString(evvResponse.data);

                if (string.IsNullOrEmpty(data))
                {
                    return;
                }

                ParseResult(data, ref ScheduleSlotIdArray);

                if (ScheduleSlotIdArray.Count > 0)
                {
                    List<SqlParameter> prm = new List<SqlParameter>()
                    {
                        new SqlParameter("@ScheduleSlotId", SqlDbType.VarChar) {Value = string.Join(",", ScheduleSlotIdArray.ToArray())},
                        new SqlParameter("@UUID", SqlDbType.VarChar) {Value =  evvResponse.id}
                    };

                    DataSet dataSet = new EvvDbOperation().GetData(configurationInfo.FromDatabase, "PrUpdateSandataVisit", prm.ToArray());
                }
                else
                {
                    List<SqlParameter> prm = new List<SqlParameter>()
                    {
                        new SqlParameter("@UUID", SqlDbType.VarChar) {Value =  evvResponse.id}
                    };

                    DataSet dataSet = new EvvDbOperation().GetData(configurationInfo.FromDatabase, "PrUpdateSandataVisit", prm.ToArray());
                }
            }
        }

        public void ParseResult(string data, ref ArrayList ScheduleSlotIdArray)
        {
            bool ErrorInVisitRecord = false;

            if (string.Equals(data, SandataConstant.AllRecordUploaded))
            {
                return;
            }

            if (string.Equals(data, SandataConstant.UUIDNotReadyYet))
            {
                return;
            }

            JsonType jsonType = CheckJsonObjectOrArray.IsArrayOrObject(data);

            if (jsonType == JsonType.Undefined)
            {
                return;
            }
            else if (jsonType == JsonType.Array)
            {
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.ContractResolver = new IgnoreJsonAttributesResolver();

                List<Visit> visitList = JsonConvert.DeserializeObject<List<Visit>>(data, settings);

                foreach (Visit visit in visitList)
                {
                    // means there is somthing wrong with patient object 
                    if (visit.ErrorCode != null || visit.ErrorMessage != null)
                    {
                        ErrorInVisitRecord = true;
                    }

                    object IndividualPayerInformation = visit.Calls;
                    if (null != IndividualPayerInformation)
                    {
                        List<Call> callList = JToken.Parse(IndividualPayerInformation.ToString()).ToObject<List<Call>>();

                        foreach (Call calls in callList)
                        {
                            if (calls.ErrorCode != null || calls.ErrorMessage != null)
                            {
                                ErrorInVisitRecord = true;
                                break;
                            }
                        }
                    }

                    // Now Collect those Schi id whose records are valid

                    if (ErrorInVisitRecord)
                    {
                        ErrorInVisitRecord = false;
                        if (ScheduleSlotIdArray.Contains(visit.ScheduleSlotId))
                            ScheduleSlotIdArray.Remove(visit.ScheduleSlotId);
                        continue;
                    }

                }
            }

        }

        public List<Dictionary<string, object>> GetFinalVisitObject(List<Visit> listVisit, List<Call> listCall, List<VisitException> visitExcetptionList, List<VisitChange> listIndividualPhones, string eVVBusinessEntityID, string eVVBusinessEntityMedicaidIdentifier, ref ArrayList ScheduleSlotIdArray)
        {
            List<Dictionary<string, object>> finalList = new List<Dictionary<string, object>>();

            foreach (Visit visit in listVisit)
            {
                string strScheduleSlotId = visit.ScheduleSlotId;

                Dictionary<string, object> finalDic = new Dictionary<string, object>();
                finalDic.Add("BusinessEntityID", eVVBusinessEntityID);
                finalDic.Add("BusinessEntityMedicaidIdentifier", eVVBusinessEntityMedicaidIdentifier);
                finalDic.Add("VisitOtherID", visit.VisitOtherID);
                finalDic.Add("SequenceID", visit.SequenceID);
                finalDic.Add("StaffOtherID", visit.StaffOtherID);
                finalDic.Add("PatientOtherID", visit.PatientOtherID);
                finalDic.Add("PatientMedicaidID", visit.PatientMedicaidID);
                finalDic.Add("VisitCancelledIndicator", visit.VisitCancelledIndicator);
                finalDic.Add("Payer", visit.Payer);
                finalDic.Add("PayerProgram", visit.PayerProgram);
                finalDic.Add("ProcedureCode", visit.ProcedureCode);
                finalDic.Add("TimeZone", visit.TimeZone);
                finalDic.Add("AdjInDateTime", visit.AdjInDateTime);
                finalDic.Add("AdjOutDateTime", visit.AdjOutDateTime);
                finalDic.Add("BillVisit", visit.BillVisit);
                finalDic.Add("HoursToBill", visit.HoursToBill);
                finalDic.Add("VisitMemo", visit.VisitMemo);
                finalDic.Add("MemberVerifiedTimes", visit.MemberVerifiedTimes);
                finalDic.Add("MemberVerifiedService", visit.MemberVerifiedService);
                finalDic.Add("MemberSignatureAvailable", visit.MemberSignatureAvailable);
                finalDic.Add("MemberVoiceRecording", visit.MemberVoiceRecording);

                ScheduleSlotIdArray.Add(visit.ScheduleSlotId);

                List<Call> CallList = listCall.Where(PayerInfo => PayerInfo.ScheduleSlotId == strScheduleSlotId).ToList();

                if (CallList.Count > 0)
                    finalDic.Add("Calls", CallList);

                //List<Address> addresses = visitExcetptionList.Where(PayerInfo => PayerInfo.PatientOtherID == strPatientOtherID).ToList();

                //List<IndividualPhone> individualPhones = listIndividualPhones.Where(PayerInfo => PayerInfo.PatientOtherID == strPatientOtherID).ToList();

                //List<PatientResponsibleParty> patientResponsibleParties = listPatientResponsibleParty.Where(PayerInfo => PayerInfo.PatientOtherID == strPatientOtherID).ToList();

                //if (individualPayerInformation.Count > 0)
                //    finalDic.Add("IndividualPayerInformation", individualPayerInformation);

                //if (addresses.Count > 0)
                //    finalDic.Add("Address", addresses);

                //if (individualPhones.Count > 0)
                //    finalDic.Add("IndividualPhones", individualPhones);

                //if (patientResponsibleParties.Count > 0)
                //    finalDic.Add("ResponsibleParty", patientResponsibleParties);

                finalList.Add(finalDic);
            }

            return finalList;
        }


        public Dictionary<string, DataTable> GetAllTables(DataSet dataSet)
        {
            Dictionary<string, DataTable> keyValues = new Dictionary<string, DataTable>();
            int TableCount = dataSet.Tables.Count;
            if (TableCount > 0)
            {
                for (int i = 0; i < TableCount; i++)
                {
                    KeyValueClass<DataTable> keyValuesTemp = GetTableType(i, dataSet);
                    keyValues.Add(keyValuesTemp.KeyName, keyValuesTemp.KeyValue);
                }
            }
            return keyValues;
        }


        public KeyValueClass<DataTable> GetTableType(int i, DataSet dataSet)
        {
            switch (i)
            {
                case 0:// Individual/Client General Information
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(VisitEnum), VisitEnum.Visit), KeyValue = dataSet.Tables[0] };

                case 1:// Individual/Client Payer Information 
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(VisitEnum), VisitEnum.Calls), KeyValue = dataSet.Tables[1] };

                case 2:// Individual/Client Address  
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(VisitEnum), VisitEnum.VisitException), KeyValue = dataSet.Tables[2] };

                case 3:// Individual/Client Phone  
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(VisitEnum), VisitEnum.VisitChanges), KeyValue = dataSet.Tables[3] };

                default:
                    return null;
            }
        }
    }
}
