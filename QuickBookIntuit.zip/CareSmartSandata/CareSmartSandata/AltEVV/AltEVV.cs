﻿namespace CareSmartSandata.AltEVV
{
    public class AltEVV
    {


    }
}
