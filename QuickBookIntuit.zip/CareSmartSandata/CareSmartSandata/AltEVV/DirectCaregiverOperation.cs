﻿using CareSmartSandata.AltEVVModel;
using CareSmartSandata.CommonClass;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CareSmartSandata.AltEVV
{
    public class DirectCaregiverOperation
    {
        public void GetCaregiverData(CompanyConfigurationInfo ConfigurationInfo)
        {
            List<SqlParameter> prm = new List<SqlParameter>()
            {
                    new SqlParameter("@AgencyID", SqlDbType.Int) {Value = ConfigurationInfo.AgencyID}
            };

            ArrayList CaregiverArray = new ArrayList();

            DataSet dataSet = new EvvDbOperation().GetData(ConfigurationInfo.FromDatabase, "USP_SandataCaregiverDetail", prm.ToArray());

            if (dataSet != null && dataSet.Tables.Count > 0)
            {
                List<DirectCaregiver> ListCaregiver = dataSet.Tables[0].ToList<DirectCaregiver>();

                foreach (DirectCaregiver caregiver in ListCaregiver)
                {
                    CaregiverArray.Add(caregiver.StaffID);
                    caregiver.BusinessEntityID = ConfigurationInfo.EVVBusinessEntityID;
                    caregiver.BusinessEntityMedicaidIdentifier = ConfigurationInfo.EVVBusinessEntityMedicaidIdentifier;
                }

                if (ListCaregiver.Count > 0)
                {
                    string output = JsonConvert.SerializeObject(ListCaregiver);

                    UploadCaregiver(ConfigurationInfo, output, CaregiverArray);
                }
                else
                {
                    TriggerGetCareGiverStatus(ConfigurationInfo);
                }
            }
            else
            {
                TriggerGetCareGiverStatus(ConfigurationInfo);
            }

        }


        public void TriggerGetCareGiverStatus(CompanyConfigurationInfo ConfigurationInfo)
        {
            ArrayList CaregiverIDArray = new ArrayList();
            DataSet dataSetUnprocessedClient = new EvvDbOperation().GetData(ConfigurationInfo.FromDatabase, "PrGetUnProccessedCaregiver");
            if (dataSetUnprocessedClient != null && dataSetUnprocessedClient.Tables.Count > 0)
            {
                DataTable DTUnprocessedClient = dataSetUnprocessedClient.Tables[0];
                if (DTUnprocessedClient.Rows.Count > 0)
                {
                    ArrayList UUIDArray = new ArrayList();
                    foreach (DataRow row in DTUnprocessedClient.Rows)
                    {
                        CaregiverIDArray.Add(Convert.ToString(row["StaffOtherID"]));
                        UUIDArray.Add(Convert.ToString(row["UUID"]));
                    }

                    foreach (string uuid in UUIDArray)
                    {
                        GetCargiverStatus(ConfigurationInfo, uuid, CaregiverIDArray);
                    }
                }
            }
        }


        public void UploadCaregiver(CompanyConfigurationInfo ConfigurationInfo, string CaregiverJson, ArrayList CaregiverArray)
        {
            try
            {
                IRestSharpRequestResponseClass restSharpRequestResponse = new EVVEndpoint().POST(ConfigurationInfo.FromDatabase, ConfigurationInfo.Phase2PostStaffURL, ConfigurationInfo.EVVUserID, ConfigurationInfo.EVVPassword, CaregiverJson);

                Logger.PrintLog(LogType.Info, string.Format("Request:{0} /n Response:{1}", restSharpRequestResponse.RequestLog, restSharpRequestResponse.ResponseLog));

                if (null != restSharpRequestResponse)
                {
                    if (string.IsNullOrEmpty(restSharpRequestResponse.IResponse.Content))
                    {
                        return;
                    }

                    EvvResponse evvResponse = JsonConvert.DeserializeObject<EvvResponse>(restSharpRequestResponse.IResponse.Content);

                    new DBLogger().LogEVVSandata(ConfigurationInfo.FromDatabase, new
                    {
                        APIEndPoint = ConfigurationInfo.Phase2PostStaffURL,
                        Request = JsonConvert.SerializeObject(restSharpRequestResponse.RequestLog),
                        Response = JsonConvert.SerializeObject(restSharpRequestResponse.ResponseLog),
                        UUID = evvResponse.id
                    });

                    // if status is BAD_REQUEST no need to proceed further.
                    if (null != evvResponse.status && Equals(evvResponse.status, "BAD_REQUEST") || evvResponse.errorMessage != null)
                    {
                        return;
                    }

                    List<SqlParameter> prm = new List<SqlParameter>()
                    {
                        new SqlParameter("@CaregiverDisplayId", SqlDbType.VarChar) {Value = string.Join(",", CaregiverArray.ToArray())},
                        new SqlParameter("@UUID", SqlDbType.VarChar) {Value =  evvResponse.id}
                    };

                    new EvvDbOperation().GetData(ConfigurationInfo.FromDatabase, "PrInsertSandataDirectCaregiver", prm.ToArray());

                    if (string.IsNullOrEmpty(evvResponse.id))
                        return;

                    GetCargiverStatus(ConfigurationInfo, evvResponse.id, CaregiverArray);
                }

            }
            catch (Exception)
            {
                throw;
            }

        }

        public void GetCargiverStatus(CompanyConfigurationInfo configurationInfo, string UUID, ArrayList CaregiverArray)
        {
            configurationInfo.Phase2GetStaffDataStatusURL = configurationInfo.Phase2GetStaffDataStatusURL.Replace("##uuid##", UUID);

            IRestSharpRequestResponseClass restSharpRequestResponse = new EVVEndpoint().GET(configurationInfo.FromDatabase, configurationInfo.Phase2GetStaffDataStatusURL, configurationInfo.EVVUserID, configurationInfo.EVVPassword);

            Logger.PrintLog(LogType.Info, string.Format("Request:{0} /n Response:{1}", restSharpRequestResponse.RequestLog, restSharpRequestResponse.ResponseLog));

            if (null != restSharpRequestResponse)
            {
                if (string.IsNullOrEmpty(restSharpRequestResponse.IResponse.Content))
                {
                    return;
                }

                EvvResponse evvResponse = JsonConvert.DeserializeObject<EvvResponse>(restSharpRequestResponse.IResponse.Content);

                new DBLogger().LogEVVSandata(configurationInfo.FromDatabase, new
                {
                    APIEndPoint = configurationInfo.Phase2GetStaffDataStatusURL,
                    Request = JsonConvert.SerializeObject(restSharpRequestResponse.RequestLog),
                    Response = JsonConvert.SerializeObject(restSharpRequestResponse.ResponseLog),
                    UUID = evvResponse.id
                });

                string data = Convert.ToString(evvResponse.data);

                if (string.IsNullOrEmpty(data))
                {
                    return;
                }

                EvvResponseMessageEnum MessageEnumType = EvvResponseMessageEnum.NoMessage;

                ParseResult(data, ref CaregiverArray, ref MessageEnumType);

                List<SqlParameter> prm = new List<SqlParameter>();

                //if (CaregiverArray.Count > 0 && MessageEnumType == EvvResponseMessageEnum.AllRecordUploaded)
                //{
                //    prm.Add(new SqlParameter("@CaregiverDisplayId", SqlDbType.VarChar) { Value = string.Join(",", CaregiverArray.ToArray())});
                //    prm.Add(new SqlParameter("@UUID", SqlDbType.VarChar) { Value = evvResponse.id });
                //}
                //else if (CaregiverArray.Count == 0 && MessageEnumType == EvvResponseMessageEnum.NoMessage)
                //{
                //    prm.Add(new SqlParameter("@UUID", SqlDbType.VarChar) { Value = evvResponse.id });
                //}
                //else if (CaregiverArray.Count > 0 && MessageEnumType == EvvResponseMessageEnum.UUIDNotReadyYet)
                //{
                //    prm.Add(new SqlParameter("@CaregiverDisplayId", SqlDbType.VarChar) { Value = string.Join(",", CaregiverArray.ToArray()) });
                //    prm.Add(new SqlParameter("@UUID", SqlDbType.VarChar) { Value = evvResponse.id });
                //    prm.Add(new SqlParameter("@Mode", SqlDbType.Bit) { Value = true });
                //}

                prm.Add(new SqlParameter("@CaregiverDisplayId", SqlDbType.VarChar) { Value = string.Join(",", CaregiverArray.ToArray()) });
                prm.Add(new SqlParameter("@UUID", SqlDbType.VarChar) { Value = evvResponse.id });
                prm.Add(new SqlParameter("@Mode", SqlDbType.Bit) { Value = (MessageEnumType == EvvResponseMessageEnum.UUIDNotReadyYet) ? true : false });

                DataSet dataSet = new EvvDbOperation().GetData(configurationInfo.FromDatabase, "PrUpdateProccessedSandataDirectCaregiver", prm.ToArray());
            }

        }

        public void ParseResult(string data, ref ArrayList CaregiverArray, ref EvvResponseMessageEnum MessageEnumType)
        {
            // this message means all record are uploaded and they are successfully uploaded
            if (string.Equals(data, SandataConstant.AllRecordUploaded))
            {
                MessageEnumType = EvvResponseMessageEnum.AllRecordUploaded;
                return;
            }

            // In this case, may be clients are uploaded successfully but thier UUIDs are ready
            // So We need to  
            if (string.Equals(data, SandataConstant.UUIDNotReadyYet))
            {
                MessageEnumType = EvvResponseMessageEnum.UUIDNotReadyYet;
                return;
            }

            JsonType jsonType = CheckJsonObjectOrArray.IsArrayOrObject(data);

            if (jsonType == JsonType.Undefined)
            {
                return;
            }
            else if (jsonType == JsonType.Array)
            {

                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.ContractResolver = new IgnoreJsonAttributesResolver();

                List<DirectCaregiver> directCaregivers = JsonConvert.DeserializeObject<List<DirectCaregiver>>(data, settings);

                foreach (DirectCaregiver Caregiver in directCaregivers)
                {
                    // means there is somthing wrong with patient object 
                    if (Caregiver.ErrorCode != null || Caregiver.ErrorMessage != null)
                    {
                        if (CaregiverArray.Contains(Caregiver.StaffID))
                            CaregiverArray.Remove(Caregiver.StaffID);
                    }
                }

            }

        }
    }
}
