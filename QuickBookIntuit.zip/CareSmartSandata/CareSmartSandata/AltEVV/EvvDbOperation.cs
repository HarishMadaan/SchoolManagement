﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace CareSmartSandata.AltEVV
{
    class EvvDbOperation
    {
        public DataSet GetData(string FromDatabase, string ProcedureName, SqlParameter[] Parameters = null)
        {
            StringBuilder builder = new StringBuilder();

            try
            {
                using (SqlConnection con = new SqlConnection(FromDatabase))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = ProcedureName;
                    if (Parameters != null)
                        command.Parameters.AddRange(Parameters);
                    command.Connection = con;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }
            return null;
        }
    }
}
