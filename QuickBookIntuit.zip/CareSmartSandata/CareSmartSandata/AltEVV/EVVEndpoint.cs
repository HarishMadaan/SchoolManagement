﻿using CareSmartSandata.CommonClass;
using RestSharp;
using System;

namespace CareSmartSandata.AltEVV
{
    class EVVEndpoint
    {
        public IRestSharpRequestResponseClass POST(string FromDatabase, string URL, string eVVUserID, string eVVPassword, string Data)
        {
            try
            {
                var client = new RestClient(URL);
                IRestRequest request = new RestRequest(Method.POST);
                request.AddHeader("authorization", ToAuthorizationKey(eVVUserID, eVVPassword));
                request.AddHeader("accept", "application/json");
                request.AddHeader("content-type", "application/json");
                request.AddParameter("application/json", Data, ParameterType.RequestBody);

                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                IRestResponse response = client.Execute(request);

                return new RestSharpRequestResponse().RequestLog(request, response);

            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }
            return null;
        }

        public IRestSharpRequestResponseClass GET(string FromDatabase, string URL, string eVVUserID, string eVVPassword)
        {
            try
            {
                var client = new RestClient(URL);
                var request = new RestRequest(Method.GET);

                request.AddHeader("authorization", ToAuthorizationKey(eVVUserID, eVVPassword));

                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                IRestResponse response = client.Execute(request);
                var content = response.Content;

                return new RestSharpRequestResponse().RequestLog(request, response);

            }
            catch (Exception ex)
            {
                Logger.PrintLog(LogType.Error, ex.ToString());
            }
            return null;
        }

        public string ToAuthorizationKey(string userid, string password)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(string.Concat(userid, ":", password));
            return string.Concat("Basic ", Convert.ToBase64String(plainTextBytes));
        }
    }

}
