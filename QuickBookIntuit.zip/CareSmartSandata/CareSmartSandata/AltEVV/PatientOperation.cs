﻿using CareSmartSandata.AltEVVModel;
using CareSmartSandata.CommonClass;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace CareSmartSandata.AltEVV
{
    public class PatientOperation
    {
        // th
        public void GetPatientData(CompanyConfigurationInfo ConfigurationInfo)
        {
            List<SqlParameter> prm = new List<SqlParameter>()
                {
                    new SqlParameter("@AgencyID", SqlDbType.Int) {Value = ConfigurationInfo.AgencyID}
                };

            DataSet dataSet = new EvvDbOperation().GetData(ConfigurationInfo.FromDatabase, "Pr_AltEVV_GetClients", prm.ToArray());

            ArrayList ClientIDArray = new ArrayList();

            if (dataSet != null && dataSet.Tables.Count > 0)
            {
                Dictionary<string, DataTable> dic = GetAllTables(dataSet);

                List<Patient> listPatient = new List<Patient>();
                if (dic.ContainsKey(Enum.GetName(typeof(PatientEnum), PatientEnum.Patient)))
                    listPatient= dic[Enum.GetName(typeof(PatientEnum), PatientEnum.Patient)].ToList<Patient>();

                List<IndividualPayerInformation> listIndividualPayerInformation = new List<IndividualPayerInformation>();
                if (dic.ContainsKey(Enum.GetName(typeof(PatientEnum), PatientEnum.IndividualPayerInformation)))
                    listIndividualPayerInformation= dic[Enum.GetName(typeof(PatientEnum), PatientEnum.IndividualPayerInformation)].ToList<IndividualPayerInformation>();

                List<Address> listAddress = new List<Address>();
                if (dic.ContainsKey(Enum.GetName(typeof(PatientEnum), PatientEnum.Address)))
                    listAddress= dic[Enum.GetName(typeof(PatientEnum), PatientEnum.Address)].ToList<Address>();

                List<IndividualPhone> listIndividualPhones = new List<IndividualPhone>();
                if (dic.ContainsKey(Enum.GetName(typeof(PatientEnum), PatientEnum.IndividualPhones)))
                    listIndividualPhones= dic[Enum.GetName(typeof(PatientEnum), PatientEnum.IndividualPhones)].ToList<IndividualPhone>();

                List<PatientResponsibleParty> listPatientResponsibleParty = new List<PatientResponsibleParty>();
                if (dic.ContainsKey(Enum.GetName(typeof(PatientEnum), PatientEnum.PatientResponsibleParty)))
                    listPatientResponsibleParty= dic[Enum.GetName(typeof(PatientEnum), PatientEnum.PatientResponsibleParty)].ToList<PatientResponsibleParty>();
                
                List<Dictionary<string, object>> finalList = GetFinalPatientObject(listPatient, listIndividualPayerInformation, listAddress, listIndividualPhones, listPatientResponsibleParty, ConfigurationInfo.EVVBusinessEntityID, ConfigurationInfo.EVVBusinessEntityMedicaidIdentifier, ref ClientIDArray);

                if (finalList.Count > 0)
                {
                    string output = JsonConvert.SerializeObject(finalList);

                    UploadPatient(ConfigurationInfo, output, ClientIDArray);
                }
                else
                {
                    TriggerGetPatientStatus(ConfigurationInfo);
                }
            }
            else
            {
                TriggerGetPatientStatus(ConfigurationInfo);
            }
        }

        public void TriggerGetPatientStatus(CompanyConfigurationInfo ConfigurationInfo)
        {
            ArrayList ClientIDArray = new ArrayList();
            DataSet dataSetUnprocessedClient = new EvvDbOperation().GetData(ConfigurationInfo.FromDatabase, "PrGetUnProccessedClients");
            if (dataSetUnprocessedClient != null && dataSetUnprocessedClient.Tables.Count > 0)
            {
                DataTable DTUnprocessedClient = dataSetUnprocessedClient.Tables[0];
                if (DTUnprocessedClient.Rows.Count > 0)
                {
                    ArrayList UUIDArray = new ArrayList();
                    foreach (DataRow row in DTUnprocessedClient.Rows)
                    {
                        ClientIDArray.Add(Convert.ToString(row["PatientOtherID"]));
                        UUIDArray.Add(Convert.ToString(row["UUID"]));
                    }

                    foreach (string uuid in UUIDArray)
                    {
                        GetPatientStatus(ConfigurationInfo, uuid, ClientIDArray);
                    }
                }
            }
        }

        public List<Dictionary<string, object>> GetFinalPatientObject(List<Patient> listPatient, List<IndividualPayerInformation> listIndividualPayerInformation, List<Address> listAddress, List<IndividualPhone> listIndividualPhones, List<PatientResponsibleParty> listPatientResponsibleParty, string eVVBusinessEntityID, string eVVBusinessEntityMedicaidIdentifier, ref ArrayList ClientIDArray)
        {
            List<Dictionary<string, object>> finalList = new List<Dictionary<string, object>>();

            foreach (Patient patient in listPatient)
            {
                string strPatientOtherID = patient.PatientOtherID;

                ClientIDArray.Add(strPatientOtherID);

                Dictionary<string, object> finalDic = new Dictionary<string, object>();
                finalDic.Add("BusinessEntityID", eVVBusinessEntityID);
                finalDic.Add("BusinessEntityMedicaidIdentifier", eVVBusinessEntityMedicaidIdentifier);
                finalDic.Add("PatientOtherID", patient.PatientOtherID);
                finalDic.Add("SequenceID", patient.SequenceID);
                finalDic.Add("PatientMedicaidID", patient.PatientMedicaidID);
                finalDic.Add("IsPatientNewborn", patient.IsPatientNewborn);
                finalDic.Add("PatientAlternateID", patient.PatientAlternateID);
                finalDic.Add("PatientLastName", patient.PatientLastName);
                finalDic.Add("PatientFirstName", patient.PatientFirstName);
                finalDic.Add("PatientTimezone", patient.PatientTimezone);

                List<IndividualPayerInformation> individualPayerInformation = listIndividualPayerInformation.Where(PayerInfo => PayerInfo.PatientOtherID == strPatientOtherID).ToList();

                List<Address> addresses = listAddress.Where(PayerInfo => PayerInfo.PatientOtherID == strPatientOtherID).ToList();

                List<IndividualPhone> individualPhones = listIndividualPhones.Where(PayerInfo => PayerInfo.PatientOtherID == strPatientOtherID).ToList();

                List<PatientResponsibleParty> patientResponsibleParties = listPatientResponsibleParty.Where(PayerInfo => PayerInfo.PatientOtherID == strPatientOtherID).ToList();

                if (individualPayerInformation.Count > 0)
                    finalDic.Add("IndividualPayerInformation", individualPayerInformation);

                if (addresses.Count > 0)
                    finalDic.Add("Address", addresses);

                if (individualPhones.Count > 0)
                    finalDic.Add("IndividualPhones", individualPhones);

                if (patientResponsibleParties.Count > 0)
                    finalDic.Add("ResponsibleParty", patientResponsibleParties);

                finalList.Add(finalDic);
            }

            return finalList;

        }

        public void UploadPatient(CompanyConfigurationInfo configurationInfo, string ClientJson, ArrayList ClientIDArray)
        {
            try
            {
                IRestSharpRequestResponseClass restSharpRequestResponse = new EVVEndpoint().POST(configurationInfo.FromDatabase, configurationInfo.Phase2PostPatientURL, configurationInfo.EVVUserID, configurationInfo.EVVPassword, ClientJson);

                Logger.PrintLog(LogType.Info, string.Format("Request:{0} /n Response:{1}", restSharpRequestResponse.RequestLog, restSharpRequestResponse.ResponseLog));

                if (null != restSharpRequestResponse)
                {
                    if (string.IsNullOrEmpty(restSharpRequestResponse.IResponse.Content))
                    {
                        return;
                    }

                    EvvResponse evvResponse = JsonConvert.DeserializeObject<EvvResponse>(restSharpRequestResponse.IResponse.Content);

                    new DBLogger().LogEVVSandata(configurationInfo.FromDatabase, new
                    {
                        APIEndPoint = configurationInfo.Phase2PostPatientURL,
                        Request = JsonConvert.SerializeObject(restSharpRequestResponse.RequestLog),
                        Response = JsonConvert.SerializeObject(restSharpRequestResponse.ResponseLog),
                        UUID = evvResponse.id
                    });

                    // if status is BAD_REQUEST no need to proceed further
                    if (null != evvResponse.status && Equals(evvResponse.status, "BAD_REQUEST") || evvResponse.errorMessage != null)
                    {
                        return;
                    }

                    if (string.IsNullOrEmpty(evvResponse.id))
                        return;

                    GetPatientStatus(configurationInfo, evvResponse.id, ClientIDArray);

                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        public void GetPatientStatus(CompanyConfigurationInfo configurationInfo, string UUID, ArrayList ClientIDArray)
        {
            configurationInfo.Phase2GetPatientDataStatusURL = configurationInfo.Phase2GetPatientDataStatusURL.Replace("##uuid##", UUID);

            IRestSharpRequestResponseClass restSharpRequestResponse = new EVVEndpoint().GET(configurationInfo.FromDatabase, configurationInfo.Phase2GetPatientDataStatusURL, configurationInfo.EVVUserID, configurationInfo.EVVPassword);

            Logger.PrintLog(LogType.Info, string.Format("Request:{0} /n Response:{1}", restSharpRequestResponse.RequestLog, restSharpRequestResponse.ResponseLog));

            if (null != restSharpRequestResponse)
            {

                if (string.IsNullOrEmpty(restSharpRequestResponse.IResponse.Content))
                {
                    return;
                }

                EvvResponse evvResponse = JsonConvert.DeserializeObject<EvvResponse>(restSharpRequestResponse.IResponse.Content);

                new DBLogger().LogEVVSandata(configurationInfo.FromDatabase, new
                {
                    APIEndPoint = configurationInfo.Phase2GetPatientDataStatusURL,
                    Request = JsonConvert.SerializeObject(restSharpRequestResponse.RequestLog),
                    Response = JsonConvert.SerializeObject(restSharpRequestResponse.ResponseLog),
                    UUID = evvResponse.id
                });

                string data = Convert.ToString(evvResponse.data);

                if (string.IsNullOrEmpty(data))
                {
                    return;
                }

                EvvResponseMessageEnum MessageEnumType = EvvResponseMessageEnum.NoMessage;

                ParseResult(data, ref ClientIDArray, ref MessageEnumType);

                if (ClientIDArray.Count > 0)
                {
                    List<SqlParameter> prm = new List<SqlParameter>()
                    {
                        new SqlParameter("@ClientID", SqlDbType.VarChar) {Value = string.Join(",", ClientIDArray.ToArray())},
                        new SqlParameter("@UUID",SqlDbType.VarChar){Value=evvResponse.id}
                    };

                    if (MessageEnumType == EvvResponseMessageEnum.UUIDNotReadyYet)
                    {
                        SqlParameter parameter = new SqlParameter("@Mode", SqlDbType.Bit) { Value = true };
                        prm.Add(parameter);
                    }

                    DataSet dataSet = new EvvDbOperation().GetData(configurationInfo.FromDatabase, "PrEvvSandata_UpdateProcessedClient", prm.ToArray());
                }
            }
        }

        public void ParseResult(string data, ref ArrayList ClientIDArray, ref EvvResponseMessageEnum MessageEnumType)
        {
            bool ErrorInPatientRecord = false;

            // this message means all record are uploaded and they are successfully uploaded
            if (string.Equals(data, SandataConstant.AllRecordUploaded))
            {
                MessageEnumType = EvvResponseMessageEnum.AllRecordUploaded;
                return;
            }

            // In this case, may be clients are uploaded successfully but thier UUIDs are ready
            // So We need to  
            if (string.Equals(data, SandataConstant.UUIDNotReadyYet))
            {
                MessageEnumType = EvvResponseMessageEnum.UUIDNotReadyYet;
                return;
            }

            JsonType jsonType = CheckJsonObjectOrArray.IsArrayOrObject(data);

            if (jsonType == JsonType.Undefined)
            {
                return;
            }
            else if (jsonType == JsonType.Array)
            {
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.ContractResolver = new IgnoreJsonAttributesResolver();

                List<Patient> patients = JsonConvert.DeserializeObject<List<Patient>>(data, settings);

                foreach (Patient patient in patients)
                {
                    // means there is somthing wrong with patient object 
                    if (patient.ErrorCode != null || patient.ErrorMessage != null)
                    {
                        ErrorInPatientRecord = true;
                    }

                    object IndividualPayerInformation = patient.IndividualPayerInformation;
                    if (null != IndividualPayerInformation)
                    {
                        List<IndividualPayerInformation> IndividualPayerInformationList = JToken.Parse(IndividualPayerInformation.ToString()).ToObject<List<IndividualPayerInformation>>();

                        foreach (IndividualPayerInformation individualPayerInformation in IndividualPayerInformationList)
                        {
                            if (individualPayerInformation.ErrorCode != null || individualPayerInformation.ErrorMessage != null)
                            {
                                ErrorInPatientRecord = true;
                                break;
                            }
                        }
                    }

                    object IndividualAddress = patient.Address;
                    if (null != IndividualAddress)
                    {
                        List<Address> addressesList = JToken.Parse(IndividualPayerInformation.ToString()).ToObject<List<Address>>();

                        foreach (Address address in addressesList)
                        {
                            if (address.ErrorCode != null || address.ErrorMessage != null)
                            {
                                ErrorInPatientRecord = true;
                                break;
                            }
                        }
                    }

                    object IndividualPhones = patient.IndividualPhones;
                    if (null != IndividualPhones)
                    {
                        List<IndividualPhone> individualPhoneList = JToken.Parse(IndividualPayerInformation.ToString()).ToObject<List<IndividualPhone>>();

                        foreach (IndividualPhone individualPhone in individualPhoneList)
                        {
                            if (individualPhone.ErrorCode != null || individualPhone.ErrorMessage != null)
                            {
                                ErrorInPatientRecord = true;
                                break;
                            }
                        }
                    }

                    object IndividualResponsibleParty = patient.PatientResponsibleParty;
                    if (null != IndividualResponsibleParty)
                    {
                        List<PatientResponsibleParty> patientResponsiblesList = JToken.Parse(IndividualPayerInformation.ToString()).ToObject<List<PatientResponsibleParty>>();

                        foreach (PatientResponsibleParty patientResponsibles in patientResponsiblesList)
                        {
                            if (patientResponsibles.ErrorCode != null || patientResponsibles.ErrorMessage != null)
                            {
                                ErrorInPatientRecord = true;
                                break;
                            }
                        }
                    }

                    // Now Collect those client id whose records are valid

                    if (ErrorInPatientRecord)
                    {
                        ErrorInPatientRecord = false;

                        if (ClientIDArray.Contains(patient.PatientOtherID))
                            ClientIDArray.Remove(patient.PatientOtherID);
                        continue;
                    }

                }
            }
            //else if (jsonType == JsonType.Object)
            //{
            //    JObject obj = JObject.Parse(data);
            //    string datum = (string)obj["data"];
            //    if (!string.Equals("datum", "All records uploaded successfully."))
            //    {
            //        ErrorInPatientRecord = true;
            //    }
            //}

            return;

        }

        public Dictionary<string, DataTable> GetAllTables(DataSet dataSet)
        {
            Dictionary<string, DataTable> keyValues = new Dictionary<string, DataTable>();
            int TableCount = dataSet.Tables.Count;
            if (TableCount > 0)
            {
                for (int i = 0; i < TableCount; i++)
                {
                    KeyValueClass<DataTable> keyValuesTemp = GetTableType(i, dataSet);
                    keyValues.Add(keyValuesTemp.KeyName, keyValuesTemp.KeyValue);
                }
            }
            return keyValues;
        }

        public KeyValueClass<DataTable> GetTableType(int i, DataSet dataSet)
        {
            switch (i)
            {
                case 0:// Individual/Client General Information
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(PatientEnum), PatientEnum.Patient), KeyValue = dataSet.Tables[0] };

                case 1:// Individual/Client Payer Information 
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(PatientEnum), PatientEnum.IndividualPayerInformation), KeyValue = dataSet.Tables[1] };

                case 2:// Individual/Client Address  
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(PatientEnum), PatientEnum.Address), KeyValue = dataSet.Tables[2] };

                case 3:// Individual/Client Phone  
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(PatientEnum), PatientEnum.IndividualPhones), KeyValue = dataSet.Tables[3] };

                case 4:// Individual/Client ResponsibleParty  
                    return new KeyValueClass<DataTable>() { KeyName = Enum.GetName(typeof(PatientEnum), PatientEnum.PatientResponsibleParty), KeyValue = dataSet.Tables[4] };

                default:
                    return null;
            }
        }
    }
}
