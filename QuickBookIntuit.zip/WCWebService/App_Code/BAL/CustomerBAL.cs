﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomerBAL
/// </summary>
public class CustomerBAL
{
    public CustomerBAL()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public List<CustomerModel> GetUnprocessedCustomers()
    {
        List<CustomerModel> lstCustomers = null;
        DataTable dtCustomer = new CustomerDAL().GetUnprocessedCustomers();
        if (dtCustomer != null && dtCustomer.Rows.Count > 0)
        {
            lstCustomers = new List<CustomerModel>();
            lstCustomers = CollectionHelper.Convert<CustomerModel>(dtCustomer);
        }
        return lstCustomers;
    }
    public void QBErrors(string Error)
    {
        new CustomerDAL().QBErrors(Error);
    }

    #region Sample Methods
    //public List<CustomerModel> GetSampleCustomerData()
    //{
    //    List<CustomerModel> lstCustomers = new List<CustomerModel>();

    //    CustomerModel oModel = new CustomerModel()
    //    {
    //        RequestId = "6771efde4c914abf8dc3d3b0fe1ec06f",
    //        Name = "Name" + DateTime.Now.Ticks.ToString(), //THIS IS UNIQUE DUPLICATE NAME WILL RESULT IN ERROR
    //        FirstName = "Pawan",
    //        LastName = "Prashar",
    //        Addr1 = "1512 Hunter Glen Drive Rd",
    //        City = "Plainsboro",
    //        State = "NJ",
    //        PostalCode = "08536",
    //        Country = "USA",
    //        Phone = "1234567890",
    //        Email = "pkprashar@netsmartz.com"
    //    };
    //    lstCustomers.Add(oModel);
    //    oModel = new CustomerModel()
    //    {
    //        RequestId = "21bfc592d8bc4b8096793fdc12b5363f",
    //        Name = "Name" + DateTime.Now.Ticks.ToString(), //THIS IS UNIQUE DUPLICATE NAME WILL RESULT IN ERROR
    //        FirstName = "Pawan",
    //        LastName = "Prashar",
    //        Addr1 = "1512 Hunter Glen Drive Rd",
    //        City = "Plainsboro",
    //        State = "NJ",
    //        PostalCode = "08536",
    //        Country = "USA",
    //        Phone = "1234567890",
    //        Email = "pkprashar@netsmartz.com"
    //    };

    //    lstCustomers.Add(oModel);


    //    return lstCustomers;
    //}
    #endregion

    #region Customer
    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public List<CustomerModel> QBGetDesktopClientForProcessing(string strUserID)
    {
        List<CustomerModel> lstCustomers = new List<CustomerModel>();
        DataTable dtCustomer = new CustomerDAL().QBGetDesktopClientForProcessing(strUserID);
        if (dtCustomer != null && dtCustomer.Rows.Count > 0)
        {
            lstCustomers = new List<CustomerModel>();
            lstCustomers = CollectionHelper.Convert<CustomerModel>(dtCustomer);
        }
        return lstCustomers;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public List<CustomerModel> AddProcessedCustomersCount()
    {
        List<CustomerModel> lstCustomers = new List<CustomerModel>();
        DataTable dtCustomer = new CustomerDAL().AddProcessedCustomersCount();
        if (dtCustomer != null && dtCustomer.Rows.Count > 0)
        {
            lstCustomers = new List<CustomerModel>();
            lstCustomers = CollectionHelper.Convert<CustomerModel>(dtCustomer);
        }
        return lstCustomers;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="ClientId"></param>
    /// <param name="ListID"></param>
    /// <param name="XMLResponse"></param>
    /// <returns></returns>
    public int QBInsertUpdateCustomerListId(Guid ClientId, string ListID, string XMLResponse)
    {
        return new CustomerDAL().QBInsertUpdateCustomerListId(ClientId, ListID, XMLResponse);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="strUserID"></param>
    /// <returns></returns>
    public int QBGetAllCustomerList(string XMLResponse, String FileName, string strUserID)
    {
        return new CustomerDAL().QBGetAllCustomerList(XMLResponse, FileName, strUserID);
    }
    #endregion

    #region Invoice
    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public List<InoviceModel> QBGetDesktopInvoiceForProcessing(string strUserID)
    {
        List<InoviceModel> lstCustomersDistinct = new List<InoviceModel>();
        InoviceModel mod = new InoviceModel();
        List<InoviceModel> lstCustomers = new List<InoviceModel>();
        List<InoviceItemModel> iteminvoice = new List<InoviceItemModel>();

        DataTable dtCustomer = new CustomerDAL().QBGetDesktopInvoiceForProcessing(strUserID);
        if (dtCustomer != null && dtCustomer.Rows.Count > 0)
        {
            lstCustomers = new List<InoviceModel>();
            lstCustomers = CollectionHelper.Convert<InoviceModel>(dtCustomer);
            string[] arr = lstCustomers.Select(x => x.InvoiceID).Distinct().ToArray();
            iteminvoice = CollectionHelper.Convert<InoviceItemModel>(dtCustomer);
            for (int i = 0; i < arr.Length; i++)
            {
                List<InoviceItemModel> iteminvoicedistinct = new List<InoviceItemModel>();
                string Getvalue = arr.GetValue(i).ToString();
                if (!lstCustomersDistinct.Any(x => x.InvoiceID == arr.GetValue(i).ToString()))
                {
                    mod = lstCustomers.Where(x => x.InvoiceID == arr.GetValue(i).ToString()).First();
                    lstCustomersDistinct.Add(mod);

                    iteminvoicedistinct = iteminvoice.Where(x => x.InvoiceID == arr.GetValue(i).ToString()).ToList();
                    if (iteminvoicedistinct.Count > 0)
                    {
                        lstCustomersDistinct[i].Items = iteminvoicedistinct;
                    }
                }
            }
        }
        return lstCustomersDistinct;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <returns></returns>
    public int QBInsertUpdateInvoiceListId(string XMLResponse)
    {
        return new CustomerDAL().QBInsertUpdateInvoiceListId(XMLResponse);
    }
    #endregion

    #region Caregiver
    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="strUserID"></param>
    /// <returns></returns>
    public int QBInsertUpdateCaregiverListFromQBDsk(string XMLResponse, String FileName, string strUserID)
    {
        return new CustomerDAL().QBGetAllCaregiverList(XMLResponse, FileName, strUserID);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public List<CaregiverModel> QBGetDesktopCaregiverForProcessing(string strUserID)
    {
        List<CaregiverModel> lstCaregiver = new List<CaregiverModel>();
        DataTable dtCaregiver = new CustomerDAL().QBGetDesktopCaregiverForProcessing(strUserID);
        if (dtCaregiver != null && dtCaregiver.Rows.Count > 0)
        {
            lstCaregiver = new List<CaregiverModel>();
            lstCaregiver = CollectionHelper.Convert<CaregiverModel>(dtCaregiver);
        }
        return lstCaregiver;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <returns></returns>
    public int QBInsertUpdateCaregiverListId(string XMLResponse)
    {
        return new CustomerDAL().QBInsertUpdateCaregiverListId(XMLResponse);
    }
    #endregion

    #region TimeTracking
    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="strUserID"></param>
    /// <returns></returns>
    public List<TimeTrackingModel> QBGetDesktopTimeTrackingForProcessing(string strUserID)
    {
        List<TimeTrackingModel> lstTimeTracking = new List<TimeTrackingModel>();
        DataTable dtTimeTracking = new CustomerDAL().QBGetDesktopTimeTrackingForProcessing(strUserID);
        if (dtTimeTracking != null && dtTimeTracking.Rows.Count > 0)
        {
            lstTimeTracking = new List<TimeTrackingModel>();
            lstTimeTracking = CollectionHelper.Convert<TimeTrackingModel>(dtTimeTracking);
        }
        return lstTimeTracking;
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <returns></returns>
    public int QBInsertUpdateTimeTrackingResponse(string XMLResponse)
    {
        return new CustomerDAL().QBInsertUpdateTimeTrackingResponse(XMLResponse);
    }

    #endregion

    #region "Class Data"
    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <returns></returns>
    public int QBInsertUpdateClassData(string XMLResponse, String FileName, String UserID)
    {
        return new CustomerDAL().QBInsertUpdateClassData(XMLResponse, FileName, UserID);
    }
    #endregion

    #region "Pay Code data"
    public int QBInsertUpdatePayCodeData(string XMLResponse, String FileName, String UserID)
    {
        return new CustomerDAL().QBInsertUpdatePayCodeData(XMLResponse, FileName, UserID);
    }
    #endregion

    #region Payment From QBD

    /// <summary>
    /// UserID as OfficeID
    /// </summary>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public string QBDFetchPaymentRequstList(String UserID)
    {
        return new CustomerDAL().QBDFetchPaymentRequstList(UserID);
    }

    public int QBDInsertUpdatePaymentFromQBD(string XMLResponse, String FileName, String UserID)
    {
        return new CustomerDAL().QBDInsertUpdatePaymentFromQBD(XMLResponse, FileName, UserID);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public string SendCS360PaymenttoQBD(String UserID)
    {
        return new CustomerDAL().SendCS360PaymenttoQBD(UserID);
    }

    /// <summary>
    /// QBD Send Payment Response
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBDSendPaymentRespose(string XMLResponse, String FileName, String UserID)
    {
        return new CustomerDAL().QBDSendPaymentRespose(XMLResponse, FileName, UserID);
    }
    #endregion

    #region Deposit Part
    /// <summary>
    /// 
    /// </summary>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public string SendCS360DepositPaymenttoQBD(String UserID)
    {
        return new CustomerDAL().SendCS360DepositPaymenttoQBD(UserID);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBSendDepositResponse(string XMLResponse, String FileName, String UserID)
    {
        return new CustomerDAL().QBSendDepositResponse(XMLResponse, FileName, UserID);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public string SendCS360RefundDepositPaymenttoQBD(String UserID)
    {
        return new CustomerDAL().SendCS360RefundDepositPaymenttoQBD(UserID);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XMLResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBSendRefundDepositResponse(string XMLResponse, String FileName, String UserID)
    {
        return new CustomerDAL().QBSendRefundDepositResponse(XMLResponse, FileName, UserID);
    }
    #endregion
}