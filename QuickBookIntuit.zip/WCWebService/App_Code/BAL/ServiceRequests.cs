﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Xml;
using System.IO;
using System.Xml.Linq;
/// <summary>
/// Summary description for ServiceRequests
/// </summary>

public class ServiceRequests
{
    public ServiceRequests()
    {

    }

    public void ProcessRequest(string xmlData, string strUserID)
    {
        try
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlData);
            XmlNode node = doc.GetElementsByTagName("QBXMLMsgsRs")[0];
            XmlNode childNode = node.ChildNodes[0];

            if (childNode != null && !string.IsNullOrEmpty(childNode.Name))
            {
                int iRetValue = 0;
                switch (childNode.Name)
                {
                    case "AccountQueryRs":
                        string accountsXml = ProcessAccountsXML(doc).OuterXml;
                        iRetValue = new ServicesDAL().ProcessMasterAccountsAndItemXML(accountsXml, Convert.ToInt16(enRequestType.Accounts), strUserID);
                        break;
                    case "ItemQueryRs":
                        string itemsXml = ProcessItemInquiryXML(doc).OuterXml;
                        iRetValue = new ServicesDAL().ProcessMasterAccountsAndItemXML(itemsXml, Convert.ToInt16(enRequestType.ItemInquiry), strUserID);
                        break;
                    case "CustomerQueryRs":
                        if (HttpContext.Current.Session["FileName"] != null)
                        {
                            string yourPath = Convert.ToString(HttpContext.Current.Session["FileName"]);
                            string RealFileName = Path.GetFileName(yourPath);
                            new CustomerBAL().QBGetAllCustomerList(xmlData, RealFileName, strUserID);
                        }
                        break;
                    case "CustomerAddRs":
                        new CustomerBAL().QBInsertUpdateCustomerListId(new Guid(), "", xmlData);
                        break;
                    case "InvoiceAddRs":
                        new CustomerBAL().QBInsertUpdateInvoiceListId(xmlData);
                        break;
                    case "EmployeeQueryRs":
                        if (HttpContext.Current.Session["FileName"] != null)
                        {
                            string yourPath = Convert.ToString(HttpContext.Current.Session["FileName"]);
                            string RealFileName = Path.GetFileName(yourPath);
                            new CustomerBAL().QBInsertUpdateCaregiverListFromQBDsk(xmlData, RealFileName, strUserID);
                        }
                        break;
                    case "EmployeeAddRs":
                        new CustomerBAL().QBInsertUpdateCaregiverListId(xmlData);
                        break;
                    case "TimeTrackingAddRs":
                        new CustomerBAL().QBInsertUpdateTimeTrackingResponse(xmlData);
                        break;
                    case "ClassQueryRs":
                        if (HttpContext.Current.Session["FileName"] != null)
                        {
                            string yourPath = Convert.ToString(HttpContext.Current.Session["FileName"]);
                            string RealFileName = Path.GetFileName(yourPath);
                            new CustomerBAL().QBInsertUpdateClassData(xmlData, RealFileName, strUserID);
                        }
                        break;
                    case "PayrollItemWageQueryRs":
                        if (HttpContext.Current.Session["FileName"] != null)
                        {
                            string yourPath = Convert.ToString(HttpContext.Current.Session["FileName"]);
                            string RealFileName = Path.GetFileName(yourPath);
                            new CustomerBAL().QBInsertUpdatePayCodeData(xmlData, RealFileName, strUserID);
                        }
                        break;
                    case "ReceivePaymentQueryRs":
                        if (HttpContext.Current.Session["FileName"] != null)
                        {
                            string yourPath = Convert.ToString(HttpContext.Current.Session["FileName"]);
                            string RealFileName = Path.GetFileName(yourPath);
                            new CustomerBAL().QBDInsertUpdatePaymentFromQBD(xmlData, RealFileName, strUserID);
                        }
                        break;
                    case "ReceivePaymentAddRs":
                        if (HttpContext.Current.Session["FileName"] != null)
                        {
                            string yourPath = Convert.ToString(HttpContext.Current.Session["FileName"]);
                            string RealFileName = Path.GetFileName(yourPath);
                            new CustomerBAL().QBDSendPaymentRespose(xmlData, RealFileName, strUserID);
                        }
                        break;
                    case "SalesReceiptAddRs":
                        if (HttpContext.Current.Session["FileName"] != null)
                        {
                            string yourPath = Convert.ToString(HttpContext.Current.Session["FileName"]);
                            string RealFileName = Path.GetFileName(yourPath);
                            new CustomerBAL().QBSendDepositResponse(xmlData, RealFileName, strUserID);
                        }
                        break;
                    case "CreditMemoAddRs":
                        if (HttpContext.Current.Session["FileName"] != null)
                        {
                            string yourPath = Convert.ToString(HttpContext.Current.Session["FileName"]);
                            string RealFileName = Path.GetFileName(yourPath);
                            new CustomerBAL().QBSendRefundDepositResponse(xmlData, RealFileName, strUserID);
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        catch (Exception ex)
        {
        }
    }

    private XmlDocument ProcessAccountsXML(XmlDocument doc)
    {


        XmlDocument xmlProcessedDoc = new XmlDocument();
        XmlNode rootNode = xmlProcessedDoc.CreateElement("accounts");
        xmlProcessedDoc.AppendChild(rootNode);

        try
        {

            //Create a XML Node List with XPath Expression  
            XmlNodeList xmlNodeList = doc.SelectNodes("/QBXML/QBXMLMsgsRs/AccountQueryRs/AccountRet");

            foreach (XmlNode xmlNode in xmlNodeList)
            {
                XmlNode dataNode = xmlProcessedDoc.CreateElement("data");
                rootNode.AppendChild(dataNode);

                XmlAttribute attribute = xmlProcessedDoc.CreateAttribute("listid");
                attribute.Value = xmlNode["ListID"].InnerText;
                dataNode.Attributes.Append(attribute);

                attribute = xmlProcessedDoc.CreateAttribute("fullname");
                attribute.Value = xmlNode["FullName"].InnerText;
                dataNode.Attributes.Append(attribute);

                attribute = xmlProcessedDoc.CreateAttribute("isactive");
                attribute.Value = xmlNode["IsActive"].InnerText;
                dataNode.Attributes.Append(attribute);

                attribute = xmlProcessedDoc.CreateAttribute("AccountType");
                attribute.Value = xmlNode["AccountType"].InnerText;
                dataNode.Attributes.Append(attribute);
            }


        }
        catch
        {
            throw;
        }


        return xmlProcessedDoc;
    }
    private XmlDocument ProcessCustomerXML(XmlDocument doc)
    {
        XmlDocument xmlProcessedDoc = new XmlDocument();
        XmlNode rootNode = xmlProcessedDoc.CreateElement("customer");
        xmlProcessedDoc.AppendChild(rootNode);

        try
        {
            XmlNode requestNode = doc.SelectNodes("/QBXML/QBXMLMsgsRs/CustomerAddRs")[0];
            string requestId = requestNode.Attributes["requestID"].Value;
            string statusCode = requestNode.Attributes["statusCode"].Value;
            int responseCode = -1;

            if (int.TryParse(statusCode, out responseCode) && responseCode == 0)
            {
                XmlNodeList xmlNodeList = doc.SelectNodes("/QBXML/QBXMLMsgsRs/CustomerAddRs/CustomerRet");

                foreach (XmlNode xmlNode in xmlNodeList)
                {
                    XmlNode dataNode = xmlProcessedDoc.CreateElement("data");
                    rootNode.AppendChild(dataNode);

                    XmlAttribute attribute = xmlProcessedDoc.CreateAttribute("requestid");
                    attribute.Value = requestId;
                    dataNode.Attributes.Append(attribute);

                    attribute = xmlProcessedDoc.CreateAttribute("listid");
                    attribute.Value = xmlNode["ListID"].InnerText;
                    dataNode.Attributes.Append(attribute);

                    attribute = xmlProcessedDoc.CreateAttribute("fullname");
                    attribute.Value = xmlNode["FullName"].InnerText;
                    dataNode.Attributes.Append(attribute);

                    attribute = xmlProcessedDoc.CreateAttribute("isactive");
                    attribute.Value = xmlNode["IsActive"].InnerText;
                    dataNode.Attributes.Append(attribute);

                    attribute = xmlProcessedDoc.CreateAttribute("email");
                    attribute.Value = xmlNode["Email"].InnerText;
                    dataNode.Attributes.Append(attribute);
                }
            }

        }
        catch
        {
            throw;
        }


        return xmlProcessedDoc;
    }
    private XmlDocument ProcessItemInquiryXML(XmlDocument doc)
    {


        XmlDocument xmlProcessedDoc = new XmlDocument();
        XmlNode rootNode = xmlProcessedDoc.CreateElement("iteminquiry");
        xmlProcessedDoc.AppendChild(rootNode);

        try
        {

            //Create a XML Node List with XPath Expression  
            XmlNodeList xmlNodeList = doc.SelectNodes("/QBXML/QBXMLMsgsRs/ItemQueryRs/ItemServiceRet");

            foreach (XmlNode xmlNode in xmlNodeList)
            {
                XmlNode dataNode = xmlProcessedDoc.CreateElement("data");
                rootNode.AppendChild(dataNode);
                XmlAttribute attribute = xmlProcessedDoc.CreateAttribute("listid");
                attribute.Value = xmlNode["ListID"].InnerText;
                dataNode.Attributes.Append(attribute);

                attribute = xmlProcessedDoc.CreateAttribute("fullname");
                attribute.Value = xmlNode["FullName"].InnerText;
                dataNode.Attributes.Append(attribute);

                attribute = xmlProcessedDoc.CreateAttribute("isactive");
                attribute.Value = xmlNode["IsActive"].InnerText;
                dataNode.Attributes.Append(attribute);
            }


        }
        catch
        {
            throw;
        }


        return xmlProcessedDoc;
    }
}