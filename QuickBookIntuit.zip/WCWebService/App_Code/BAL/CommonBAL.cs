﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CommonBAL
/// </summary>
public class CommonBAL
{
    public CommonBAL()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int QuickBookfindAgencyId(string UserName)
    {
        return new CommonDAL().QuickBookfindAgencyId(UserName);
    }
    public String getconnectionStringbyAgencyId(Int32 AgencyId)
    {
        return new CommonDAL().getconnectionStringbyAgencyId(AgencyId);
    }
}