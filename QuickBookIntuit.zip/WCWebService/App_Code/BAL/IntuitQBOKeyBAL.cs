﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Dapper;

/// <summary>
/// Summary description for IntuitQBOKeyBAL
/// </summary>
public class IntuitQBOKeyBAL
{
    public IntuitQBOKeyBAL()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static DataTable GetDbConnections(Int16 ServerId, string FromDatabase)
    {
        try
        {
            IntuitQBOKeyDAL objModel = new IntuitQBOKeyDAL();
            DataTable dt = new DataTable();
            dt = IntuitQBOKeyDAL.GetDbConnections(ServerId, FromDatabase);
            if (dt != null && dt.Rows.Count > 0)
                return dt;
            else
                return null;
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    public IntuitQBOKeyModel GetAutorizedDotNetPaymentTransactionList(int cszp_at_top, String FromDatabase, Guid GatewayType, Guid PaymentType)
    {
        IntuitQBOKeyModel response = new IntuitQBOKeyModel();

        try
        {

            using (IDbConnection db = new SqlConnection(FromDatabase))
            {
                //DynamicParameters param = new DynamicParameters();
                //param.Add("@GatewayType", GatewayType);
                //param.Add("@PaymentType", PaymentType);

                //response.responseData = db.Query<CreditCardTransactionModel>("SP_GetUpdatedTransactions", param, commandType: CommandType.StoredProcedure, commandTimeout: 0, buffered: true)
                //    .ToList();

                //db.Close();
            }
            return response;

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}