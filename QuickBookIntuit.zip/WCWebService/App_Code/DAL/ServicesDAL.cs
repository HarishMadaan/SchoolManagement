﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using WCWebService;
using DAL.Helpers;

/// <summary>
/// Summary description for ServicesDAL
/// </summary>
public class ServicesDAL
{
    private string CTZConnection = SessionVariables.ConnectionString; // Convert.ToString(ConfigurationManager.ConnectionStrings["CTZConnection"]);

    public int ProcessMasterAccountsAndItemXML(string xml, int mode, string ID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] parms = new SqlParameter[3];
            parms[0] = new SqlParameter("XMLDetail", xml);
            parms[1] = new SqlParameter("Mode", mode);
            parms[2] = new SqlParameter("ID", ID);
            return SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "spCaresmartz_InsertAccountAndItemsMasterList", null, parms);
        }
    }

 
    
}