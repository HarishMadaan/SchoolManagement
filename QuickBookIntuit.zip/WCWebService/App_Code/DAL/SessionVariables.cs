﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Configuration;

namespace DAL.Helpers
{
    public static class SessionVariables
    {
        public static Boolean ValidateSession()
        {
            if (HttpContext.Current.Session["UserID"] != null)
                return true;
            else
                return false;
        }

        public static Guid UserID
        {
            get
            {
                if (HttpContext.Current.Session["UserID"] != null)
                    return new Guid(HttpContext.Current.Session["UserID"].ToString());
                else
                    return Guid.Empty;
            }
            set {
                HttpContext.Current.Session["UserID"] = value;
            }
        }
        public static Guid UserTypeID
        {
            get
            {
                if (HttpContext.Current.Session["UserTypeID"] != null)
                    return new Guid(HttpContext.Current.Session["UserTypeID"].ToString());
                else
                    return Guid.Empty;
            }
            set
            {
                HttpContext.Current.Session["UserTypeID"] = value;
            }
        }
        public static String FirstName
        {
            get
            {
                if (HttpContext.Current.Session["FirstName"] != null)
                    return  HttpContext.Current.Session["FirstName"].ToString();
                else
                    return String.Empty;
            }
            set
            {
                HttpContext.Current.Session["FirstName"] = value;
            }
        }
        public static String LastName
        {
            get
            {
                if (HttpContext.Current.Session["LastName"] != null)
                    return HttpContext.Current.Session["LastName"].ToString();
                else
                    return String.Empty;
            }
            set
            {
                HttpContext.Current.Session["LastName"] = value;
            }
        }
        public static String UserName
        {
            get
            {
                if (HttpContext.Current.Session["UserName"] != null)
                    return HttpContext.Current.Session["UserName"].ToString();
                else
                    return String.Empty;
            }
            set
            {
                HttpContext.Current.Session["UserName"] = value;
            }
        }
        public static Guid OfficeId
        {
            get
            {
                if (HttpContext.Current.Session["OfficeId"] != null)
                    return new Guid(HttpContext.Current.Session["OfficeId"].ToString());
                else
                    return Guid.Empty;
            }
            set
            {
                HttpContext.Current.Session["OfficeId"] = value;
            }
        }

        public static String AgencyId
        {
            get
            {
                if (HttpContext.Current.Session["AgencyId"] != null)
                    return HttpContext.Current.Session["AgencyId"].ToString();
                else
                    return string.Empty;
            }
            set
            {
                HttpContext.Current.Session["AgencyId"] = value;
            }
        }
        public static String ConnectionString
        {
            get
            {
                if (HttpContext.Current.Session["ConnectionString"] != null)
                    return HttpContext.Current.Session["ConnectionString"].ToString();
                else
                    return string.Empty;
            }
            set
            {
                HttpContext.Current.Session["ConnectionString"] = value;
            }
        }
        public static Guid UserTimeZoneID
        {
            get
            {
                if (HttpContext.Current.Session["UserTimeZoneID"] != null)
                    return new Guid(HttpContext.Current.Session["UserTimeZoneID"].ToString());
                else
                    return Guid.Empty;
            }
            set
            {
                HttpContext.Current.Session["UserTimeZoneID"] = value;
            }
        }
        public static List<Guid> UserRoles
        {
            get
            {
                if (HttpContext.Current.Session["UserRoles"] != null)
                    return (List<Guid>)HttpContext.Current.Session["UserRoles"];
                else
                    return new List<Guid>();
            }
            set
            {
                HttpContext.Current.Session["UserRoles"] = value;
            }
        }
    }

   
}