﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using WCWebService;
using System.Configuration;
using DAL.Helpers;
using Dapper;

/// <summary>
/// Summary description for IntuitQBOKeyDAL
/// </summary>
public class IntuitQBOKeyDAL
{
    public IntuitQBOKeyDAL()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public string CTZConnection = SessionVariables.ConnectionString;

    public static DataTable GetDbConnections(Int16 ServerId, string FromDatabase)
    {
        try
        {            
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            SqlParameter[] arrParam = new SqlParameter[1];
            arrParam[0] = new SqlParameter("@ServerId", ServerId);
            ds = SQlHelper.ExecuteDataset("Sp_GetDBConnections", FromDatabase, arrParam);
            if (ds.Tables.Count > 0)
                return ds.Tables[0];
            else
                return null;            
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    public IntuitQBOKeyModel GetAutorizedDotNetPaymentTransactionList(int cszp_at_top, String FromDatabase, Guid GatewayType, Guid PaymentType)
    {
        IntuitQBOKeyModel response = new IntuitQBOKeyModel();

        try
        {

            using (IDbConnection db = new SqlConnection(FromDatabase))
            {
                //DynamicParameters param = new DynamicParameters();
                //param.Add("@GatewayType", GatewayType);
                //param.Add("@PaymentType", PaymentType);

                //response.responseData = db.Query<CreditCardTransactionModel>("SP_GetUpdatedTransactions", param, commandType: CommandType.StoredProcedure, commandTimeout: 0, buffered: true)
                //    .ToList();

                db.Close();
            }
            return response;

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

}