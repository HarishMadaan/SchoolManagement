﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using WCWebService;
using System.Configuration;
using DAL.Helpers;




/// <summary>
/// Summary description for CustomerDAL
/// </summary>
public class CustomerDAL
{

    public CustomerDAL()
    {

    }

    private string CTZConnection = SessionVariables.ConnectionString;

    public DataTable GetUnprocessedCustomers()
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "spCaresmartz_InsertAccountAndItemsMasterList", null);
            if (ds != null && ds.Tables.Count > 0)
            {
                return ds.Tables[0];
            }
        }
        return null;
    }

    #region Customer
    public DataTable QBGetDesktopClientForProcessing(string strUserID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            //SqlParameter[] param = new SqlParameter[1];
            //param[0] = new SqlParameter();
            //param[0].ParameterName = "@XMLResponse";
            //param[0].SqlDbType = SqlDbType.NVarChar;
            //param[0].Value = XmlResponse;

            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@OfficeID", strUserID));

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "QBGetDesktopClientForProcessing", parameters.ToArray());
            if (ds != null && ds.Tables.Count > 0)
            {
                return ds.Tables[0];
            }
        }
        return null;
    }
    public DataTable AddProcessedCustomersCount()
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            //SqlParameter[] param = new SqlParameter[1];
            //param[0] = new SqlParameter();
            //param[0].ParameterName = "@XMLResponse";
            //param[0].SqlDbType = SqlDbType.NVarChar;
            //param[0].Value = XmlResponse;
            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "QBGetDesktopClientForProcessing", null);
            if (ds != null && ds.Tables.Count > 0)
            {
                return ds.Tables[0];
            }
        }
        return null;
    }
    public int QBInsertUpdateCustomerListId(Guid ClientId, string ListID, string XmlResponse)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[1];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "USP_QBDesktopUpdateProcessedCustomers", "", param);
            retval = 1;
        }
        return retval;
    }

    /// <summary>
    /// Insert/Update Customer list from QuickBooks Desktop
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBGetAllCustomerList(string XmlResponse, String FileName, String UserID)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[3];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@QBFileName";
            param[1].SqlDbType = SqlDbType.VarChar;
            param[1].Value = FileName;

            param[2] = new SqlParameter();
            param[2].ParameterName = "@UserID";
            param[2].SqlDbType = SqlDbType.VarChar;
            param[2].Value = UserID;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "USP_GetAllCustomerListByQBFileName", "", param);
            retval = 1;
        }
        return retval;
    }

    #endregion

    #region Invoice
    public DataTable QBGetDesktopInvoiceForProcessing(string strUserID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@OfficeID", strUserID));

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "PrQuickBooks_DesktopExportInvoiceDetails", parameters.ToArray());
            if (ds != null && ds.Tables.Count > 0)
            {
                return ds.Tables[0];
            }
        }
        return null;
    }
    public void QBErrors(string Error)
    {

        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[1];

            param[0] = new SqlParameter();
            param[0].ParameterName = "@Error";
            param[0].SqlDbType = SqlDbType.NVarChar;
            param[0].Value = Error;
            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "USP_QBErrors", "", param);

        }

    }
    public int QBInsertUpdateInvoiceListId(string XmlResponse)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[1];

            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;



            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "USP_QBDesktopUpdateProcessedInvoices", "", param);
            retval = 1;
        }
        return retval;
    }

    #endregion

    #region Caregiver
    /// <summary>
    /// Insert/Update Caregiver list from QuickBooks Desktop
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBGetAllCaregiverList(string XmlResponse, String FileName, String UserID)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[3];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@QBFileName";
            param[1].SqlDbType = SqlDbType.VarChar;
            param[1].Value = FileName;

            param[2] = new SqlParameter();
            param[2].ParameterName = "@UserID";
            param[2].SqlDbType = SqlDbType.VarChar;
            param[2].Value = UserID;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "PrQBDesktop_InsertUpdateAllCaregiverListByFileName", "", param);
            retval = 1;
        }
        return retval;
    }

    /// <summary>
    /// Get Caregiver list for processing
    /// </summary>
    /// <returns></returns>
    public DataTable QBGetDesktopCaregiverForProcessing(string strUserID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {

            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@OfficeID", strUserID));

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "PrQuickBooks_FetchCaregiverListForProcessing", parameters.ToArray());
            if (ds != null && ds.Tables.Count > 0)
            {
                return ds.Tables[0];
            }
        }
        return null;
    }

    /// <summary>
    /// Update caregiver List ID
    /// </summary>
    /// <param name="ClientId"></param>
    /// <param name="ListID"></param>
    /// <param name="XmlResponse"></param>
    /// <returns></returns>
    public int QBInsertUpdateCaregiverListId(string XmlResponse)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[1];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "USP_QBDesktopUpdateProcessedCaregiver", "", param);
            retval = 1;
        }
        return retval;
    }

    #endregion

    #region TimeTracking
    /// <summary>
    /// Insert/Update TimeTracking list from QuickBooks Desktop
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>

    /// <summary>
    /// Get TimeTracking list for processing
    /// </summary>
    /// <returns></returns>
    public DataTable QBGetDesktopTimeTrackingForProcessing(string strUserID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@EntityID", strUserID));

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "PrQuickBooks_FetchSericeTimeTrackingDatatoProcess", parameters.ToArray());
            if (ds != null && ds.Tables.Count > 0)
            {
                return ds.Tables[0];
            }
        }
        return null;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <returns></returns>
    public int QBInsertUpdateTimeTrackingResponse(string XmlResponse)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[1];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "PrQuickBooks_UpdateTimeTrackingStatus", "", param);
            retval = 1;
        }
        return retval;
    }

    #endregion

    #region "Class Data"
    /// <summary>
    /// 
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <returns></returns>
    public int QBInsertUpdateClassData(string XmlResponse, String FileName, String UserID)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[3];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@QBFileName";
            param[1].SqlDbType = SqlDbType.VarChar;
            param[1].Value = FileName;

            param[2] = new SqlParameter();
            param[2].ParameterName = "@UserID";
            param[2].SqlDbType = SqlDbType.VarChar;
            param[2].Value = UserID;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "PrQBDesktop_InsertUpdateClassData", "", param);
            retval = 1;
        }
        return retval;
    }

    #endregion

    #region "Pay Code data"
    /// <summary>
    /// 
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBInsertUpdatePayCodeData(string XmlResponse, String FileName, String UserID)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[3];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@QBFileName";
            param[1].SqlDbType = SqlDbType.VarChar;
            param[1].Value = FileName;

            param[2] = new SqlParameter();
            param[2].ParameterName = "@UserID";
            param[2].SqlDbType = SqlDbType.VarChar;
            param[2].Value = UserID;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "PrQBDesktop_InsertUpdatePayCodeData", "", param);
            retval = 1;
        }
        return retval;
    }
    #endregion

    #region Payment From QBD

    /// <summary>
    /// 
    /// </summary>
    /// <param name="strUserID"></param>
    /// <returns></returns>
    public string QBDFetchPaymentRequstList(string strUserID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@OfficeID", strUserID));

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "PrQBDesktop_InvoicePaymentFetch", parameters.ToArray());
            if (ds != null && ds.Tables.Count > 0)
            {
                return Convert.ToString(ds.Tables[0].Rows[0][0]);
            }
        }
        return null;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBDInsertUpdatePaymentFromQBD(string XmlResponse, String FileName, String UserID)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[3];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@QBFileName";
            param[1].SqlDbType = SqlDbType.VarChar;
            param[1].Value = FileName;

            param[2] = new SqlParameter();
            param[2].ParameterName = "@UserID";
            param[2].SqlDbType = SqlDbType.VarChar;
            param[2].Value = UserID;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "PrQBD_FetchInsertUpdate_PaymentData", "", param);
            retval = 1;
        }
        return retval;
    }

    /// <summary>
    /// Payment from CS360 TO QBD
    /// </summary>
    /// <param name="strUserID"></param>
    /// <returns></returns>
    public string SendCS360PaymenttoQBD(string strUserID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@OfficeID", strUserID));

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "PrQBDesktop_CaresmartzInvoicePaymentSend", parameters.ToArray());
            if (ds != null && ds.Tables.Count > 0 && Convert.ToString(ds.Tables[0].Rows[0]["Empty"]) != "0")
            {
                return Convert.ToString(ds.Tables[0].Rows[0][0]);
            }
        }
        return null;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBDSendPaymentRespose(string XmlResponse, String FileName, String UserID)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[3];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@QBFileName";
            param[1].SqlDbType = SqlDbType.VarChar;
            param[1].Value = FileName;

            param[2] = new SqlParameter();
            param[2].ParameterName = "@UserID";
            param[2].SqlDbType = SqlDbType.VarChar;
            param[2].Value = UserID;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "PrQBD_FetchInsertUpdate_PaymentDataSent", "", param);
            retval = 1;
        }
        return retval;
    }

    #endregion

    #region Sales Receipt Part

    /// <summary>
    /// 
    /// </summary>
    /// <param name="strUserID"></param>
    /// <returns></returns>
    public string SendCS360DepositPaymenttoQBD(string strUserID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@OfficeID", strUserID));

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "PrQBDesktop_CaresmartzSendDeposit", parameters.ToArray());
            if (ds != null && ds.Tables.Count > 0 && Convert.ToString(ds.Tables[0].Rows[0]["Empty"]) != "0")
            {
                return Convert.ToString(ds.Tables[0].Rows[0][0]);
            }
        }
        return null;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBSendDepositResponse(string XmlResponse, String FileName, String UserID)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[3];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@QBFileName";
            param[1].SqlDbType = SqlDbType.VarChar;
            param[1].Value = FileName;

            param[2] = new SqlParameter();
            param[2].ParameterName = "@UserID";
            param[2].SqlDbType = SqlDbType.VarChar;
            param[2].Value = UserID;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "PrQBD_UpdateDepositResponse", "", param);
            retval = 1;
        }
        return retval;
    }
    #endregion

    #region Credit Memo Refund Part
    /// <summary>
    /// 
    /// </summary>
    /// <param name="strUserID"></param>
    /// <returns></returns>
    public string SendCS360RefundDepositPaymenttoQBD(string strUserID)
    {
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@OfficeID", strUserID));

            DataSet ds = SQlHelper.getDataset(conn, CommandType.StoredProcedure, "PrQBDesktop_CaresmartzSendRefund", parameters.ToArray());
            if (ds != null && ds.Tables.Count > 0 && Convert.ToString(ds.Tables[0].Rows[0]["Empty"]) != "0")
            {
                return Convert.ToString(ds.Tables[0].Rows[0][0]);
            }
        }
        return null;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="XmlResponse"></param>
    /// <param name="FileName"></param>
    /// <param name="UserID"></param>
    /// <returns></returns>
    public int QBSendRefundDepositResponse(string XmlResponse, String FileName, String UserID)
    {
        int retval = 0;
        using (SqlConnection conn = new SqlConnection(CTZConnection))
        {
            SqlParameter[] param = new SqlParameter[3];


            param[0] = new SqlParameter();
            param[0].ParameterName = "@Response";
            param[0].SqlDbType = SqlDbType.Xml;
            param[0].Value = XmlResponse;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@QBFileName";
            param[1].SqlDbType = SqlDbType.VarChar;
            param[1].Value = FileName;

            param[2] = new SqlParameter();
            param[2].ParameterName = "@UserID";
            param[2].SqlDbType = SqlDbType.VarChar;
            param[2].Value = UserID;


            SQlHelper.ExecuteNonQuerySp1(conn, CommandType.StoredProcedure, "PrQBD_UpdateRefundDepositResponse", "", param);
            retval = 1;
        }
        return retval;
    }

    #endregion

}