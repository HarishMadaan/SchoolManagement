﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

/// <summary>
/// Summary description for Readconfiguration
/// </summary>
/// namespace DAL.Helpers
/// 
namespace DAL.Helpers
{
    public class ReadConfiguration
    {
        public static string SchedularCalendarURL;
        public static string DisplayName { get; set; }
        public static string BaseSiteUrl { get; set; }
        public static string SmtpClient { get; set; }
        public static string SmtpPort { get; set; }
        public static string MailPassword { get; set; }
        public static string UserName { get; set; }
        public static string EnableSSL { get; set; }
        public static string MailFrom { get; set; }
        public static String HCMConnectionString { get; set; }
        public static string ConnectionString { get; set; }
        public static string UserBlockMin { get; set; }
        public static string RecentPasswordUse { get; set; }
        public static string ReportsUserName { get; set; }
        public static string ReportsPassword { get; set; }
        public static string ReportServerUrl { get; set; }
        public static string ReportFolder { get; set; }
        public static string ReportsDomain { get; set; }
        public static string IntakeReportFolder { get; set; }
        public static string PDFCreatePath { get; set; }
        public static string LocalConnectionString { get; set; }

        public static string PDFCreateAbsolutePath { get; set; }

        public static string PDFCreateFlag { get; set; }
        public static string LogOutMin { get; set; }


        static ReadConfiguration()
        {
            SchedularCalendarURL = ConfigurationManager.AppSettings["SchedularCalendarURL"];
            DisplayName = ConfigurationManager.AppSettings["DisplayName"];
            BaseSiteUrl = ConfigurationManager.AppSettings["BaseSiteUrl"];
            SmtpClient = ConfigurationManager.AppSettings["SmtpClient"];
            SmtpPort = ConfigurationManager.AppSettings["SmtpPort"];
            MailPassword = ConfigurationManager.AppSettings["MailPassword"];
            UserName = ConfigurationManager.AppSettings["UserName"];
            EnableSSL = ConfigurationManager.AppSettings["EnableSSL"];
            MailFrom = ConfigurationManager.AppSettings["MailFrom"];
            UserBlockMin = ConfigurationManager.AppSettings["UserBlockMin"];
            HCMConnectionString = ConfigurationManager.ConnectionStrings["HMCConnectionString"].ToString();
            ConnectionString = ConfigurationManager.AppSettings["CommonConnectionString"].ToString();
            RecentPasswordUse = ConfigurationManager.AppSettings["RecentPasswordUse"];
            ReportsUserName = ConfigurationManager.AppSettings["ReportsUserName"];
            ReportsPassword = ConfigurationManager.AppSettings["ReportsPassword"];
            ReportServerUrl = ConfigurationManager.AppSettings["ReportServerUrl"].ToString();
            ReportFolder = ConfigurationManager.AppSettings["ReportFolder"].ToString();
            ReportsDomain = ConfigurationManager.AppSettings["ReportsDomain"];
            IntakeReportFolder = ConfigurationManager.AppSettings["IntakeReportFolder"];
            PDFCreatePath = ConfigurationManager.AppSettings["PDFCreatePath"];
            LocalConnectionString = ConfigurationManager.AppSettings["LocalConnectionString"];
            PDFCreateAbsolutePath = ConfigurationManager.AppSettings["PDFCreateAbsolutePath"];
            PDFCreateFlag = ConfigurationManager.AppSettings["PDFCreateFlag"];
            LogOutMin = ConfigurationManager.AppSettings["LogOutMin"];
        }
    }
}