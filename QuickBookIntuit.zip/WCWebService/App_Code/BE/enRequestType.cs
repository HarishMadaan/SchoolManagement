﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// Summary description for enRequestType
/// </summary>
public enum enRequestType
{
    Accounts = 1,
    ItemInquiry=2,
    AddCustomer=3
}

 