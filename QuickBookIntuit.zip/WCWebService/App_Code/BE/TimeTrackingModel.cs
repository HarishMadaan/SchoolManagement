﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for TimeTrackingModel
/// </summary>
public class TimeTrackingModel
{
    public TimeTrackingModel()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public Guid RequestID { get; set; }
    public string PayrollItem { get; set; }
    public string Notes { get; set; }
    public string EmpID { get; set; }
    public string CustomerFullName { get; set; }
    public string ItemServiceListID { get; set; }
    public string ItemServiceFullName { get; set; }
    public DateTime TxDate { get; set; }
    public string Duration { get; set; }
    public string AccountsName { get; set; }
    public string QBDskTopAccountsPayableListID { get; set; }
    public string QBDskPayrollItemServiceListID { get; set; }
    public string QBDskListCustID { get; set; }
    public string PayrollItemWageRef { get; set; }

    public string BillableStatus { get; set; }

    public string QBClassRef { get; set; }
}