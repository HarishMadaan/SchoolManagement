﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

/// <summary>
/// Summary description for CollectionHelper
/// </summary>
public class CollectionHelper
{
    public CollectionHelper()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static List<T> Convert<T>(DataTable dt)
    {
        List<T> data = new List<T>();
        foreach (DataRow row in dt.Rows)
        {
            T item = GetItem<T>(row);
            data.Add(item);
        }
        return data;
    }
    private static T GetItem<T>(DataRow dr)
    {
        Type temp = typeof(T);
        T obj = Activator.CreateInstance<T>();

        foreach (DataColumn column in dr.Table.Columns)
        {
            foreach (PropertyInfo pro in temp.GetProperties())
            {
                if (pro.Name == column.ColumnName)
                    try
                    {
                        if (!string.IsNullOrEmpty(dr[column.ColumnName].ToString()))
                        {
                            pro.SetValue(obj, dr[column.ColumnName], null);
                        }
                        else
                        {
                            if (column.DataType == typeof(DateTime))
                                pro.SetValue(obj, null, null);
                            else
                                pro.SetValue(obj, "", null);
                        }
                    }
                    catch(Exception ex) {
                        Guid ReauestID = new Guid(dr[column.ColumnName].ToString());
                        pro.SetValue(obj, ReauestID.ToString(), null);
                    }
                  
                else
                    continue;
            }
        }
        return obj;
    }


}
