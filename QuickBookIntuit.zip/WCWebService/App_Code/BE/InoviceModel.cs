﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for InoviceModel
/// </summary>
/// 
public class InoviceModel
{
    public InoviceModel()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public string InvoiceID { get; set; }
    public string ClientName { get; set; }

    public string InvoiceNumber { get; set; }
    public string PayerAddress1 { get; set; }
    public string PayerCity { get; set; }
    public string PayerStateOrProvince { get; set; }
    public string PayerPostalCode { get; set; }
    public string PayerCountry { get; set; }
    
    public DateTime DueDate { get; set; }
    public DateTime InvoiceDate { get; set; }
    public List<InoviceItemModel> Items { get; set; }
    public string PayerName { get; set; }
    public string QBDskListCustID { get; set; }
    public string QBClassRef { get; set; }
    public int PreferredDelivery { get; set; }

   

}

public class InoviceModelWithoutItem
{
    public InoviceModelWithoutItem()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public string InvoiceID { get; set; }
    public string ClientName { get; set; }

    public string InvoiceNumber { get; set; }
    public string PayerAddress1 { get; set; }
    public string PayerCity { get; set; }
    public string PayerStateOrProvince { get; set; }
    public string PayerPostalCode { get; set; }
    public string PayerCountry { get; set; }


}
public class InoviceItemModel
{
    public InoviceItemModel()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string InvoiceID { get; set; }
    public string FullName { get; set; }
    public string LineDescription { get; set; }
    public decimal LineUnits { get; set; }//quantity
    public decimal ChargeRate { get; set; }
    public string ItemService { get; set; }
    public decimal LineTotal { get; set; }
    public string QbItemID { get; set; }
    public DateTime ServiceDate { get; set; }
}