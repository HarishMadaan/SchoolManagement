﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for IntuitQBOKeyModel
/// </summary>
public class IntuitQBOKeyModel
{
    public IntuitQBOKeyModel()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public Guid IntuitQBID { get; set; }
    public Guid FranchiseID { get; set; }
    public string AccessToken_QBO2 { get; set; }
    public DateTime AccessTokenExpiresAt_QBO2 { get; set; }
    public string RefreshToken_QBO2 { get; set; }
    public DateTime RefreshTokenExpiresAt_QBO2 { get; set; }
    public string RealmId_QBO2 { get; set; }
    public string Code_QBO2 { get; set; }
}