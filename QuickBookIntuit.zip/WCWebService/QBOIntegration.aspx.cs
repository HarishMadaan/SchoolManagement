﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Threading.Tasks;
using System.Configuration;
using Intuit.Ipp.OAuth2PlatformClient;

public partial class QBOIntegration : System.Web.UI.Page
{
    public string ConnectionString { get { return ConfigurationManager.AppSettings["CommonConnectionString"].ToString(); } }
    public String HCMConnectionString { get { return ConfigurationManager.ConnectionStrings["CTZConnection"].ToString(); } }

    public static string clientid = ConfigurationManager.AppSettings["clientid"];
    public static string clientsecret = ConfigurationManager.AppSettings["clientsecret"];
    public static string redirectUrl = ConfigurationManager.AppSettings["redirectUrl"];
    public static string environment = ConfigurationManager.AppSettings["appEnvironment"];

    public static OAuth2Client auth2ClientNew = new OAuth2Client(clientid, clientsecret, redirectUrl, environment);

    protected void Page_Load(object sender, EventArgs e)
    {
        PaymentCallMethod();

        if (Request.QueryString.Count > 0)
        {

            List<string> queryKeys = new List<string>(Request.QueryString.AllKeys);

            if (queryKeys.Contains("code"))
            {
                ReadToken_QBO2().Wait();
            }

        }
    }


    public async Task ReadToken_QBO2()
    {
        try
        {
            //Sync the state info and update if it is not the same
            var state = Request.QueryString["state"];
            if (state.Equals(auth2ClientNew.CSRFToken, StringComparison.Ordinal))
            {
                ViewState["State"] = state + " (valid)";
            }
            else
            {
                ViewState["State"] = state + " (invalid)";
            }

            string code = Request.QueryString["code"] ?? "none";
            string realmId = Request.QueryString["realmId"] ?? "none";

            ViewState["Error"] = Request.QueryString["error"] ?? "none";

            await GetAuthTokensAsync(code, realmId);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Exchange Auth code with Auth Access and Refresh tokens and add them to Claim list
    /// </summary>
    private async Task GetAuthTokensAsync(string code, string realmId)
    {
        try
        {
            //if (realmId != null)
            //{
            //    Session["realmId"] = Convert.ToString(realmId);
            //}
            //if (code != null)
            //{
            //    Session["Code_QBO2"] = Convert.ToString(code);
            //}
            ////Refresh token endpoint
            var tokenResponse = await auth2ClientNew.GetBearerTokenAsync(code);

            //if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
            //{
            //    Session["access_token"] = Convert.ToString(tokenResponse.AccessToken);
            //    Session["access_token_expires_at"] = Convert.ToString(DateTime.UtcNow.AddSeconds(tokenResponse.AccessTokenExpiresIn));
            //}

            //if (!string.IsNullOrWhiteSpace(tokenResponse.RefreshToken))
            //{
            //    Session["refresh_token"] = Convert.ToString(tokenResponse.RefreshToken);
            //    Session["refresh_token_expires_at"] = Convert.ToString(DateTime.UtcNow.AddSeconds(tokenResponse.RefreshTokenExpiresIn));
            //    //claims.Add(new Claim("refresh_token", tokenResponse.RefreshToken));
            //    //claims.Add(new Claim("refresh_token_expires_at", (DateTime.Now.AddSeconds(tokenResponse.RefreshTokenExpiresIn)).ToString()));
            //}

            //if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
            //{

            //    //Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "RefreshParentPage();", true);

            //    //UpdateAccess_RefreshTokenValueToDB_QBO2(FromDatabase, DomainURL);
            //}
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    ///// <summary>
    ///// 
    ///// </summary>
    //private int getkeysbasedonoffice()
    //{
    //    int res = 0;
    //    //consumerkey = globalmultitenancy.multitenancy.configurationkey("consumerkey");
    //    //consumersecret = globalmultitenancy.multitenancy.configurationkey("consumersecret");
    //    //httpcontext.current.session["consumerkey"] = consumerkey;
    //    //httpcontext.current.session["consumersecret"] = consumersecret;

    //    //httpcontext.current.session["clientid_qbo2"] = globalmultitenancy.multitenancy.configurationkey("clientid_qbo2");
    //    //httpcontext.current.session["clientsecret_qbo2"] = globalmultitenancy.multitenancy.configurationkey("clientsecret_qbo2");

    //    //res = 1;
    //    return res;

    //}

    /// <summary>
    /// function used to update access and refresh token values
    /// </summary>
    protected void UpdateAccess_RefreshTokenValueToDB_QBO2(String FromDatabase, String DomainURL, String DBName, Int32 AgencyId)
    {
        var state = Request.QueryString["state"];
        Guid FranchiseID = new Guid(Convert.ToString(state));
        IntuitQBOKeyModel QbInst = new IntuitQBOKeyModel();

        QbInst.AccessToken_QBO2 = Convert.ToString(Session["access_token"]);
        QbInst.AccessTokenExpiresAt_QBO2 = Convert.ToDateTime(Session["access_token_expires_at"]);
        QbInst.RefreshToken_QBO2 = Convert.ToString(Session["refresh_token"]);
        QbInst.RefreshTokenExpiresAt_QBO2 = Convert.ToDateTime(Session["refresh_token_expires_at"]);
        QbInst.RealmId_QBO2 = Convert.ToString(Session["realmId"]);
        QbInst.Code_QBO2 = Convert.ToString(Session["Code_QBO2"]);

        //int res = QbInst.UpdateAccessRelatedInfoByOffice_QBO2(FranchiseID, accessToken_QBO2, access_token_expires_at_QBO2, refresh_token_QBO2, refresh_token_expires_at_QBO2, Companyrealm_QBO2, Code_QBO2);

        //if (res == 1)
        //{
        //    Session.Remove("access_token");
        //    Session.Remove("refresh_token");
        //    Session.Remove("realmId");
        //    Session.Remove("Code_QBO2");
        //}

    }

    public void PaymentCallMethod()
    {
        try
        {

            DataTable dt = IntuitQBOKeyBAL.GetDbConnections(Convert.ToInt16(readConfig("ServerId")), HCMConnectionString);
            foreach (DataRow item in dt.Rows)
            {
                if (Convert.ToString(item["DBName"]) == "CS360_Localbranchmerge")
                {
                    String FromDatabase = ConnectionString.Replace("$Databasename$", Convert.ToString(item["DBName"]))
                        .Replace("$DataSource$", SecurityClass.Decrypt(Convert.ToString(item["DataSource"]))).Replace("$UserName$", SecurityClass.Decrypt(Convert.ToString(item["Username"]))).Replace("$Password$", SecurityClass.Decrypt(Convert.ToString(item["Password"])));
                    String DomainURL = Convert.ToString(item["DomainURL"]);
                    String DBName = Convert.ToString(item["DBName"]);
                    Int32 AgencyId = Convert.ToInt32(item["AgencyId"]);

                    UpdateAccess_RefreshTokenValueToDB_QBO2(FromDatabase, DomainURL, DBName, AgencyId);
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    public string readConfig(string strKey)
    {
        var key = Convert.ToString(ConfigurationManager.AppSettings[strKey]);
        if (String.IsNullOrEmpty(key))
            key = "false";
        return key;
    }

}