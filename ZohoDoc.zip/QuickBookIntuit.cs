﻿#region Using Statements
using CareSmartzModel;
using Dapper;
using Intuit.Ipp.Core;
using Intuit.Ipp.Data;
using Intuit.Ipp.DataService;
using Intuit.Ipp.QueryFilter;
using Intuit.Ipp.Security;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Objects;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using Intuit.Ipp.OAuth2PlatformClient;
using PayrollAndInvoiceSerive;
using System.Collections.ObjectModel;
#endregion

namespace IntuitQuickBooks
{
    /// <summary>
    /// Summary description for QuickBookIntuit
    /// </summary>
    public class QuickBookIntuit : System.IDisposable
    {

        public OAuth2Client auth2Client = null;
        public string ClientId_QBO2 = string.Empty;
        public string ClientSecret_QBO2 = string.Empty;
        public string RedirectUrl_QBO2 = string.Empty;
        public string Environment_QBO2 = string.Empty;

        public QuickBookIntuit()
        {
            //
            // TODO: Add constructor logic here
            //
            
        }

        #region QuickBooks Integration
        /// <summary>
        /// From Admin side page currently not in use
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <param name="strConsumerKey"></param>
        /// <param name="strConsumerSecret"></param>
        /// <param name="strCompany"></param>
        /// <param name="strAppToken"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public int InsertUpdateQBRequiredFields(Guid OfficeID, string strConsumerKey, string strConsumerSecret,
            string strCompany, string strAppToken, Guid UserID, Int16 Mode)
        {
            int res = 0;
            try
            {
                using (CareSmartzEntities QB = new CareSmartzEntities())
                {
                    QB.PrQuickBooks_InsertUpdate(OfficeID, strConsumerKey, strConsumerSecret, strCompany, strAppToken, Mode, UserID);
                    res = 1;
                }
            }
            catch (Exception)
            {

            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <returns></returns>
        public List<PrQuickBooks_FetchDataByFranchiseID_Result> GetQBDataByFranchise(Guid FranchiseID, Guid OfficeID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.PrQuickBooks_FetchDataByFranchiseID(FranchiseID, OfficeID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrQuickBooks_FetchDataByFranchiseID_Result>();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <returns></returns>
        public Int16 UpdateAccessRelatedInfoByOffice(Guid? FranchiseID, string AccessToken, string TokenSecret,
            string oauthToken, string oauthVerifyer, string strCompanyrealm)
        {
            Int16 res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    TbIntuitQBKey TbQb = (from p in QBDb.TbIntuitQBKeys
                                          where p.FranchiseID == FranchiseID
                                          && p.IsActive == true && p.IsArchived == false
                                          select p).FirstOrDefault();

                    if (TbQb != null)
                    {
                        TbQb.AccessToken = AccessToken;
                        TbQb.AccessTokenSecret = TokenSecret;
                        TbQb.OauthToken = oauthToken;
                        TbQb.OauthVerifyer = oauthVerifyer;
                        TbQb.IntuitcompanyID = strCompanyrealm;
                        TbQb.ModifiedOn = DateTime.UtcNow;
                        QBDb.SaveChanges();
                    }
                    else
                    {
                        TbIntuitQBKey TbQbActive = (from p in QBDb.TbIntuitQBKeys
                                                    where p.IsActive == true && p.IsArchived == false && p.FranchiseID == FranchiseID
                                                    select p).FirstOrDefault();

                        if (TbQbActive != null)
                        {
                            TbQbActive.AccessToken = AccessToken;
                            TbQbActive.AccessTokenSecret = TokenSecret;
                            TbQbActive.OauthToken = oauthToken;
                            TbQbActive.OauthVerifyer = oauthVerifyer;
                            TbQbActive.IntuitcompanyID = strCompanyrealm;
                            TbQbActive.FranchiseID = FranchiseID;
                            TbQbActive.ModifiedOn = DateTime.UtcNow;
                            QBDb.SaveChanges();
                        }
                    }
                    res = 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return res;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <returns></returns>
        public Int16 UpdateAccessRelatedInfoByOffice_QBO2(Guid? FranchiseID, string AccessToken, DateTime AccessTokenExpiresAt,
            string RefreshToken, DateTime RefreshTokenExpiresAt, string Companyrealm, string Code_QBO2)
        {
            Int16 res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    TbIntuitQBKey TbQb = (from p in QBDb.TbIntuitQBKeys
                                          where p.FranchiseID == FranchiseID
                                          && p.IsActive == true && p.IsArchived == false
                                          select p).FirstOrDefault();

                    if (TbQb != null)
                    {
                        TbQb.AccessToken_QBO2 = AccessToken;
                        TbQb.AccessTokenExpiresAt_QBO2 = AccessTokenExpiresAt;
                        TbQb.RefreshToken_QBO2 = RefreshToken;
                        TbQb.RefreshTokenExpiresAt_QBO2 = RefreshTokenExpiresAt;
                        TbQb.RealmId_QBO2 = Companyrealm;
                        TbQb.Code_QBO2 = Code_QBO2;
                        TbQb.ModifiedOn = DateTime.UtcNow;
                        QBDb.SaveChanges();
                    }
                    else
                    {
                        TbIntuitQBKey TbQbActive = (from p in QBDb.TbIntuitQBKeys
                                                    where p.IsActive == true && p.IsArchived == false && p.FranchiseID == FranchiseID
                                                    select p).FirstOrDefault();

                        if (TbQbActive != null)
                        {
                            TbQbActive.AccessToken_QBO2 = AccessToken;
                            TbQbActive.AccessTokenExpiresAt_QBO2 = AccessTokenExpiresAt;
                            TbQbActive.RefreshToken_QBO2 = RefreshToken;
                            TbQbActive.RefreshTokenExpiresAt_QBO2 = RefreshTokenExpiresAt;
                            TbQbActive.RealmId_QBO2 = Companyrealm;
                            TbQbActive.Code_QBO2 = Code_QBO2;
                            TbQbActive.FranchiseID = FranchiseID;
                            TbQbActive.ModifiedOn = DateTime.UtcNow;
                            QBDb.SaveChanges();
                        }
                    }
                    res = 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <returns></returns>
        public List<PrQuickBooks_FetchOffice4AdminCallTypesByUserID_Result> GetCallTypes4QBByOfficeID(Guid UserID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.PrQuickBooks_FetchOffice4AdminCallTypesByUserID(UserID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrQuickBooks_FetchOffice4AdminCallTypesByUserID_Result>();
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <returns></returns>
        public List<PrQuickBooks_CheckQuickBooksKeyByOfficeID_Result> CheckQBKeyByOffice(Guid OfficeID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.PrQuickBooks_CheckQuickBooksKeyByOfficeID(OfficeID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrQuickBooks_CheckQuickBooksKeyByOfficeID_Result>();
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="strClDis"></param>
        /// <returns></returns>
        public string CreateCustomer(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret, string strClDis, Int32 iNameSetting, Guid FranchiseID)
        {
            int res = 0;
            Customer customer = new Customer();
            PhysicalAddress custAddres = new PhysicalAddress();
            TelephoneNumber custTel = new TelephoneNumber();
            EmailAddress CustEmail = new EmailAddress();

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                string[] words = strClDis.Split(',');
                foreach (string word in words)
                {
                    using (CareSmartzEntities QBDb = new CareSmartzEntities())
                    {
                        var clDet = QBDb.PrQuickBooks_FetchClientDetailByDisplayID(word).FirstOrDefault();

                        if (clDet != null)
                        {
                            // Check if the customer already exists in QuickBooks
                            QueryService<Customer> customerQueryService = new QueryService<Customer>(context);
                            int customerCount = customerQueryService.ExecuteIdsQuery("Select GivenName From Customer WHERE GivenName = '" + clDet.FirstName + "' and FamilyName = '" + clDet.LastName + "'").Count();

                            if (customerCount == 0)
                            {
                                customer.GivenName = clDet.FirstName;
                                customer.FamilyName = clDet.LastName;
                                //customer.CompanyName = strrealmId;
                                if (iNameSetting == 1)
                                    customer.DisplayName = clDet.FirstName + ", " + clDet.LastName;
                                else if (iNameSetting == 2)
                                    customer.DisplayName = clDet.LastName + ", " + clDet.FirstName;

                                //customer.FullyQualifiedName = customer.DisplayName + "( " + strrealmId + " )";

                                custAddres.Line1 = clDet.Address1;
                                custAddres.City = clDet.CityName;
                                custAddres.CountrySubDivisionCode = clDet.StateName;
                                custAddres.PostalCode = clDet.ZipCode;

                                //custTel.FreeFormNumber = clDet.Phone;
                                customer.BillAddr = custAddres;

                                //customer.PrimaryPhone = custTel;

                                if (!string.IsNullOrEmpty(clDet.Email1))
                                {
                                    CustEmail.Address = clDet.Email1;
                                    if (IsValidEmailAddress(clDet.Email1))
                                        customer.PrimaryEmailAddr = CustEmail;
                                }

                                customer.Taxable = false;
                                customer.TaxableSpecified = false;

                                var getResponse = service.Add(customer);

                                if (getResponse != null)
                                {
                                    Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                                    string strGetData = Convert.ToString(getResponse.Id);
                                    QBDb.PrQuickBooks_UpdateQBCustIDByClientDisID(strGetData, word, UserId, FranchiseID);

                                    res = 1;
                                }
                            }
                        }
                    }
                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
                custAddres = null;
                //custTel = null;
                CustEmail = null;
                customer = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strClDis"></param>
        /// <returns></returns>
        public int ClientSyncUpdateLocal(Dictionary<string, string> openWith, Guid FranchiseID)
        {
            int res = 0;
            try
            {
                foreach (var kvp in openWith.ToArray())
                {
                    using (CareSmartzEntities QBDb = new CareSmartzEntities())
                    {
                        Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                        QBDb.PrQuickBooks_UpdateQBCustIDByClientDisID(kvp.Value, kvp.Key, UserId, FranchiseID);
                        res = 1;
                    }
                }

                return res;
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public int QBInsertInvoiceForDesktop(string InvoiceIds, string InvoiceListID)
        {
            int res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                    QBDb.usp_QBDesktopInvoiceQueueExportInsert(InvoiceIds, InvoiceListID, UserId, UserId);
                    res = 1;
                }
            }
            catch (Exception)
            {
                res = 0;
            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="strInvoiceID"></param>
        /// <returns></returns>
        /// 
        public string CreateCustomerInvoice(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret, string strInvoiceID, string TaxCodeName = null)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                int CountryId = Common.GetAgencyCountry();

                //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
                QueryService<TaxCode> stateTaxCodeQueryService = new QueryService<TaxCode>(context);
                TaxCode stateTaxCode = null;

                if (CountryId == 4)// USA
                {
                    stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From TaxCode Where Name='StateSalesTax' AND Active = true StartPosition 1 MaxResults 1").FirstOrDefault<TaxCode>();
                }
                else if (CountryId == 9) // Canada
                {
                    if (string.IsNullOrEmpty(TaxCodeName))
                        stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From TaxCode Where Name='HST ON' AND Active = true StartPosition 1 MaxResults 1").FirstOrDefault<TaxCode>();
                    else
                        stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From TaxCode Where Name='" + TaxCodeName + "' AND Active = true StartPosition 1 MaxResults 1").FirstOrDefault<TaxCode>();
                }

                string[] words = strInvoiceID.Split(',');
                foreach (string word in words)
                {
                    using (CareSmartzEntities QBDb = new CareSmartzEntities())
                    {
                        var clDet = QBDb.PrQuickBooks_FetchInvoiceDetailsByInvoiceID(new Guid(word)).ToList();
                        if (clDet.Count > 0)
                        {
                            Invoice invoice = new Invoice();

                            //DocNumber - QBO Only, otherwise use DocNumber
                            invoice.AutoDocNumber = true;
                            invoice.AutoDocNumberSpecified = true;
                            invoice.DocNumber = clDet[0].InvoiceNumber;

                            //TxnDate
                            invoice.TxnDate = Convert.ToDateTime(clDet[0].InvoiceDate); //DateTime.Now.Date;
                            invoice.TxnDateSpecified = true;

                            invoice.GlobalTaxCalculation = GlobalTaxCalculationEnum.NotApplicable;
                            //invoice.GlobalTaxCalculation = GlobalTaxCalculationEnum.TaxExcluded;
                            invoice.GlobalTaxCalculationSpecified = false;

                            Intuit.Ipp.Data.Line[] invoiceLineCollection = new Intuit.Ipp.Data.Line[clDet.Count];
                            for (int i = 0; i < clDet.Count; i++)
                            {
                                var line = clDet[i];
                                var qboInvoiceLine = new Intuit.Ipp.Data.Line()
                                {
                                    Amount = Convert.ToDecimal(line.LineTotal),
                                    AmountSpecified = true,
                                    Description = line.LineDescription,
                                    DetailType = LineDetailTypeEnum.SalesItemLineDetail,
                                    DetailTypeSpecified = true,

                                    AnyIntuitObject = new SalesItemLineDetail()
                                    {
                                        ItemRef = new ReferenceType()
                                        {
                                            Value = Convert.ToString(line.QbItemID)
                                        },

                                        ItemElementName = ItemChoiceType.UnitPrice,
                                        TaxCodeRef = new ReferenceType()
                                        {
                                            Value = stateTaxCode == null ? "NON" : stateTaxCode.Id
                                        },

                                        ClassRef = new ReferenceType()
                                        {
                                            Value = Convert.ToString(clDet[0].MTClsFlag) == "1" ? Convert.ToString(clDet[0].QBClassRef) : null
                                        },

                                        //Qty = Convert.ToDecimal(line.LineUnits),
                                        //QtySpecified = true,


                                        ServiceDate = line.ServiceStartDate.Value,
                                        ServiceDateSpecified = true,

                                        //AnyIntuitObject = Convert.ToDecimal(line.ChargeRate)


                                        AnyIntuitObject = Convert.ToDecimal(line.LineTotal)
                                    }
                                };

                                invoiceLineCollection[i] = qboInvoiceLine;
                            }

                            invoice.Line = invoiceLineCollection;


                            //Customer (Client)
                            invoice.CustomerRef = new ReferenceType()
                            {
                                Value = Convert.ToString(clDet[0].QbCustID)
                            };

                            // QB Support Email Address Lenght 100
                            if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].PayerEmailTo)))
                            {
                                if (Convert.ToString(clDet[0].PayerEmailTo).Length <= 100)
                                {
                                    invoice.BillEmail = new EmailAddress()
                                    {
                                        Address = Convert.ToString(clDet[0].PayerEmailTo),
                                    };
                                }
                                invoice.EmailStatus = EmailStatusEnum.NotSet;
                                invoice.BillEmail.DefaultSpecified = true;
                            }

                            //QB CC Email Address
                            if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].PayerCCEMail)))
                            {
                                //if (Convert.ToString(clDet[0].PayerCCEMail).Length <= 100)
                                //{
                                //    invoice.BillEmailCc = new EmailAddress()
                                //    {
                                //        Address = Convert.ToString(clDet[0].PayerCCEMail),
                                //    };
                                //}
                                //invoice.EmailStatus = EmailStatusEnum.NotSet;
                                //invoice.BillEmailCc.DefaultSpecified = true;
                            }


                            //DueDate
                            invoice.DueDate = Convert.ToDateTime(clDet[0].InvoiceDate).AddDays(Convert.ToInt32(clDet[0].DueDays)).Date; //DateTime.Now.AddDays(Convert.ToInt32(clDet[0].DueDays)).Date;
                            invoice.DueDateSpecified = true;


                            ////ARAccountRef
                            invoice.ARAccountRef = new ReferenceType()
                            {
                                Value = Convert.ToString(clDet[0].AccountReceivables)
                            };


                            Invoice invoiceAdded = service.Add(invoice);

                            if (invoiceAdded != null)
                            {
                                Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                                string strGetData = Convert.ToString(invoiceAdded.Id);
                                QBDb.PrQuickBooks_UpdateQuickBookDocInvoiceByInvoiceID(new Guid(word), Convert.ToInt64(strGetData), UserId);

                                res = 1;
                            }
                        }
                    }
                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }

                return returnMessage;
            }
            finally
            {
                //custAddres = null;
                //custTel = null;
                //CustEmail = null;
                //customer = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="strDepositRefundIDPRegNo"></param>
        /// <returns></returns>
        public string CreateCustomerDeposit(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret, string strInvoiceID)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
                QueryService<Deposit> stateTaxCodeQueryService = new QueryService<Deposit>(context);
                //TaxCode stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From TaxCode Where Name='StateSalesTax' StartPosition 1 MaxResults 1").FirstOrDefault<TaxCode>();
                Deposit stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From Deposit MaxResults 1").FirstOrDefault<Deposit>();

                string[] words = strInvoiceID.Split(',');
                foreach (string word in words)
                {
                    var clDet = GetClientPaymentRegisterDepositDetail(new Guid(word)).ToList();
                    if (clDet.Count > 0)
                    {
                        Deposit d = new Deposit();
                        //d.SyncToken = "30";
                        d.domain = "QBO";
                        //d.DepositToAccountRef = new ReferenceType { name = "Savings", Value = "36" };
                        if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].BankDepositId)))
                            d.DepositToAccountRef = new ReferenceType { Value = Convert.ToString(clDet[0].BankDepositId) };
                        else
                            d.DepositToAccountRef = new ReferenceType { Value = "36" };
                        d.TxnDate = Convert.ToDateTime(clDet[0].PaymentReceivedDate);
                        //d.TotalAmt = 55;
                        //d.TotalAmtSpecified = true;
                        d.sparse = false;
                        //d.Id = "162";
                        d.CurrencyRef = new ReferenceType { name = "United States Dollar", Value = "USD" };
                        d.PrivateNote = "Submit Deposit amount to QBO";

                        List<Line> listLine = new List<Line>();
                        Line line = new Line();

                        for (int i = 0; i < clDet.Count; i++)
                        {
                            var lineItemValue = clDet[i];

                            //line.Id = "1";
                            //line.LineNum = "1";
                            line.Amount = lineItemValue.IHCDeposit;
                            line.AmountSpecified = true;
                            line.Description = lineItemValue.DepostiPaymentMemo;

                            line.DetailType = LineDetailTypeEnum.DepositLineDetail;
                            line.DetailTypeSpecified = true;

                            DepositLineDetail lifd = new DepositLineDetail();

                            lifd.Entity = new ReferenceType { Value = lineItemValue.QbCustID };

                            //lifd.AccountRef = new ReferenceType { Value = "34", name = "Opening Balance Equity" };
                            if (!string.IsNullOrEmpty(Convert.ToString(lineItemValue.DepositId)))
                                lifd.AccountRef = new ReferenceType { Value = Convert.ToString(lineItemValue.DepositId) };
                            else
                                lifd.AccountRef = new ReferenceType { Value = "34", name = "Opening Balance Equity" };

                            lifd.PaymentMethodRef = new ReferenceType { Value = "1", name = "Cash" };
                            line.AnyIntuitObject = lifd;

                            //line.LinkedTxn = txnlist.ToArray();
                            listLine.Add(line);

                        }

                        //List<LinkedTxn> txnlist = new List<LinkedTxn>();
                        //LinkedTxn txn = new LinkedTxn();
                        //txn.TxnId = "154";
                        //txn.TxnLineId = "0";
                        //txn.TxnType = "payment";
                        //txnlist.Add(txn);

                        //List<Line> listLine = new List<Line>();
                        //Line line = new Line();
                        ////line.Id = "1";
                        ////line.LineNum = "1";
                        //line.Amount = clDet[0].IHCDeposit;
                        //line.AmountSpecified = true;
                        //line.Description = clDet[0].DepostiPaymentMemo;

                        //line.DetailType = LineDetailTypeEnum.DepositLineDetail;
                        //line.DetailTypeSpecified = true;

                        //DepositLineDetail lifd = new DepositLineDetail();

                        //lifd.Entity = new ReferenceType { Value = clDet[0].QbCustID };

                        //lifd.AccountRef = new ReferenceType { Value = "34", name = "Opening Balance Equity" };
                        ////lifd.AccountRef = new ReferenceType { Value = "4", name = "Undeposited Funds" };
                        //lifd.PaymentMethodRef = new ReferenceType { Value = "1", name = "Cash" };
                        //line.AnyIntuitObject = lifd;

                        ////line.LinkedTxn = txnlist.ToArray();
                        //listLine.Add(line);

                        d.Line = listLine.ToArray();

                        d.DocNumber = Convert.ToString(clDet[0].DepostiPaymentMemo);

                        Deposit DepositAdded = service.Add(d);

                        if (DepositAdded != null)
                        {
                            res = 1;

                            Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                            int _result = PrQuickBooks_UpdateClientRegisterDepositIdSentToQB(new Guid(word), UserId);
                            if (_result == 1)
                                res = 1;
                        }
                    }

                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }

                return returnMessage;
            }
            finally
            {
                //custAddres = null;
                //custTel = null;
                //CustEmail = null;
                //customer = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="strInvoiceID"></param>
        /// <returns></returns>
        public string CreateCustomerRefund(string straccessToken, string straccessTokenSecret, string strrealmId,
                string consumerKey, string consumerSecret, Dictionary<string, string> strInvoiceID)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
                //QueryService<RefundReceipt> stateTaxCodeQueryService = new QueryService<RefundReceipt>(context);
                //RefundReceipt stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("select * from RefundReceipt where Id='362' MaxResults 1").FirstOrDefault<RefundReceipt>();

                foreach (string RegisterId in strInvoiceID.Keys)
                {
                    QuickBookIntuit objQB = new QuickBookIntuit();

                    var clDet = objQB.GetClientPaymentRegisterDepositDetail(new Guid(RegisterId)).ToList();
                    if (clDet.Count > 0)
                    {
                        RefundReceipt d = new RefundReceipt();
                        d.domain = "QBO";

                        if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].BankDepositId)) && Convert.ToString(clDet[0].BankDepositId) != "0")
                            d.DepositToAccountRef = new ReferenceType { Value = Convert.ToString(clDet[0].BankDepositId) };
                        else
                            d.DepositToAccountRef = new ReferenceType { Value = "36" };
                        d.TxnDate = Convert.ToDateTime(clDet[0].PaymentReceivedDate);
                        d.TxnDateSpecified = true;

                        d.sparse = false;

                        d.CurrencyRef = new ReferenceType { name = "United States Dollar", Value = "USD" };
                        d.PrivateNote = "Refund Deposit amount to QBO";

                        List<Line> listLine = new List<Line>();
                        Line line = new Line();

                        for (int i = 0; i < clDet.Count; i++)
                        {
                            var lineItemValue = clDet[i];

                            line.Amount = lineItemValue.IHCDeposit;
                            line.AmountSpecified = true;
                            line.Description = lineItemValue.DepostiPaymentMemo;

                            line.DetailType = LineDetailTypeEnum.SalesItemLineDetail;
                            line.DetailTypeSpecified = true;

                            SalesItemLineDetail lifd = new SalesItemLineDetail();

                            lifd.ItemRef = new ReferenceType { Value = "7" };

                            if (!string.IsNullOrEmpty(Convert.ToString(lineItemValue.DepositId)) && Convert.ToString(clDet[0].DepositId) != "0")
                                lifd.ItemAccountRef = new ReferenceType { Value = Convert.ToString(lineItemValue.DepositId) };
                            else
                                lifd.ItemAccountRef = new ReferenceType { Value = "34", name = "Opening Balance Equity" };

                            line.AnyIntuitObject = lifd;

                            listLine.Add(line);

                        }

                        d.Line = listLine.ToArray();
                        d.CustomerRef = new ReferenceType { Value = clDet[0].QbCustID };
                        d.CustomerMemo = new MemoRef { Value = "Thank you for your business and have a great day!" };

                        if (!string.IsNullOrEmpty(clDet[0].EmailID))
                            d.BillEmail = new EmailAddress { Address = clDet[0].EmailID };

                        d.AutoDocNumber = true;

                        RefundReceipt RefundReceiptAdded = service.Add(d);

                        var json = new JavaScriptSerializer().Serialize(d);

                        if (RefundReceiptAdded != null)
                        {
                            res = 1;

                            Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                            int _result = PrQuickBooks_UpdateClientRegisterDepositIdSentToQB(new Guid(RegisterId), UserId);
                            if (_result == 1)
                                res = 1;
                        }
                    }

                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }

                return returnMessage;
            }
            finally
            {
                //custAddres = null;
                //custTel = null;
                //CustEmail = null;
                //customer = null;
            }
        }


        /// <summary>
        /// NOT IN USE
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <returns></returns>
        //public string CreateServiceExpenseType(string straccessToken, string straccessTokenSecret, string strrealmId,
        //    string consumerKey, string consumerSecret, string strCallType, Guid OfficeID, int Mode)
        //{
        //    int res = 0;
        //    Item itm = new Item();
        //    ReferenceType IncomeRef = new ReferenceType();
        //    IncomeRef.Value = "10";
        //    IncomeRef.name = "Cost";

        //    ReferenceType ExpRef = new ReferenceType();
        //    ExpRef.Value = "30";
        //    ExpRef.name = "Sales";

        //    try
        //    {
        //        System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
        //        var serviceType = IntuitServicesType.QBO;
        //        var accessToken = straccessToken;
        //        var accessTokenSecret = straccessTokenSecret;
        //        var realmId = strrealmId;

        //        var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
        //        var context = new ServiceContext(realmId, serviceType, validator);

        //        context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
        //        var service = new DataService(context);

        //        string[] words = strCallType.Split(',');
        //        foreach (string word in words)
        //        {
        //            using (CareSmartzEntities QBDb = new CareSmartzEntities())
        //            {
        //                var callDet = QBDb.PrQuickBooks_FetchServiceTypeDetails(new Guid(word)).FirstOrDefault();
        //                if (callDet != null)
        //                {
        //                    itm.Name = callDet.Value;
        //                    itm.Description = callDet.Description;
        //                    itm.IncomeAccountRef = IncomeRef;
        //                    itm.ExpenseAccountRef = ExpRef;
        //                    itm.TrackQtyOnHand = false;

        //                    var getResponse = service.Add(itm);
        //                    if (getResponse != null)
        //                    {
        //                        Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
        //                        string strGetData = Convert.ToString(getResponse.Id);
        //                        if (Mode == 1) /// Mode 1 for CallType and 2 for Expense
        //                            QBDb.PrQuickBooks_InsertTypeMappings(OfficeID, new Guid(word), Convert.ToInt64(strGetData), 1, UserId);
        //                        else
        //                            QBDb.PrQuickBooks_InsertTypeMappings(OfficeID, new Guid(word), Convert.ToInt64(strGetData), 2, UserId);

        //                        res = 1;
        //                    }
        //                } // End If
        //            } // End Using
        //        } /// End foreach
        //        return Convert.ToString(res);
        //    }
        //    catch (Intuit.Ipp.Exception.IdsException ex)
        //    {
        //        //TODO: handle dupe or other....
        //        var returnMessage = string.Empty;
        //        var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
        //        if (innerException != null)
        //        {
        //            returnMessage = innerException.Message;
        //        }

        //        return returnMessage;
        //    }
        //    finally
        //    {
        //        itm = null;
        //        IncomeRef = null;
        //        ExpRef = null;
        //    }
        //}


        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="strCustID"></param>
        /// <returns></returns>
        public string UpdateCustomerInfo(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret, string strCustID)
        {

            int res = 0;
            Customer customer = new Customer();
            PhysicalAddress custAddres = new PhysicalAddress();
            EmailAddress CustEmail = new EmailAddress();

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    var clDet = QBDb.PrQuickBooks_FetchClientDetailByDisplayID(strCustID).FirstOrDefault();
                    if (clDet != null)
                    {
                        QueryService<Customer> customerQueryService = new QueryService<Customer>(context);
                        customer = customerQueryService.ExecuteIdsQuery("Select * From Customer where id='" + Convert.ToString(clDet.QbCustID) + "'").FirstOrDefault<Customer>();

                        if (customer != null)
                        {
                            customer.Id = customer.Id;
                            customer.SyncToken = customer.SyncToken;
                            customer.GivenName = clDet.FirstName + "_" + Convert.ToString(clDet.ClientDisplayId); ;
                            customer.FamilyName = clDet.LastName;
                            customer.DisplayName = clDet.FirstName + ", " + clDet.LastName;

                            custAddres.Line1 = clDet.Address1;
                            custAddres.City = clDet.CityName;
                            custAddres.CountrySubDivisionCode = clDet.StateName;
                            custAddres.PostalCode = clDet.ZipCode;

                            CustEmail.Address = clDet.Email1;

                            customer.BillAddr = custAddres;

                            customer.PrimaryEmailAddr = CustEmail;

                            var getResponse = service.Update(customer);
                            res = 1;
                        }
                    }
                }

                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
                custAddres = null;
                //custTel = null;
                CustEmail = null;
                customer = null;
            }
        }


        /// <summary>
        /// NOT IN USE
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="strCallType"></param>
        /// <param name="OfficeID"></param>
        /// <param name="Mode"></param>
        /// <returns></returns>
        //public string UpdateServiceExpenseType(string straccessToken, string straccessTokenSecret, string strrealmId,
        //    string consumerKey, string consumerSecret, string strCallType, Guid OfficeID, string QBitmID, int Mode)
        //{
        //    int res = 0;
        //    Item itm = new Item();
        //    ReferenceType IncomeRef = new ReferenceType();
        //    IncomeRef.Value = "10";
        //    IncomeRef.name = "Cost";

        //    ReferenceType ExpRef = new ReferenceType();
        //    ExpRef.Value = "30";
        //    ExpRef.name = "Sales";

        //    try
        //    {
        //        System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
        //        var serviceType = IntuitServicesType.QBO;
        //        var accessToken = straccessToken;
        //        var accessTokenSecret = straccessTokenSecret;
        //        var realmId = strrealmId;

        //        var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
        //        var context = new ServiceContext(realmId, serviceType, validator);

        //        context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
        //        var service = new DataService(context);


        //        using (CareSmartzEntities QBDb = new CareSmartzEntities())
        //        {
        //            var callDet = QBDb.PrQuickBooks_FetchQBDataToUpdate(OfficeID, new Guid(strCallType), Convert.ToInt64(QBitmID)).FirstOrDefault();
        //            if (callDet != null)
        //            {
        //                //Find Item
        //                QueryService<Item> itemQueryService = new QueryService<Item>(context);
        //                Item item = itemQueryService.ExecuteIdsQuery("Select * From Item where id='" + Convert.ToString(callDet.IntuitQBItemID) + "'").FirstOrDefault<Item>();

        //                itm.Id = item.Id;
        //                itm.SyncToken = item.SyncToken;
        //                itm.Name = callDet.Value;
        //                itm.Description = callDet.Description;
        //                itm.IncomeAccountRef = IncomeRef;
        //                itm.ExpenseAccountRef = ExpRef;
        //                itm.TrackQtyOnHand = false;

        //                var getResponse = service.Add(itm);
        //                res = 1;
        //            } // End If
        //        } // End Using

        //        return Convert.ToString(res);
        //    }
        //    catch (Intuit.Ipp.Exception.IdsException ex)
        //    {
        //        //TODO: handle dupe or other....
        //        var returnMessage = string.Empty;
        //        var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
        //        if (innerException != null)
        //        {
        //            returnMessage = innerException.Message;
        //        }

        //        return returnMessage;
        //    }
        //    finally
        //    {
        //        itm = null;
        //        IncomeRef = null;
        //        ExpRef = null;
        //    }
        //}


        /// <summary>
        /// ID refers here franchiseID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public int CheckQBReqToLockConnectTab(Guid ID)
        {
            Int16 res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    TbIntuitQBKey TbQb = (from p in QBDb.TbIntuitQBKeys
                                          where p.FranchiseID == ID && p.IsActive == true && p.IsArchived == false
                                          select p).FirstOrDefault();

                    if (TbQb != null)
                        res = 1;
                    else
                        res = 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return res;
        }

        /// <summary>
        /// ID refers to Franchise/AgencyID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public List<PrQuickBooks_FetchClientsToSyncByID_Result> FetchClienttoSyncWithQB(Guid ID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.PrQuickBooks_FetchClientsToSyncByID(ID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrQuickBooks_FetchClientsToSyncByID_Result>();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        public List<Utilities.DropDown> GetQuickBooksCustomerList(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                QueryService<Customer> customerQueryService = new QueryService<Customer>(context);
                var customer = customerQueryService.ExecuteIdsQuery("Select * From Customer MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.FamilyName + ", " + p.GivenName });

                return customer.ToList();

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        public List<Utilities.DropDownOnly> GetQuickBookCustomerListDesktop()
        {
            List<Utilities.DropDownOnly> obj = new List<Utilities.DropDownOnly>();
            try
            {
                using (CareSmartzEntities QB = new CareSmartzEntities())
                {
                    obj = QB.USP_GetClientListForDesktopQB().Select(x => new Utilities.DropDownOnly() { NID = x.NId, Value = x.Value }).ToList();
                }
            }
            catch (Exception)
            {

            }
            return obj;
        }

        /// <summary>
        /// Fatch Account Information
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetQuickBooksAccountsList(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Account - Accounts Receivable account required
                QueryService<Account> accountQueryService = new QueryService<Account>(context);
                var account = accountQueryService.ExecuteIdsQuery("Select * From Account MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.Name });

                return account.ToList();

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }



        /// <summary>
        /// Fatch Account Information
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetQuickBankList(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret, string Query)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Account - Accounts Receivable account required
                QueryService<Account> accountQueryService = new QueryService<Account>(context);

                var account = new List<Utilities.DropDown>();
                // var account = accountQueryService.ExecuteIdsQuery("Select * From Account WHERE AccountType='Bank' MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.Name });
                if (!string.IsNullOrEmpty(Query))
                    account = accountQueryService.ExecuteIdsQuery(Query).Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.Name }).ToList();

                return account;

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }



        /// <summary>
        /// Fatch Account Information
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetQuickBooksItemsList(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Item - 
                QueryService<Item> itemQueryService = new QueryService<Item>(context);
                var item = itemQueryService.ExecuteIdsQuery("Select * From Item MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.Name });

                return item.ToList();

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FranchiseID"></param>
        /// <param name="iNameSetting"></param>
        /// <param name="iAccountReceivables"></param>
        /// <param name="ItemServices"></param>
        /// <param name="ItemExpenses"></param>
        /// <param name="iCCInvoice"></param>
        /// <param name="UserID"></param>
        /// <param name="Mode"></param>
        /// <param name="qBDskAccountReceivables"></param>
        /// <param name="qBDskItemServices"></param>
        /// <param name="qBDskItemExpenses"></param>
        /// <param name="qBDskCCInvoice"></param>
        /// <param name="QBDsktopAccountsPayable"></param>
        /// <param name="QBDskPayrollItemService"></param>
        /// <param name="iAccountPayableOnline"></param>
        /// <param name="iItmServicePayOnline"></param>
        /// <returns></returns>
        public int InsertUpdateQBAccountRequiredSettings(Guid FranchiseID, Int32 iNameSetting, Int32 iAccountReceivables,
            Int32 ItemServices, Int32 ItemExpenses, Int32 iCCInvoice, Guid UserID, int Mode,
            string qBDskAccountReceivables, string qBDskItemServices, string qBDskItemExpenses,
            string qBDskCCInvoice, string QBDsktopAccountsPayable, string QBDskPayrollItemService,
            Int32 iAccountPayableOnline, Int32 iItmServicePayOnline, Int32 depositId, Int32 BankdepositId, String QBDesktopdepositId = "", String QBDesktopBankdepositId = "")
        {
            int res = 0;
            try
            {
                using (IDbConnection con = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    con.Open();
                    con.Execute("PrQuickBooks_InsertUpdateAccountsSetings", new
                    {
                        @FranchiseID = FranchiseID,
                        @NameSetting = iNameSetting,
                        @AccountReceivables = iAccountReceivables,
                        @ItemServices = ItemServices,
                        @ItemExpenses = ItemExpenses,
                        @CCInvoice = iCCInvoice,
                        @UserID = UserID,
                        @Mode = Mode,
                        @QBDskAccountReceivables = qBDskAccountReceivables,
                        @QBDskItemServices = qBDskItemServices,
                        @QBDskItemExpenses = qBDskItemExpenses,
                        @QBDskCCInvoice = qBDskCCInvoice,
                        @QBDskTopAccountsPayable = QBDsktopAccountsPayable,
                        @QBDskPayrollItemService = QBDskPayrollItemService,
                        @AccountPayableOnline = iAccountPayableOnline,
                        @ItmServicePayOnline = iItmServicePayOnline,
                        @DepositId = depositId,
                        @BankDepositId = BankdepositId,
                        @QBDesktop_DepositId = QBDesktopdepositId,
                        @QBDesktop_BankDepositId = QBDesktopBankdepositId

                    }, commandType: CommandType.StoredProcedure);
                    res = 1;
                }


                //using (CareSmartzEntities QB = new CareSmartzEntities())
                //{
                //    QB.PrQuickBooks_InsertUpdateAccountsSetings(, , ,
                //        , , , , ,
                //        , , ,
                //        , , , , , depositId, BankdepositId);
                //    res = 1;
                //}
            }
            catch (Exception)
            {

            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DisplayIDs"></param>
        /// <param name="Createdby"></param>
        /// <param name="Modifiedby"></param>
        /// <returns></returns>
        public int USP_Insert_QB_Desktop_Mapping(string DisplayIDs, Guid Createdby, Guid Modifiedby)
        {
            int res = 0;
            try
            {

                var list = DisplayIDs.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                         .Select((ClientDisplayIDs) => new { ClientDisplayIDs, Createdby, Modifiedby }).ToList();
                // OPTIMIZTED THE CODE AS IT WAS ITERATE THE FOR LOOP FOR TOTAL DICTIONARY ITEMS
                using (IDbConnection con = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    con.Open();
                    con.Execute("USP_Insert_QB_Desktop_Mapping", list, commandType: CommandType.StoredProcedure);
                    res = 1;
                }
                //using (CareSmartzEntities QB = new CareSmartzEntities())
                //{
                //    QB.USP_Insert_QB_Desktop_Mapping(DisplayIDs, Createdby, Modifiedby);
                //    res = 1;
                //}
            }
            catch (Exception)
            {

            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public List<PrQuickBooks_FetchAccountSettingsByID_Result> FetchAccountSettingsByID(Guid ID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.PrQuickBooks_FetchAccountSettingsByID(ID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrQuickBooks_FetchAccountSettingsByID_Result>();
            }
        }

        /// <summary>
        /// Purpose: this method will remove QB settings key for new installation as per user request
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public int ResetQuickBooksKeyToNewInstallationByID(Guid ID)
        {
            int res = 0;
            try
            {
                Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    QBDb.PrQuickBooks_RemoveKeystoResetByID(ID, UserId);
                }
                res = 1;
            }
            catch (Exception)
            {
                res = 0;
            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public int CheckQBReqTokens4Connect(Guid ID)
        {
            Int16 res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    TbIntuitQBKey TbQb = (from p in QBDb.TbIntuitQBKeys
                                          where p.FranchiseID == ID && p.IsActive == true && p.IsArchived == false
                                          select p).FirstOrDefault();


                    if (TbQb != null)
                    {
                        if (TbQb.QuickBooksMode == 2)
                        {
                            TbIntuitQBKey TbQbDT = (from p in QBDb.TbIntuitQBKeys
                                                    where p.FranchiseID == ID && p.IsActive == true && p.IsArchived == false
                                                    && p.AccessToken == null && p.AccessTokenSecret == null
                                                          && p.OauthToken == null && p.OauthVerifyer == null && p.IntuitcompanyID == null
                                                    select p).FirstOrDefault();
                            if (TbQbDT != null)
                            {
                                if (TbQbDT.IsQWCFileDownloaded == 0)
                                {
                                    res = 4; // when file not downloaded
                                }
                                else
                                {
                                    res = Convert.ToInt16(TbQbDT.QuickBooksMode);
                                }
                            }
                            else
                                res = 0;
                        }
                        else if (TbQb.QuickBooksMode == 1)
                        {
                            // code for connect QB oauth 2
                            TbIntuitQBKey TbQbOnLine = (from p in QBDb.TbIntuitQBKeys
                                                        where p.FranchiseID == ID && p.AccessToken_QBO2 != null && p.RealmId_QBO2 != null
                                                        && p.IsActive == true && p.IsArchived == false
                                                        select p).FirstOrDefault();

                            // code for connect QB oauth 1
                            //TbIntuitQBKey TbQbOnLine = (from p in QBDb.TbIntuitQBKeys
                            //                            where p.FranchiseID == ID && p.AccessToken != null && p.AccessTokenSecret != null
                            //                            && p.OauthToken != null && p.OauthVerifyer != null && p.IntuitcompanyID != null
                            //                            && p.IsActive == true && p.IsArchived == false
                            //                            select p).FirstOrDefault();


                            if (TbQbOnLine != null)
                            {
                                res = 3; // When there is connection done
                            }

                            else
                                res = 1;
                        }
                    }
                    else
                    {
                        res = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public int CheckQBAccountSettingsDone(Guid ID)
        {
            Int16 res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    var ChkAccount = QBDb.PrQuickBooks_CheckQBAccountSettings(ID).FirstOrDefault();

                    if (ChkAccount.Value == 1)
                        res = 1;
                    else
                        res = 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="gFranchiseID"></param>
        /// <param name="iMode"></param>
        /// <param name="strConsumerkey"></param>
        /// <param name="strConsumerSecret"></param>
        /// <param name="strAppToken"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public int InsertUpdateQuickBooksSettings(Guid gFranchiseID, int iMode, string strConsumerkey, string strConsumerSecret,
            string strAppToken, Guid UserID, int AgencyID, string ClientId_QBO2, string ClientSecret_QBO2, string RedirectUrl_QBO2, string Environment_QBO2)
        {
            int res = 0;
            try
            {
                using (CareSmartzEntities QB = new CareSmartzEntities())
                {
                    QB.spCaresmartz_InsertQuickModeSettingsByID(gFranchiseID, iMode, strConsumerkey, strConsumerSecret, strAppToken, UserID, AgencyID, ClientId_QBO2, ClientSecret_QBO2, RedirectUrl_QBO2, Environment_QBO2);
                    res = 1;
                }
            }
            catch (Exception)
            {
                res = 0;
            }
            return res;
        }

        /// <summary>
        /// Method used to get AgencyName and ID to display in Desktop 
        /// </summary>
        /// <param name="FranchiseID"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<spCaresmartz_FetchQBDesktopQWCFileDetails_Result> GetQBDesktopQWCFileDetails(Guid FranchiseID, Guid UserID, int AgencyID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.spCaresmartz_FetchQBDesktopQWCFileDetails(FranchiseID, UserID, AgencyID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<spCaresmartz_FetchQBDesktopQWCFileDetails_Result>();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FranchiseID"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public int QBDownloadFlagUpdateByID(Guid FranchiseID, Guid UserID)
        {
            int res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    QBDb.spCaresmartz_UpdateQBdownloadflagByID(FranchiseID, UserID);
                    res = 1;
                }
                return res;
            }
            catch (Exception)
            {
                return res;
            }
        }

        /// <summary>
        /// Account Master List from Local 
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<spCareSmartzQBDesktop_FetchAccountsListMaster_Result> GetQuickBooksDesktopAccountsList(Guid UserID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.spCareSmartzQBDesktop_FetchAccountsListMaster(UserID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<spCareSmartzQBDesktop_FetchAccountsListMaster_Result>();
            }
        }

        /// <summary>
        /// QuickBooksDesktop Item list
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<spCareSmartzQBDesktop_FetchItemListMaster_Result> GetQuickBooksDesktopItemList(Guid UserID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.spCareSmartzQBDesktop_FetchItemListMaster(UserID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<spCareSmartzQBDesktop_FetchItemListMaster_Result>();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emailaddress"></param>
        /// <returns></returns>
        public bool IsValidEmailAddress(string emailaddress)
        {
            try
            {
                System.Net.Mail.MailAddress m = new System.Net.Mail.MailAddress(emailaddress);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        //public bool IsPhoneNumber(string number)
        //{
        //    return Regex.Match(number, @"^(\+[0-9]{9})$").Success;
        //}

        #endregion

        #region CMS 1500

        /// <summary>
        /// Purpose: Get Records for ICD10 CMS 1500
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<PrCMS1500_FetchICD10Codes_Result> GetICD10Details(Guid UserID)
        {
            try
            {
                using (CareSmartzEntities CMSICD10 = new CareSmartzEntities())
                {
                    return CMSICD10.PrCMS1500_FetchICD10Codes(UserID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrCMS1500_FetchICD10Codes_Result>();
            }
        }

        /// <summary>
        /// Purpose: To List Agency Name for Agency  
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<PrProducts_GetFranchiseNameByUserID_Result> GetFranchiseName4ProductPage(Guid UserID)
        {
            try
            {
                using (CareSmartzEntities PrdPage = new CareSmartzEntities())
                {
                    return PrdPage.PrProducts_GetFranchiseNameByUserID(UserID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrProducts_GetFranchiseNameByUserID_Result>();
            }
        }

        #endregion

        #region Commented Section




        //static void CreateQBOInvoice(DataService dataService, ServiceContext context)
        //{

        //    //Find Customer
        //    QueryService<Customer> customerQueryService = new QueryService<Customer>(context);
        //    Customer customer = customerQueryService.ExecuteIdsQuery("Select * From Customer StartPosition 1 MaxResults 1").FirstOrDefault<Customer>();

        //    //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
        //    QueryService<TaxCode> stateTaxCodeQueryService = new QueryService<TaxCode>(context);
        //    TaxCode stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From TaxCode Where Name='StateSalesTax' StartPosition 1 MaxResults 1").FirstOrDefault<TaxCode>();

        //    //Find Account - Accounts Receivable account required
        //    QueryService<Account> accountQueryService = new QueryService<Account>(context);
        //    Account account = accountQueryService.ExecuteIdsQuery("Select * From Account Where AccountType='Accounts Receivable' StartPosition 1 MaxResults 1").FirstOrDefault<Account>();

        //    //Find Item
        //    QueryService<Item> itemQueryService = new QueryService<Item>(context);
        //    Item item = itemQueryService.ExecuteIdsQuery("Select * From Item StartPosition 1 MaxResults 1").FirstOrDefault<Item>();

        //    //Find Term
        //    QueryService<Term> termQueryService = new QueryService<Term>(context);
        //    Term term = termQueryService.ExecuteIdsQuery("Select * From Term StartPosition 1 MaxResults 1").FirstOrDefault<Term>();

        //    Invoice invoice = new Invoice();

        //    //DocNumber - QBO Only, otherwise use DocNumber
        //    invoice.AutoDocNumber = true;
        //    invoice.AutoDocNumberSpecified = true;

        //    //TxnDate
        //    invoice.TxnDate = DateTime.Now.Date;
        //    invoice.TxnDateSpecified = true;

        //    //PrivateNote
        //    invoice.PrivateNote = "This is a private note";

        //    //Line
        //    Line invoiceLine = new Line();
        //    //Line Description
        //    invoiceLine.Description = "Invoice line description.";
        //    //Line Amount
        //    invoiceLine.Amount = 330m;
        //    invoiceLine.AmountSpecified = true;
        //    //Line Detail Type
        //    invoiceLine.DetailType = LineDetailTypeEnum.SalesItemLineDetail;
        //    invoiceLine.DetailTypeSpecified = true;
        //    //Line Sales Item Line Detail
        //    SalesItemLineDetail lineSalesItemLineDetail = new SalesItemLineDetail();
        //    //Line Sales Item Line Detail - ItemRef
        //    lineSalesItemLineDetail.ItemRef = new ReferenceType()
        //    {
        //        name = item.Name,
        //        Value = item.Id
        //    };
        //    //Line Sales Item Line Detail - UnitPrice
        //    lineSalesItemLineDetail.AnyIntuitObject = 33m;
        //    lineSalesItemLineDetail.ItemElementName = ItemChoiceType.UnitPrice;
        //    //Line Sales Item Line Detail - Qty
        //    lineSalesItemLineDetail.Qty = 10;
        //    lineSalesItemLineDetail.QtySpecified = true;
        //    //Line Sales Item Line Detail - TaxCodeRef
        //    //For US companies, this can be 'TAX' or 'NON'
        //    lineSalesItemLineDetail.TaxCodeRef = new ReferenceType()
        //    {
        //        Value = "TAX"
        //    };
        //    //Line Sales Item Line Detail - ServiceDate 
        //    lineSalesItemLineDetail.ServiceDate = DateTime.Now.Date;
        //    lineSalesItemLineDetail.ServiceDateSpecified = true;
        //    //Assign Sales Item Line Detail to Line Item
        //    invoiceLine.AnyIntuitObject = lineSalesItemLineDetail;
        //    //Assign Line Item to Invoice
        //    invoice.Line = new Line[] { invoiceLine };

        //    //TxnTaxDetail
        //    TxnTaxDetail txnTaxDetail = new TxnTaxDetail();
        //    txnTaxDetail.TxnTaxCodeRef = new ReferenceType()
        //    {
        //        name = stateTaxCode.Name,
        //        Value = stateTaxCode.Id
        //    };
        //    Line taxLine = new Line();
        //    taxLine.DetailType = LineDetailTypeEnum.TaxLineDetail;
        //    TaxLineDetail taxLineDetail = new TaxLineDetail();
        //    //Assigning the fist Tax Rate in this Tax Code
        //    taxLineDetail.TaxRateRef = stateTaxCode.SalesTaxRateList.TaxRateDetail[0].TaxRateRef;
        //    taxLine.AnyIntuitObject = taxLineDetail;
        //    txnTaxDetail.TaxLine = new Line[] { taxLine };
        //    invoice.TxnTaxDetail = txnTaxDetail;

        //    //Customer (Client)
        //    invoice.CustomerRef = new ReferenceType()
        //    {
        //        name = customer.DisplayName,
        //        Value = customer.Id
        //    };

        //    //Billing Address
        //    PhysicalAddress billAddr = new PhysicalAddress();
        //    billAddr.Line1 = "123 Main St.";
        //    billAddr.Line2 = "Unit 506";
        //    billAddr.City = "Brockton";
        //    billAddr.CountrySubDivisionCode = "MA";
        //    billAddr.Country = "United States";
        //    billAddr.PostalCode = "02301";
        //    billAddr.Note = "Billing Address Note";
        //    invoice.BillAddr = billAddr;

        //    //Shipping Address
        //    PhysicalAddress shipAddr = new PhysicalAddress();
        //    shipAddr.Line1 = "100 Fifth Ave.";
        //    shipAddr.City = "Waltham";
        //    shipAddr.CountrySubDivisionCode = "MA";
        //    shipAddr.Country = "United States";
        //    shipAddr.PostalCode = "02452";
        //    shipAddr.Note = "Shipping Address Note";
        //    invoice.ShipAddr = shipAddr;

        //    //SalesTermRef
        //    invoice.SalesTermRef = new ReferenceType()
        //    {
        //        name = term.Name,
        //        Value = term.Id
        //    };

        //    //DueDate
        //    invoice.DueDate = DateTime.Now.AddDays(30).Date;
        //    invoice.DueDateSpecified = true;

        //    //ARAccountRef
        //    invoice.ARAccountRef = new ReferenceType()
        //    {
        //        name = account.Name,
        //        Value = account.Id
        //    };

        //    Invoice invoiceAdded = dataService.Add<Invoice>(invoice);


        //}


        //public void AddInvoice()
        //{
        //    OAuthRequestValidator reqValidator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerKeySecret);
        //    ServiceContext context = new ServiceContext(realmId, IntuitServicesType.QBO, reqValidator);

        //    Invoice added = Helper.Add(qboContextoAuth, CreateInvoice(qboContextoAuth));

        //}

        //internal Invoice CreateInvoice(ServiceContext context)
        //{
        //Customer customer = FindorAdd(context, new Customer());
        //TaxCode taxCode = FindorAdd(context, new TaxCode());
        //Account account = FindOrADDAccount(context, AccountTypeEnum.AccountsReceivable, AccountClassificationEnum.Liability);

        //Invoice invoice = new Invoice();
        //invoice.Deposit = new Decimal(0.00);
        //invoice.DepositSpecified = true;
        //invoice.AllowIPNPayment = false;
        //invoice.AllowIPNPaymentSpecified = true;

        //invoice.CustomerRef = new ReferenceType()
        //{
        //    name = customer.DisplayName,
        //    Value = customer.Id
        //};
        //invoice.DueDate = DateTime.UtcNow.Date;
        //invoice.DueDateSpecified = true;
        //invoice.GlobalTaxCalculation = GlobalTaxCalculationEnum.TaxExcluded;
        //invoice.GlobalTaxCalculationSpecified = true;
        //invoice.TotalAmt = new Decimal(0.00);
        //invoice.TotalAmtSpecified = true;
        //invoice.ApplyTaxAfterDiscount = false;
        //invoice.ApplyTaxAfterDiscountSpecified = true;

        //invoice.PrintStatus = PrintStatusEnum.NotSet;
        //invoice.PrintStatusSpecified = true;
        //invoice.EmailStatus = EmailStatusEnum.NotSet;
        //invoice.EmailStatusSpecified = true;
        //invoice.ARAccountRef = new ReferenceType()
        //{
        //    type = Enum.GetName(typeof(objectNameEnumType), objectNameEnumType.Account),
        //    name = "Account Receivable",
        //    Value = "QB:37"
        //};
        //invoice.Balance = new Decimal(0.00);
        //invoice.BalanceSpecified = true;

        //List lineList = new List();
        //Line line = new Line();
        //line.Description = "Description";
        //line.Amount = new Decimal(100.00);
        //line.AmountSpecified = true;

        //line.DetailType = LineDetailTypeEnum.DescriptionOnly;
        //line.DetailTypeSpecified = true;

        //lineList.Add(line);
        //invoice.Line = lineList.ToArray();
        //TxnTaxDetail txnTaxDetail = new TxnTaxDetail();
        //txnTaxDetail.DefaultTaxCodeRef = new ReferenceType()
        //{
        //    Value = taxCode.Id,
        //    type = Enum.GetName(typeof(objectNameEnumType), objectNameEnumType.Customer),
        //    name = taxCode.Name
        //};

        //txnTaxDetail.TotalTax = new Decimal(0.00);
        //txnTaxDetail.TotalTaxSpecified = true;


        //return invoice;
        //}
        #endregion

        #region CareSmartz SMSSection
        /// <summary>
        /// 
        /// </summary>
        /// <param name="EntityIDs"></param>
        /// <param name="EntityType"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<PrSMS_FetchEntityNameByID_Result> GetListOfEntityWithoutNum(string EntityIDs, string EntityType, Guid UserID)
        {
            try
            {
                using (CareSmartzEntities SMSList = new CareSmartzEntities())
                {
                    return SMSList.PrSMS_FetchEntityNameByID(EntityIDs, EntityType, UserID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrSMS_FetchEntityNameByID_Result>();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<fetchSMSLog_Result> GetListOfSMSLog(int SMSType, DateTime DateFrom, DateTime DateTo,
            string EntityType, Guid? EntityId, string OfficeId, Guid UserId, int PageNo, int pageSize, string sortcolumn, string sortdirection)
        {
            try
            {
                using (CareSmartzEntities SMSList = new CareSmartzEntities())
                {
                    ObjectParameter objParamTPages = new ObjectParameter("TotalPages", typeof(int));
                    ObjectParameter objParamTCount = new ObjectParameter("TotalCount", typeof(int));

                    if (EntityId == new Guid(CaresmartzApplicationConfiguration.Common.EmptyGuid))
                        EntityId = null;

                    return SMSList.fetchSMSLog(SMSType, DateFrom, DateTo,
                        EntityType, EntityId, OfficeId, UserId, PageNo, pageSize, sortcolumn, sortdirection, objParamTPages, objParamTCount).ToList();
                }
            }
            catch (Exception)
            {
                return new List<fetchSMSLog_Result>();
            }
        }

        #endregion

        #region Unavailability Listing
        public List<FetchUnavailabilityListingByCaregiver_Result> GetUnAvailabilityListingByCaregiver(Guid CaregiverID, int pageNo, int pageSize, Guid userId)
        {
            try
            {
                using (CareSmartzEntities objDb = new CareSmartzEntities())
                {
                    return objDb.FetchUnavailabilityListingByCaregiver(CaregiverID, pageNo, pageSize, userId).ToList();
                }
            }
            catch (Exception)
            {
                return new List<FetchUnavailabilityListingByCaregiver_Result>();
                throw;
            }
        }

        public List<FetchAvailabilityListingByCaregiverAndScheduleType_Result> GetAvailabilityListingByCaregiverAndScheduleType(Guid CaregiverID, int pageNo, int pageSize, Guid userId, Int32 scheduleType)
        {
            try
            {
                using (CareSmartzEntities objDb = new CareSmartzEntities())
                {
                    return objDb.FetchAvailabilityListingByCaregiverAndScheduleType(CaregiverID, pageNo, pageSize, userId, scheduleType).ToList();
                }
            }
            catch (Exception)
            {
                return new List<FetchAvailabilityListingByCaregiverAndScheduleType_Result>();
                throw;
            }
        }

        #endregion

        #region QuickBooks Get Details
        /// <summary>
        /// To get Details for QuickBooks Settings
        /// </summary>
        /// <returns></returns>
        public List<PrQuickBooks_FetchSavedDetails_Result> GetQuickBooksSaveDetails()
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.PrQuickBooks_FetchSavedDetails().ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrQuickBooks_FetchSavedDetails_Result>();
            }
        }

        /// <summary>
        /// Check Agency Setting for QuickBooks Option selected
        /// </summary>
        /// <param name="AgencyID"></param>
        /// <returns></returns>
        public List<PrQuickBooks_FetchQuickBooksModeByAgencyID_Result> CheckQuickBooksTypeByAgencyID(int AgencyID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.PrQuickBooks_FetchQuickBooksModeByAgencyID(AgencyID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrQuickBooks_FetchQuickBooksModeByAgencyID_Result>();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public List<PrQuickBooks_FetchCaregiverToSyncByID_Result> FetchCaregivertoSyncWithQB(Guid ID)
        {
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    return QBDb.PrQuickBooks_FetchCaregiverToSyncByID(ID).ToList();
                }
            }
            catch (Exception)
            {
                return new List<PrQuickBooks_FetchCaregiverToSyncByID_Result>();
            }
        }

        /// <summary>
        /// Bind caregiver for QuickBooks Desktop
        /// Id by Office for Desktop only
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public List<Utilities.DropDownOnly> GetQuickBookCaregiverListDesktop(Guid ID)
        {
            List<Utilities.DropDownOnly> obj = new List<Utilities.DropDownOnly>();
            try
            {
                using (CareSmartzEntities QB = new CareSmartzEntities())
                {
                    obj = QB.PrQuickBooks_GetCaregiverListForDesktopQB(ID).Select(x => new Utilities.DropDownOnly() { NID = x.NID, Value = x.Value }).ToList();
                }
            }
            catch (Exception)
            {

            }
            return obj;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DisplayIDs"></param>
        /// <param name="Createdby"></param>
        /// <param name="Modifiedby"></param>
        /// <returns></returns>
        public int InsertCaregiverID4QBDesktopMapping(Dictionary<String, String> DisplayIDs, Guid Createdby, Guid Modifiedby)
        {
            int res = 0;
            try
            {
                var list = DisplayIDs.Select(x => new { CaregiverDisplayIDs = x.Value, CreatedBy = Createdby, Modifiedby }).ToList();

                // OPTIMIZTED THE CODE AS IT WAS ITERATE THE FOR LOOP FOR TOTAL DICTIONARY ITEMS
                using (IDbConnection con = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    con.Open();
                    con.Execute("PrQuickBooks_InsertDesktopMappingByCaregiverID", list, commandType: CommandType.StoredProcedure);
                    res = 1;
                }
            }
            catch (Exception)
            {

            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="openWith"></param>
        /// <param name="FranchiseID"></param>
        /// <returns></returns>
        public int CaregiverSyncUpdateLocal(Dictionary<string, string> openWith, Guid FranchiseID)
        {
            int res = 0;
            try
            {

                Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                var list = openWith.Select(x => new { CGDisplayID = x.Key, QBCaregiverListID = x.Value, UserId, FranchiseID }).ToList();
                // OPTIMIZTED THE CODE AS IT WAS ITERATE THE FOR LOOP FOR TOTAL DICTIONARY ITEMS
                using (IDbConnection con = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    con.Open();
                    con.Execute("PrQuickBooks_UpdateQBEmpListIDByCaregiverDisplayID", list, commandType: CommandType.StoredProcedure);
                    res = 1;
                }

                return res;
            }
            catch (Exception)
            {
                return 0;
            }
        }
        #endregion

        #region QuickBooks Online Employee
        /// <summary>
        /// To Get Employee List from QuickBooks Online
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetQuickBooksEmployeeList(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret)
        {
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                QueryService<Employee> EmployeeQueryService = new QueryService<Employee>(context);

                var Employee = EmployeeQueryService.ExecuteIdsQuery("Select * From Employee MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.GivenName + " " + p.FamilyName });

                return Employee.ToList();

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        /// <summary>
        /// Online Caregiver/Employee
        /// </summary>
        /// <param name="openWith"></param>
        /// <param name="FranchiseID"></param>
        /// <returns></returns>
        public int CaregiverOnlineSyncUpdateLocal(Dictionary<string, string> openWith, Guid FranchiseID)
        {
            int res = 0;
            try
            {
                foreach (var kvp in openWith.ToArray())
                {
                    using (CareSmartzEntities QBDb = new CareSmartzEntities())
                    {
                        Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                        QBDb.PrQuickBooks_UpdateQBEmpIDByCGDisID(Convert.ToUInt32(kvp.Value), Convert.ToInt32(kvp.Key), UserId, FranchiseID);
                        res = 1;
                    }
                }

                return res;
            }
            catch (Exception)
            {
                return 0;
            }
        }

        /// <summary>
        /// Sending data to Qb Online by PBD ID
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="FranchiseID"></param>
        /// <param name="PBDetailID"></param>
        /// <returns></returns>
        public string CreateEmployeeTimeTrackingActivitySingle(string straccessToken, string straccessTokenSecret, string strrealmId,
           string consumerKey, string consumerSecret, Guid FranchiseID, Guid PBDetailID)
        {
            string res = string.Empty;
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    var CGTimeTrackingData = QBDb.PrQuickBooks_FetchDataSendSingleByPBDID(PBDetailID, FranchiseID).FirstOrDefault();

                    TimeActivity timeActivity = new TimeActivity();
                    timeActivity.BillableStatus = BillableStatusEnum.NotBillable;
                    timeActivity.BillableStatusSpecified = true;

                    timeActivity.TxnDateSpecified = true;
                    timeActivity.TxnDate = DateTime.Parse(CGTimeTrackingData.TxDate);

                    timeActivity.StartTimeSpecified = true;
                    timeActivity.StartTime = DateTime.Parse(CGTimeTrackingData.ConvertStartDateTime);
                    timeActivity.EndTimeSpecified = true;
                    timeActivity.EndTime = DateTime.Parse(CGTimeTrackingData.ConvertEndDateTime);

                    timeActivity.HourlyRate = Convert.ToDecimal(CGTimeTrackingData.Rate);
                    timeActivity.HourlyRateSpecified = true;

                    timeActivity.NameOf = TimeActivityTypeEnum.Employee;
                    timeActivity.NameOfSpecified = true;

                    timeActivity.AnyIntuitObject = new ReferenceType()
                    {
                        Value = Convert.ToString(CGTimeTrackingData.QBEmpID),
                    };

                    //timeActivity.CustomerRef = new ReferenceType()
                    //{
                    //    Value = Convert.ToString(CGTimeTrackingData.QbCustID),
                    //};

                    timeActivity.ItemRef = new ReferenceType()
                    {
                        Value = Convert.ToString(CGTimeTrackingData.TimetrackingItem),
                    };


                    timeActivity.Description = CGTimeTrackingData.DescData;
                    TimeActivity timeActivityResult = service.Add(timeActivity);

                    if (timeActivityResult != null)
                    {
                        Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));
                        string GetData = timeActivityResult.Id;
                        QBDb.PrQuickBooks_UpdateQBOnlineTrackingIDByDetID(PBDetailID, Convert.ToInt32(GetData), UserId);

                        res = "1";
                    }
                }
                return res;
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
            }
        }


        /// <summary>
        /// Used to Export Time tracking data in Batch details
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="FranchiseID"></param>
        /// <param name="BatchID"></param>
        /// <returns></returns>
        public string CreateEmployeeTimeTrackingActivityByBatchID(string straccessToken, string straccessTokenSecret, string strrealmId,
           string consumerKey, string consumerSecret, Guid FranchiseID, Guid BatchID)
        {
            string res = string.Empty;
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    var CGTimeTrackingData = QBDb.PrQuickBooks_FetchDataSendDataByBatchID(BatchID, FranchiseID).ToList();
                    if (CGTimeTrackingData.Count > 0)
                    {
                        foreach (var CGTi in CGTimeTrackingData)
                        {
                            TimeActivity timeActivity = new TimeActivity();
                            timeActivity.BillableStatus = BillableStatusEnum.NotBillable;
                            timeActivity.BillableStatusSpecified = true;

                            timeActivity.TxnDateSpecified = true;
                            timeActivity.TxnDate = DateTime.Parse(CGTi.TxDate);

                            timeActivity.StartTimeSpecified = true;
                            timeActivity.StartTime = DateTime.Parse(CGTi.ConvertStartDateTime);
                            timeActivity.EndTimeSpecified = true;
                            timeActivity.EndTime = DateTime.Parse(CGTi.ConvertEndDateTime);

                            timeActivity.HourlyRate = Convert.ToDecimal(CGTi.Rate);
                            timeActivity.HourlyRateSpecified = true;

                            timeActivity.NameOf = TimeActivityTypeEnum.Employee;
                            timeActivity.NameOfSpecified = true;

                            timeActivity.AnyIntuitObject = new ReferenceType()
                            {
                                Value = Convert.ToString(CGTi.QBEmpID),
                            };

                            //timeActivity.CustomerRef = new ReferenceType()
                            //{
                            //    Value = Convert.ToString(CGTi.QbCustID),
                            //};

                            timeActivity.ItemRef = new ReferenceType()
                            {
                                Value = Convert.ToString(CGTi.TimetrackingItem),
                            };

                            timeActivity.Description = CGTi.DescData;
                            TimeActivity timeActivityResult = service.Add(timeActivity);

                            if (timeActivityResult != null)
                            {
                                Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));
                                string GetData = timeActivityResult.Id;
                                QBDb.PrQuickBooks_UpdateQBOnlineTrackingIDByDetID(CGTi.PayrollBatchDetailId, Convert.ToInt32(GetData), UserId);

                                res = "1";
                            }
                        }
                    }
                    else
                    {
                        res = "0";
                    }
                }

                return res;
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
            }
        }
        #endregion


        #region Quick Book Auth2


        /// <summary>
        /// Function used to get new access token based on refresh token
        /// </summary>
        /// <param name="FranchiseID"></param>
        /// <param name="RefreshToken"></param>
        /// <param name="Companyrealm_QBO2"></param>
        /// <returns></returns>
        public string GetAuthTokensAsync(Guid? FranchiseID, string RefreshToken, string Companyrealm_QBO2)
        {
            //try
            //{
            //    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;

            //    //Refresh token endpoint
            //    var accesstokenResponse = auth2Client.RefreshTokenAsync(RefreshToken);
            //    accesstokenResponse.Wait();
            //    if (accesstokenResponse.Result != null)
            //    {
            //        var tokenResponse = accesstokenResponse.Result;

            //        if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
            //        {
            //            HttpContext.Current.Session["access_token_new"] = tokenResponse.AccessToken;
            //            HttpContext.Current.Session["access_token_expires_at_new"] = DateTime.UtcNow.AddSeconds(Convert.ToDouble(tokenResponse.AccessTokenExpiresIn)); //DateTime.Now.AddSeconds(tokenResponse.AccessTokenExpiresIn);
            //        }
            //        if (!string.IsNullOrWhiteSpace(tokenResponse.RefreshToken))
            //        {
            //            HttpContext.Current.Session["refresh_token_new"] = tokenResponse.RefreshToken;
            //            HttpContext.Current.Session["refresh_token_expires_at_new"] = DateTime.UtcNow.AddSeconds(Convert.ToDouble(tokenResponse.RefreshTokenExpiresIn));
            //        }

            //        if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
            //        {
            //            string result = UpdateAccessRefreshTokenValueToDB_QBO2(FranchiseID);
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    // function used to trck Quick Book Error Details.
            //    //SaveQuickBookErrorDetails("QuickBookIntuit", "GetAuthTokensAsync", ex.Message);

            //    throw ex;
            //}
            return "";
        }


        /// <summary>
        /// Function used to update new access token value
        /// </summary>
        protected string UpdateAccessTokenValueToDB_QBO2(Guid? Franchiseid)
        {
            try
            {
                Guid FranchiseID = new Guid(Convert.ToString(Franchiseid));

                string accessToken_QBO2 = Convert.ToString(HttpContext.Current.Session["access_token_new"]);
                DateTime access_token_expires_at_QBO2 = Convert.ToDateTime(HttpContext.Current.Session["access_token_expires_at_new"]);

                int res = UpdateAccessRelatedInfoByOffice_QBO2(FranchiseID, accessToken_QBO2, access_token_expires_at_QBO2);

                if (res == 1)
                {
                    HttpContext.Current.Session.Remove("access_token_new");
                    HttpContext.Current.Session.Remove("access_token_expires_at_new");
                }

            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "UpdateAccessTokenValueToDB_QBO2", ex.Message);

                throw ex;
            }
            return "";
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="FranchiseID"></param>
        /// <param name="RefreshToken"></param>
        /// <param name="Companyrealm_QBO2"></param>
        /// <returns></returns>
        public string GetAuth_RefreshTokensAsync(Guid? FranchiseID, string RefreshToken, string Companyrealm_QBO2)
        {
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;


                ClientId_QBO2 = "ABuYMERYlt0TYuoEfFJl8Zr1bUcqMLgFU1dVNlWv7vI7kX2nM6";
                ClientSecret_QBO2 = "IgIAKV0IzOmjdzmvQhoiQDzGwka71aK4PjrSkv1e";
                RedirectUrl_QBO2 = "http://localhost:57229/Callback";
                Environment_QBO2 = "sandbox";

                if (!string.IsNullOrEmpty(ClientId_QBO2) && !string.IsNullOrEmpty(ClientSecret_QBO2) && !string.IsNullOrEmpty(RedirectUrl_QBO2) && !string.IsNullOrEmpty(Environment_QBO2))
                {
                    if (auth2Client == null)
                    {
                        auth2Client = new OAuth2Client(ClientId_QBO2, ClientSecret_QBO2, RedirectUrl_QBO2, Environment_QBO2);

                    }
                }

                //Refresh token endpoint
                var accesstokenResponse = auth2Client.RefreshTokenAsync(RefreshToken);
                accesstokenResponse.Wait();
                var tokenResponse = accesstokenResponse.Result;

                if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
                {
                    HttpContext.Current.Session["access_token_new"] = tokenResponse.AccessToken;
                    HttpContext.Current.Session["access_token_expires_at_new"] = DateTime.UtcNow.AddSeconds(Convert.ToDouble(tokenResponse.AccessTokenExpiresIn));
                }
                if (!string.IsNullOrWhiteSpace(tokenResponse.RefreshToken))
                {
                    HttpContext.Current.Session["refresh_token_new"] = tokenResponse.RefreshToken;
                    HttpContext.Current.Session["refresh_token_expires_at_new"] = DateTime.UtcNow.AddSeconds(Convert.ToDouble(tokenResponse.RefreshTokenExpiresIn));
                }

                if (!string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
                {
                    string result = UpdateAccessRefreshTokenValueToDB_QBO2(FranchiseID);
                }

            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetAuth_RefreshTokensAsync", ex.Message);

                throw ex;
            }
            return "";
        }



        /// <summary>
        /// Function used to update new access token value
        /// </summary>
        protected string UpdateAccessRefreshTokenValueToDB_QBO2(Guid? Franchiseid)
        {
            try
            {
                Guid FranchiseID = new Guid(Convert.ToString(Franchiseid));
                using (QuickBookIntuit QbInst = new QuickBookIntuit())
                {
                    string accessToken_QBO2 = Convert.ToString(HttpContext.Current.Session["access_token_new"]);
                    DateTime access_token_expires_at_QBO2 = Convert.ToDateTime(HttpContext.Current.Session["access_token_expires_at_new"]);
                    string refreshToken_QBO2 = Convert.ToString(HttpContext.Current.Session["refresh_token_new"]);
                    DateTime refresh_token_expires_at_QBO2 = Convert.ToDateTime(HttpContext.Current.Session["refresh_token_expires_at_new"]);
                    //string Companyrealm_QBO2 = Convert.ToString(Session["realmId"]);

                    int res = QbInst.UpdateAccessRefreshTokenInfoByOffice_QBO2(FranchiseID, accessToken_QBO2, access_token_expires_at_QBO2, refreshToken_QBO2, refresh_token_expires_at_QBO2);

                    if (res == 1)
                    {
                        HttpContext.Current.Session.Remove("access_token_new");
                        HttpContext.Current.Session.Remove("access_token_expires_at_new");
                        HttpContext.Current.Session.Remove("refresh_token_new");
                        HttpContext.Current.Session.Remove("refresh_token_expires_at_new");
                    }
                }
            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "UpdateAccessRefreshTokenValueToDB_QBO2", ex.Message);

                throw ex;
            }
            return "";
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="FranchiseID"></param>
        /// <param name="AccessToken"></param>
        /// <param name="AccessTokenExpiresAt"></param>
        /// <returns></returns>
        public Int16 UpdateAccessRelatedInfoByOffice_QBO2(Guid? FranchiseID, string AccessToken, DateTime AccessTokenExpiresAt)
        {
            Int16 res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    TbIntuitQBKey TbQb = (from p in QBDb.TbIntuitQBKeys
                                          where p.FranchiseID == FranchiseID
                                          && p.IsActive == true && p.IsArchived == false
                                          select p).FirstOrDefault();

                    if (TbQb != null)
                    {
                        TbQb.AccessToken_QBO2 = AccessToken;
                        TbQb.AccessTokenExpiresAt_QBO2 = AccessTokenExpiresAt;
                        TbQb.ModifiedOn = DateTime.UtcNow;
                        QBDb.SaveChanges();
                    }
                    else
                    {
                        TbIntuitQBKey TbQbActive = (from p in QBDb.TbIntuitQBKeys
                                                    where p.IsActive == true && p.IsArchived == false && p.FranchiseID == FranchiseID
                                                    select p).FirstOrDefault();

                        if (TbQbActive != null)
                        {
                            TbQbActive.AccessToken_QBO2 = AccessToken;
                            TbQbActive.AccessTokenExpiresAt_QBO2 = AccessTokenExpiresAt;
                            TbQbActive.FranchiseID = FranchiseID;
                            TbQbActive.ModifiedOn = DateTime.UtcNow;
                            QBDb.SaveChanges();
                        }
                    }
                    res = 1;
                }
            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "UpdateAccessRelatedInfoByOffice_QBO2", ex.Message);

                throw ex;
            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FranchiseID"></param>
        /// <param name="AccessToken"></param>
        /// <param name="AccessTokenExpiresAt"></param>
        /// <returns></returns>
        public Int16 UpdateAccessRefreshTokenInfoByOffice_QBO2(Guid? FranchiseID, string AccessToken, DateTime AccessTokenExpiresAt, string RefreshToken, DateTime RefreshTokenExpiresAt)
        {
            Int16 res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    TbIntuitQBKey TbQb = (from p in QBDb.TbIntuitQBKeys
                                          where p.FranchiseID == FranchiseID
                                          && p.IsActive == true && p.IsArchived == false
                                          select p).FirstOrDefault();

                    if (TbQb != null)
                    {
                        TbQb.AccessToken_QBO2 = AccessToken;
                        TbQb.AccessTokenExpiresAt_QBO2 = AccessTokenExpiresAt;
                        TbQb.RefreshToken_QBO2 = RefreshToken;
                        TbQb.RefreshTokenExpiresAt_QBO2 = RefreshTokenExpiresAt;
                        TbQb.ModifiedOn = DateTime.UtcNow;
                        QBDb.SaveChanges();
                    }
                    else
                    {
                        TbIntuitQBKey TbQbActive = (from p in QBDb.TbIntuitQBKeys
                                                    where p.IsActive == true && p.IsArchived == false && p.FranchiseID == FranchiseID
                                                    select p).FirstOrDefault();

                        if (TbQbActive != null)
                        {
                            TbQbActive.AccessToken_QBO2 = AccessToken;
                            TbQbActive.AccessTokenExpiresAt_QBO2 = AccessTokenExpiresAt;
                            TbQbActive.RefreshToken_QBO2 = RefreshToken;
                            TbQbActive.RefreshTokenExpiresAt_QBO2 = RefreshTokenExpiresAt;
                            TbQbActive.FranchiseID = FranchiseID;
                            TbQbActive.ModifiedOn = DateTime.UtcNow;
                            QBDb.SaveChanges();
                        }
                    }
                    res = 1;
                }
            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "UpdateAccessRefreshTokenInfoByOffice_QBO2", ex.Message);

                throw ex;
            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public int CheckQBReqTokens4Connect_QBO2(Guid ID)
        {
            Int16 res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    TbIntuitQBKey TbQb = (from p in QBDb.TbIntuitQBKeys
                                          where p.FranchiseID == ID && p.IsActive == true && p.IsArchived == false
                                          select p).FirstOrDefault();


                    if (TbQb != null)
                    {
                        if (TbQb.QuickBooksMode == 2)
                        {
                            TbIntuitQBKey TbQbDT = (from p in QBDb.TbIntuitQBKeys
                                                    where p.FranchiseID == ID && p.IsActive == true && p.IsArchived == false
                                                    && p.AccessToken_QBO2 == null && p.RealmId_QBO2 == null
                                                    select p).FirstOrDefault();
                            if (TbQbDT != null)
                            {
                                if (TbQbDT.IsQWCFileDownloaded == 0)
                                {
                                    res = 4; // when file not downloaded
                                }
                                else
                                {
                                    res = Convert.ToInt16(TbQbDT.QuickBooksMode);
                                }
                            }
                            else
                                res = 0;
                        }
                        else if (TbQb.QuickBooksMode == 1)
                        {
                            TbIntuitQBKey TbQbOnLine = (from p in QBDb.TbIntuitQBKeys
                                                        where p.FranchiseID == ID
                                                        && p.AccessToken_QBO2 != null && p.RealmId_QBO2 != null

                                                        && p.IsActive == true && p.IsArchived == false
                                                        select p).FirstOrDefault();

                            if (TbQbOnLine != null)
                            {
                                res = 3; // When there is connection done
                            }

                            else
                                res = 1;
                        }
                    }
                    else
                    {
                        res = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "CheckQBReqTokens4Connect_QBO2", ex.Message);

                throw ex;
            }
            return res;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="strClDis"></param>
        /// <param name="iNameSetting"></param>
        /// <param name="FranchiseID"></param>
        /// <returns></returns>
        public string CreateEmployee(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret, string CGDisplayID, Int32 iNameSetting, Guid FranchiseID)
        {
            int res = 0;
            Employee Emp = new Employee();
            PhysicalAddress EmpAddres = new PhysicalAddress();
            EmailAddress EmpEmail = new EmailAddress();

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                string[] words = CGDisplayID.Split(',');
                foreach (string word in words)
                {
                    using (CareSmartzEntities QBDb = new CareSmartzEntities())
                    {
                        var EmpDet = QBDb.PrQuickBooks_FetchCaregiverDetailByDisplayID(word).FirstOrDefault();

                        if (EmpDet != null)
                        {
                            // Check if the Employee already exists in QuickBooks
                            QueryService<Employee> EmpQueryService = new QueryService<Employee>(context);
                            int EmpCount = EmpQueryService.ExecuteIdsQuery("Select GivenName From Employee WHERE GivenName = '" + EmpDet.FirstName + "' and FamilyName = '" + EmpDet.LastName + "'").Count();

                            if (EmpCount == 0)
                            {
                                Emp.GivenName = EmpDet.FirstName;
                                Emp.FamilyName = EmpDet.LastName;

                                if (iNameSetting == 1)
                                    Emp.DisplayName = EmpDet.FirstName + ", " + EmpDet.LastName;
                                else if (iNameSetting == 2)
                                    Emp.DisplayName = EmpDet.LastName + ", " + EmpDet.FirstName;

                                Emp.PrintOnCheckName = EmpDet.FirstName + " " + EmpDet.LastName;

                                Emp.Active = true;

                                EmpAddres.Line1 = EmpDet.Address1;
                                EmpAddres.City = EmpDet.CityName;
                                EmpAddres.CountrySubDivisionCode = EmpDet.StateName;
                                EmpAddres.PostalCode = EmpDet.ZipCode;
                                EmpAddres.Country = EmpDet.CountryName;

                                Emp.PrimaryAddr = EmpAddres;

                                if (!string.IsNullOrEmpty(EmpDet.Email1))
                                {
                                    EmpEmail.Address = EmpDet.Email1;
                                    if (IsValidEmailAddress(EmpDet.Email1))
                                        Emp.PrimaryEmailAddr = EmpEmail;
                                }

                                if (EmpDet.HireDate != null)
                                {
                                    Emp.HiredDateSpecified = true;
                                    Emp.HiredDate = Convert.ToDateTime(EmpDet.HireDate).Date;
                                }

                                var getResponse = service.Add(Emp);

                                if (getResponse != null)
                                {
                                    Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));
                                    Int32 iGetData = Convert.ToInt32(getResponse.Id);
                                    QBDb.PrQuickBooks_UpdateQBEmpIDByCGDisID(iGetData, Convert.ToInt32(word), UserId, FranchiseID);

                                    res = 1;
                                }
                            }
                        }
                    }
                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
                EmpAddres = null;
                EmpEmail = null;
                Emp = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <param name="CGDisplayID"></param>
        /// <param name="iNameSetting"></param>
        /// <param name="FranchiseID"></param>
        /// <returns></returns>
        public string CreateEmployee(string straccessToken, string strrealmId,
            Dictionary<string, string> CGDisplayID, Int32 iNameSetting, Guid FranchiseID)
        {
            int res = 0;
            Employee Emp = new Employee();
            PhysicalAddress EmpAddres = new PhysicalAddress();
            EmailAddress EmpEmail = new EmailAddress();
            TelephoneNumber EmpPhone = new TelephoneNumber();

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                //var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                //var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());

                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //string[] words = CGDisplayID.Split(',');
                Dictionary<string, string>.KeyCollection keyColl = CGDisplayID.Keys;

                foreach (string word in keyColl)
                {
                    using (CareSmartzEntities QBDb = new CareSmartzEntities())
                    {
                        var EmpDet = QBDb.PrQuickBooks_FetchCaregiverDetailByDisplayID(word).FirstOrDefault();

                        if (EmpDet != null)
                        {
                            // Check if the Employee already exists in QuickBooks
                            QueryService<Employee> EmpQueryService = new QueryService<Employee>(context);
                            int EmpCount = EmpQueryService.ExecuteIdsQuery("Select GivenName From Employee WHERE GivenName = '" + EmpDet.FirstName + "' and FamilyName = '" + EmpDet.LastName + "'").Count();

                            if (EmpCount == 0)
                            {
                                Emp.GivenName = EmpDet.FirstName;
                                Emp.FamilyName = EmpDet.LastName;

                                if (iNameSetting == 1)
                                    Emp.DisplayName = EmpDet.FirstName + ", " + EmpDet.LastName;
                                else if (iNameSetting == 2)
                                    Emp.DisplayName = EmpDet.LastName + ", " + EmpDet.FirstName;

                                Emp.PrintOnCheckName = EmpDet.FirstName + " " + EmpDet.LastName;

                                Emp.Active = true;

                                EmpAddres.Line1 = EmpDet.Address1;
                                EmpAddres.City = EmpDet.CityName;
                                EmpAddres.CountrySubDivisionCode = EmpDet.StateName;
                                EmpAddres.PostalCode = EmpDet.ZipCode;
                                EmpAddres.Country = EmpDet.CountryName;

                                Emp.PrimaryAddr = EmpAddres;

                                if (!string.IsNullOrEmpty(EmpDet.Email1))
                                {
                                    EmpEmail.Address = EmpDet.Email1;
                                    if (IsValidEmailAddress(EmpDet.Email1))
                                        Emp.PrimaryEmailAddr = EmpEmail;
                                }

                                if (!string.IsNullOrEmpty(EmpDet.PhoneType))
                                {
                                    if (EmpDet.PhoneType.ToString().ToLower() == "work" || EmpDet.PhoneType.ToString().ToLower() == "home")
                                    {
                                        if (!string.IsNullOrEmpty(EmpDet.Phone))
                                        {
                                            EmpPhone.FreeFormNumber = EmpDet.Phone;
                                            Emp.PrimaryPhone = EmpPhone;
                                        }
                                    }
                                    if (EmpDet.PhoneType.ToString().ToLower() == "mobile")
                                    {
                                        if (!string.IsNullOrEmpty(EmpDet.Phone))
                                        {
                                            EmpPhone.FreeFormNumber = EmpDet.Phone;
                                            Emp.Mobile = EmpPhone;
                                        }
                                    }
                                }

                                if (EmpDet.TelephonyId != null)
                                {
                                    Emp.EmployeeNumber = EmpDet.TelephonyId;
                                }
                                if (EmpDet.EncSSNNo != null)
                                {
                                    Emp.SSN = EmpDet.EncSSNNo;
                                }
                                if (EmpDet.BirthDate != null)
                                {
                                    Emp.BirthDateSpecified = true;
                                    Emp.BirthDate = Convert.ToDateTime(EmpDet.BirthDate).Date;
                                }
                                if (EmpDet.Gender != null)
                                {
                                    if (EmpDet.Gender.ToString().ToLower() == "male")
                                    {
                                        Emp.GenderSpecified = true;
                                        Emp.Gender = gender.Male;
                                    }
                                    else if (EmpDet.Gender.ToString().ToLower() == "female")
                                    {
                                        Emp.GenderSpecified = true;
                                        Emp.Gender = gender.Female;
                                    }
                                }
                                if (EmpDet.MaritalStatus != null)
                                {
                                    //Emp.ma = EmpDet.Gender;
                                }
                                if (EmpDet.HireDate != null)
                                {
                                    Emp.HiredDateSpecified = true;
                                    Emp.HiredDate = Convert.ToDateTime(EmpDet.HireDate).Date;
                                }

                                var getResponse = service.Add(Emp);

                                if (getResponse != null)
                                {
                                    Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));
                                    Int32 iGetData = Convert.ToInt32(getResponse.Id);
                                    QBDb.PrQuickBooks_UpdateQBEmpIDByCGDisID(iGetData, Convert.ToInt32(word), UserId, FranchiseID);

                                    res = 1;
                                }
                            }
                        }
                    }
                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetRefreshButtonStatus", ex.Message);

                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
                EmpAddres = null;
                EmpEmail = null;
                Emp = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetQuickBooksCustomerList(string straccessToken, string strrealmId)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                QueryService<Customer> customerQueryService = new QueryService<Customer>(context);
                var customer = customerQueryService.ExecuteIdsQuery("Select * From Customer MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.FamilyName + ", " + p.GivenName });

                return customer.ToList();

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetRefreshButtonStatus", ex.Message);

                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetClassFromQBOnline(string straccessToken, string strrealmId)
        {
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                var classQuery = service.FindAll(new Class()).Where(q => q.Active == true).Select(cls => new Utilities.DropDown { Value = Convert.ToString(cls.Id), description = cls.Name });

                return classQuery.ToList();
            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetClassFromQBOnline", ex.Message);

                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetQuickBooksEmployeeList(string straccessToken, string strrealmId)
        {
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                QueryService<Employee> EmployeeQueryService = new QueryService<Employee>(context);

                var Employee = EmployeeQueryService.ExecuteIdsQuery("Select * From Employee MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.GivenName + " " + p.FamilyName });

                return Employee.ToList();

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetQuickBooksEmployeeList", ex.Message);

                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetQuickBooksAccountsList(string straccessToken, string strrealmId)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                var oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Account - Accounts Receivable account required
                QueryService<Account> accountQueryService = new QueryService<Account>(context);
                var account = accountQueryService.ExecuteIdsQuery("Select * From Account MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.Name });

                return account.ToList();

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetQuickBooksAccountsList", ex.Message);

                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetQuickBooksItemsList(string straccessToken, string strrealmId)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                var oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Item - 
                QueryService<Item> itemQueryService = new QueryService<Item>(context);
                var item = itemQueryService.ExecuteIdsQuery("Select * From Item MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.Name });

                return item.ToList();

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetQuickBooksItemsList", ex.Message);

                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <param name="strClDis"></param>
        /// <param name="iNameSetting"></param>
        /// <param name="FranchiseID"></param>
        /// <returns></returns>
        public string CreateCustomer(string straccessToken, string strrealmId, string strClDis, Int32 iNameSetting, Guid FranchiseID)
        {
            int res = 0;
            Customer customer = new Customer();
            PhysicalAddress custAddres = new PhysicalAddress();
            TelephoneNumber custTel = new TelephoneNumber();
            EmailAddress CustEmail = new EmailAddress();

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;

                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                string[] words = strClDis.Split(',');
                foreach (string word in words)
                {
                    using (CareSmartzEntities QBDb = new CareSmartzEntities())
                    {
                        var clDet = QBDb.PrQuickBooks_FetchClientDetailByDisplayID(word).FirstOrDefault();

                        if (clDet != null)
                        {
                            // Check if the customer already exists in QuickBooks
                            QueryService<Customer> customerQueryService = new QueryService<Customer>(context);
                            int customerCount = customerQueryService.ExecuteIdsQuery("Select GivenName From Customer WHERE GivenName = '" + clDet.FirstName + "' and FamilyName = '" + clDet.LastName + "'").Count();

                            if (customerCount == 0)
                            {
                                customer.GivenName = clDet.FirstName;
                                customer.FamilyName = clDet.LastName;
                                //customer.CompanyName = strrealmId;
                                if (iNameSetting == 1)
                                    customer.DisplayName = clDet.FirstName + ", " + clDet.LastName;
                                else if (iNameSetting == 2)
                                    customer.DisplayName = clDet.LastName + ", " + clDet.FirstName;

                                //customer.FullyQualifiedName = customer.DisplayName + "( " + strrealmId + " )";

                                custAddres.Line1 = clDet.Address1;
                                custAddres.City = clDet.CityName;
                                custAddres.CountrySubDivisionCode = clDet.StateName;
                                custAddres.PostalCode = clDet.ZipCode;

                                //custTel.FreeFormNumber = clDet.Phone;
                                customer.BillAddr = custAddres;

                                //customer.PrimaryPhone = custTel;

                                if (!string.IsNullOrEmpty(clDet.Email1))
                                {
                                    CustEmail.Address = clDet.Email1;
                                    if (IsValidEmailAddress(clDet.Email1))
                                        customer.PrimaryEmailAddr = CustEmail;
                                }

                                customer.Taxable = false;
                                customer.TaxableSpecified = false;

                                var getResponse = service.Add(customer);

                                if (getResponse != null)
                                {
                                    Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                                    string strGetData = Convert.ToString(getResponse.Id);
                                    QBDb.PrQuickBooks_UpdateQBCustIDByClientDisID(strGetData, word, UserId, FranchiseID);

                                    res = 1;
                                }
                            }
                        }
                    }
                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "CreateCustomer", ex.Message);

                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
                custAddres = null;
                //custTel = null;
                CustEmail = null;
                customer = null;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="strInvoiceID"></param>
        /// <returns></returns>
        /// 
        public string CreateCustomerInvoice(string straccessToken, string strrealmId, string strInvoiceID, string TaxCodeName = null)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                int CountryId = Common.GetAgencyCountry();

                //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
                QueryService<TaxCode> stateTaxCodeQueryService = new QueryService<TaxCode>(context);

                TaxCode stateTaxCode = null;

                if (CountryId == 4)// USA
                {
                    stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From TaxCode Where Name='StateSalesTax' AND Active = true StartPosition 1 MaxResults 1").FirstOrDefault<TaxCode>();
                }
                else if (CountryId == 9) // Canada
                {
                    if (string.IsNullOrEmpty(TaxCodeName))
                        stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From TaxCode Where Name='HST ON' AND Active = true StartPosition 1 MaxResults 1").FirstOrDefault<TaxCode>();
                    else
                        stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From TaxCode Where Name='" + TaxCodeName + "' AND Active = true StartPosition 1 MaxResults 1").FirstOrDefault<TaxCode>();
                }

                string[] words = strInvoiceID.Split(',');
                foreach (string word in words)
                {
                    using (CareSmartzEntities QBDb = new CareSmartzEntities())
                    {
                        var clDet = QBDb.PrQuickBooks_FetchInvoiceDetailsByInvoiceID(new Guid(word)).ToList();
                        if (clDet.Count > 0)
                        {
                            Invoice invoice = new Invoice();

                            //DocNumber - QBO Only, otherwise use DocNumber
                            invoice.AutoDocNumber = true;
                            invoice.AutoDocNumberSpecified = true;
                            invoice.DocNumber = clDet[0].InvoiceNumber;

                            //TxnDate
                            invoice.TxnDate = Convert.ToDateTime(clDet[0].InvoiceDate); //DateTime.Now.Date;
                            invoice.TxnDateSpecified = true;
                            invoice.GlobalTaxCalculation = GlobalTaxCalculationEnum.NotApplicable;
                            //invoice.GlobalTaxCalculation = GlobalTaxCalculationEnum.TaxExcluded;
                            invoice.GlobalTaxCalculationSpecified = false;

                            Intuit.Ipp.Data.Line[] invoiceLineCollection = new Intuit.Ipp.Data.Line[clDet.Count];
                            for (int i = 0; i < clDet.Count; i++)
                            {
                                var line = clDet[i];
                                var qboInvoiceLine = new Intuit.Ipp.Data.Line()
                                {
                                    Amount = Convert.ToDecimal(line.LineTotal),
                                    AmountSpecified = true,
                                    Description = line.LineDescription,
                                    DetailType = LineDetailTypeEnum.SalesItemLineDetail,
                                    DetailTypeSpecified = true,

                                    AnyIntuitObject = new SalesItemLineDetail()
                                    {
                                        ItemRef = new ReferenceType()
                                        {
                                            Value = Convert.ToString(line.QbItemID)
                                        },

                                        ItemElementName = ItemChoiceType.UnitPrice,
                                        TaxCodeRef = new ReferenceType()
                                        {
                                            Value = stateTaxCode == null ? "NON" : stateTaxCode.Id
                                        },

                                        ClassRef = new ReferenceType()
                                        {
                                            Value = Convert.ToString(clDet[0].MTClsFlag) == "1" ? Convert.ToString(clDet[0].QBClassRef) : null
                                        },

                                        //Qty = Convert.ToDecimal(line.LineUnits),
                                        //QtySpecified = true,

                                        ServiceDate = line.ServiceStartDate.Value,
                                        ServiceDateSpecified = true,

                                        AnyIntuitObject = Convert.ToDecimal(line.ChargeRate)
                                    }
                                };

                                invoiceLineCollection[i] = qboInvoiceLine;
                            }

                            invoice.Line = invoiceLineCollection;


                            //Customer (Client)
                            invoice.CustomerRef = new ReferenceType()
                            {
                                Value = Convert.ToString(clDet[0].QbCustID)
                            };

                            // QB Support Email Address Lenght 100
                            if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].PayerEmailTo)))
                            {
                                if (Convert.ToString(clDet[0].PayerEmailTo).Length <= 100)
                                {
                                    invoice.BillEmail = new EmailAddress()
                                    {
                                        Address = Convert.ToString(clDet[0].PayerEmailTo),
                                    };
                                }
                                invoice.EmailStatus = EmailStatusEnum.NotSet;
                                invoice.BillEmail.DefaultSpecified = true;
                            }

                            //QB CC Email Address
                            if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].PayerCCEMail)))
                            {
                                //if (Convert.ToString(clDet[0].PayerCCEMail).Length <= 100)
                                //{
                                //    invoice.BillEmailCc = new EmailAddress()
                                //    {
                                //        Address = Convert.ToString(clDet[0].PayerCCEMail),
                                //    };
                                //}
                                //invoice.EmailStatus = EmailStatusEnum.NotSet;
                                //invoice.BillEmailCc.DefaultSpecified = true;
                            }

                            //DueDate
                            invoice.DueDate = Convert.ToDateTime(clDet[0].InvoiceDate).AddDays(Convert.ToInt32(clDet[0].DueDays)).Date; //DateTime.Now.AddDays(Convert.ToInt32(clDet[0].DueDays)).Date;
                            invoice.DueDateSpecified = true;


                            ////ARAccountRef
                            invoice.ARAccountRef = new ReferenceType()
                            {
                                Value = Convert.ToString(clDet[0].AccountReceivables)
                            };

                            Invoice invoiceAdded = service.Add(invoice);

                            if (invoiceAdded != null)
                            {
                                Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                                string strGetData = Convert.ToString(invoiceAdded.Id);
                                QBDb.PrQuickBooks_UpdateQuickBookDocInvoiceByInvoiceID(new Guid(word), Convert.ToInt64(strGetData), UserId);

                                res = 1;
                            }
                        }
                    }
                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                // SaveQuickBookErrorDetails("QuickBookIntuit", "CreateCustomerInvoice", ex.Message);

                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }

                return returnMessage;
            }
            finally
            {
                //custAddres = null;
                //custTel = null;
                //CustEmail = null;
                //customer = null;
            }
        }
        /// <summary>
        /// MANDEEP SINGH
        /// USED TO SAVE QB DESKTOP PAYEMENT DATA
        /// 11-14-2019
        /// </summary>
        /// <param name="InvoiceHeaderIds"></param>
        /// <param name="FranchiseID"></param>
        /// <returns></returns>
        public String QBDesktop_InvoicePaymentQueue(List<String> InvoiceHeaderIds)
        {
            String res = "0";
            try
            {

                Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                var list = InvoiceHeaderIds.Select(x => new { InvoiceHeaderID = x.ToString(), UserId }).ToList();
                using (IDbConnection con = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    con.Open();
                    con.Execute("PrQBDesktop_InvoicePaymentQueue", list, commandType: CommandType.StoredProcedure);
                    res = "1";
                }

                return res;
            }
            catch
            {
                return "0";
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="QBCustID"></param>
        /// <param name="QBInvID"></param>
        /// <returns></returns>
        public string GetCustomerInvoicePaymentStatus(string straccessToken, string strrealmId, string QBCustID, string QBInvID)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                //var service = new DataService(context);
                //var paymentQuery = service.FindAll(new Payment()).Where(q => q.CustomerRef.Value == QBCustID && q.Line[0].LinkedTxn[0].TxnId == QBInvID);

                QueryService<Payment> paymentQueryService = new QueryService<Payment>(context);
                //var paymentQuery = paymentQueryService.ExecuteIdsQuery("SELECT * FROM Payment MaxResults 1000").Where(q => q.CustomerRef.Value == QBCustID && q.Line[0].LinkedTxn[0].TxnId == QBInvID).ToList();
                var paymentQuery = paymentQueryService.ExecuteIdsQuery("SELECT * FROM Payment MaxResults 1000").Where(q => q.CustomerRef.Value == QBCustID).ToList();

                string[] ids = new string[2];
                ids[0] = "/'488/'";
                ids[1] = "/'489/'";
                string a = string.Join(",", ids);

                //var paymentQuery2 = paymentQueryService.ExecuteIdsQuery("SELECT * FROM Payment where Id in ('488','489')").ToList();

                var paymentQuery2 = paymentQueryService.ExecuteIdsQuery("SELECT * FROM Payment where Id in ("+string.Join(",", ids)+")").ToList();

                //Use QueryService to read an existing Invoice having custom fields
                QueryService<Invoice> querservice = new QueryService<Invoice>(context);
                Invoice invoiceQuery = querservice.ExecuteIdsQuery("select * from Invoice where Id = '471'").FirstOrDefault();

                //invoiceObj.LinkedTxn 

                if (invoiceQuery.LinkedTxn.Count() > 0)
                {
                    DataTable ot = CreateDataTable();

                    foreach (var idata in invoiceQuery.LinkedTxn)
                    {

                        var lineList = idata.TxnId;

                        var paymentQuery3 = paymentQueryService.ExecuteIdsQuery("SELECT * FROM Payment where Id='"+ idata.TxnId + "'").ToList();

                    }
                }


                //get customFieldName
                var customFieldName = invoiceQuery.CustomField[0].Name;
                //get custom field definitionId
                //var customFieldDefinitionId = invoiceQuery.CustomField[0].DefintionId;
                //get custom field value
                var customFieldValue = invoiceQuery.CustomField[0].AnyIntuitObject;


                List<Intuit.Ipp.Data.IEntity> entityList1 = new List<Intuit.Ipp.Data.IEntity>();
                //entityList1.Add(new Intuit.Ipp.Data.Customer());
                entityList1.Add(new Intuit.Ipp.Data.Payment()); 
                //entityList1.Add(new Intuit.Ipp.Data.Invoice()); 
                //entityList1.Add(new Intuit.Ipp.Data.Bill()); 
                var DataService1 = new DataService(context);
                //var CDCResponse = DataService1.CDC(entityList1, DateTime.Now.AddDays(-30)).entities;

                var CDCResponse = DataService1.CDC(entityList1, DateTime.Now.AddYears(-1)).entities;
                foreach (string key in CDCResponse.Keys)
                {
                    var Payments = CDCResponse[key];
                    foreach (Intuit.Ipp.Data.Payment payment in Payments)
                    {
                        var lineList = payment.Line.ToList();

                        if (lineList.Count() > 0)
                        {
                            foreach (var lnList in lineList)
                            {
                                var LinkedTxnList = lnList.LinkedTxn.ToList();

                                if (LinkedTxnList.Count() > 0)
                                {
                                    foreach (var TxnList in LinkedTxnList)
                                    {
                                        string TxnId = TxnList.TxnId;

                                        if (!string.IsNullOrEmpty(TxnId) && TxnId == "471")
                                        {
                                            string custref = payment.CustomerRef.Value;
                                            string idt = payment.Id;
                                            decimal amt = payment.TotalAmt;
                                            decimal lineamt = payment.Line[0].Amount;

                                            //DataRow dtrow = ot.NewRow();
                                            ////dtrow["CustID"] = idata.CustomerRef.Value;
                                            //dtrow["CustID"] = QBCustID;
                                            //dtrow["ID"] = idata.Id;
                                            //dtrow["TotalAmt"] = idata.TotalAmt;
                                            //dtrow["CreateTime"] = idata.MetaData.CreateTime;
                                            //dtrow["ProcessPayment"] = idata.ProcessPayment;
                                            //dtrow["QBCustomerName"] = idata.CustomerRef.name;
                                            //dtrow["TxnDate"] = idata.TxnDate;
                                            ////dtrow["QBInvID"] = idata.Line[0].LinkedTxn[0].TxnId;
                                            //dtrow["QBInvID"] = QBInvID;
                                            //dtrow["TxnType"] = idata.Line[0].LinkedTxn[0].TxnType;
                                            //dtrow["CurrencyRef"] = idata.CurrencyRef.Value;
                                            //dtrow["LineAmount"] = idata.Line[0].Amount;
                                            //dtrow["PrivateNote"] = idata.PrivateNote;
                                            //dtrow["PaymentTypeField"] = idata.PaymentType;

                                            //ot.Rows.Add(dtrow);

                                        }
                                    }
                                }
                            }
                        }

                    }
                }




                if (paymentQuery2.Count() > 0)
                {
                    DataTable ot = CreateDataTable();

                    foreach (var idata in paymentQuery2)
                    {

                        var lineList = idata.Line.ToList();

                        if (lineList.Count() > 0)
                        {
                            foreach (var lnList in lineList)
                            {
                                var LinkedTxnList = lnList.LinkedTxn.ToList();

                                if (LinkedTxnList.Count() > 0)
                                {
                                    foreach (var TxnList in LinkedTxnList)
                                    {
                                        string TxnId = TxnList.TxnId;

                                        if (!string.IsNullOrEmpty(TxnId) && TxnId == QBInvID)
                                        {
                                            string custref = idata.CustomerRef.Value;
                                            string idt = idata.Id;
                                            decimal amt = idata.TotalAmt;
                                            decimal lineamt = idata.Line[0].Amount;

                                            DataRow dtrow = ot.NewRow();
                                            //dtrow["CustID"] = idata.CustomerRef.Value;
                                            dtrow["CustID"] = QBCustID;
                                            dtrow["ID"] = idata.Id;
                                            dtrow["TotalAmt"] = idata.TotalAmt;
                                            dtrow["CreateTime"] = idata.MetaData.CreateTime;
                                            dtrow["ProcessPayment"] = idata.ProcessPayment;
                                            dtrow["QBCustomerName"] = idata.CustomerRef.name;
                                            dtrow["TxnDate"] = idata.TxnDate;
                                            //dtrow["QBInvID"] = idata.Line[0].LinkedTxn[0].TxnId;
                                            dtrow["QBInvID"] = QBInvID;
                                            dtrow["TxnType"] = idata.Line[0].LinkedTxn[0].TxnType;
                                            dtrow["CurrencyRef"] = idata.CurrencyRef.Value;
                                            dtrow["LineAmount"] = idata.Line[0].Amount;
                                            dtrow["PrivateNote"] = idata.PrivateNote;
                                            dtrow["PaymentTypeField"] = idata.PaymentType;

                                            ot.Rows.Add(dtrow);

                                        }
                                    }
                                }
                            }
                        }
                    }

                    ot.AcceptChanges();

                    Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));

                    if (ot.Rows.Count > 0)
                    {
                        res = SendQbOnlinePaymentData(UserId, ot);
                    }
                    ot.Dispose();
                }
                else
                {
                    res = 3;
                }

                if (paymentQuery.Count() > 0 )
                {
                    DataTable ot = CreateDataTable();

                    foreach (var idata in paymentQuery)
                    {

                        var lineList = idata.Line.ToList();

                        if (lineList.Count() > 0)
                        {
                            foreach (var lnList in lineList)
                            {
                                var LinkedTxnList = lnList.LinkedTxn.ToList();

                                if (LinkedTxnList.Count() > 0)
                                {
                                    foreach (var TxnList in LinkedTxnList)
                                    {
                                        string TxnId = TxnList.TxnId;

                                        if (!string.IsNullOrEmpty(TxnId) && TxnId == QBInvID)
                                        {

                                            //DataRow dtrow = ot.NewRow();
                                            //dtrow["CustID"] = idata.CustomerRef.Value;
                                            //dtrow["ID"] = idata.Id;
                                            //dtrow["TotalAmt"] = idata.TotalAmt;
                                            //dtrow["CreateTime"] = idata.MetaData.CreateTime;
                                            //dtrow["ProcessPayment"] = idata.ProcessPayment;
                                            //dtrow["QBCustomerName"] = idata.CustomerRef.name;
                                            //dtrow["TxnDate"] = idata.TxnDate;
                                            //dtrow["QBInvID"] = idata.Line[0].LinkedTxn[0].TxnId;
                                            //dtrow["TxnType"] = idata.Line[0].LinkedTxn[0].TxnType;
                                            //dtrow["CurrencyRef"] = idata.CurrencyRef.Value;
                                            //dtrow["LineAmount"] = idata.Line[0].Amount;
                                            //dtrow["PrivateNote"] = idata.PrivateNote;
                                            //dtrow["PaymentTypeField"] = idata.PaymentType;

                                            //ot.Rows.Add(dtrow);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    ot.AcceptChanges();

                    Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));

                    if (ot.Rows.Count > 0)
                    {
                       // res = SendQbOnlinePaymentData(UserId, ot);
                    }
                    ot.Dispose();
                }
                else
                {
                    res = 3;
                }

                return Convert.ToString(res);
            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetCustomerInvoicePaymentStatus", ex.Message);

                return Convert.ToString(ex.Message.ToString());
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <param name="strInvoiceID"></param>
        /// <returns></returns>
        public string CreateCustomerDeposit(string straccessToken, string strrealmId, Dictionary<string, string> strInvoiceID)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
                QueryService<Deposit> stateTaxCodeQueryService = new QueryService<Deposit>(context);
                //Deposit stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From Deposit MaxResults 1").FirstOrDefault<Deposit>();

                Dictionary<string, string>.KeyCollection keyColl = strInvoiceID.Keys;

                foreach (string word in keyColl)
                {
                    var clDet = GetClientPaymentRegisterDepositDetail(new Guid(word)).ToList();
                    if (clDet.Count > 0)
                    {
                        Deposit d = new Deposit();
                        //d.SyncToken = "30";
                        d.domain = "QBO";
                        //d.DepositToAccountRef = new ReferenceType { name = "Savings", Value = "36" };
                        if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].BankDepositId)) && Convert.ToString(clDet[0].BankDepositId) != "0")
                            d.DepositToAccountRef = new ReferenceType { Value = Convert.ToString(clDet[0].BankDepositId) };
                        else
                            d.DepositToAccountRef = new ReferenceType { Value = "36" };
                        d.TxnDate = Convert.ToDateTime(clDet[0].PaymentReceivedDate);
                        d.TxnDateSpecified = true;
                        //d.TotalAmt = 55;
                        //d.TotalAmtSpecified = true;
                        d.sparse = false;
                        //d.Id = "162";
                        d.CurrencyRef = new ReferenceType { name = "United States Dollar", Value = "USD" };
                        d.PrivateNote = "Submit Deposit amount to QBO";

                        List<Line> listLine = new List<Line>();
                        Line line = new Line();

                        for (int i = 0; i < clDet.Count; i++)
                        {
                            var lineItemValue = clDet[i];

                            //line.Id = "1";
                            //line.LineNum = "1";
                            line.Amount = lineItemValue.IHCDeposit;
                            line.AmountSpecified = true;
                            line.Description = lineItemValue.DepostiPaymentMemo;

                            line.DetailType = LineDetailTypeEnum.DepositLineDetail;
                            line.DetailTypeSpecified = true;

                            DepositLineDetail lifd = new DepositLineDetail();

                            lifd.Entity = new ReferenceType { Value = lineItemValue.QbCustID };

                            if (!string.IsNullOrEmpty(Convert.ToString(lineItemValue.DepositId)) && Convert.ToString(clDet[0].DepositId) != "0")
                                lifd.AccountRef = new ReferenceType { Value = Convert.ToString(lineItemValue.DepositId) };
                            else
                                lifd.AccountRef = new ReferenceType { Value = "34", name = "Opening Balance Equity" };

                            //lifd.PaymentMethodRef = new ReferenceType { Value = "1", name = "Cash" };
                            line.AnyIntuitObject = lifd;

                            //line.LinkedTxn = txnlist.ToArray();
                            listLine.Add(line);

                        }

                        d.Line = listLine.ToArray();

                        d.DocNumber = Convert.ToString(clDet[0].DirectInvoiceNum);

                        Deposit DepositAdded = service.Add(d);

                        var json = new JavaScriptSerializer().Serialize(d);

                        if (DepositAdded != null)
                        {
                            res = 1;

                            Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                            int _result = PrQuickBooks_UpdateClientRegisterDepositIdSentToQB(new Guid(word), UserId);
                            if (_result == 1)
                                res = 1;
                        }
                    }

                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }

                // function used to store QBO deposit message returned.
                PrQuickBooks_RegisterDepositMessageFromQB(1, Convert.ToString(ex), "CreateCustomerDeposit");

                return returnMessage;
            }
            finally
            {
                //custAddres = null;
                //custTel = null;
                //CustEmail = null;
                //customer = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <param name="strInvoiceID"></param>
        /// <returns></returns>
        public string CreateCustomerSaleReceipt(string straccessToken, string strrealmId, string strInvoiceID)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
                QueryService<SalesReceipt> stateTaxCodeQueryService = new QueryService<SalesReceipt>(context);
                SalesReceipt stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From SalesReceipt MaxResults 1").FirstOrDefault<SalesReceipt>();

                string[] words = strInvoiceID.Split(',');
                foreach (string word in words)
                {
                    var clDet = GetClientPaymentRegisterDepositDetail(new Guid(word)).ToList();
                    if (clDet.Count > 0)
                    {
                        SalesReceipt salesReceipt = new SalesReceipt();

                        salesReceipt.domain = "QBO";
                        salesReceipt.DepositToAccountRef = new ReferenceType { Value = "36" };
                        salesReceipt.TxnDate = Convert.ToDateTime(clDet[0].PaymentReceivedDate);
                        salesReceipt.TxnDateSpecified = true;
                        salesReceipt.sparse = false;
                        salesReceipt.CurrencyRef = new ReferenceType { name = "United States Dollar", Value = "USD" };
                        salesReceipt.PrivateNote = "Thank you for your business and have a great day!";
                        
                        salesReceipt.CustomerRef = new ReferenceType { Value = clDet[0].QbCustID };

                        List<Line> listLine = new List<Line>();
                        Line line = new Line();

                        for (int i = 0; i < clDet.Count; i++)
                        {
                            var lineItemValue = clDet[i];

                            line.Amount = lineItemValue.IHCDeposit;
                            line.AmountSpecified = true;
                            line.Description = lineItemValue.DepostiPaymentMemo;

                            line.DetailType = LineDetailTypeEnum.SalesItemLineDetail;
                            line.DetailTypeSpecified = true;

                            SalesItemLineDetail lifd = new SalesItemLineDetail();

                            if (!string.IsNullOrEmpty(Convert.ToString(lineItemValue.DepositId)) && Convert.ToString(clDet[0].DepositId) != "0")
                                lifd.ItemAccountRef = new ReferenceType { Value = Convert.ToString(lineItemValue.DepositId) };
                            else
                                lifd.ItemAccountRef = new ReferenceType { Value = "34", name = "Opening Balance Equity" };

                            line.AnyIntuitObject = lifd;

                            listLine.Add(line);

                        }

                        salesReceipt.Line = listLine.ToArray();

                        salesReceipt.DocNumber = Convert.ToString(clDet[0].DirectInvoiceNum);

                        SalesReceipt SalesReceiptAdded = service.Add(salesReceipt);

                        var json = new JavaScriptSerializer().Serialize(salesReceipt);

                        if (SalesReceiptAdded != null)
                        {
                            res = 1;

                            Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                            int _result = PrQuickBooks_UpdateClientRegisterDepositIdSentToQB(new Guid(word), UserId);
                            if (_result == 1)
                                res = 1;
                        }
                    }

                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }

                // function used to store QBO deposit message returned.
                PrQuickBooks_RegisterDepositMessageFromQB(1, Convert.ToString(ex), "CreateCustomerSaleReceipt");

                return returnMessage;
            }
            finally
            {
                //custAddres = null;
                //custTel = null;
                //CustEmail = null;
                //customer = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <param name="strInvoiceID"></param>
        /// <returns></returns>
        public string CreateCustomerRefund(string straccessToken, string strrealmId, Dictionary<string, string> strInvoiceID)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
                //QueryService<RefundReceipt> stateTaxCodeQueryService = new QueryService<RefundReceipt>(context);
                //RefundReceipt stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("select * from RefundReceipt where Id='362' MaxResults 1").FirstOrDefault<RefundReceipt>();

                foreach (string RegisterId in strInvoiceID.Keys)
                {
                    QuickBookIntuit objQB = new QuickBookIntuit();

                    var clDet = objQB.GetClientPaymentRegisterDepositDetail(new Guid(RegisterId)).ToList();
                    if (clDet.Count > 0)
                    {
                        RefundReceipt d = new RefundReceipt();
                        d.domain = "QBO";

                        if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].BankDepositId)) && Convert.ToString(clDet[0].BankDepositId) != "0")
                            d.DepositToAccountRef = new ReferenceType { Value = Convert.ToString(clDet[0].BankDepositId) };
                        else
                            d.DepositToAccountRef = new ReferenceType { Value = "36" };
                        d.TxnDate = Convert.ToDateTime(clDet[0].PaymentReceivedDate);
                        d.TxnDateSpecified = true;

                        d.sparse = false;

                        d.CurrencyRef = new ReferenceType { name = "United States Dollar", Value = "USD" };
                        d.PrivateNote = "Refund Deposit amount to QBO";

                        List<Line> listLine = new List<Line>();
                        Line line = new Line();

                        for (int i = 0; i < clDet.Count; i++)
                        {
                            var lineItemValue = clDet[i];

                            line.Amount = lineItemValue.IHCDeposit;
                            line.AmountSpecified = true;
                            line.Description = lineItemValue.DepostiPaymentMemo;

                            line.DetailType = LineDetailTypeEnum.SalesItemLineDetail;
                            line.DetailTypeSpecified = true;

                            SalesItemLineDetail lifd = new SalesItemLineDetail();

                            lifd.ItemRef = new ReferenceType { Value = "7" };

                            if (!string.IsNullOrEmpty(Convert.ToString(lineItemValue.DepositId)) && Convert.ToString(clDet[0].DepositId) != "0")
                                lifd.ItemAccountRef = new ReferenceType { Value = Convert.ToString(lineItemValue.DepositId) };
                            else
                                lifd.ItemAccountRef = new ReferenceType { Value = "34", name = "Opening Balance Equity" };

                            line.AnyIntuitObject = lifd;

                            listLine.Add(line);

                        }

                        d.Line = listLine.ToArray();
                        d.CustomerRef = new ReferenceType { Value = clDet[0].QbCustID };
                        d.CustomerMemo = new MemoRef { Value = "Thank you for your business and have a great day!" };

                        if (!string.IsNullOrEmpty(clDet[0].EmailID))
                            d.BillEmail = new EmailAddress { Address = clDet[0].EmailID };

                        d.AutoDocNumber = true;

                        RefundReceipt RefundReceiptAdded = service.Add(d);

                        var json = new JavaScriptSerializer().Serialize(d);

                        if (RefundReceiptAdded != null)
                        {
                            res = 1;

                            Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                            int _result = PrQuickBooks_UpdateClientRegisterDepositIdSentToQB(new Guid(RegisterId), UserId);
                            if (_result == 1)
                                res = 1;
                        }
                    }

                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }

                return returnMessage;
            }
            finally
            {
                //custAddres = null;
                //custTel = null;
                //CustEmail = null;
                //customer = null;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <param name="strInvoiceID"></param>
        /// <returns></returns>
        public string CreateCustomerSaleReceiptDeposit(string straccessToken, string strrealmId, Dictionary<string, string> strInvoiceID)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Tax Code for Invoice - Searching for a tax code named 'StateSalesTax' in this example
                //QueryService<SalesReceipt> stateTaxCodeQueryService = new QueryService<SalesReceipt>(context);
                //SalesReceipt stateTaxCode = stateTaxCodeQueryService.ExecuteIdsQuery("Select * From SalesReceipt MaxResults 1").FirstOrDefault<SalesReceipt>();

                QuickBookIntuit QbInst = new QuickBookIntuit();

                foreach (string RegisterId in strInvoiceID.Keys)
                {
                    var clDet = QbInst.GetClientPaymentRegisterDepositDetail(new Guid(RegisterId)).ToList();
                    if (clDet.Count > 0)
                    {
                        SalesReceipt salesReceipt = new SalesReceipt();

                        salesReceipt.domain = "QBO";

                        if (!string.IsNullOrEmpty(Convert.ToString(clDet[0].BankDepositId)) && Convert.ToString(clDet[0].BankDepositId) != "0")
                            salesReceipt.DepositToAccountRef = new ReferenceType { Value = Convert.ToString(clDet[0].BankDepositId) };
                        else
                            salesReceipt.DepositToAccountRef = new ReferenceType { Value = "36" };

                        salesReceipt.TxnDate = Convert.ToDateTime(clDet[0].PaymentReceivedDate);
                        salesReceipt.TxnDateSpecified = true;
                        salesReceipt.sparse = false;
                        salesReceipt.CurrencyRef = new ReferenceType { name = "United States Dollar", Value = "USD" };
                        salesReceipt.PrivateNote = "Thank you for your business and have a great day!";

                        salesReceipt.CustomerRef = new ReferenceType { Value = clDet[0].QbCustID };
                        salesReceipt.CustomerMemo = new MemoRef { Value = "Thank you for your business and have a great day!" };
                        if (!string.IsNullOrEmpty(clDet[0].EmailID))
                            salesReceipt.BillEmail = new EmailAddress { Address = clDet[0].EmailID };

                        List<Line> listLine = new List<Line>();
                        Line line = new Line();

                        for (int i = 0; i < clDet.Count; i++)
                        {
                            var lineItemValue = clDet[i];

                            line.Amount = lineItemValue.IHCDeposit;
                            line.AmountSpecified = true;
                            line.Description = lineItemValue.DepostiPaymentMemo;
                            
                            line.DetailType = LineDetailTypeEnum.SalesItemLineDetail;
                            line.DetailTypeSpecified = true;

                            SalesItemLineDetail lifd = new SalesItemLineDetail();

                            if (!string.IsNullOrEmpty(Convert.ToString(lineItemValue.DepositId)) && Convert.ToString(clDet[0].DepositId) != "0")
                                lifd.ItemAccountRef = new ReferenceType { Value = Convert.ToString(lineItemValue.DepositId) };
                            else
                                lifd.ItemAccountRef = new ReferenceType { Value = "34", name = "Opening Balance Equity" };

                            if (!string.IsNullOrEmpty(Convert.ToString(lineItemValue.DepositId)) && Convert.ToString(clDet[0].DepositId) != "0")
                                lifd.ItemRef = new ReferenceType { Value = Convert.ToString(lineItemValue.DepositId) };
                            else
                                lifd.ItemRef = new ReferenceType { Value = "1"};

                            lifd.Qty = 1;
                            lifd.QtySpecified = true;
                            
                            line.AnyIntuitObject = lifd;

                            listLine.Add(line);

                        }

                        salesReceipt.Line = listLine.ToArray();

                        salesReceipt.DocNumber = Convert.ToString(clDet[0].DirectInvoiceNum);

                        SalesReceipt SalesReceiptAdded = service.Add(salesReceipt);

                        var json = new JavaScriptSerializer().Serialize(salesReceipt);

                        if (SalesReceiptAdded != null)
                        {
                            res = 1;

                            Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());
                            int _result = PrQuickBooks_UpdateClientRegisterDepositIdSentToQB(new Guid(RegisterId), UserId);
                            if (_result == 1)
                                res = 1;
                        }
                    }

                }
                return Convert.ToString(res);
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }

                // function used to store QBO deposit message returned.
                PrQuickBooks_RegisterDepositMessageFromQB(1, Convert.ToString(ex), "CreateCustomerSaleReceiptDeposit");

                return returnMessage;
            }
            finally
            {
                //custAddres = null;
                //custTel = null;
                //CustEmail = null;
                //customer = null;
            }
        }

        public List<Utilities.DropDown> GetQuickBankList(string straccessToken, string strrealmId, string Query)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                //Find Account - Accounts Receivable account required
                QueryService<Account> accountQueryService = new QueryService<Account>(context);

                var account = new List<Utilities.DropDown>();
                // var account = accountQueryService.ExecuteIdsQuery("Select * From Account WHERE AccountType='Bank' MaxResults 1000").Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.Name });
                if (!string.IsNullOrEmpty(Query))
                    account = accountQueryService.ExecuteIdsQuery(Query).Select(p => new Utilities.DropDown { NID = Convert.ToInt32(p.Id), Value = p.Name }).ToList();

                return account;

            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                ////TODO: handle dupe or other....
                //var returnMessage = string.Empty;
                //var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                //if (innerException != null)
                //{
                //    returnMessage = innerException.Message;
                //}
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="QBCustID"></param>
        /// <param name="QBInvID"></param>
        public void SendCustomerInvoicePaymentStatusToQB(string straccessToken, string strrealmId, string QBCustID, string QBInvID)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);
                Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());

                ScheduleManagementDapperService.ScheduleManagementDapper dapper = new ScheduleManagementDapperService.ScheduleManagementDapper();
                Utilities.QBSendPayment qBSend = new Utilities.QBSendPayment();
                qBSend.InvoiceNumber = QBInvID;
                qBSend.UserId = UserId;
                List<Utilities.QBSendPayment> qBSendPayment = dapper.SendCustomerInvoicePaymentStatusToQB(qBSend);

                if (qBSendPayment.Count > 0)
                {
                    for (int i = 0; i < qBSendPayment.Count; i++)
                    {
                        var payment = new Payment();  //Quickbooks Payment Entity  
                        payment.TxnDate = qBSendPayment[i].PaymentReceivedDate;
                        payment.TxnDateSpecified = true;
                        payment.CustomerRef = new ReferenceType()
                        {
                            //type = Enum.GetName(typeof(objectNameEnumType), objectNameEnumType.Customer),
                            Value = Convert.ToString(qBSendPayment[i].QbCustID)
                            // name = "<CustomerName>"
                        };

                        payment.PaymentMethodRef = new ReferenceType
                        {
                            name = "Cash"
                        };

                        var linkedTxn = new List<LinkedTxn>
                        {
                            new LinkedTxn
                            {
                                TxnId = Convert.ToString(qBSendPayment[i].InvoiceNumber),
                                TxnType = Convert.ToString(objectNameEnumType.Invoice),
                            }
                        };

                        var line = new List<Line>
                        {
                            new Line
                            {
                              Amount = qBSendPayment[i].PaymentReceivedAmount,
                              LinkedTxn = linkedTxn.ToArray(),
                              AmountSpecified = true
                            }
                        };

                        payment.Line = line.ToArray();
                        payment.TotalAmt = qBSendPayment[i].PaymentReceivedAmount;
                        payment.TotalAmtSpecified = true;
                        var result = service.Add(payment);
                        if (result != null)
                        {
                            try
                            {
                                Utilities.QbSendPaymentResponse paymentResponse = new Utilities.QbSendPaymentResponse();
                                JavaScriptSerializer serializer = new JavaScriptSerializer();
                                paymentResponse.ResponseId = result.Id;
                                paymentResponse.Response = serializer.Serialize(result);
                                paymentResponse.ModifiedBy = UserId;
                                paymentResponse.QbCustID = Convert.ToString(qBSendPayment[i].QbCustID);
                                paymentResponse.QbDocInvNumber = qBSendPayment[i].InvoiceNumber;
                                paymentResponse.ClientPaymentRegisterId = qBSendPayment[i].ClientPaymentRegisterId;
                                dapper.QbSendPaymentResponseUpdate(paymentResponse);
                            }
                            catch
                            {

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "SendCustomerInvoicePaymentStatusToQB", ex.Message);

                //return Convert.ToString(ex.Message.ToString());
            }
            finally
            {

            }
        }

        /// <summary>
        /// Used to Export Time tracking data in Batch details
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="strrealmId"></param>
        /// <param name="FranchiseID"></param>
        /// <param name="BatchID"></param>
        /// <returns></returns>
        public string CreateEmployeeTimeTrackingActivityByBatchID(string straccessToken, string strrealmId, Guid FranchiseID, Guid BatchID)
        {
            string res = string.Empty;
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    var CGTimeTrackingData = QBDb.PrQuickBooks_FetchDataSendDataByBatchID(BatchID, FranchiseID).ToList();
                    if (CGTimeTrackingData.Count > 0)
                    {
                        foreach (var CGTi in CGTimeTrackingData)
                        {
                            TimeActivity timeActivity = new TimeActivity();
                            timeActivity.BillableStatus = BillableStatusEnum.NotBillable;
                            timeActivity.BillableStatusSpecified = true;

                            timeActivity.TxnDateSpecified = true;
                            timeActivity.TxnDate = DateTime.Parse(CGTi.TxDate);

                            timeActivity.StartTimeSpecified = true;
                            timeActivity.StartTime = DateTime.Parse(CGTi.ConvertStartDateTime);
                            timeActivity.EndTimeSpecified = true;
                            timeActivity.EndTime = DateTime.Parse(CGTi.ConvertEndDateTime);

                            timeActivity.HourlyRate = Convert.ToDecimal(CGTi.Rate);
                            timeActivity.HourlyRateSpecified = true;

                            timeActivity.NameOf = TimeActivityTypeEnum.Employee;
                            timeActivity.NameOfSpecified = true;

                            timeActivity.AnyIntuitObject = new ReferenceType()
                            {
                                Value = Convert.ToString(CGTi.QBEmpID),
                            };

                            //timeActivity.CustomerRef = new ReferenceType()
                            //{
                            //    Value = Convert.ToString(CGTi.QbCustID),
                            //};

                            timeActivity.ItemRef = new ReferenceType()
                            {
                                Value = Convert.ToString(CGTi.TimetrackingItem),
                            };

                            timeActivity.Description = CGTi.DescData;

                            TimeActivity timeActivityResult = service.Add(timeActivity);

                            if (timeActivityResult != null)
                            {
                                Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));
                                string GetData = timeActivityResult.Id;
                                QBDb.PrQuickBooks_UpdateQBOnlineTrackingIDByDetID(CGTi.PayrollBatchDetailId, Convert.ToInt32(GetData), UserId);

                                res = "1";
                            }
                        }
                    }
                    else
                    {
                        res = "0";
                    }
                }

                return res;
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "CreateEmployeeTimeTrackingActivityByBatchID", ex.Message);

                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
            }
        }


        /// <summary>
        /// Sending data to Qb Online by PBD ID
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="FranchiseID"></param>
        /// <param name="PBDetailID"></param>
        /// <returns></returns>
        public string CreateEmployeeTimeTrackingActivitySingle(string straccessToken, string strrealmId, Guid FranchiseID, Guid PBDetailID)
        {
            string res = string.Empty;
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var realmId = strrealmId;

                OAuth2RequestValidator oauthValidator = new OAuth2RequestValidator(accessToken.ToString());
                var context = new ServiceContext(realmId, serviceType, oauthValidator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    var CGTimeTrackingData = QBDb.PrQuickBooks_FetchDataSendSingleByPBDID(PBDetailID, FranchiseID).FirstOrDefault();

                    TimeActivity timeActivity = new TimeActivity();
                    timeActivity.BillableStatus = BillableStatusEnum.NotBillable;
                    timeActivity.BillableStatusSpecified = true;

                    timeActivity.TxnDateSpecified = true;
                    timeActivity.TxnDate = DateTime.Parse(CGTimeTrackingData.TxDate);

                    timeActivity.StartTimeSpecified = true;
                    timeActivity.StartTime = DateTime.Parse(CGTimeTrackingData.ConvertStartDateTime);
                    timeActivity.EndTimeSpecified = true;
                    timeActivity.EndTime = DateTime.Parse(CGTimeTrackingData.ConvertEndDateTime);

                    timeActivity.HourlyRate = Convert.ToDecimal(CGTimeTrackingData.Rate);
                    timeActivity.HourlyRateSpecified = true;

                    timeActivity.NameOf = TimeActivityTypeEnum.Employee;
                    timeActivity.NameOfSpecified = true;

                    timeActivity.AnyIntuitObject = new ReferenceType()
                    {
                        Value = Convert.ToString(CGTimeTrackingData.QBEmpID),
                    };

                    //timeActivity.CustomerRef = new ReferenceType()
                    //{
                    //    Value = Convert.ToString(CGTimeTrackingData.QbCustID),
                    //};

                    timeActivity.ItemRef = new ReferenceType()
                    {
                        Value = Convert.ToString(CGTimeTrackingData.TimetrackingItem),
                    };


                    timeActivity.Description = CGTimeTrackingData.DescData;
                    TimeActivity timeActivityResult = service.Add(timeActivity);

                    if (timeActivityResult != null)
                    {
                        Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));
                        string GetData = timeActivityResult.Id;
                        QBDb.PrQuickBooks_UpdateQBOnlineTrackingIDByDetID(PBDetailID, Convert.ToInt32(GetData), UserId);

                        res = "1";
                    }
                }
                return res;
            }
            catch (Intuit.Ipp.Exception.IdsException ex)
            {
                // function used to trck Quick Book Error Details.
                //SaveQuickBookErrorDetails("QuickBookIntuit", "CreateEmployeeTimeTrackingActivitySingle", ex.Message);

                //TODO: handle dupe or other....
                var returnMessage = string.Empty;
                var innerException = ((Intuit.Ipp.Exception.ValidationException)(ex.InnerException)).InnerExceptions.FirstOrDefault();
                if (innerException != null)
                {
                    returnMessage = innerException.Message;
                }
                return returnMessage;
            }
            finally
            {
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <returns></returns>
        public int GetRefreshButtonStatus(Guid? FranchiseID)
        {
            int res = 0;
            try
            {
                using (CareSmartzEntities QBDb = new CareSmartzEntities())
                {
                    TbIntuitQBKey TbQb = (from p in QBDb.TbIntuitQBKeys
                                          where p.FranchiseID == FranchiseID
                                          && p.AccessToken_QBO2 != null
                                          && p.IsActive == true && p.IsArchived == false
                                          select p).FirstOrDefault();

                    if (TbQb != null)
                        res = 1;
                    else
                        res = 0;
                }
            }
            catch (Exception ex)
            {
                //SaveQuickBookErrorDetails("QuickBookIntuit", "GetRefreshButtonStatus", ex.Message);
                throw ex;
            }
            return res;
        }

        #region Methosd to Log Status 
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageName"></param>
        /// <param name="MethodEvent"></param>
        /// <param name="MessageInfo"></param>
        /// <param name="ProcessStatus"></param>
        /// <param name="UserID"></param>
        /// <param name="InvoiceID"></param>
        /// <returns></returns>
        public Int32 SaveQuickBookErrorDetails(string PageName, string MethodName, string MessageInfo)
        {
            Int32 RetVal = 0;
            return RetVal;
            //try
            //{
            //    using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
            //    {
            //        dbConnection.Open();
            //        DynamicParameters parameters = new DynamicParameters();
            //        parameters.Add("@PageName", PageName);
            //        parameters.Add("@MethodName", MethodName);
            //        parameters.Add("@MessageInfo", MessageInfo);                    
            //        dbConnection.Query<Guid>("PrRecordErrorLog_QuickBook", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

            //        return RetVal;
            //    }
            //}
            //catch (Exception)
            //{
            //    return 0;
            //}
        }
        #endregion



        #endregion

        #region QuickBooks Dapper Part
        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <param name="UserID"></param>
        /// <param name="QBMode"></param>
        /// <returns></returns>
        public DataTable GetCallTypeforQB(Guid OfficeID, Guid UserID, int QBMode)
        {
            var dtTable = new DataTable();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@OfficeID", OfficeID);
                    parameters.Add("@UserID", UserID);
                    parameters.Add("@QBMode", QBMode);
                    IDataReader list = dbConnection.ExecuteReader("PrQB_FetchCallTypes", parameters, commandType: CommandType.StoredProcedure);
                    dtTable.Load(list);
                }
            }
            catch
            {
            }
            return dtTable;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <param name="UserID"></param>
        /// <param name="QBMode"></param>
        /// <returns></returns>
        public DataTable GetPayCodeforQB(Guid OfficeID, Guid UserID, int QBMode)
        {
            var dtTable = new DataTable();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@OfficeID", OfficeID);
                    parameters.Add("@UserID", UserID);
                    parameters.Add("@QBMode", QBMode);
                    IDataReader list = dbConnection.ExecuteReader("QB_FetchPayCode", parameters, commandType: CommandType.StoredProcedure);
                    dtTable.Load(list);
                }
            }
            catch
            {
            }
            return dtTable;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <param name="UserID"></param>
        /// <param name="QBMode"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetPayCodeQBItemList(Guid OfficeID)
        {
            List<Utilities.DropDown> lst = new List<Utilities.DropDown>();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@OfficeID", OfficeID);
                  lst = dbConnection.Query<Utilities.DropDown>("GetPayCodeQBItemList", parameters, commandType: CommandType.StoredProcedure).ToList();
                 
                }
            }
            catch
            {
            }
            return lst;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> QB_GetAccountType(Guid OfficeID)
        {
            List<Utilities.DropDown> lst = new List<Utilities.DropDown>();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@OfficeID", OfficeID);
                    lst = dbConnection.Query<Utilities.DropDown>("QB_GetAccountType", parameters, commandType: CommandType.StoredProcedure).ToList();

                }
            }
            catch
            {
            }
            return lst;
        }

        /// <summary>
        /// Used in Desktop Call Type Mapping
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <param name="XMLValues"></param>
        /// <param name="UserID"></param>
        public int InsertCallTypeMappingDesktop(Guid OfficeID, string XMLValues, Guid UserID)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@OfficeID", OfficeID);
                    parameters.Add("@XMLData", XMLValues);
                    parameters.Add("@UserID", UserID);
                    var res = dbConnection.Execute("PrQBDesktop_InsertUpdateCallTypeMapping", parameters, commandType: CommandType.StoredProcedure);
                    return 1;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        /// <summary>
        /// Used for Online QuickBooks Call Type Mapping
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <param name="XMLValues"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public int InsertUpdateCallTypeMappingOnline(Guid OfficeID, string XMLValues, Guid UserID)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@OfficeID", OfficeID);
                    parameters.Add("@XMLData", XMLValues);
                    parameters.Add("@UserID", UserID);
                    var res = dbConnection.Execute("PrQBOnline_InsertUpdateCallTypeMapping", parameters, commandType: CommandType.StoredProcedure);
                    return 1;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="QBCustID"></param>
        /// <param name="QBInvID"></param>
        /// <returns></returns>
        public string GetCustomerInvoicePaymentStatus(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret, string QBCustID, string QBInvID)
        {
            int res = 0;

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                //var service = new DataService(context);
                //var paymentQuery = service.FindAll(new Payment()).Where(q => q.CustomerRef.Value == QBCustID && q.Line[0].LinkedTxn[0].TxnId == QBInvID);

                QueryService<Payment> paymentQueryService = new QueryService<Payment>(context);
                var paymentQuery = paymentQueryService.ExecuteIdsQuery("SELECT * FROM Payment MaxResults 1000").Where(q => q.CustomerRef.Value == QBCustID && q.Line[0].LinkedTxn[0].TxnId == QBInvID).ToList();

                if (paymentQuery.Count() > 0)
                {
                    DataTable ot = CreateDataTable();

                    foreach (var idata in paymentQuery)
                    {
                        DataRow dtrow = ot.NewRow();
                        dtrow["CustID"] = idata.CustomerRef.Value;
                        dtrow["ID"] = idata.Id;
                        dtrow["TotalAmt"] = idata.TotalAmt;
                        dtrow["CreateTime"] = idata.MetaData.CreateTime;
                        dtrow["ProcessPayment"] = idata.ProcessPayment;
                        dtrow["QBCustomerName"] = idata.CustomerRef.name;
                        dtrow["TxnDate"] = idata.TxnDate;
                        dtrow["QBInvID"] = idata.Line[0].LinkedTxn[0].TxnId;
                        dtrow["TxnType"] = idata.Line[0].LinkedTxn[0].TxnType;
                        dtrow["CurrencyRef"] = idata.CurrencyRef.Value;
                        dtrow["LineAmount"] = idata.Line[0].Amount;
                        dtrow["PrivateNote"] = idata.PrivateNote;
                        dtrow["PaymentTypeField"] = idata.PaymentType;

                        ot.Rows.Add(dtrow);
                    }
                    ot.AcceptChanges();

                    Guid UserId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));

                    res = SendQbOnlinePaymentData(UserId, ot);

                    ot.Dispose();
                }
                else
                {
                    res = 3;
                }

                return Convert.ToString(res);
            }
            catch (Exception ex)
            {
                return Convert.ToString(ex.Message.ToString());
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="QBCustID"></param>
        /// <param name="QBInvID"></param>
        public void SendCustomerInvoicePaymentStatusToQB(string straccessToken, string straccessTokenSecret,
            string strrealmId, string consumerKey, string consumerSecret, string QBCustID, string QBInvID)
        {

            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);
                Guid UserId = new Guid(HttpContext.Current.Session[Utilities.Utility.UserID].ToString());

                ScheduleManagementDapperService.ScheduleManagementDapper dapper = new ScheduleManagementDapperService.ScheduleManagementDapper();
                Utilities.QBSendPayment qBSend = new Utilities.QBSendPayment();
                qBSend.InvoiceNumber = QBInvID;
                qBSend.UserId = UserId;
                List<Utilities.QBSendPayment> qBSendPayment = dapper.SendCustomerInvoicePaymentStatusToQB(qBSend);

                if (qBSendPayment.Count > 0)
                {
                    for (int i = 0; i < qBSendPayment.Count; i++)
                    {
                        var payment = new Payment();  //Quickbooks Payment Entity  
                        payment.TxnDate = qBSendPayment[i].PaymentReceivedDate;
                        payment.TxnDateSpecified = true;
                        payment.CustomerRef = new ReferenceType()
                        {
                            //type = Enum.GetName(typeof(objectNameEnumType), objectNameEnumType.Customer),
                            Value = Convert.ToString(qBSendPayment[i].QbCustID)
                            // name = "<CustomerName>"
                        };

                        payment.PaymentMethodRef = new ReferenceType
                        {
                            name = "Cash"
                        };

                        var linkedTxn = new List<LinkedTxn>
                        {
                            new LinkedTxn
                            {
                                TxnId = Convert.ToString(qBSendPayment[i].InvoiceNumber),
                                TxnType = Convert.ToString(objectNameEnumType.Invoice),
                            }
                        };

                        var line = new List<Line>
                        {
                            new Line
                            {
                              Amount = qBSendPayment[i].PaymentReceivedAmount,
                              LinkedTxn = linkedTxn.ToArray(),
                              AmountSpecified = true
                            }
                        };

                        payment.Line = line.ToArray();
                        payment.TotalAmt = qBSendPayment[i].PaymentReceivedAmount;
                        payment.TotalAmtSpecified = true;
                        var result = service.Add(payment);
                        if (result != null)
                        {
                            try
                            {
                                Utilities.QbSendPaymentResponse paymentResponse = new Utilities.QbSendPaymentResponse();
                                JavaScriptSerializer serializer = new JavaScriptSerializer();
                                paymentResponse.ResponseId = result.Id;
                                paymentResponse.Response = serializer.Serialize(result);
                                paymentResponse.ModifiedBy = UserId;
                                paymentResponse.QbCustID = Convert.ToString(qBSendPayment[i].QbCustID);
                                paymentResponse.QbDocInvNumber = qBSendPayment[i].InvoiceNumber;
                                paymentResponse.ClientPaymentRegisterId = qBSendPayment[i].ClientPaymentRegisterId;
                                dapper.QbSendPaymentResponseUpdate(paymentResponse);
                            }
                            catch
                            {

                            }
                        }
                    }
                }
            }
            catch (Exception)
            {

                //return Convert.ToString(ex.Message.ToString());
            }
            finally
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        protected DataTable CreateDataTable()
        {
            // Create a new DataTable.    
            DataTable odt = new DataTable("QBonlinePaymantRows");
            DataColumn dtColumn;
            //DataRow myDataRow;

            // Create id column  
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(Int32);
            dtColumn.ColumnName = "IncrID";
            dtColumn.AutoIncrement = true;
            dtColumn.AutoIncrementSeed = 1;
            dtColumn.AutoIncrementStep = 1;
            // Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            // Create CustID column.  -- DONE  
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(long);
            dtColumn.ColumnName = "CustID";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            // Create Payment transID column.   -- DONE  
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(long);
            dtColumn.ColumnName = "ID";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            // Create Payment Amount column.    -- DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(Decimal);
            dtColumn.ColumnName = "TotalAmt";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            // Create Payment Amount column.    -- DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(DateTime);
            dtColumn.ColumnName = "CreateTime";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            //ProcessPayment                - DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(bool);
            dtColumn.ColumnName = "ProcessPayment";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            //Customer name         -- DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(string);
            dtColumn.ColumnName = "QBCustomerName";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            // TxnDate              -- DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(DateTime);
            dtColumn.ColumnName = "TxnDate";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            //LinkedTxn         -- DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(long);
            dtColumn.ColumnName = "QBInvID";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            //TxnType       DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(string);
            dtColumn.ColumnName = "TxnType";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            //CurrencyRef       -- DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(string);
            dtColumn.ColumnName = "CurrencyRef";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            //Line Amount   -- DONE
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(Decimal);
            dtColumn.ColumnName = "LineAmount";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            /// PrivateNote
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(string);
            dtColumn.ColumnName = "PrivateNote";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);

            ///PaymentTypeField
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(string);
            dtColumn.ColumnName = "PaymentTypeField";
            /// Add column to the DataColumnCollection.  
            odt.Columns.Add(dtColumn);


            ////txnOpenBalance
            //dtColumn = new DataColumn();
            //dtColumn.DataType = typeof(Decimal);
            //dtColumn.ColumnName = "txnOpenBalance";
            ///// Add column to the DataColumnCollection.  
            //odt.Columns.Add(dtColumn);

            ////txnReferenceNumber
            //dtColumn = new DataColumn();
            //dtColumn.DataType = typeof(string);
            //dtColumn.ColumnName = "txnReferenceNumber";
            ///// Add column to the DataColumnCollection.  
            //odt.Columns.Add(dtColumn);

            ///// intuitTid
            //dtColumn = new DataColumn();
            //dtColumn.DataType = typeof(string);
            //dtColumn.ColumnName = "status";
            ///// Add column to the DataColumnCollection.  
            //odt.Columns.Add(dtColumn);


            return odt;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="Odt"></param>
        /// <returns></returns>
        protected int SendQbOnlinePaymentData(Guid UserID, DataTable Odt)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@UserID", UserID);
                    parameters.Add("@tblPaymentData", Odt.AsTableValuedParameter("dbo.tblPaymentData"));

                    var res = dbConnection.Execute("PrQbOnline_InsertUpdatePaymentData", parameters, commandType: CommandType.StoredProcedure);
                    return 1;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="straccessToken"></param>
        /// <param name="straccessTokenSecret"></param>
        /// <param name="strrealmId"></param>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <returns></returns>
        public List<Utilities.DropDown> GetClassFromQBOnline(string straccessToken, string straccessTokenSecret, string strrealmId,
            string consumerKey, string consumerSecret)
        {
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                var serviceType = IntuitServicesType.QBO;
                var accessToken = straccessToken;
                var accessTokenSecret = straccessTokenSecret;
                var realmId = strrealmId;

                var validator = new OAuthRequestValidator(accessToken, accessTokenSecret, consumerKey, consumerSecret);
                var context = new ServiceContext(realmId, serviceType, validator);

                context.IppConfiguration.BaseUrl.Qbo = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ServiceContext.BaseUrl.Qbo");
                var service = new DataService(context);

                var classQuery = service.FindAll(new Class()).Where(q => q.Active == true).Select(cls => new Utilities.DropDown { Value = Convert.ToString(cls.Id), description = cls.Name });

                return classQuery.ToList();
            }
            catch (Exception)
            {
                return new List<Utilities.DropDown>();
            }
            finally
            {

            }
        }

        #region CLASS MAPPING ::  Saveen's Code
        public List<Utilities.DropDown> GetClassListforQBDesktop(Guid OfficeID)
        {
            List<Utilities.DropDown> lst = new List<Utilities.DropDown>();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    lst = dbConnection.Query<Utilities.DropDown>("PrQuickBooks_GetCLassListForDesktopQB", new { @OfficeId = OfficeID }, commandType: CommandType.StoredProcedure).ToList();

                }
            }
            catch
            {
            }
            return lst;
        }
        public DataTable GetClassMatchingforQB(Guid OfficeID, Guid UserID, int Mode)
        {
            var dtTable = new DataTable();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@FranchiseID", OfficeID);
                    parameters.Add("@UserID", UserID);
                    IDataReader list = dbConnection.ExecuteReader("PrQuickBooks_GetTerritoryClassbyID", parameters, commandType: CommandType.StoredProcedure);
                    dtTable.Load(list);
                }
            }
            catch
            {
            }
            return dtTable;
        }

        /// <summary>
        /// Used for Online QuickBooks Call Type Mapping
        /// </summary>
        /// <param name="OfficeID"></param>
        /// <param name="XMLValues"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public int InsertUpdateClassMatching(Guid OfficeID, string XMLValues, Guid UserID)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@FranchiseID", OfficeID);
                    parameters.Add("@XMLData", XMLValues);
                    parameters.Add("@UserID", UserID);
                    var res = dbConnection.Execute("PrQBOnline_InsertTerritoryClassMapping", parameters, commandType: CommandType.StoredProcedure);
                    return 1;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }
        // DTO
        public class QBClassMatching
        {
            public Guid FranchiseId { get; set; } // PASS OFFICE ID IN THIS FIELD
            public Guid TerritoryId { get; set; }
            public String QBClassListId { get; set; }
            public Guid UserId { get; set; }

        }
        public int InsertUpdateClassMatchingQBDesktop(List<QBClassMatching> lst)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    var res = dbConnection.Execute("PrQBDesktop_InsertTerritoryClassMapping", lst, commandType: CommandType.StoredProcedure);
                    return 1;
                }
            }
            catch
            {
                return 0;
            }
        }
        // DTO PAYCODE
        public class QBPayCodeMatching
        {
            public Guid OfficeId { get; set; } // PASS OFFICE ID IN THIS FIELD
            public String QBPayCodeListId { get; set; }
            public Guid MasterTableValueID { get; set; }
            public String MasterTableValueText { get; set; }
            public String QBPayCodeListText { get; set; }
            public Guid UserId { get; set; }

        }
        /// <summary>
        /// MANDEEP SINGH 
        /// 11-13-2019
        /// </summary>
        /// <param name="lst"></param>
        /// <returns></returns>
        public int InsertUpdatePaycodeMatchingQBDesktop(List<QBPayCodeMatching> lst)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    var res = dbConnection.Execute("PrQBDesktop_InsertUpdatePaycodeMapping", lst, commandType: CommandType.StoredProcedure);
                    return 1;
                }
            }
            catch
            {
                return 0;
            }
        }
        public string GetQBOAccountType(Guid OfficeID)
        {
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@FranchiseID", OfficeID);
                    var res = dbConnection.ExecuteScalar<string>("PrGetQBOAccountType", parameters, commandType: CommandType.StoredProcedure);
                    return res;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion

        #endregion



        #region
        public List<OutPackets.StaffToSynchQuickBook> getSttaffSyncToQuickBook(Guid AgencyId)
        {
            List<OutPackets.StaffToSynchQuickBook> lstofStaffs = new List<OutPackets.StaffToSynchQuickBook>();
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AgencyId", AgencyId);
                    lstofStaffs = dbConnection.Query<OutPackets.StaffToSynchQuickBook>("PrQuickBooks_FetchStaffToSyncByID", parameters, commandType: CommandType.StoredProcedure).ToList();
                    return lstofStaffs;
                }
            }
            catch (Exception)
            {
                return new List<OutPackets.StaffToSynchQuickBook>();

            }

        }
        #endregion

        #region Fetch Deposit Detail from the Client Payment Register Procedure

        public List<InsertClientPaymentReg> GetClientPaymentRegisterDepositDetail(Guid ClientPaymentRegisterId)
        {
            List<InsertClientPaymentReg> objDepositDetail = new List<InsertClientPaymentReg>();

            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@ClientPaymentRegisterId", ClientPaymentRegisterId);
                    objDepositDetail = dbConnection.Query<InsertClientPaymentReg>("PrQuickBooks_FetchClientRegisterDepositDetail", parameters, commandType: CommandType.StoredProcedure).ToList();
                    return objDepositDetail;
                }
            }
            catch (Exception)
            {
                return new List<InsertClientPaymentReg>();

            }
        }

        public int PrQuickBooks_UpdateClientRegisterDepositIdSentToQB(Guid ClientPaymentRegisterId, Guid UserId)
        {
            int result = 0;
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@ClientPaymentRegisterId", ClientPaymentRegisterId);
                    parameters.Add("@UserID", UserId);
                    result = dbConnection.Query<int>("PrQuickBooks_UpdateClientRegisterDepositSentToQB", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                    return result;
                }
            }
            catch (Exception ex)
            {
                return 0;
                throw ex;
            }
        }

        #endregion

        public int PrQuickBooks_RegisterDepositMessageFromQB(int Mode, String ErrorMessage, String MethodName)
        {
            int result = 0;
            try
            {
                using (IDbConnection dbConnection = new SqlConnection(GlobalMultiTenancy.MultiTenancy.connectionString()))
                {
                    dbConnection.Open();
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Mode", Mode);
                    parameters.Add("@ErrorMessage", ErrorMessage);
                    parameters.Add("@MethodName", MethodName);
                    result = dbConnection.Query<int>("USP_PrQuickBooks_RegisterDepositMessageFromQB", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                    return result;
                }
            }
            catch (Exception ex)
            {
                return 0;
                throw ex;
            }
        }

        public string GetQBOAuthorizationURL(string CRFToken)
        {
            string returnAuthorizeURL = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(CRFToken))
                {
                    ClientId_QBO2 = "ABuYMERYlt0TYuoEfFJl8Zr1bUcqMLgFU1dVNlWv7vI7kX2nM6";
                    ClientSecret_QBO2 = "IgIAKV0IzOmjdzmvQhoiQDzGwka71aK4PjrSkv1e";
                    RedirectUrl_QBO2 = "http://localhost:57229/Callback";
                    Environment_QBO2 = "sandbox";

                    if (!string.IsNullOrEmpty(ClientId_QBO2) && !string.IsNullOrEmpty(ClientSecret_QBO2) && !string.IsNullOrEmpty(RedirectUrl_QBO2) && !string.IsNullOrEmpty(Environment_QBO2))
                    {
                        if (auth2Client == null)
                        {
                            auth2Client = new OAuth2Client(ClientId_QBO2, ClientSecret_QBO2, RedirectUrl_QBO2, Environment_QBO2);

                        }
                    }

                    List<OidcScopes> scopes = new List<OidcScopes>();
                    scopes.Add(OidcScopes.Accounting);

                    returnAuthorizeURL = auth2Client.GetAuthorizationURL(scopes, CRFToken);

                }

                return returnAuthorizeURL;
            }
            catch (Exception ex)
            {
                // function used to store QBO GetQBOAuthorizationURL message returned.
                PrQuickBooks_RegisterDepositMessageFromQB(1, Convert.ToString(ex), "GetQBOAuthorizationURL");

                return returnAuthorizeURL;
                
            }
        }

        public void Dispose()
        {

        }
    }
}