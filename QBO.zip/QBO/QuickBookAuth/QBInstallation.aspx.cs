﻿using IntuitQuickBooks;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Telerik.Web.UI;
using Intuit.Ipp.OAuth2PlatformClient;
using System.Web.UI.HtmlControls;

public partial class QuickBookAuth_QBInstallation : CompressViewState
{
    #region <<App Properties >>
    public string GrantUrl = GlobalMultiTenancy.MultiTenancy.ConfigurationKey("GrantUrl");
    List<Utilities.DropDown> QbCustData = new List<Utilities.DropDown>();
    List<Utilities.DropDownOnly> QbCustDataDesk = new List<Utilities.DropDownOnly>();
    List<Utilities.DropDownOnly> QbCaregiverDataDesk = new List<Utilities.DropDownOnly>();

    List<Utilities.DropDown> QBEmpData = new List<Utilities.DropDown>();
    List<Utilities.DropDown> QbData = new List<Utilities.DropDown>();
    List<Utilities.DropDown> QbItemsData = new List<Utilities.DropDown>();
    List<Utilities.DropDown> QBMatchingClass = new List<Utilities.DropDown>();
    List<Utilities.DropDown> QBMatchingPayCode = new List<Utilities.DropDown>();

    public int MyQuickBooksSettingDesktop { get; set; }
    List<HtmlGenericControl> lstNavigation = new List<HtmlGenericControl>();
    List<HtmlGenericControl> lstNavigationTargetContainer = new List<HtmlGenericControl>();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session[Utilities.Utility.UserID] == null)
        {
            FormsAuthentication.RedirectToLoginPage();
            return;
        }


        /// Check Permissions
        CheckPermission();
        MyQuickBooksSettingDesktop = CheckAgencyQuickBooksMode();

        switch (MyQuickBooksSettingDesktop)
        {
            case 1:
                lblEntity.InnerHtml = Resources.Resource.FranchiseID;
                PayCodeMapping.Visible = false;
                //ClientSetting.Visible = true;
                break;
            case 2:
                lblEntity.InnerHtml = Resources.Resource.Office;
                PayCodeMapping.Visible = true;
                //ClientSetting.Visible = true;
                break;
            default:
                if (ddlQBMode.SelectedValue == "2")
                    lblEntity.InnerHtml = Resources.Resource.Office;
                else
                {
                    lblEntity.InnerHtml = Resources.Resource.FranchiseID;
                    btnQBModeSave.Visible = true;
                }

                break;
        }
        CustomizeNavigation();
        if (!Page.IsPostBack)
        {
            if (ddlQBMode.Items.FindByValue(Convert.ToString(MyQuickBooksSettingDesktop)) != null)
            {
                ddlQBMode.SelectedIndex = -1;
                ddlQBMode.Items.FindByValue(Convert.ToString(MyQuickBooksSettingDesktop)).Selected = true;
            }

            BindFranchisees();
            CheckFranchiseCont();
            //ShowHideCaregiverLink();
            CheckQBReqToLockConnectTab(false);
            if (lnkQuickBooksMode.Enabled != true)
                CheckQBAccountSettingsDone();

            BindQuickBooksItemsForCallType();
        }
        /// Agency Check
        checkAgencyType();
        //ShowHideClassMatchingLink(Convert.ToInt32(ddlQBMode.SelectedValue));
    }

    private void CustomizeNavigation()
    {
        lstNavigation.Clear();
        // ADD LEFT NAVIGATION
        lstNavigation.Add(QuickBooksMode);
        lstNavigation.Add(StepInstallation);
        lstNavigation.Add(StepSettings);
        lstNavigation.Add(CallTypeMatching);
        lstNavigation.Add(ClassMatching);
        lstNavigation.Add(PayCodeMapping);
        lstNavigation.Add(ClientSetting);
        lstNavigation.Add(CaregiverSettings);
        lstNavigation.Add(StaffSettings);
        lstNavigation.Add(DesktopDisconnect);
        // NAVIGATION CONTAINER
        lstNavigationTargetContainer.Clear();
        lstNavigationTargetContainer.Add(QBMode);
        lstNavigationTargetContainer.Add(Installation);
        lstNavigationTargetContainer.Add(Settings);
        lstNavigationTargetContainer.Add(divCallTypeMain);
        lstNavigationTargetContainer.Add(dvPaycodeSection);
        lstNavigationTargetContainer.Add(ClientMatching);
        lstNavigationTargetContainer.Add(CaregiverMatching);
        lstNavigationTargetContainer.Add(divClassMatchingMain);
        lstNavigationTargetContainer.Add(StaffMatching);
    }


    #region Agency Check
    /// <summary>
    /// 
    /// </summary>
    protected void checkAgencyType()
    {
        using (HomeCare360Services.HomeCare360Management obj = new HomeCare360Services.HomeCare360Management())
        {
            int AgencyType = obj.checkAgencyType();

            switch (AgencyType)
            {
                case 1:
                    //divAgFr.Visible = false;
                    divAgFr.Style.Add("display", "");
                    break;
                default:
                    //divAgFr.Visible = true;
                    divAgFr.Style.Add("display", "");
                    break;
            }
        }
    }
    #endregion


    #region Check Permissions
    /// <summary>
    /// Purpose: Check Permissions
    /// </summary>
    void CheckPermission()
    {
        using (Common common = new Common())
        {
            int res = common.CheckPermission(new Guid(CaresmartzApplicationConfiguration.Privileges.Accounting.Client_Billing.QuickBooksIntegration));

            if (res == 0)
            {
                Response.Redirect("~/NoAccess.aspx");
            }
            else if (res == 2)
            {
                Response.Redirect("~/NoAccess.aspx");
            }
        }
    }
    #endregion

    #region Methods
    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    protected int BindFranchisees()
    {
        int res = 0;
        if (HttpContext.Current.Session[Utilities.Utility.UserID] != null)
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
            {
                Common.FetchFranchiseList(ddlQBFranchise, null, new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID])));
                if (ddlQBFranchise.Items.Count > 1)
                {
                    ddlQBFranchise.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));
                }
                res = 1;
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)
            {
                try
                {
                    List<Utilities.DropDown> ObjDrd = new List<Utilities.DropDown>();
                    using (ClientManagementService.ClientManagementClient Client = new ClientManagementService.ClientManagementClient())
                    {
                        Guid userId = new Guid(Convert.ToString(HttpContext.Current.Session[Utilities.Utility.UserID]));
                        ObjDrd = Client.GetOffices(userId).ToList();
                        ddlQBFranchise.Items.Clear();
                        ddlQBFranchise.ClearSelection();
                        ddlQBFranchise.DataTextField = "Value";
                        ddlQBFranchise.DataValueField = "ID";
                        ddlQBFranchise.DataSource = ObjDrd;
                        ddlQBFranchise.DataBind();
                        ddlQBFranchise.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));

                    }
                }
                catch (Exception)
                {
                    ddlQBFranchise.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));
                }
                res = 1;
            }
        }
        return res;
    }

    /// <summary>
    /// 
    /// </summary>
    protected void CheckFranchiseCont()
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            if (Session["QBFranc"] == null)
            {
                Session.Add("QBFranc", ddlQBFranchise.SelectedValue);
            }
            else
            {
                Session.Remove("QBFranc");
                Session.Add("QBFranc", ddlQBFranchise.SelectedValue);
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    protected void CheckQBReqToLockConnectTab(bool flag)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                int qbLock = QbInst.CheckQBReqTokens4Connect(new Guid(ddlQBFranchise.SelectedValue));

                switch (qbLock)
                {
                    case 1: // QuickBooks Online
                        QbOnline.Visible = true;
                        QbDesktop.Visible = false;
                        QBMode.Style.Add("display", "none");
                        lnkQuickBooksMode.Enabled = true;
                        PnlQBBtn.Visible = true;
                        PnlQBMsg.Visible = false;
                        Settings.Visible = false;
                        EnableLeftNavigation(false);
                        ActiveInactiveNavigation(StepInstallation, Installation);
                        //SetRequiredKey4OnlneSettings();
                        FetchDetailsFilled();
                        GetQuickBooksAccountsList();
                        GetQuickBooksItemsList(0);
                        BindAccountSettingsSavedLocalByID(new Guid(ddlQBFranchise.SelectedValue));
                        //dvPayroll.Visible = false;
                        ShowHideClassMatchingLink(1);
                        break;
                    case 2: // QuickBooks Desktop
                        QbOnline.Visible = false;
                        QbDesktop.Visible = false;

                        /// Step: QuickBooks Mode
                        QuickBooksMode.Attributes.Add("class", "");
                        QuickBooksMode.Attributes.Add("class", "tab-pane");

                        //QBMode.Visible = false;
                        QBMode.Style.Add("display", "none");
                        lnkQuickBooksMode.Enabled = false;

                        // Check if Account settings already done
                        int AccountSettingsLock = QbInst.CheckQBAccountSettingsDone(new Guid(ddlQBFranchise.SelectedValue));
                        if (AccountSettingsLock == 1)
                        {
                            Installation.Visible = false;
                            lnkInstallation.Enabled = false;
                            Settings.Visible = false;
                            /// Step Setting
                            ClientMatching.Visible = false;
                            EnableLeftNavigation();
                            ActiveInactiveNavigation(CallTypeMatching, divCallTypeMain);
                            BindCaresmartzSystemCallType(1);
                        }
                        else
                        {
                            if (flag == false)
                            {

                                /// Step Setting
                                ActiveInactiveNavigation(StepSettings, Settings);
                                EnableLeftNavigation(false);
                                lnkAccountSettings.Enabled = true;
                                //GetDataQWCFileDetails();
                                GetAccountListDesktop();
                                GetQBDesktopItemList(0);
                                //BindClientsToSync(1);
                                ClientMatching.Visible = false;
                                dvPayroll.Visible = true;
                                BindAccountSettingsSavedLocalByID(new Guid(ddlQBFranchise.SelectedValue));
                            }
                            else
                            {
                                /// Step: Installation
                                ActiveInactiveNavigation(StepInstallation, Installation);
                                // Step Client
                                EnableLeftNavigation();
                                GetDataQWCFileDetails();
                                BindAccountSettingsSavedLocalByID(new Guid(ddlQBFranchise.SelectedValue));
                            }
                        }
                        ShowHideClassMatchingLink(2);
                        break;
                    case 3:// Online when Connection is done

                        QbOnline.Visible = true;
                        QbDesktop.Visible = false;

                        /// Step: QuickBooks Mode
                        QuickBooksMode.Attributes.Add("class", "");
                        QuickBooksMode.Attributes.Add("class", "tab-pane");

                        //QBMode.Visible = false;
                        QBMode.Style.Add("display", "none");
                        lnkQuickBooksMode.Enabled = true;

                        // Check if Account settings already done
                        int AccountSettingsLockOnline = QbInst.CheckQBAccountSettingsDone(new Guid(ddlQBFranchise.SelectedValue));

                        if (AccountSettingsLockOnline == 1)
                        {
                            Installation.Visible = false;
                            lnkInstallation.Enabled = false;
                            Settings.Visible = false;
                            ClientMatching.Visible = false;
                            EnableLeftNavigation();
                            BindCaresmartzSystemCallType(1);
                            ActiveInactiveNavigation(CallTypeMatching, divCallTypeMain);
                        }
                        else
                        {
                            Installation.Visible = false;
                            ActiveInactiveNavigation(StepSettings, Settings);
                            EnableLeftNavigation();
                            /// Method calling
                            //SetRequiredKey4OnlneSettings();
                            FetchDetailsFilled();
                            GetQuickBooksAccountsList();
                            GetQuickBooksItemsList(0);
                            BindAccountSettingsSavedLocalByID(new Guid(ddlQBFranchise.SelectedValue));
                        }
                        ShowHideClassMatchingLink(1);
                        break;
                    case 4: // QuickBooks Desktop
                        QbOnline.Visible = false;
                        QbDesktop.Visible = true;
                        //QBMode.Visible = false;
                        QBMode.Style.Add("display", "none");
                        lnkQuickBooksMode.Enabled = false;
                        /// Step: Installation
                        ActiveInactiveNavigation(StepInstallation, Settings);
                        Installation.Visible = true;
                        lnkInstallation.Enabled = true;
                        EnableLeftNavigation(false);
                        GetDataQWCFileDetails();
                        Settings.Visible = false;
                        ClientMatching.Visible = false;
                        break;
                    default:
                        lnkQuickBooksMode.Enabled = true;
                        //QBMode.Visible = true;
                        QBMode.Style.Add("display", "");
                        lnkInstallation.Enabled = false;
                        Installation.Visible = false;
                        PnlQBBtn.Visible = false;
                        PnlQBMsg.Visible = false;
                        EnableLeftNavigation(false);
                        break;
                }
            }
        }
        else
        {
            lnkQuickBooksMode.Enabled = true;
            //QBMode.Visible = true;
            QBMode.Style.Add("display", "");
            //StepInstallation.Attributes.Add("class", "active");
            lnkInstallation.Enabled = false;
            Installation.Visible = false;
            PnlQBBtn.Visible = false;
            PnlQBMsg.Visible = false;
            EnableLeftNavigation(false);

        }
    }
    /// <summary>
    /// 
    /// </summary>
    protected void CheckQBAccountSettingsDone()
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                int AccountSettingsLock = QbInst.CheckQBAccountSettingsDone(new Guid(ddlQBFranchise.SelectedValue));
                if (AccountSettingsLock == 1)
                {
                    // Step Client
                    lnkClientMatching.Enabled = true;
                    Installation.Visible = false;
                    GetQuickBooksCustomerList();
                    BindClientsToSync(1);
                    Settings.Visible = false;

                    ActiveInactiveNavigation(ClientMatching, ClientMatching);
                }
                else
                {
                    lnkClientMatching.Enabled = false;
                }
            }
        }
        else
        {
            lnkClientMatching.Enabled = false;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public void FetchDetailsFilled()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            if (ddlQBFranchise.SelectedValue != "-1")
            {
                Guid gFranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                var qbd = QbInst.GetQBDataByFranchise(gFranchiseID, gFranchiseID).ToList();
                if (qbd.Count() != 0)
                {
                    switch (Convert.ToString(qbd[0].QuickBooksMode))
                    {
                        case "2": // QuickBooks Desktop
                            if (ddlQBMode.Items.FindByValue(Convert.ToString(qbd[0].QuickBooksMode)) != null)
                            {
                                ddlQBMode.SelectedIndex = -1;
                                ddlQBMode.Items.FindByValue(Convert.ToString(qbd[0].QuickBooksMode)).Selected = true;
                            }

                            DesktopDisconnect.Visible = true;
                            break;
                        case "1": // QuickBooks Online
                            if (ddlQBMode.Items.FindByValue(Convert.ToString(qbd[0].QuickBooksMode)) != null)
                            {
                                ddlQBMode.SelectedIndex = -1;
                                ddlQBMode.Items.FindByValue(Convert.ToString(qbd[0].QuickBooksMode)).Selected = true;
                            }
                            hdnConsumerkey.Value = qbd[0].ConsumerKey;
                            hdnConsumerSecret.Value = qbd[0].ConsumerSecret;
                            hdnCompanyID.Value = qbd[0].IntuitcompanyID;
                            hdnAppToken.Value = qbd[0].AppToken;
                            hdnaccessToken.Value = qbd[0].AccessToken;
                            hdnaccessTokenSecret.Value = qbd[0].AccessTokenSecret;

                            //#region Quick Book Auth 2 Code Section
                            // checking Access Token validity
                            int result = DateTime.Compare(Convert.ToDateTime(qbd[0].AccessTokenExpiresAt_QBO2), DateTime.UtcNow);

                            if (result > 0)
                            {
                                // taking auth 2 access token value in hidden fields
                                hdnAccessToken_QBO2.Value = qbd[0].AccessToken_QBO2;
                                hdnAccessTokenExpireAt_QBO2.Value = Convert.ToString(qbd[0].AccessTokenExpiresAt_QBO2);
                                hdnRealmID_QBO2.Value = qbd[0].RealmId_QBO2;
                                hdnRefreshToken_QBO2.Value = qbd[0].RefreshToken_QBO2;
                                hdnRefreshTokenExpireAt_QBO2.Value = Convert.ToString(qbd[0].RefreshTokenExpiresAt_QBO2);
                            }
                            else
                            {

                                // checking Refress Token validity
                                int result_RefreshToken = DateTime.Compare(Convert.ToDateTime(qbd[0].RefreshTokenExpiresAt_QBO2), DateTime.UtcNow.AddDays(10));

                                if (result_RefreshToken > 0)
                                {
                                    if (!String.IsNullOrEmpty(qbd[0].RefreshToken_QBO2))
                                    {
                                        Guid? gFranchiseID2 = new Guid(ddlQBFranchise.SelectedValue);

                                        // function used to get new token based on refresh token
                                        QbInst.GetAuth_RefreshTokensAsync(gFranchiseID2, Convert.ToString(qbd[0].RefreshToken_QBO2), Convert.ToString(qbd[0].RealmId_QBO2));

                                        // call the function again to get the updated access tokens
                                        FetchDetailsFilled();
                                    }
                                }
                                else
                                {
                                    if (!String.IsNullOrEmpty(qbd[0].RefreshToken_QBO2))
                                    {
                                        Guid? gFranchiseID2 = new Guid(ddlQBFranchise.SelectedValue);

                                        // function used to get new token based on refresh token
                                        QbInst.GetAuth_RefreshTokensAsync(gFranchiseID2, Convert.ToString(qbd[0].RefreshToken_QBO2), Convert.ToString(qbd[0].RealmId_QBO2));

                                        // call the function again to get the updated access tokens
                                        FetchDetailsFilled();
                                    }
                                }
                            }

                            //#endregion

                            DesktopDisconnect.Visible = false;
                            break;
                    }

                    //CheckQBReqToLockConnectTab();
                }
                else
                {
                    SetRequiredKey4OnlneSettings();
                }
            }
            else
            {
                SetRequiredKey4OnlneSettings();
            }
        }
    }


    /// <summary>
    /// Get QuickBooks Account Heads
    /// </summary>
    protected void GetQuickBooksAccountsList()
    {
        List<Utilities.DropDown> QbAccountsData = new List<Utilities.DropDown>();

        List<Utilities.DropDown> QbBankData = new List<Utilities.DropDown>();

        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            //QbAccountsData = QbInst.GetQuickBooksAccountsList(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
            //   hdnConsumerkey.Value, hdnConsumerSecret.Value).ToList().OrderBy(p => p.Value).ToList();

            string BankAccountTypeQuery = QbInst.GetQBOAccountType(ConvertToGUID(ddlQBFranchise.SelectedValue));

            //QbBankData = QbInst.GetQuickBankList(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
            //   hdnConsumerkey.Value, hdnConsumerSecret.Value, BankAccountTypeQuery).ToList().OrderBy(p => p.Value).ToList();

            QbBankData = QbInst.GetQuickBankList(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value, BankAccountTypeQuery).ToList().OrderBy(p => p.Value).ToList();

            QbAccountsData = QbInst.GetQuickBooksAccountsList(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value
               ).ToList().OrderBy(p => p.Value).ToList();

            ddlQbAccList.Items.Clear();
            ddlQbAccList.DataSource = QbAccountsData;
            ddlQbAccList.DataTextField = "Value";
            ddlQbAccList.DataValueField = "NID";
            ddlQbAccList.DataBind();

            ddlQbAccList.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));

            //ddlDepositList.Items.Clear();
            //ddlDepositList.DataSource = QbAccountsData;
            //ddlDepositList.DataTextField = "Value";
            //ddlDepositList.DataValueField = "NID";
            //ddlDepositList.DataBind();

            //ddlDepositList.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));


            /// Online Payroll
            DdQbpayroll.Items.Clear();
            DdQbpayroll.DataSource = QbAccountsData;
            DdQbpayroll.DataTextField = "Value";
            DdQbpayroll.DataValueField = "NID";
            DdQbpayroll.DataBind();

            DdQbpayroll.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));


            ddlDepositBankAccount.Items.Clear();
            ddlDepositBankAccount.DataSource = QbBankData;
            ddlDepositBankAccount.DataTextField = "Value";
            ddlDepositBankAccount.DataValueField = "NID";
            ddlDepositBankAccount.DataBind();

            ddlDepositBankAccount.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));

        }
    }


    /// <summary>
    /// Items online Items data
    /// </summary>
    protected void GetQuickBooksItemsList(int Mode)
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            //QbItemsData = QbInst.GetQuickBooksItemsList(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
            //   hdnConsumerkey.Value, hdnConsumerSecret.Value).ToList().OrderBy(p => p.Value).ToList();

            QbItemsData = QbInst.GetQuickBooksItemsList(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value).ToList().OrderBy(p => p.Value).ToList();

            /// Services
            //BindDropdowns(QbItemsData, ddlQbItemService); Commented As per CS360-3850
            if (Mode == 0)
            {
                /// Expense
                BindDropdowns(QbItemsData, ddlQbExp);
                /// Credit Cards
                BindDropdowns(QbItemsData, ddlQBCC);
                /// Payroll items
                BindDropdowns(QbItemsData, DDPayItemService);
                /// Sale Receipt items
                BindDropdowns(QbItemsData, ddlDepositList);

            }
            else if (Mode == 1)
            {
                BindDropdowns(QbItemsData, ddlPopupQBCallTypeItemsList);
            }
        }
    }

    /// <summary>
    /// Common method to bind dropdown
    /// </summary>
    /// <param name="Data"></param>
    /// <param name="ddl"></param>
    private void BindDropdowns(List<Utilities.DropDown> Data, DropDownList ddl)
    {
        ddl.Items.Clear();
        ddl.DataSource = Data;
        ddl.DataTextField = "Value";
        ddl.DataValueField = "NID";
        ddl.DataBind();

        ddl.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="FranchiseID"></param>
    private void BindAccountSettingsSavedLocalByID(Guid FranchiseID)
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            var AccountData = QbInst.FetchAccountSettingsByID(FranchiseID).ToList();

            if (AccountData.Count > 0)
            {
                if (AccountData[0].NameSetting == 1)
                {
                    RdoFirtNameFirst.Checked = true;
                }
                else
                {
                    RdoLastNameFirst.Checked = true;
                }

                if (AccountData[0].QBMode == 1) // Online
                {
                    /// Accounts
                    if (ddlQbAccList.Items.FindByValue(Convert.ToString(AccountData[0].AccountReceivables)) != null)
                    {
                        ddlQbAccList.SelectedIndex = -1;
                        ddlQbAccList.Items.FindByValue(Convert.ToString(AccountData[0].AccountReceivables)).Selected = true;
                    }

                    ///Items Commented As per CS360-3850
                    //if (ddlQbItemService.Items.FindByValue(Convert.ToString(AccountData[0].ItemServices)) != null)
                    //{
                    //    ddlQbItemService.SelectedIndex = -1;
                    //    ddlQbItemService.Items.FindByValue(Convert.ToString(AccountData[0].ItemServices)).Selected = true;
                    //}

                    /// Expense
                    if (ddlQbExp.Items.FindByValue(Convert.ToString(AccountData[0].ItemExpenses)) != null)
                    {
                        ddlQbExp.SelectedIndex = -1;
                        ddlQbExp.Items.FindByValue(Convert.ToString(AccountData[0].ItemExpenses)).Selected = true;
                    }

                    /// Credit Card
                    if (ddlQBCC.Items.FindByValue(Convert.ToString(AccountData[0].CCInvoice)) != null)
                    {
                        ddlQBCC.SelectedIndex = -1;
                        ddlQBCC.Items.FindByValue(Convert.ToString(AccountData[0].CCInvoice)).Selected = true;
                    }

                    /// Accounts Payable
                    if (DdQbpayroll.Items.FindByValue(Convert.ToString(AccountData[0].AccountPayableOnline)) != null)
                    {
                        DdQbpayroll.SelectedIndex = -1;
                        DdQbpayroll.Items.FindByValue(Convert.ToString(AccountData[0].AccountPayableOnline)).Selected = true;
                    }

                    /// Payroll Item service
                    if (DDPayItemService.Items.FindByValue(Convert.ToString(AccountData[0].ItmServicePayOnline)) != null)
                    {
                        DDPayItemService.SelectedIndex = -1;
                        DDPayItemService.Items.FindByValue(Convert.ToString(AccountData[0].ItmServicePayOnline)).Selected = true;
                    }

                    /// Deposit Item service
                    if (ddlDepositList.Items.FindByValue(Convert.ToString(AccountData[0].DepositId)) != null)
                    {
                        ddlDepositList.SelectedIndex = -1;
                        ddlDepositList.Items.FindByValue(Convert.ToString(AccountData[0].DepositId)).Selected = true;
                    }

                    /// Bank Deposit Item service
                    if (ddlDepositBankAccount.Items.FindByValue(Convert.ToString(AccountData[0].BankDepositId)) != null)
                    {
                        ddlDepositBankAccount.SelectedIndex = -1;
                        ddlDepositBankAccount.Items.FindByValue(Convert.ToString(AccountData[0].BankDepositId)).Selected = true;
                    }
                }
                else if (AccountData[0].QBMode == 2) // Desktop
                {
                    /// Accounts
                    if (ddlQbAccList.Items.FindByValue(Convert.ToString(AccountData[0].QBDskAccountReceivables)) != null)
                    {
                        ddlQbAccList.SelectedIndex = -1;
                        ddlQbAccList.Items.FindByValue(Convert.ToString(AccountData[0].QBDskAccountReceivables)).Selected = true;
                    }

                    ///Items Commented As per CS360-3850
                    //if (ddlQbItemService.Items.FindByValue(Convert.ToString(AccountData[0].QBDskItemServices)) != null)
                    //{
                    //    ddlQbItemService.SelectedIndex = -1;
                    //    ddlQbItemService.Items.FindByValue(Convert.ToString(AccountData[0].QBDskItemServices)).Selected = true;
                    //}

                    /// Expense
                    if (ddlQbExp.Items.FindByValue(Convert.ToString(AccountData[0].QBDskItemExpenses)) != null)
                    {
                        ddlQbExp.SelectedIndex = -1;
                        ddlQbExp.Items.FindByValue(Convert.ToString(AccountData[0].QBDskItemExpenses)).Selected = true;
                    }

                    /// Credit Card
                    if (ddlQBCC.Items.FindByValue(Convert.ToString(AccountData[0].QBDskCCInvoice)) != null)
                    {
                        ddlQBCC.SelectedIndex = -1;
                        ddlQBCC.Items.FindByValue(Convert.ToString(AccountData[0].QBDskCCInvoice)).Selected = true;
                    }

                    /// Accounts Payable
                    if (DdQbpayroll.Items.FindByValue(Convert.ToString(AccountData[0].QBDskTopAccountsPayable)) != null)
                    {
                        DdQbpayroll.SelectedIndex = -1;
                        DdQbpayroll.Items.FindByValue(Convert.ToString(AccountData[0].QBDskTopAccountsPayable)).Selected = true;
                    }

                    /// Payroll Item service
                    if (DDPayItemService.Items.FindByValue(Convert.ToString(AccountData[0].QBDskPayrollItemService)) != null)
                    {
                        DDPayItemService.SelectedIndex = -1;
                        DDPayItemService.Items.FindByValue(Convert.ToString(AccountData[0].QBDskPayrollItemService)).Selected = true;
                    }

                    ///DEPOSITE LIST
                    if (ddlDepositList.Items.FindByValue(Convert.ToString(AccountData[0].QBDesktop_DepositId)) != null)
                    {
                        ddlDepositList.SelectedValue = AccountData[0].QBDesktop_DepositId;
                    }
                    /// DEPOSITE BANK ACCOUNT
                    if (ddlDepositBankAccount.Items.FindByValue(Convert.ToString(AccountData[0].QBDesktop_BankDepositId)) != null)
                    {
                        ddlDepositBankAccount.SelectedValue = AccountData[0].QBDesktop_BankDepositId;
                    }
                }
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private void ResetMethod()
    {
        lnkQuickBooksMode.Enabled = true;
        //QBMode.Visible = true;
        QBMode.Style.Add("display", "");
        //StepInstallation.Attributes.Add("class", "active");

        lnkInstallation.Enabled = false;
        Installation.Visible = false;

        /// Step Setting
        StepSettings.Attributes.Add("class", "");
        Settings.Attributes.Add("class", "tab-pane");

        // Step Client
        ClientSetting.Attributes.Add("class", "");
        ClientMatching.Attributes.Add("class", "tab-pane");

        StaffSettings.Attributes.Add("class", "");
        StaffMatching.Attributes.Add("class", "tab-pane");

        //lnkAccountSettings.Enabled = false;
        //lnkClientMatching.Enabled = false;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="strMessage"></param>
    protected void JSMessage(string strMessage)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), "alert('" + strMessage + "');", true);
    }
    protected void JSMessage(string strMessage, int Msg)
    {
        string alertScript = string.Empty;
        switch (Msg)
        {
            case 1:
                alertScript = String.Format("MessageToastr.Success('{0}');", strMessage);
                ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), alertScript, true);
                break;
            case 2:
                alertScript = String.Format("MessageToastr.Success('{0}');", strMessage);
                ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), alertScript, true);
                break;
            case 3:
                alertScript = String.Format("MessageToastr.Validation('{0}');", strMessage);
                ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), alertScript, true);
                break;
            case 4:
                alertScript = String.Format("MessageToastr.Error('{0}');", strMessage);
                ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), alertScript, true);
                break;
            default:
                alertScript = String.Format("MessageToastr.Success('{0}');", strMessage);
                ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), alertScript, true);
                break;
        }

    }
    /// <summary>
    /// 
    /// </summary>
    protected void BindClientsToSync(int mode)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                var QbCliLst = QbInst.FetchClienttoSyncWithQB(new Guid(ddlQBFranchise.SelectedValue));
                rgClientSyncQb.DataSource = QbCliLst;
                if (mode == 1)
                    rgClientSyncQb.Rebind();

            }
        }
        ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), "ShowHideHeader();", true);
    }
    #endregion

    #region Dropdown Selection
    /// <summary>
    /// As per new Changes commented code
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlQBFranchise_SelectedIndexChanged(object sender, EventArgs e)
    {
        PreparePage();
        CheckQBReqToLockConnectTab(false);
    }
    #endregion

    #region QuickBooks Method
    /// <summary>
    /// 
    /// </summary>
    protected void GetQuickBooksCustomerList()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
            {
                SetRequiredKey4OnlneSettings();
                //QbCustData = QbInst.GetQuickBooksCustomerList(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
                //hdnConsumerkey.Value, hdnConsumerSecret.Value).OrderBy(p => p.Value).ToList();

                QbCustData = QbInst.GetQuickBooksCustomerList(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value).OrderBy(p => p.Value).ToList();

                //bind popup dropdown form qb clients
                ddlPopupQBCustomers.DataTextField = "Value";
                ddlPopupQBCustomers.DataValueField = "NID";
                ddlPopupQBCustomers.DataSource = QbCustData;
                ddlPopupQBCustomers.DataBind();
                ddlPopupQBCustomers.Items.Insert(0, new ListItem("Don't Match", "-1"));
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)
            {
                QbCustDataDesk = QbInst.GetQuickBookCustomerListDesktop();
                //QbCaregiverDataDesk = QbInst.GetQuickBookCaregiverListDesktop(new Guid(ddlQBFranchise.SelectedValue));
                //bind popup dropdown form qb clients
                ddlPopupQBCustomers.DataTextField = "Value";
                ddlPopupQBCustomers.DataValueField = "NID";
                ddlPopupQBCustomers.DataSource = QbCustDataDesk;
                ddlPopupQBCustomers.DataBind();
                ddlPopupQBCustomers.Items.Insert(0, new ListItem("Don't Match", "-1"));


            }
        }
    }

    /// <summary>
    /// QB Online Employee
    /// </summary>
    protected void GetQuickBooksEmployeeList()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
            {
                SetRequiredKey4OnlneSettings();
                //QBEmpData = QbInst.GetQuickBooksEmployeeList(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
                //hdnConsumerkey.Value, hdnConsumerSecret.Value).OrderBy(p => p.Value).ToList();

                QBEmpData = QbInst.GetQuickBooksEmployeeList(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value).OrderBy(p => p.Value).ToList();

                //bind popup dropdown form qb employeees
                ddlPopupQBCaregiverList.DataTextField = "Value";
                ddlPopupQBCaregiverList.DataValueField = "NID";
                ddlPopupQBCaregiverList.DataSource = QBEmpData;
                ddlPopupQBCaregiverList.DataBind();
                ddlPopupQBCaregiverList.Items.Insert(0, new ListItem("Don't Match", "-1"));
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)
            {
                QbCaregiverDataDesk = QbInst.GetQuickBookCaregiverListDesktop(new Guid(ddlQBFranchise.SelectedValue));
                //bind popup dropdown form qb employeees
                ddlPopupQBCaregiverList.DataTextField = "Value";
                ddlPopupQBCaregiverList.DataValueField = "NID";
                ddlPopupQBCaregiverList.DataSource = QbCaregiverDataDesk;
                ddlPopupQBCaregiverList.DataBind();
                ddlPopupQBCaregiverList.Items.Insert(0, new ListItem("Don't Match", "-1"));


            }
        }
    }

    #endregion

    #region RadGrid Events
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void rgClientSyncQb_ItemDataBound(object sender, Telerik.Web.UI.GridItemEventArgs e)
    {
        if (e.Item.ItemType == GridItemType.Item || e.Item.ItemType == GridItemType.AlternatingItem)
        {
            List<Utilities.DropDown> lstoddlQbCust = new List<Utilities.DropDown>();
            List<Utilities.DropDownOnly> lstoddlQbCust_1 = new List<Utilities.DropDownOnly>();
            //DropDownList oddlQbCust = (DropDownList)(e.Item.FindControl("ddlQBCliList"));
            HiddenField ohdnQbCustID = (HiddenField)(e.Item.FindControl("hdnQbCustID"));
            HiddenField ohdnClientName = (HiddenField)(e.Item.FindControl("hdnClientName"));

            LinkButton lnkbtnQBCliList = (LinkButton)(e.Item.FindControl("lnkbtnQBCliList"));
            HiddenField hdnlnkbtnQBCliList = (HiddenField)e.Item.FindControl("hdnlnkbtnQBCliList");

            System.Web.UI.HtmlControls.HtmlInputCheckBox oChkbox = (System.Web.UI.HtmlControls.HtmlInputCheckBox)(e.Item.FindControl("Chkbox"));
            System.Web.UI.HtmlControls.HtmlGenericControl ochkMsg = (System.Web.UI.HtmlControls.HtmlGenericControl)(e.Item.FindControl("chkMsg"));
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
            {
                //oddlQbCust.DataTextField = "Value";
                //oddlQbCust.DataValueField = "NID";
                //oddlQbCust.DataSource = QbCustData;
                //oddlQbCust.DataBind();
                //oddlQbCust.Items.Insert(0, new ListItem("Don't Match", "-1"));

                lstoddlQbCust = QbCustData;
            }
            else
            {
                //oddlQbCust.DataTextField = "Value";
                //oddlQbCust.DataValueField = "NID";
                //oddlQbCust.DataSource = QbCustDataDesk;
                //oddlQbCust.DataBind();
                //oddlQbCust.Items.Insert(0, new ListItem("Don't Match", "-1"));

                lstoddlQbCust_1 = QbCustDataDesk;
            }

            if (ohdnQbCustID.Value != null && ohdnQbCustID.Value != "")
            {
                //if (oddlQbCust.Items.FindByValue(ohdnQbCustID.Value) != null)
                //{
                //    oddlQbCust.SelectedIndex = -1;
                //    oddlQbCust.Items.FindByValue(ohdnQbCustID.Value).Selected = true;
                //    oChkbox.Style.Add("display", "none");
                //    ochkMsg.Style.Add("display", "none");
                //    //oChkbox.Visible = false;
                //    //ochkMsg.Visible = false;
                //}
                if (lnkbtnQBCliList != null && hdnlnkbtnQBCliList != null)
                {
                    if (lstoddlQbCust != null && lstoddlQbCust.Count > 0)
                    {
                        foreach (Utilities.DropDown itm in lstoddlQbCust)
                        {
                            if (ohdnQbCustID.Value == "-1")
                            {
                                if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "ClientName"))))
                                {
                                    lnkbtnQBCliList.Text = itm.Value;
                                    hdnlnkbtnQBCliList.Value = itm.NID.ToString();
                                    oChkbox.Style.Add("display", "none");
                                    ochkMsg.Style.Add("display", "none");
                                    break;
                                }
                            }
                            else if (itm.NID == Convert.ToInt32(ohdnQbCustID.Value))
                            {
                                lnkbtnQBCliList.Text = itm.Value;
                                hdnlnkbtnQBCliList.Value = itm.NID.ToString();
                                oChkbox.Style.Add("display", "none");
                                ochkMsg.Style.Add("display", "none");
                                break;
                            }
                        }
                    }
                    else if (lstoddlQbCust_1 != null && lstoddlQbCust_1.Count > 0)
                    {
                        foreach (Utilities.DropDownOnly itm in lstoddlQbCust_1)
                        {
                            if (ohdnQbCustID.Value == "-1")
                            {
                                if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "ClientName"))))
                                {
                                    lnkbtnQBCliList.Text = itm.Value;
                                    hdnlnkbtnQBCliList.Value = itm.NID.ToString();
                                    oChkbox.Style.Add("display", "none");
                                    ochkMsg.Style.Add("display", "none");
                                    break;
                                }
                            }
                            else if (itm.NID.Trim().ToLower() == ohdnQbCustID.Value.Trim().ToLower())
                            {
                                lnkbtnQBCliList.Text = itm.Value;
                                hdnlnkbtnQBCliList.Value = itm.NID.ToString();
                                oChkbox.Style.Add("display", "none");
                                ochkMsg.Style.Add("display", "none");
                                break;
                            }
                        }
                    }
                }
            }
            else
            {
                if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
                {
                    //if (oddlQbCust.Items.Count > 1)
                    //{
                    //    foreach (ListItem itm in oddlQbCust.Items)
                    //    {
                    //        oddlQbCust.SelectedIndex = -1;
                    //        if (itm.Text.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "ClientName"))))
                    //        {
                    //            itm.Selected = true;
                    //            oChkbox.Style.Add("display", "none");
                    //            ochkMsg.Style.Add("display", "none");
                    //            //oChkbox.Visible = false;
                    //            //ochkMsg.Visible = false;
                    //            break;
                    //        }
                    //    }
                    //}

                    if (lstoddlQbCust != null && lstoddlQbCust.Count > 0)
                    {
                        foreach (Utilities.DropDown itm in lstoddlQbCust)
                        {
                            if (itm.Value.Trim().ToLower() ==
                                Convert.ToString(DataBinder.Eval(e.Item.DataItem, "ClientName")).Trim().ToLower())
                            {
                                lnkbtnQBCliList.Text = itm.Value;
                                hdnlnkbtnQBCliList.Value = itm.NID.ToString();
                                oChkbox.Style.Add("display", "none");
                                ochkMsg.Style.Add("display", "none");
                                break;
                            }
                        }
                    }
                }
            }

            if (String.IsNullOrEmpty(lnkbtnQBCliList.Text.Trim()))
            {
                lnkbtnQBCliList.Text = "Don't Match";
                hdnlnkbtnQBCliList.Value = "-1";
            }

        }
        else if (e.Item.ItemType == GridItemType.Footer)
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1) // Online
            {
                UpdateClientsAndCaregiversForQBOnline(1);
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2) // Desktop
            {
                UpdateClientsAndCaregiversForQBDesktop(1);
            }
        }
    }

    protected void rgClientSyncQb_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        GetQuickBooksCustomerList();
        BindClientsToSync(0);
    }



    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlQBCliList_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlist = (DropDownList)sender;
        GridDataItem item = (GridDataItem)ddlist.NamingContainer;

        System.Web.UI.HtmlControls.HtmlInputCheckBox oChkbox = (System.Web.UI.HtmlControls.HtmlInputCheckBox)(item.FindControl("Chkbox"));
        System.Web.UI.HtmlControls.HtmlGenericControl ochkMsg = (System.Web.UI.HtmlControls.HtmlGenericControl)(item.FindControl("chkMsg"));
        HiddenField ohdnQbCustID = (HiddenField)(item.FindControl("hdnQbCustID"));

        if (ddlist.SelectedValue == "-1")
        {
            oChkbox.Style.Add("display", "");
            ochkMsg.Style.Add("display", "");
            //oChkbox.Visible = true;
            //ochkMsg.Visible = true;
        }
        else
        {
            oChkbox.Style.Add("display", "none");
            ochkMsg.Style.Add("display", "none");
            //oChkbox.Visible = false;
            //ochkMsg.Visible = false;
        }
    }
    #endregion

    #region Click Events
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lnkClientMatching_Click(object sender, EventArgs e)
    {
        ActiveInactiveNavigation(ClientSetting, ClientMatching);
        GetQuickBooksCustomerList();
        BindClientsToSync(1);
        Settings.Visible = false;
        CaregiverMatching.Visible = false;
        StaffMatching.Visible = false;
        divCallTypeMain.Visible = false;
        ClientMatching.Visible = true;
        lnkClassMatching.Enabled = true;
        divClassMatchingMain.Visible = false;
        hdnGridMode.Value = "3";

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lnkAccountSettings_Click(object sender, EventArgs e)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            //FetchDetailsFilled();
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                Guid gFranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                var qbd = QbInst.GetQBDataByFranchise(gFranchiseID, gFranchiseID).ToList();
                if (qbd.Count() != 0)
                {
                    if (Convert.ToString(qbd[0].QuickBooksMode) == "1")
                    {
                        GetQuickBooksAccountsList();
                        GetQuickBooksItemsList(0);
                    }
                    else
                    {
                        GetAccountListDesktop();
                        GetQBDesktopItemList(0);
                    }
                    BindAccountSettingsSavedLocalByID(new Guid(ddlQBFranchise.SelectedValue));
                }
            }

            /// Step ClientMatching
            ActiveInactiveNavigation(StepSettings, Settings);
            Settings.Visible = true;
            divCallTypeMain.Visible = false;
            ClientMatching.Visible = false;
            CaregiverMatching.Visible = false;
            StaffMatching.Visible = false;
            Installation.Visible = false;
            divClassMatchingMain.Visible = false;

        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void BtnAccountSettings_Click(object sender, EventArgs e)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            if (Session[Utilities.Utility.UserID] != null)
            {
                Guid UserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));

                using (QuickBookIntuit QbInst = new QuickBookIntuit())
                {
                    Guid gFranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                    var qbd = QbInst.GetQBDataByFranchise(gFranchiseID, gFranchiseID).ToList();
                    if (qbd.Count() != 0)
                    {
                        int RdoChk = 2;

                        if (RdoFirtNameFirst.Checked)
                        {
                            RdoChk = 1;
                        }
                        else if (RdoLastNameFirst.Checked)
                        {
                            RdoChk = 2;
                        }

                        int res = 0;

                        if (Convert.ToString(qbd[0].QuickBooksMode) == "1")
                        {
                            int? depositId = null;
                            if (Convert.ToString(ddlDepositList.SelectedValue) != "-1")
                                depositId = Convert.ToInt32(ddlDepositList.SelectedValue);
                            int? BankdepositId = null;
                            if (Convert.ToString(ddlDepositBankAccount.SelectedValue) != "-1")
                                BankdepositId = Convert.ToInt32(ddlDepositBankAccount.SelectedValue);

                            res = QbInst.InsertUpdateQBAccountRequiredSettings(new Guid(ddlQBFranchise.SelectedValue), RdoChk,
                            Convert.ToInt32(ddlQbAccList.SelectedValue), 0,
                            Convert.ToInt32(ddlQbExp.SelectedValue), Convert.ToInt32(ddlQBCC.SelectedValue),
                            UserId, 1, null, null, null, null, null, null,
                            Convert.ToInt32(DdQbpayroll.SelectedValue), Convert.ToInt32(DDPayItemService.SelectedValue), Convert.ToInt32(depositId), Convert.ToInt32(BankdepositId));
                        }
                        else
                        {
                            string PayrollPayableAccount = string.Empty;
                            string PayrollItemService = string.Empty;

                            if (!string.IsNullOrEmpty(DdQbpayroll.SelectedValue))
                            {
                                PayrollPayableAccount = DdQbpayroll.SelectedValue;
                            }
                            else
                            {
                                PayrollPayableAccount = null;
                            }

                            if (!string.IsNullOrEmpty(DDPayItemService.SelectedValue))
                            {
                                PayrollItemService = DDPayItemService.SelectedValue;
                            }
                            else
                            {
                                PayrollItemService = null;
                            }
                            res = QbInst.InsertUpdateQBAccountRequiredSettings(new Guid(ddlQBFranchise.SelectedValue), RdoChk,
                            0, 0, 0, 0, UserId, 2, ddlQbAccList.SelectedValue, null,
                            ddlQbExp.SelectedValue, ddlQBCC.SelectedValue, PayrollPayableAccount, PayrollItemService, 0, 0, 0, 0, ddlDepositList.SelectedValue, ddlDepositBankAccount.SelectedValue);
                        }

                        if (res == 1)
                        {
                            JSMessage("Account settings completed successfully.", 1);
                            Installation.Visible = false;
                            lnkInstallation.Enabled = false;
                            Settings.Visible = false;
                            /// Step Setting
                            ClientMatching.Visible = false;
                            EnableLeftNavigation();
                            ActiveInactiveNavigation(CallTypeMatching, divCallTypeMain);
                            BindCaresmartzSystemCallType(1);

                        }
                    }
                }
            }
        }
    }

    private void EnableLeftNavigation(Boolean IsEnable = true)
    {
        lnkStaffMatching.Enabled =
                         lnkCallTypeMatching.Enabled =
                         lnkCaregiverMatching.Enabled =
                         lnkClientMatching.Enabled =
                         lnkClassMatching.Enabled =
                         lnkPayCodeMapping.Enabled =
                         lnkAccountSettings.Enabled = IsEnable;
    }

    public class QbClient
    {
        public string ClientName { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnExportClientQB_Click(object sender, EventArgs e)
    {
        try
        {


            StringBuilder strClDisplay = new StringBuilder();
            List<QbClient> qbclient = new List<QbClient>();
            //StringBuilder strlocalClUpd = new StringBuilder();
            Dictionary<string, string> openWith = new Dictionary<string, string>();
            //int checkDuplicat = 0;
            foreach (GridDataItem dataItem in rgClientSyncQb.MasterTableView.Items)
            {
                HiddenField oHdnClientDisplayID = (HiddenField)dataItem.FindControl("HdnClientDisplayID");
                HiddenField ohdnQbCustID = (HiddenField)dataItem.FindControl("hdnQbCustID");
                HiddenField hdnclientname = (HiddenField)dataItem.FindControl("hdnClientName");
                //DropDownList oddlQBCliList = (DropDownList)dataItem.FindControl("ddlQBCliList");

                HiddenField hdnlnkbtnQBCliList = (HiddenField)dataItem.FindControl("hdnlnkbtnQBCliList");

                System.Web.UI.HtmlControls.HtmlInputCheckBox oChkbox = (System.Web.UI.HtmlControls.HtmlInputCheckBox)dataItem.FindControl("Chkbox");

                if (oChkbox.Checked)// && string.IsNullOrEmpty(ohdnQbCustID.Value))
                {
                    if (string.IsNullOrEmpty(Convert.ToString(strClDisplay).Trim()))
                    {
                        strClDisplay.Append(oHdnClientDisplayID.Value);
                        QbClient qbobj = new QbClient();
                        qbobj.ClientName = Convert.ToString(hdnclientname.Value);
                        qbclient.Add(qbobj);
                    }
                    else
                    {
                        strClDisplay.Append("," + oHdnClientDisplayID.Value);
                        QbClient qbobj = new QbClient();
                        qbobj.ClientName = Convert.ToString(hdnclientname.Value);
                        qbclient.Add(qbobj);

                    }
                }

                ////stop value using from dropdown dated: 20th June, 2019 start
                //if (oddlQBCliList.SelectedValue != "-1")
                //{
                //    //if (ohdnQbCustID.Value.Trim() != oddlQBCliList.SelectedValue.Trim())
                //    //{
                //    openWith.Add(oHdnClientDisplayID.Value, oddlQBCliList.SelectedValue);
                //    //}
                //}
                ////stop value using from dropdown dated: 20th June, 2019 end
                //start value using from hidden field dated: 20th June, 2019 start
                if (hdnlnkbtnQBCliList != null)
                {
                    if (!openWith.ContainsKey(oHdnClientDisplayID.Value))
                    {
                        openWith.Add(oHdnClientDisplayID.Value, hdnlnkbtnQBCliList.Value);
                    }
                }
                //start value using from hidden field dated: 20th June, 2019 end
            }
            var duplicatesqbCleints = qbclient.GroupBy(s => s.ClientName.ToLower()).SelectMany(grp => grp.Skip(1)).ToList();
            var item = duplicatesqbCleints.GroupBy(x => x.ClientName.ToLower()).Distinct().OrderBy(x => x.Key).ToList();

            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {

                if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)// for online quickbook
                {
                    if (item.Count > 0)
                    {
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < item.Count; i++)
                        {
                            sb.Append("<tr><td>" + (i + 1).ToString() + ".</td><td>" + item[i].Key + "</td></tr>");
                        }
                        tbbodyqbclients.InnerHtml = sb.ToString();
                        ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), "showpopup();", true);
                    }
                    else
                    {
                        string strStatus = string.Empty;
                        var AccountData = QbInst.FetchAccountSettingsByID(new Guid(ddlQBFranchise.SelectedValue)).ToList();

                        if (!string.IsNullOrEmpty(Convert.ToString(strClDisplay)))
                        {
                            //strStatus = QbInst.CreateCustomer(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
                            //   hdnConsumerkey.Value, hdnConsumerSecret.Value, Convert.ToString(strClDisplay),
                            //   Convert.ToInt32(AccountData[0].NameSetting), new Guid(ddlQBFranchise.SelectedValue));

                            strStatus = QbInst.CreateCustomer(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value, Convert.ToString(strClDisplay),
                               Convert.ToInt32(AccountData[0].NameSetting), new Guid(ddlQBFranchise.SelectedValue));
                        }

                        /// If both side client exists and match
                        int iRes = 0;
                        if (openWith.Count() > 0)
                        {
                            iRes = QbInst.ClientSyncUpdateLocal(openWith, new Guid(ddlQBFranchise.SelectedValue));
                        }

                        if (strStatus == "1")
                        {
                            JSMessage(Resources.Resource.QBClientMatching, 2);
                            GetQuickBooksCustomerList();
                            BindClientsToSync(1);
                        }
                        else if (iRes == 1)
                        {
                            JSMessage(Resources.Resource.QBClientMatching, 2);
                            GetQuickBooksCustomerList();
                            BindClientsToSync(1);
                        }
                    }
                }
                else// for desktop
                {
                    int response = 0;
                    int iRes = 0;
                    Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));

                    response = QbInst.USP_Insert_QB_Desktop_Mapping(strClDisplay.ToString(), LoginUserId, LoginUserId);

                    if (openWith.Count() > 1)
                    {
                        iRes = QbInst.ClientSyncUpdateLocal(openWith, new Guid(ddlQBFranchise.SelectedValue));
                    }
                    if (response == 1)
                    {
                        JSMessage(Resources.Resource.QBClientMatching, 2);
                        lnkCaregiverMatching_Click(null, null);
                    }
                    //GetQuickBooksCustomerList();
                    //BindClientsToSync(1);

                }
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    /// <summary>
    /// Method to show Telerik Confirm box
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Install_OnCommand(Object sender, CommandEventArgs e)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                Guid gFranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                var qbd = QbInst.GetQBDataByFranchise(gFranchiseID, gFranchiseID).ToList();
                if (qbd.Count() != 0)
                {
                    MyQuickBooksSettingDesktop = Convert.ToInt32(qbd[0].QuickBooksMode);
                    switch (Convert.ToString(qbd[0].QuickBooksMode))
                    {
                        case "2": // QuickBooks Desktop
                            //RadWindowManager1.RadConfirm("Would you like to start new QuickBooks Installation? Note: Disconnecting the QuickBooks Account will completely disconnect your QuickBooks account with CareSmartz360, i.e.All the logs regarding the invoices exported to QuickBooks will be cleared as well.It will NOT impact the invoice(s) created in CareSmartz360 or Invoice(s) in QuickBooks in any manner.", "confirmCallBackFn", 400, 100, null, "QuickBooks Installation");
                            //BindFranchisees();
                            //CheckFranchiseCont();
                            PreparePage();
                            break;
                        case "1": // QuickBooks Online
                            RadWindowManager1.RadConfirm("Would you like to start new QuickBooks Installation? Note: Disconnecting the QuickBooks Account will completely disconnect your QuickBooks account with CareSmartz360, i.e.All the logs regarding the invoices exported to QuickBooks will be cleared as well.It will NOT impact the invoice(s) created in CareSmartz360 or Invoice(s) in QuickBooks in any manner.", "confirmCallBackFn", 400, 100, null, "QuickBooks Installation");
                            break;
                    }
                }
            }
        }
    }
    #endregion

    #region WebMethods
    [System.Web.Services.WebMethod(EnableSession = true)]
    public static int QBRestInstallationMethod()
    {
        int res;
        if (!string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["QBFranc"])))
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                res = QbInst.ResetQuickBooksKeyToNewInstallationByID(new Guid(Convert.ToString(HttpContext.Current.Session["QBFranc"])));

                if (res == 1)
                {

                }
            }
        }
        else
        {
            res = 0;
        }

        return res;
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnQBModeSave_Click(object sender, EventArgs e)
    {
        Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
        Guid gFranchiseID = new Guid(ddlQBFranchise.SelectedValue);
        int res = 0;
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            Int32 AgencyId = 0;
            using (HomeCare360Services.HomeCare360Management hm = new HomeCare360Services.HomeCare360Management())
            {
                AgencyId = hm.AgencyID();
            }
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
                {
                    SetRequiredKey4OnlneSettings();
                    res = QbInst.InsertUpdateQuickBooksSettings(gFranchiseID, Convert.ToInt32(ddlQBMode.SelectedValue),
                        hdnConsumerkey.Value, hdnConsumerSecret.Value, hdnAppToken.Value, LoginUserId, AgencyId, hdnClientId_QBO2.Value, hdnClientSecret_QBO2.Value, hdnRedirectURL_QBO2.Value, hdnEnvironment_QBO2.Value);
                }
                else
                {

                    res = QbInst.InsertUpdateQuickBooksSettings(gFranchiseID, Convert.ToInt32(ddlQBMode.SelectedValue),
                        null, null, null, LoginUserId, AgencyId, hdnClientId_QBO2.Value, hdnClientSecret_QBO2.Value, hdnRedirectURL_QBO2.Value, hdnEnvironment_QBO2.Value);
                }
            }

            if (res == 1)
            {
                CheckQBReqToLockConnectTab(false);
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    protected void GetDataQWCFileDetails()
    {
        Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
        Guid gFranchiseID = new Guid(ddlQBFranchise.SelectedValue);
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            Int32 AgencyId = 0;
            using (HomeCare360Services.HomeCare360Management hm = new HomeCare360Services.HomeCare360Management())
            {
                AgencyId = hm.AgencyID();
            }

            using (QuickBookIntuit QbGet = new QuickBookIntuit())
            {
                var res = QbGet.GetQBDesktopQWCFileDetails(gFranchiseID, LoginUserId, AgencyId).ToList();
                if (res.Count > 0)
                {
                    lnkDwnloadFile.Text = Convert.ToString(res[0].AgencyName);
                    lblAgID.Text = Convert.ToString(res[0].AgencyID);
                    lblAgPSID.Text = Convert.ToString(res[0].AgencyID);
                    hdnAppURL.Value = Convert.ToString(res[0].AppURL);
                    hdnDomainURL.Value = Convert.ToString(res[0].DomainURL);
                    hdnAppSupport.Value = Convert.ToString(res[0].AppSupport);
                }
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lnkDwnloadFile_Click(object sender, EventArgs e)
    {
        QWCFileCreateAndDownloadByID();

        /// Step: Installation
        Installation.Visible = false;
        lnkInstallation.Enabled = false;
        ActiveInactiveNavigation(StepSettings, Settings);
        //lnkInstallation.Enabled = true;
        lnkAccountSettings.Enabled = true;
        lnkClientMatching.Enabled = true;
        //GetDataQWCFileDetails();
        GetAccountListDesktop();
        GetQBDesktopItemList(0);
        ClientMatching.Visible = false;
        //BindClientsToSync(1);
        Settings.Visible = true;
        ClientMatching.Visible = false;
        CheckQBReqToLockConnectTab(false);
    }

    /// <summary>
    /// 
    /// </summary>
    protected void QWCFileCreateAndDownloadByID()
    {
        try
        {
            /// Save download details
            using (QuickBookIntuit QbGet = new QuickBookIntuit())
            {
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                Guid gFranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                QbGet.QBDownloadFlagUpdateByID(gFranchiseID, LoginUserId);
            }

            XmlDocument doc = new XmlDocument();
            doc.LoadXml("<QBWCXML>" +
                "<AppName>QuickBooks Integrator:" + ddlQBFranchise.SelectedItem.Text + "</AppName>" +
                "<AppID></AppID>" +
                "<AppURL>" + hdnAppURL.Value + "</AppURL>" +
                "<AppDescription>" + hdnDomainURL.Value + "</AppDescription>" +
                "<AppSupport>" + hdnAppSupport.Value + "</AppSupport>" +
                "<UserName>" + "{" + lblAgID.Text + "}" + "</UserName>" +
                "<OwnerID>" + "{" + Convert.ToString(Guid.NewGuid()) + "}" + "</OwnerID>" +
                "<FileID>" + "{" + Convert.ToString(Guid.NewGuid()) + "}" + "</FileID>" +
                "<QBType>QBFS</QBType>" +
                "<IsReadOnly>IsReadOnly</IsReadOnly>" +
                "</QBWCXML>");

            System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex("[*'\",_&#^@]");

            //Create an XML declaration. 
            XmlDeclaration xmldecl;
            xmldecl = doc.CreateXmlDeclaration("1.0", "UTF-8\" standalone=\"yes", "");

            //Add the new node to the document.
            XmlElement root = doc.DocumentElement;
            doc.InsertBefore(xmldecl, root);
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=" + reg.Replace(lnkDwnloadFile.Text, string.Empty) + ".qwc");
            Response.AddHeader("Content-Length", doc.OuterXml.Length.ToString());
            Response.Charset = "";
            Response.ContentType = "text/xml";
            Response.ContentEncoding = Encoding.UTF8;
            Response.Output.Write(doc.OuterXml);
            HttpContext.Current.Response.Flush();

            #region Commented Code
            //Response.Close();

            //XmlDocument xmlDoc = new XmlDocument();
            //XmlNode XmlDeclaration = xmlDoc.CreateXmlDeclaration("1.0", "UTF-8\" standalone=\"yes", "");
            ////XmlNode XmlDeclaration = xmlDoc.CreateXmlDeclaration("1.0", "utf-8", null);
            //xmlDoc.AppendChild(XmlDeclaration);


            //XmlNode rootNode = xmlDoc.CreateElement("QBWCXML");
            //xmlDoc.AppendChild(rootNode);

            ///// AppName
            //XmlNode qbAppName = xmlDoc.CreateElement("AppName");
            //qbAppName.InnerText = "CareSmartz360";
            //rootNode.AppendChild(qbAppName);

            ///// AppID
            //XmlNode qbAppID = xmlDoc.CreateElement("AppID");
            //qbAppID.InnerText = "";
            //rootNode.AppendChild(qbAppID);

            ///// AppURL
            //XmlNode qbAppURL = xmlDoc.CreateElement("AppURL");
            //qbAppURL.InnerText = hdnAppURL.Value;
            //rootNode.AppendChild(qbAppURL);

            ///// AppDescription
            //XmlNode qbAppDescription = xmlDoc.CreateElement("AppDescription");
            //qbAppDescription.InnerText = hdnDomainURL.Value;
            //rootNode.AppendChild(qbAppDescription);


            ///// AppSupport
            //XmlNode qbAppSupport = xmlDoc.CreateElement("AppSupport");
            //qbAppSupport.InnerText = hdnAppSupport.Value;
            //rootNode.AppendChild(qbAppSupport);

            ///// UserName
            //XmlNode qbUserName = xmlDoc.CreateElement("UserName");
            //qbUserName.InnerText = "{" + lblAgID.Text + "}";
            //rootNode.AppendChild(qbUserName);

            ///// OwnerID
            //XmlNode qbOwnerID = xmlDoc.CreateElement("OwnerID");
            //qbOwnerID.InnerText = "{" + lblAgID.Text + "}";
            //rootNode.AppendChild(qbOwnerID);

            ///// FileID
            //XmlNode qbFileID = xmlDoc.CreateElement("FileID");
            //qbFileID.InnerText = "{" + Convert.ToString(Guid.NewGuid()) + "}";
            //rootNode.AppendChild(qbFileID);

            ///// QBType
            //XmlNode qbQBType = xmlDoc.CreateElement("QBType");
            //qbQBType.InnerText = "QBFS";
            //rootNode.AppendChild(qbQBType);

            ///// IsReadOnly
            //XmlNode qbIsReadOnly = xmlDoc.CreateElement("IsReadOnly");
            //qbIsReadOnly.InnerText = "IsReadOnly";
            //rootNode.AppendChild(qbIsReadOnly);

            ////Download the .qwc file.
            //Response.Clear();
            //Response.Buffer = true;
            //Response.AddHeader("content-disposition", "attachment;filename=" + lnkDwnloadFile.Text + ".qwc");
            //Response.Charset = "";
            //Response.ContentType = "text/xml";
            //Response.ContentEncoding = Encoding.UTF8;
            //Response.Output.Write(rootNode.OuterXml);
            //Response.Flush();
            //Response.Close();
            //Response.End();
            #endregion
        }
        catch (Exception)
        {

        }
        finally
        {
            HttpContext.Current.Response.End();
        }
    }

    /// <summary>
    /// Method used to get required keys for Online from web config
    /// </summary>
    protected void SetRequiredKey4OnlneSettings()
    {
        if (!string.IsNullOrEmpty(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerKey")))
        {
            hdnConsumerkey.Value = Convert.ToString(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerKey"));
            hdnConsumerSecret.Value = Convert.ToString(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ConsumerSecret"));
            hdnAppToken.Value = Convert.ToString(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("AppToken"));

            // Quick Book Online 2.0 API Store in Table "TbIntuitQBKey"
            //hdnClientId_QBO2.Value = Convert.ToString(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientId_QBO2"));
            //hdnClientSecret_QBO2.Value = Convert.ToString(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("ClientSecret_QBO2"));
            //hdnRedirectURL_QBO2.Value = Convert.ToString(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("RedirectUrl_QBO2"));
            //hdnEnvironment_QBO2.Value = Convert.ToString(GlobalMultiTenancy.MultiTenancy.ConfigurationKey("Environment_QBO2"));
        }
    }

    /// <summary>
    /// Used to load QuickBooks desktop Accounts list from local Database
    /// </summary>
    protected void GetAccountListDesktop()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));

            if (LoginUserId != Guid.Empty)
            {
                var QbAccountsDesktopData = QbInst.GetQuickBooksDesktopAccountsList(new Guid(ddlQBFranchise.SelectedValue));

                /// Invoice
                ddlDepositList.Items.Clear();
                ddlQbAccList.Items.Clear();
                ddlQbAccList.DataSource = QbAccountsDesktopData;
                ddlQbAccList.DataTextField = "AccountsName";
                ddlQbAccList.DataValueField = "QbAccountsID";
                ddlQbAccList.DataBind();

                ddlDepositList.DataTextField = "";
                ddlDepositList.DataValueField = "";
                ddlDepositList.DataSource = null;
                ddlDepositList.DataBind();

                ddlDepositList.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));
                ddlQbAccList.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));

                /// Payroll
                DdQbpayroll.Items.Clear();
                DdQbpayroll.DataSource = QbAccountsDesktopData;
                DdQbpayroll.DataTextField = "AccountsName";
                DdQbpayroll.DataValueField = "QbAccountsID";
                DdQbpayroll.DataBind();

                DdQbpayroll.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));

                // Show the deposit drop down for desktop option.
                dvDeposit.Visible = true;

                //BIND ACCOUNT TYPE
                GetAccountTypeListDesktop();

            }
        }
    }
    /// <summary>
    /// MANDEEP SINGH
    /// BANK NAME FOR YOUR DEPOSIT: 11-13-2019
    /// </summary>
    protected void GetAccountTypeListDesktop()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));

            if (LoginUserId != Guid.Empty)
            {
                var QbAccountsDesktopData = QbInst.QB_GetAccountType(new Guid(ddlQBFranchise.SelectedValue));

                /// Bank Name for your deposit:
                ddlDepositBankAccount.Items.Clear();
                ddlDepositBankAccount.Items.Clear();
                ddlDepositBankAccount.DataSource = QbAccountsDesktopData;
                ddlDepositBankAccount.DataTextField = "description";
                ddlDepositBankAccount.DataValueField = "value";
                ddlDepositBankAccount.DataBind();
                ddlDepositBankAccount.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));


            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    protected void GetQBDesktopItemList(int Mode)
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));

            if (LoginUserId != Guid.Empty && ddlQBFranchise.SelectedValue != "-1")
            {
                var QbAccountsDesktopData = QbInst.GetQuickBooksDesktopItemList(new Guid(ddlQBFranchise.SelectedValue));

                QbData = QbAccountsDesktopData.Select(p => new Utilities.DropDown { Value = Convert.ToString(p.QbItemID), description = p.ItemName }).ToList();

                /// Services
                //BindDropdownsDesktop(QbData, ddlQbItemService); Commented As per CS360-3850

                if (Mode == 0)
                {
                    /// Expense
                    BindDropdownsDesktop(QbData, ddlQbExp);
                    /// Credit Cards
                    BindDropdownsDesktop(QbData, ddlQBCC);
                    /// Payroll Item service
                    BindDropdownsDesktop(QbData, DDPayItemService);
                    ddlDepositList.Items.Clear();
                    ddlDepositList.DataSource = QbData;
                    ddlDepositList.DataTextField = "description";
                    ddlDepositList.DataValueField = "Value";
                    ddlDepositList.DataBind();
                    ddlDepositList.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));
                }
                else if (Mode == 1)
                {
                    BindDropdownsDesktop(QbData, ddlPopupQBCallTypeItemsList);

                }
                dvDepositBankAccount.Visible = false;
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="Data"></param>
    /// <param name="ddl"></param>
    private void BindDropdownsDesktop(List<Utilities.DropDown> Data, DropDownList ddl)
    {
        ddl.Items.Clear();
        ddl.DataSource = Data;
        ddl.DataTextField = "description";
        ddl.DataValueField = "Value";
        ddl.DataBind();

        ddl.Items.Insert(0, new ListItem(Resources.Resource.PleaseSelect, "-1"));
    }

    protected void lnkInstallation_Click(object sender, EventArgs e)
    {


        if (MyQuickBooksSettingDesktop == 1)
            CheckQBReqToLockConnectTab(true);
        else if (MyQuickBooksSettingDesktop == 2)
        {
            BindFranchisees();
            CheckFranchiseCont();
            PreparePage();
        }
        ActiveInactiveNavigation(StepInstallation, Installation);
    }

    protected void ddlQBMode_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindFranchisees();
        CheckFranchiseCont();
        if (ddlQBMode.SelectedValue.ToString() == "1")
        {
            StaffSettings.Visible = true;
            PayCodeMapping.Visible = false;
        }
        else if (ddlQBMode.SelectedValue.ToString() == "2")
        {
            StaffSettings.Visible = false;
            PayCodeMapping.Visible = true;
        }
        else
        {
            StaffSettings.Visible = false;
            PayCodeMapping.Visible = false;
        }
        //PreparePage();
        //ShowHideCaregiverLink();
    }

    protected void ShowHideCaregiverLink()
    {
        //if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
        //{
        //    CaregiverSettings.Visible = false;
        //    dvPayroll.Visible = false;
        //}
        //else
        //{
        //    CaregiverSettings.Visible = true;
        //    dvPayroll.Visible = true;
        //}
    }

    /// <summary>
    /// 
    /// </summary>
    protected void PreparePage()
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            ResetMethod();
            if (Session["QBFranc"] == null)
            {
                Session.Add("QBFranc", ddlQBFranchise.SelectedValue);
            }
            else
            {
                Session.Remove("QBFranc");
                Session.Add("QBFranc", ddlQBFranchise.SelectedValue);
            }

            FetchDetailsFilled();
            btnQBModeSave.Visible = true;
        }
        else
        {
            lnkQuickBooksMode.Enabled = true;
            QBMode.Style.Add("display", "");
            lnkInstallation.Enabled = false;
            Installation.Visible = false;
            PnlQBBtn.Visible = false;
            PnlQBMsg.Visible = true;
            lnkAccountSettings.Enabled = false;
            lnkClientMatching.Enabled = false;
            btnQBModeSave.Visible = false;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    protected void GetOnloadData()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            var qbd = QbInst.GetQuickBooksSaveDetails().ToList();
            if (qbd.Count() != 0)
            {
                switch (Convert.ToString(qbd[0].QuickBooksMode))
                {
                    case "2": // QuickBooks Desktop
                        if (ddlQBMode.Items.FindByValue(Convert.ToString(qbd[0].QuickBooksMode)) != null)
                        {
                            ddlQBMode.SelectedIndex = -1;
                            ddlQBMode.Items.FindByValue(Convert.ToString(qbd[0].QuickBooksMode)).Selected = true;
                        }
                        break;
                    case "1": // QuickBooks Online
                        if (ddlQBMode.Items.FindByValue(Convert.ToString(qbd[0].QuickBooksMode)) != null)
                        {
                            ddlQBMode.SelectedIndex = -1;
                            ddlQBMode.Items.FindByValue(Convert.ToString(qbd[0].QuickBooksMode)).Selected = true;
                        }
                        break;
                }

                BindFranchisees();

                if (ddlQBFranchise.Items.FindByValue(Convert.ToString(qbd[0].FranchiseID)) != null)
                {
                    ddlQBFranchise.SelectedIndex = -1;
                    ddlQBFranchise.Items.FindByValue(Convert.ToString(qbd[0].FranchiseID)).Selected = true;
                }

                CheckFranchiseCont();
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    protected Int32 CheckAgencyQuickBooksMode()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            Int32 AgencyId = 0;
            using (HomeCare360Services.HomeCare360Management hm = new HomeCare360Services.HomeCare360Management())
            {
                AgencyId = hm.AgencyID();
            }

            var QbMode = QbInst.CheckQuickBooksTypeByAgencyID(AgencyId);

            if (QbMode.Count > 0)
            {
                ddlQBMode.Enabled = false;
                dvOpt.Visible = true;
                return Convert.ToInt32(QbMode[0].QuickBooksMode);
            }
            else
            {
                ddlQBMode.Enabled = true;
                if (ddlQBMode.SelectedValue == "0")
                {
                    dvOpt.Visible = false;
                    StaffSettings.Visible = false;
                    PayCodeMapping.Visible = false;
                }
                else
                    dvOpt.Visible = true;
                return 0;
            }
        }
    }

    /// <summary>
    /// Disconnect selected office from desktop
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lnkDesktopDisconnect_Click(object sender, EventArgs e)
    {
        RadWindowManager1.RadConfirm("Would you like to start new QuickBooks Installation? Note: Disconnecting the QuickBooks Account will completely disconnect your QuickBooks account with CareSmartz360, i.e.All the logs regarding the invoices exported to QuickBooks will be cleared as well.It will NOT impact the invoice(s) created in CareSmartz360 or Invoice(s) in QuickBooks in any manner.", "confirmCallBackFn", 400, 100, null, "QuickBooks Installation");
    }

    protected void lnkCaregiverMatching_Click(object sender, EventArgs e)
    {
        ClientMatching.Visible = false;
        /// Step ClientMatching
        CaregiverMatching.Visible = true;
        StaffMatching.Visible = false;
        /// Step Caregiver Matching
        ActiveInactiveNavigation(CaregiverSettings, CaregiverMatching);
        GetQuickBooksEmployeeList();
        BindCaregiverToSync(1);
        Settings.Visible = false;
        ClientMatching.Visible = false;
        divCallTypeMain.Visible = false;
        CaregiverMatching.Visible = true;
        lnkClassMatching.Enabled = true;
        divClassMatchingMain.Visible = false;
        hdnGridMode.Value = "4";
    }

    /// <summary>
    /// Caregiver List bind to Grid
    /// </summary>
    /// <param name="mode"></param>
    protected void BindCaregiverToSync(int mode)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                var QbCliLst = QbInst.FetchCaregivertoSyncWithQB(new Guid(ddlQBFranchise.SelectedValue));
                rgCaregiverMatchingList.DataSource = QbCliLst;
                if (mode == 1)
                    rgCaregiverMatchingList.Rebind();

            }
        }
        ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), "ShowHideHeader();", true);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void rgCaregiverMatchingList_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        //GetQuickBooksCustomerList();
        BindCaregiverToSync(0);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void rgCaregiverMatchingList_ItemDataBound(object sender, GridItemEventArgs e)
    {
        if (e.Item.ItemType == GridItemType.Item || e.Item.ItemType == GridItemType.AlternatingItem)
        {

            List<Utilities.DropDown> lstoddlQbEmployee = new List<Utilities.DropDown>();
            List<Utilities.DropDownOnly> lstoddlQbEmployee_1 = new List<Utilities.DropDownOnly>();

            //DropDownList oddlQBCaregiverList = (DropDownList)(e.Item.FindControl("ddlQBCaregiverList"));
            HiddenField ohdnQbCaregiverID = (HiddenField)(e.Item.FindControl("hdnQbCaregiverID"));
            HiddenField ohdnCaregiverName = (HiddenField)(e.Item.FindControl("hdnCaregiverName"));

            LinkButton lnkbtnQBCaregiverList = (LinkButton)(e.Item.FindControl("lnkbtnQBCaregiverList"));
            HiddenField hdnlnkbtnQBCaregiverList = (HiddenField)e.Item.FindControl("hdnlnkbtnQBCaregiverList");

            System.Web.UI.HtmlControls.HtmlInputCheckBox oChkbox = (System.Web.UI.HtmlControls.HtmlInputCheckBox)(e.Item.FindControl("Chkbox"));
            System.Web.UI.HtmlControls.HtmlGenericControl ochkMsg = (System.Web.UI.HtmlControls.HtmlGenericControl)(e.Item.FindControl("chkMsg"));

            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
            {
                //oddlQBCaregiverList.DataTextField = "Value";
                //oddlQBCaregiverList.DataValueField = "NID";
                //oddlQBCaregiverList.DataSource = QBEmpData;
                //oddlQBCaregiverList.DataBind();
                //oddlQBCaregiverList.Items.Insert(0, new ListItem("Don't Match", "-1"));
                lstoddlQbEmployee = QBEmpData;

            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)
            {
                //oddlQBCaregiverList.DataTextField = "Value";
                //oddlQBCaregiverList.DataValueField = "NID";
                //oddlQBCaregiverList.DataSource = QbCaregiverDataDesk;
                //oddlQBCaregiverList.DataBind();
                //oddlQBCaregiverList.Items.Insert(0, new ListItem("Don't Match", "-1"));
                lstoddlQbEmployee_1 = QbCaregiverDataDesk;
            }

            if (ohdnQbCaregiverID.Value != null && ohdnQbCaregiverID.Value != "")
            {
                //if (oddlQBCaregiverList.Items.FindByValue(ohdnQbCaregiverID.Value) != null)
                //{
                //    oddlQBCaregiverList.SelectedIndex = -1;
                //    oddlQBCaregiverList.Items.FindByValue(ohdnQbCaregiverID.Value).Selected = true;
                //    oChkbox.Style.Add("display", "none");
                //    ochkMsg.Style.Add("display", "none");
                //}

                if (hdnlnkbtnQBCaregiverList != null && hdnlnkbtnQBCaregiverList != null)
                {
                    if (lstoddlQbEmployee != null && lstoddlQbEmployee.Count > 0)
                    {
                        foreach (Utilities.DropDown itm in lstoddlQbEmployee)
                        {
                            if (ohdnQbCaregiverID.Value == "-1")
                            {
                                if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "CaregiverName"))))
                                {
                                    lnkbtnQBCaregiverList.Text = itm.Value;
                                    hdnlnkbtnQBCaregiverList.Value = itm.NID.ToString();
                                    oChkbox.Style.Add("display", "none");
                                    ochkMsg.Style.Add("display", "none");
                                    break;
                                }
                            }
                            else if (itm.NID == Convert.ToInt32(ohdnQbCaregiverID.Value))
                            {
                                lnkbtnQBCaregiverList.Text = itm.Value;
                                hdnlnkbtnQBCaregiverList.Value = itm.NID.ToString();
                                oChkbox.Style.Add("display", "none");
                                ochkMsg.Style.Add("display", "none");
                                break;
                            }
                        }
                    }
                    else if (lstoddlQbEmployee_1 != null && lstoddlQbEmployee_1.Count > 0)
                    {
                        foreach (Utilities.DropDownOnly itm in lstoddlQbEmployee_1)
                        {
                            if (ohdnQbCaregiverID.Value == "-1")
                            {
                                if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "CaregiverName"))))
                                {
                                    lnkbtnQBCaregiverList.Text = itm.Value;
                                    hdnlnkbtnQBCaregiverList.Value = itm.NID.ToString();
                                    oChkbox.Style.Add("display", "none");
                                    ochkMsg.Style.Add("display", "none");
                                    break;
                                }
                            }
                            else if (itm.NID.Trim().ToLower() == ohdnQbCaregiverID.Value.Trim().ToLower())
                            {
                                lnkbtnQBCaregiverList.Text = itm.Value;
                                hdnlnkbtnQBCaregiverList.Value = itm.NID.ToString();
                                oChkbox.Style.Add("display", "none");
                                ochkMsg.Style.Add("display", "none");
                                break;
                            }
                        }
                    }
                }
            }
            else if (lstoddlQbEmployee != null && lstoddlQbEmployee.Count > 0)
            {
                foreach (Utilities.DropDown itm in lstoddlQbEmployee)
                {
                    if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "CaregiverName"))))
                    {
                        lnkbtnQBCaregiverList.Text = itm.Value;
                        hdnlnkbtnQBCaregiverList.Value = itm.NID.ToString();
                        oChkbox.Style.Add("display", "none");
                        ochkMsg.Style.Add("display", "none");
                        break;
                    }

                }
            }
            if (String.IsNullOrEmpty(lnkbtnQBCaregiverList.Text.Trim()))
            {
                lnkbtnQBCaregiverList.Text = "Don't Match";
                hdnlnkbtnQBCaregiverList.Value = "-1";
            }

        }
        else if (e.Item.ItemType == GridItemType.Footer)
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1) // Online
            {
                UpdateClientsAndCaregiversForQBOnline(2);
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2) // Desktop
            {
                UpdateClientsAndCaregiversForQBDesktop(2);
            }
        }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCaregiverExport_Click(object sender, EventArgs e)
    {
        StringBuilder strCGDisplay = new StringBuilder();
        Dictionary<string, string> openWith = new Dictionary<string, string>();
        Dictionary<string, string> CaregiverData = new Dictionary<string, string>();
        foreach (GridDataItem dataItem in rgCaregiverMatchingList.MasterTableView.Items)
        {
            HiddenField oHdnCaregiverDisplayID = (HiddenField)dataItem.FindControl("HdnCaregiverDisplayID");
            HiddenField ohdnQbCaregiverID = (HiddenField)dataItem.FindControl("hdnQbCaregiverID");
            HiddenField ohdnCaregiverName = (HiddenField)dataItem.FindControl("hdnCaregiverName");
            //DropDownList oddlQBCaregiverList = (DropDownList)dataItem.FindControl("ddlQBCaregiverList");
            System.Web.UI.HtmlControls.HtmlInputCheckBox oChkbox = (System.Web.UI.HtmlControls.HtmlInputCheckBox)dataItem.FindControl("Chkbox");
            HiddenField hdnlnkbtnQBCaregiverList = (HiddenField)dataItem.FindControl("hdnlnkbtnQBCaregiverList");
            if (oChkbox.Checked && string.IsNullOrEmpty(ohdnQbCaregiverID.Value))
            {
                CaregiverData.Add(oHdnCaregiverDisplayID.Value, oHdnCaregiverDisplayID.Value);
            }

            if (hdnlnkbtnQBCaregiverList != null)
            {
                if (!String.IsNullOrEmpty(hdnlnkbtnQBCaregiverList.Value))// && hdnlnkbtnQBCaregiverList.Value != "-1")
                {
                    //CHECK IF THE KEY IS ALREADY ADDED OR NOT
                    if (!openWith.ContainsKey(oHdnCaregiverDisplayID.Value))
                    {
                        openWith.Add(oHdnCaregiverDisplayID.Value, hdnlnkbtnQBCaregiverList.Value.Trim());
                    }
                }
            }
        }

        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)// for online quickbook
            {
                string strStatus = string.Empty;
                if (CaregiverData.Count() > 0)
                {
                    var AccountData = QbInst.FetchAccountSettingsByID(new Guid(ddlQBFranchise.SelectedValue)).ToList();
                    //strStatus = QbInst.CreateEmployee(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
                    //   hdnConsumerkey.Value, hdnConsumerSecret.Value, Convert.ToString(strCGDisplay),
                    //   Convert.ToInt32(AccountData[0].NameSetting), new Guid(ddlQBFranchise.SelectedValue));

                    strStatus = QbInst.CreateEmployee(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value,
                       CaregiverData, Convert.ToInt32(AccountData[0].NameSetting), new Guid(ddlQBFranchise.SelectedValue));
                }

                /// If both side client exists and match
                int iRes = 0;
                if (openWith.Count() > 0)
                {
                    //iRes = QbInst.CaregiverOnlineSyncUpdateLocal(openWith, new Guid(ddlQBFranchise.SelectedValue));
                }

                if (strStatus == "1")
                {
                    JSMessage(Resources.Resource.QBCaregiverMatching, 2);
                    GetQuickBooksEmployeeList();
                    BindCaregiverToSync(1);
                }
                else if (iRes == 1)
                {
                    JSMessage(Resources.Resource.QBCaregiverMatching, 2);
                    GetQuickBooksEmployeeList();
                    BindCaregiverToSync(1);
                }
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)// for desktop quickbook
            {
                int response = 0;
                int iRes = 0;
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                response = QbInst.InsertCaregiverID4QBDesktopMapping(CaregiverData, LoginUserId, LoginUserId);
                if (openWith.Count() > 0)
                {
                    iRes = QbInst.CaregiverSyncUpdateLocal(openWith, new Guid(ddlQBFranchise.SelectedValue));
                }
                if (response == 1)
                {
                    JSMessage(Resources.Resource.QBCaregiverMatching, 2);
                }
                // MOVE TO NEXT STEP
                lnkStaffMatching_Click(null, null);
                //GetQuickBooksEmployeeList();
                //BindCaregiverToSync(1);
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lnkCallTypeMatching_Click(object sender, EventArgs e)
    {
        /// Step: Installation
        Installation.Visible = false;
        lnkInstallation.Enabled = false;
        Settings.Visible = false;
        /// Step Setting
        divClassMatchingMain.Visible = false;
        ClientMatching.Visible = false;
        EnableLeftNavigation();
        ActiveInactiveNavigation(CallTypeMatching, divCallTypeMain);
        BindCaresmartzSystemCallType(1);
        hdnGridMode.Value = "3";
    }

    protected void BindQuickBooksItemsForCallType()
    {

        //code added to bind popup dropdown dated: 4th July, 2019 start
        if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
        {
            if (QbItemsData.Count == 0)
            {
                FetchDetailsFilled();
                GetQuickBooksItemsList(1);
            }
            ddlPopupQBCallTypeItemsList.Items.Clear();
            ddlPopupQBCallTypeItemsList.DataSource = QbItemsData;
            ddlPopupQBCallTypeItemsList.DataTextField = "Value";
            ddlPopupQBCallTypeItemsList.DataValueField = "NID";
            ddlPopupQBCallTypeItemsList.DataBind();
            ddlPopupQBCallTypeItemsList.Items.Insert(0, new ListItem("Don't Match", "-1"));

        }
        else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)
        {
            if (QbData.Count == 0)
            {
                GetQBDesktopItemList(1);
            }
            ddlPopupQBCallTypeItemsList.Items.Clear();
            ddlPopupQBCallTypeItemsList.DataSource = QbData;
            ddlPopupQBCallTypeItemsList.DataTextField = "description";
            ddlPopupQBCallTypeItemsList.DataValueField = "Value";
            ddlPopupQBCallTypeItemsList.DataBind();
            ddlPopupQBCallTypeItemsList.Items.Insert(0, new ListItem("Don't Match", "-1"));
        }

        //code added to bind popup dropdown dated: 4th July, 2019 end

    }

    /// <summary>
    /// 
    /// </summary>
    protected void BindCaresmartzSystemCallType(int mode)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit Qb = new QuickBookIntuit())
            {
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                DataTable dt = Qb.GetCallTypeforQB(ConvertToGUID(ddlQBFranchise.SelectedValue), LoginUserId, Convert.ToInt32(ddlQBMode.SelectedValue));
                rgCallType.DataSource = dt;
                if (mode == 1)
                    rgCallType.Rebind();
            }
        }
    }



    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void rgCallType_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        BindCaresmartzSystemCallType(0);
    }

    protected void rgClassMatching_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        BindClassMatching(1);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void rgCallType_ItemDataBound(object sender, GridItemEventArgs e)
    {
        if (e.Item.ItemType == GridItemType.Item || e.Item.ItemType == GridItemType.AlternatingItem)
        {
            List<Utilities.DropDown> lstQbItemsData = new List<Utilities.DropDown>();
            List<Utilities.DropDown> lstQbData = new List<Utilities.DropDown>();

            //DropDownList oddlQbItem = (DropDownList)(e.Item.FindControl("ddlQBItemist"));
            HiddenField ohdnQBItmIID = (HiddenField)(e.Item.FindControl("hdnQBItmIID"));

            LinkButton lnkbtnQBCallTypeList = (LinkButton)(e.Item.FindControl("lnkbtnQBCallTypeList"));
            HiddenField hdnlnkbtnQBCallTypeList = (HiddenField)e.Item.FindControl("hdnlnkbtnQBCallTypeList");


            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
            {
                if (QbItemsData.Count == 0)
                {
                    FetchDetailsFilled();
                    GetQuickBooksItemsList(1);
                }
                //oddlQbItem.DataTextField = "Value";
                //oddlQbItem.DataValueField = "NID";
                //oddlQbItem.DataSource = QbItemsData;
                //oddlQbItem.DataBind();
                //oddlQbItem.Items.Insert(0, new ListItem("Don't Match", "-1"));
                lstQbItemsData = QbItemsData;
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)
            {
                if (QbData.Count == 0)
                {
                    GetQBDesktopItemList(1);
                }
                //oddlQbItem.Items.Clear();
                //oddlQbItem.DataSource = QbData;
                //oddlQbItem.DataTextField = "description";
                //oddlQbItem.DataValueField = "Value";
                //oddlQbItem.DataBind();
                //oddlQbItem.Items.Insert(0, new ListItem("Don't Match", "-1"));
                lstQbData = QbData;
            }

            if (ohdnQBItmIID.Value != null && ohdnQBItmIID.Value != "")
            {
                //if (oddlQbItem.Items.FindByValue(ohdnQBItmIID.Value) != null)
                //{
                //    oddlQbItem.SelectedIndex = -1;
                //    oddlQbItem.Items.FindByValue(ohdnQBItmIID.Value).Selected = true;
                //}

                if (lstQbData != null && lstQbData.Count > 0)
                {
                    foreach (Utilities.DropDown itm in lstQbData)
                    {

                        if (ohdnQBItmIID.Value == "-1" || string.IsNullOrEmpty(ohdnQBItmIID.Value))
                        {
                            if (Convert.ToString(itm.description).Trim() == Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value")).Trim())
                            {
                                lnkbtnQBCallTypeList.Text = itm.description;
                                hdnlnkbtnQBCallTypeList.Value = Convert.ToString(itm.Value);
                                break;
                            }
                        }
                        else if (itm.Value == ohdnQBItmIID.Value)
                        {
                            lnkbtnQBCallTypeList.Text = itm.description;
                            hdnlnkbtnQBCallTypeList.Value = itm.Value;
                            break;
                        }
                    }
                }

                if (lstQbItemsData != null && lstQbItemsData.Count > 0)
                {
                    foreach (Utilities.DropDown itm in lstQbItemsData)
                    {
                        if (ohdnQBItmIID.Value == "-1" || string.IsNullOrEmpty(ohdnQBItmIID.Value))
                        {
                            if (Convert.ToString(itm.Value).Trim() == Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value")).Trim())
                            {
                                lnkbtnQBCallTypeList.Text = itm.Value;
                                hdnlnkbtnQBCallTypeList.Value = Convert.ToString(itm.NID);
                                break;
                            }
                        }
                        else if (Convert.ToString(itm.NID) == ohdnQBItmIID.Value)
                        {
                            lnkbtnQBCallTypeList.Text = itm.Value;
                            hdnlnkbtnQBCallTypeList.Value = Convert.ToString(itm.NID);
                            break;
                        }
                    }
                }


            }
            else if (string.IsNullOrEmpty(ohdnQBItmIID.Value))
            {
                //if (oddlQbItem.Items.Count > 1)
                //{
                //    foreach (ListItem itm in oddlQbItem.Items)
                //    {
                //        oddlQbItem.SelectedIndex = -1;
                //        if (itm.Text.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value"))))
                //        {
                //            itm.Selected = true;
                //            break;
                //        }
                //    }
                //}

                if (lstQbData != null && lstQbData.Count > 0)
                {
                    foreach (Utilities.DropDown itm in lstQbData)
                    {
                        if (ohdnQBItmIID.Value == "-1" || string.IsNullOrEmpty(ohdnQBItmIID.Value))
                        {
                            if (Convert.ToString(itm.description).Trim() == Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value")).Trim())
                            {
                                lnkbtnQBCallTypeList.Text = itm.description;
                                hdnlnkbtnQBCallTypeList.Value = Convert.ToString(itm.Value);
                                break;
                            }
                        }
                        else if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value"))))
                        {
                            lnkbtnQBCallTypeList.Text = itm.description;
                            hdnlnkbtnQBCallTypeList.Value = itm.Value;
                            break;
                        }
                    }
                }

                if (lstQbItemsData != null && lstQbItemsData.Count > 0)
                {
                    foreach (Utilities.DropDown itm in lstQbItemsData)
                    {
                        if (ohdnQBItmIID.Value == "-1" || string.IsNullOrEmpty(ohdnQBItmIID.Value))
                        {
                            if (Convert.ToString(itm.Value).Trim() == Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value")).Trim())
                            {
                                lnkbtnQBCallTypeList.Text = itm.Value;
                                hdnlnkbtnQBCallTypeList.Value = Convert.ToString(itm.NID);
                                break;
                            }
                        }
                        else if (Convert.ToString(itm.NID).Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value"))))
                        {
                            lnkbtnQBCallTypeList.Text = itm.Value;
                            hdnlnkbtnQBCallTypeList.Value = Convert.ToString(itm.NID);
                            break;
                        }
                    }
                }

            }

            if (String.IsNullOrEmpty(lnkbtnQBCallTypeList.Text.Trim()))
            {
                lnkbtnQBCallTypeList.Text = "Don't Match";
                hdnlnkbtnQBCallTypeList.Value = "-1";
            }

            if (e.Item is GridDataItem)
            {
                GridDataItem item = (GridDataItem)e.Item;
                //DropDownList list = (DropDownList)item.FindControl("ddlQBItemist");
                //list.Attributes.Add("onChange", "OnSelectedIndexChange('" + item.ItemIndex + "');");

                if (lnkbtnQBCallTypeList != null)
                {
                    //showCallTypeMatchingSelectpopup('divqbCallTypeMatchingPopToSelectDifferent', this.id); return false;
                    lnkbtnQBCallTypeList.Attributes.Add("onclick", "OnSelectedIndexChange('" + item.ItemIndex + "');showCallTypeMatchingSelectpopup('divqbCallTypeMatchingPopToSelectDifferent', this.id); return false;");
                }


            }
        }
        else if (e.Item.ItemType == GridItemType.Footer)
        {

            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1) // Online
            {
                SaveMatchedCallTypeOnLoad();
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2) // Desktop
            {
                UpdateCallTypeQBDesktop();
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void BtnCallTypeMatching_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1) // Online
        {
            InsertUpdateOnlineQBCallTypeMapping();
        }
        else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2) // Desktop
        {
            InsertUpdateDesktopCallTypeMapping();
        }
        Settings.Visible = false;
        CaregiverMatching.Visible = false;
        StaffMatching.Visible = false;
        divCallTypeMain.Visible = false;

        GetQuickBooksCustomerList();

        if (CheckIfTerritoryExists())
        {

            ActiveInactiveNavigation(ClassMatching, divClassMatchingMain);
            lnkClassMatching.Enabled = true;
            BindClassMatching(1);
        }
        else
        {
            /// Step ClientMatching
            ClientMatching.Visible = true;
            //ClientSetting.Attributes.Add("class", "active");
            //ClientMatching.Attributes.Add("class", "active");
            ActiveInactiveNavigation(ClientSetting, ClientMatching);
            BindClientsToSync(1);
        }

    }



    /// <summary>
    /// Used to insert Desktop call type
    /// </summary>
    protected void InsertUpdateDesktopCallTypeMapping()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)// for desktop quickbook
            {
                int response = 0;
                string strCallTypeData = strCreateXMLItmCallType();
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                response = QbInst.InsertCallTypeMappingDesktop(ConvertToGUID(ddlQBFranchise.SelectedValue), strCallTypeData, LoginUserId);
                if (response == 1)
                {
                    JSMessage(Resources.Resource.QBCallTypeMatching, 2);
                    BindCaresmartzSystemCallType(1);
                }
            }
        }
    }

    /// <summary>
    /// Used to Insert Online Call type Mapping
    /// </summary>
    protected void InsertUpdateOnlineQBCallTypeMapping()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)// for Online QuickBooks
            {
                int response = 0;
                string strCallTypeData = strCreateXMLItmCallType();
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                response = QbInst.InsertUpdateCallTypeMappingOnline(ConvertToGUID(ddlQBFranchise.SelectedValue), strCallTypeData, LoginUserId);
                if (response == 1)
                {
                    JSMessage(Resources.Resource.QBCallTypeMatching, 2);
                    BindCaresmartzSystemCallType(1);
                }
            }
        }
    }

    #region Create XML Data Call type
    private string strCreateXMLItmCallType()
    {
        try
        {
            string[] strNodesName = new string[3];
            string[] strNodeValues = new string[Convert.ToInt32(rgCallType.Items.Count)];
            int iCount = 0;

            strNodesName[0] = "MstValueID";
            strNodesName[1] = "QBListID";
            strNodesName[2] = "Flag";

            foreach (GridDataItem item in rgCallType.MasterTableView.Items)
            {
                HiddenField ohdnItmMstValueID = (HiddenField)item.FindControl("hdnItmMstValueID");
                //DropDownList oddlQBCaregiverList = (DropDownList)item.FindControl("ddlQBItemist");
                HiddenField ohdnFlagReset = (HiddenField)item.FindControl("hdnFlagReset");

                HiddenField hdnlnkbtnQBCallTypeList = (HiddenField)item.FindControl("hdnlnkbtnQBCallTypeList");

                //if (oddlQBCaregiverList.SelectedValue != "-1" && !string.IsNullOrEmpty(ohdnItmMstValueID.Value) && ohdnFlagReset.Value == "0")
                //{
                //    strNodeValues[iCount] = ohdnItmMstValueID.Value + "~" + oddlQBCaregiverList.SelectedValue + "~" + ohdnFlagReset.Value;
                //}
                //else if (ohdnFlagReset.Value == "1" && oddlQBCaregiverList.SelectedValue == "-1" && !string.IsNullOrEmpty(ohdnItmMstValueID.Value))
                //{
                //    strNodeValues[iCount] = ohdnItmMstValueID.Value + "~" + null + "~" + ohdnFlagReset.Value;
                //}
                if (hdnlnkbtnQBCallTypeList != null)
                {
                    if (hdnlnkbtnQBCallTypeList.Value != "-1" && !string.IsNullOrEmpty(ohdnItmMstValueID.Value) && ohdnFlagReset.Value == "0")
                    {
                        strNodeValues[iCount] = ohdnItmMstValueID.Value + "~" + hdnlnkbtnQBCallTypeList.Value + "~" + ohdnFlagReset.Value;
                    }
                    else if (ohdnFlagReset.Value == "1" && hdnlnkbtnQBCallTypeList.Value == "-1" && !string.IsNullOrEmpty(ohdnItmMstValueID.Value))
                    {
                        strNodeValues[iCount] = ohdnItmMstValueID.Value + "~" + null + "~" + ohdnFlagReset.Value;
                    }
                }

                iCount = iCount + 1;
            }

            return WriteXMLFromNodes(strNodesName, strNodeValues);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    /// <summary>
    /// Purpose: To Create XML string to pass to sql
    /// </summary>
    /// <param name="strNodeName"></param>
    /// <param name="strNodeValues"></param>
    /// <returns></returns>
    public string WriteXMLFromNodes(string[] strNodeName, string[] strNodeValues)
    {
        try
        {
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.LoadXml("<insert></insert>");
            XmlNode root = xmldoc.DocumentElement;

            //Counting the Total Rows
            for (int i = 0; i < strNodeValues.Length; i++)
            {
                if (strNodeValues[i] != null)
                {
                    char[] Splitter = { '~' };
                    string[] strNodeData = strNodeValues[i].Split(Splitter);
                    //Counting the Total Columns
                    XmlElement childNode = xmldoc.CreateElement("QbItmMap");
                    for (int j = 0; j < strNodeData.Length; j++)
                    {
                        if ((strNodeData[j] == null) || (strNodeData[j].Trim() == "")) { strNodeData[j] = ""; }
                        //let's add the root element                           
                        childNode.SetAttribute(strNodeName[j].ToString(), strNodeData[j].ToString());
                    }
                    root.AppendChild(childNode);
                }
            }
            return xmldoc.OuterXml.ToString();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion

    #region Helper Methods
    public Decimal ConvertToDecimal(String StrValue)
    {
        Decimal RetVal = 0;
        StrValue = HttpUtility.HtmlDecode(StrValue).Trim();
        try
        {
            Decimal.TryParse(StrValue, out RetVal);
        }
        catch (Exception)
        {

        }
        return RetVal;
    }

    public Guid ConvertToGUID(String StrValue)
    {
        Guid RetVal = new Guid();
        StrValue = HttpUtility.HtmlDecode(StrValue).Trim();
        try
        {
            Guid.TryParse(StrValue, out RetVal);
        }
        catch (Exception)
        {

        }
        return RetVal;
    }

    public DateTime ConvertToDateTime(String StrValue)
    {
        DateTime RetVal = new DateTime();
        StrValue = HttpUtility.HtmlDecode(StrValue).Trim();
        try
        {
            DateTime.TryParse(StrValue, out RetVal);
        }
        catch (Exception)
        {


        }
        return RetVal;
    }
    #endregion


    #region Devender 
    private void SaveMatchedCallTypeOnLoad()
    {
        List<Utilities.QBCallType> callType = new List<Utilities.QBCallType>();
        foreach (GridDataItem dataItem in rgCallType.MasterTableView.Items)
        {
            //DropDownList ohdnQBItmIID = (DropDownList)dataItem.FindControl("ddlQBItemist");

            HiddenField hdnlnkbtnQBCallTypeList = (HiddenField)dataItem.FindControl("hdnlnkbtnQBCallTypeList");

            Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
            Guid OfficeId = ConvertToGUID(ddlQBFranchise.SelectedValue);
            string CallTypeName = dataItem["ValueDesc"].Text;
            // string firstName = (dataItem["TempColumn1"].FindControl("TextBox1") as TextBox).Text;

            for (int i = 0; i < QbItemsData.Count; i++)
            {
                if (!string.IsNullOrEmpty(CallTypeName))
                {
                    if (QbItemsData[i].Value.ToLower() == CallTypeName.ToLower())
                    {
                        Utilities.QBCallType type = new Utilities.QBCallType();
                        type.OfficeID = OfficeId;
                        type.CallTypeName = CallTypeName;
                        //type.IntuitQBItemID = Convert.ToInt64(ohdnQBItmIID.SelectedValue);
                        type.IntuitQBItemID = Convert.ToInt64(hdnlnkbtnQBCallTypeList.Value);
                        type.CreatedBy = LoginUserId;
                        callType.Add(type);
                    }
                }
            }

        }
        ScheduleManagementDapperService.ScheduleManagementDapper dapper = new ScheduleManagementDapperService.ScheduleManagementDapper();
        if (callType.Count > 0)
        {
            dapper.SaveQBCallTypes(callType);
        }
        //rgCallType
    }

    private void UpdateClientsAndCaregiversForQBOnline(int type)
    {
        try
        {
            if (type == 1)// for client matching Online
            {
                List<Utilities.QBItemListing> listing = new List<Utilities.QBItemListing>();
                foreach (GridDataItem dataItem in rgClientSyncQb.MasterTableView.Items)
                {
                    //DropDownList ddlQBCaregiverList = (DropDownList)dataItem.FindControl("ddlQBCaregiverList");
                    HiddenField oHdnClientDisplayID = (HiddenField)dataItem.FindControl("HdnClientDisplayID");
                    HiddenField ohdnQbCustID = (HiddenField)dataItem.FindControl("hdnQbCustID");
                    HiddenField hdnclientname = (HiddenField)dataItem.FindControl("hdnClientName");
                    //DropDownList oddlQBCliList = (DropDownList)dataItem.FindControl("ddlQBCliList");

                    Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                    Guid OfficeId = ConvertToGUID(ddlQBFranchise.SelectedValue);
                    string ClientName = dataItem["ClientName"].Text;
                    // string firstName = (dataItem["TempColumn1"].FindControl("TextBox1") as TextBox).Text;

                    for (int i = 0; i < QbCustData.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(ClientName))
                        {
                            if (QbCustData[i].Value.ToLower() == ClientName.ToLower())
                            {
                                Utilities.QBItemListing list = new Utilities.QBItemListing();
                                list.FranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                                list.DisplayID = oHdnClientDisplayID.Value;
                                list.UserID = LoginUserId;
                                list.QbCustID = Convert.ToString(QbCustData[i].NID);
                                list.Type = 1;
                                listing.Add(list);
                            }
                        }
                    }
                }
                ScheduleManagementDapperService.ScheduleManagementDapper dapper = new ScheduleManagementDapperService.ScheduleManagementDapper();
                if (listing.Count > 0)
                {
                    dapper.UpdateClientsAndCaregiversForQBOnline(listing);
                }
            }
            else if (type == 2)// for caregiver matching Online
            {
                List<Utilities.QBItemListing> listing = new List<Utilities.QBItemListing>();
                foreach (GridDataItem dataItem in rgCaregiverMatchingList.MasterTableView.Items)
                {
                    HiddenField oHdnCaregiverDisplayID = (HiddenField)dataItem.FindControl("HdnCaregiverDisplayID");
                    //DropDownList oddlQBCaregiverList = (DropDownList)dataItem.FindControl("ddlQBCaregiverList");


                    Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                    Guid OfficeId = ConvertToGUID(ddlQBFranchise.SelectedValue);
                    string ClientName = dataItem["CaregiverName"].Text;
                    // string firstName = (dataItem["TempColumn1"].FindControl("TextBox1") as TextBox).Text;

                    for (int i = 0; i < QBEmpData.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(ClientName))
                        {
                            if (QBEmpData[i].Value.ToLower() == ClientName.ToLower())
                            {
                                Utilities.QBItemListing list = new Utilities.QBItemListing();
                                list.FranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                                list.DisplayID = oHdnCaregiverDisplayID.Value;
                                list.UserID = LoginUserId;
                                list.Type = 2;
                                list.QbCustID = Convert.ToString(QBEmpData[i].NID);
                                listing.Add(list);
                            }
                        }
                    }
                }
                ScheduleManagementDapperService.ScheduleManagementDapper dapper = new ScheduleManagementDapperService.ScheduleManagementDapper();
                if (listing.Count > 0)
                {
                    dapper.UpdateClientsAndCaregiversForQBOnline(listing);
                }
            }
            else if (type == 3) // for staff matching online
            {
                List<Utilities.QBItemListing> listing = new List<Utilities.QBItemListing>();
                foreach (GridDataItem dataItem in rgStaffMatchingList.MasterTableView.Items)
                {
                    HiddenField oHdnStaffDisplayID = (HiddenField)dataItem.FindControl("HdnStaffDisplayID");
                    //DropDownList oddlQBCaregiverList = (DropDownList)dataItem.FindControl("ddlQBCaregiverList");


                    Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                    Guid OfficeId = ConvertToGUID(ddlQBFranchise.SelectedValue);
                    string StaffName = dataItem["StaffName"].Text;
                    // string firstName = (dataItem["TempColumn1"].FindControl("TextBox1") as TextBox).Text;

                    for (int i = 0; i < QBEmpData.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(StaffName))
                        {
                            if (QBEmpData[i].Value.ToLower().Trim() == StaffName.ToLower().Trim())
                            {
                                Utilities.QBItemListing list = new Utilities.QBItemListing();
                                list.FranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                                list.DisplayID = oHdnStaffDisplayID.Value;
                                list.UserID = LoginUserId;
                                list.Type = 3;
                                list.QbCustID = Convert.ToString(QBEmpData[i].NID);
                                listing.Add(list);
                            }
                        }
                    }
                }
                ScheduleManagementDapperService.ScheduleManagementDapper dapper = new ScheduleManagementDapperService.ScheduleManagementDapper();
                if (listing.Count > 0)
                {
                    dapper.UpdateClientsAndCaregiversForQBOnline(listing);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void UpdateCallTypeQBDesktop()
    {
        List<Utilities.QBCallTypeDesktop> callType = new List<Utilities.QBCallTypeDesktop>();
        foreach (GridDataItem dataItem in rgCallType.MasterTableView.Items)
        {
            //DropDownList ohdnQBItmIID = (DropDownList)dataItem.FindControl("ddlQBItemist");
            HiddenField hdnlnkbtnQBCallTypeList = (HiddenField)dataItem.FindControl("hdnlnkbtnQBCallTypeList");

            Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
            Guid OfficeId = ConvertToGUID(ddlQBFranchise.SelectedValue);
            string CallTypeName = dataItem["ValueDesc"].Text;
            // string firstName = (dataItem["TempColumn1"].FindControl("TextBox1") as TextBox).Text;

            for (int i = 0; i < QbData.Count; i++)
            {
                if (!string.IsNullOrEmpty(CallTypeName))
                {
                    if (QbData[i].description.ToLower() == CallTypeName.ToLower())
                    {
                        Utilities.QBCallTypeDesktop type = new Utilities.QBCallTypeDesktop();
                        type.OfficeID = OfficeId;
                        type.ItemName = CallTypeName;
                        //type.ItemListID = Convert.ToString(ohdnQBItmIID.SelectedValue);
                        type.ItemListID = Convert.ToString(hdnlnkbtnQBCallTypeList.Value);
                        type.CreatedBy = LoginUserId;
                        callType.Add(type);
                    }
                }
            }

        }
        ScheduleManagementDapperService.ScheduleManagementDapper dapper = new ScheduleManagementDapperService.ScheduleManagementDapper();
        if (callType.Count > 0)
        {
            dapper.UpdateCallTypeQBDesktop(callType);
        }
        //rgCallType
    }

    private void UpdateClientsAndCaregiversForQBDesktop(int type)
    {
        ScheduleManagementDapperService.ScheduleManagementDapper dapper = new ScheduleManagementDapperService.ScheduleManagementDapper();
        try
        {
            if (type == 1)// for client matching Online
            {
                List<Utilities.QBItemListing> listing = new List<Utilities.QBItemListing>();
                foreach (GridDataItem dataItem in rgClientSyncQb.MasterTableView.Items)
                {
                    //DropDownList ddlQBCaregiverList = (DropDownList)dataItem.FindControl("ddlQBCaregiverList");
                    HiddenField oHdnClientDisplayID = (HiddenField)dataItem.FindControl("HdnClientDisplayID");
                    HiddenField ohdnQbCustID = (HiddenField)dataItem.FindControl("hdnQbCustID");
                    HiddenField hdnclientname = (HiddenField)dataItem.FindControl("hdnClientName");
                    //DropDownList oddlQBCliList = (DropDownList)dataItem.FindControl("ddlQBCliList");

                    HiddenField hdnlnkbtnQBCliList = (HiddenField)dataItem.FindControl("hdnlnkbtnQBCliList");


                    Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                    Guid OfficeId = ConvertToGUID(ddlQBFranchise.SelectedValue);
                    string ClientName = dataItem["ClientName"].Text;
                    // string firstName = (dataItem["TempColumn1"].FindControl("TextBox1") as TextBox).Text;

                    for (int i = 0; i < QbCustDataDesk.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(ClientName))
                        {
                            if (QbCustDataDesk[i].Value.ToLower() == ClientName.ToLower())
                            {
                                Utilities.QBItemListing list = new Utilities.QBItemListing();
                                list.FranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                                list.DisplayID = oHdnClientDisplayID.Value;
                                list.UserID = LoginUserId;
                                list.QbCustID = Convert.ToString(QbCustDataDesk[i].NID);
                                list.Type = 1;
                                listing.Add(list);
                            }
                        }
                    }
                }

                if (listing.Count > 0)
                {
                    dapper.UpdateClientsAndCaregiversForQBDesktop(listing);
                }
            }
            else if (type == 2)// for caregiver matching Online
            {
                List<Utilities.QBItemListing> listing = new List<Utilities.QBItemListing>();
                foreach (GridDataItem dataItem in rgCaregiverMatchingList.MasterTableView.Items)
                {
                    HiddenField oHdnCaregiverDisplayID = (HiddenField)dataItem.FindControl("HdnCaregiverDisplayID");
                    //DropDownList oddlQBCaregiverList = (DropDownList)dataItem.FindControl("ddlQBCaregiverList");


                    Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                    Guid OfficeId = ConvertToGUID(ddlQBFranchise.SelectedValue);
                    string ClientName = dataItem["CaregiverName"].Text;
                    // string firstName = (dataItem["TempColumn1"].FindControl("TextBox1") as TextBox).Text;

                    for (int i = 0; i < QbCaregiverDataDesk.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(ClientName))
                        {
                            if (QbCaregiverDataDesk[i].Value.ToLower() == ClientName.ToLower())
                            {
                                Utilities.QBItemListing list = new Utilities.QBItemListing();
                                list.FranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                                list.DisplayID = oHdnCaregiverDisplayID.Value;
                                list.UserID = LoginUserId;
                                list.Type = 2;
                                list.QbCustID = Convert.ToString(QbCaregiverDataDesk[i].NID);
                                listing.Add(list);
                            }
                        }
                    }
                }

                if (listing.Count > 0)
                {
                    dapper.UpdateClientsAndCaregiversForQBDesktop(listing);
                }
            }
        }
        catch (Exception)
        {

        }
    }


    #endregion


    #region CLASS MATCHING :: SAVEEN

    protected void ShowHideClassMatchingLink(int mode)
    {
        //if (mode == 1)
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit Qb = new QuickBookIntuit())
            {
                if (CheckIfTerritoryExists())
                {
                    ClassMatching.Visible = true;
                }
                else
                {
                    ClassMatching.Visible = false;
                }
            }
        }
    }

    public bool CheckIfTerritoryExists()
    {
        try
        {
            using (QuickBookIntuit Qb = new QuickBookIntuit())
            {
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                DataTable dt = Qb.GetClassMatchingforQB(ConvertToGUID(ddlQBFranchise.SelectedValue), LoginUserId, Convert.ToInt32(ddlQBMode.SelectedValue));
                if (dt.Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        catch (Exception)
        {
            return false;
        }
    }

    protected void lnkClassMatching_Click(object sender, EventArgs e)
    {
        EnableLeftNavigation();
        ActiveInactiveNavigation(ClassMatching, divClassMatchingMain);
        BindClassMatching(1);
        //hdnGridMode.Value = "2";
        hdnGridMode.Value = "3";
    }

    protected void BindClassMatching(int mode)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit Qb = new QuickBookIntuit())
            {

                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                GetMatchingClassList();
                DataTable dt = Qb.GetClassMatchingforQB(ConvertToGUID(ddlQBFranchise.SelectedValue), LoginUserId, Convert.ToInt32(ddlQBMode.SelectedValue));
                rgClassMatching.DataSource = dt;
                if (mode == 1)
                    rgClassMatching.Rebind();

                //code added to bind popup dropdown dated: 3rd July, 2019 start
                SetRequiredKey4OnlneSettings();
                ddlPopupQBItemsList.Items.Clear();
                ddlPopupQBItemsList.DataSource = QBMatchingClass;
                ddlPopupQBItemsList.DataTextField = "description";
                ddlPopupQBItemsList.DataValueField = "Value";
                ddlPopupQBItemsList.DataBind();
                ddlPopupQBItemsList.Items.Insert(0, new ListItem("Don't Match", "-1"));
                //code added to bind popup dropdown dated: 3rd July, 2019 end


            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSaveClassMatching_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1) // Online
        {
            InsertUpdateOnlineQBClassMatchingMapping();
            // MOVE TO NEXT STEP CLIENT
            lnkClientMatching_Click(null, null);
        }
        else
        {
            InsertUpdateClassMappingQBDesktop(); // QB DESKTOP
                                                 // MOVE TO NEXT STEP
            lnkPayCodeMapping_Click(null, null);

        }
    }

    protected void rgClassMatching_ItemDataBound(object sender, GridItemEventArgs e)
    {
        if (e.Item.ItemType == GridItemType.Item || e.Item.ItemType == GridItemType.AlternatingItem)
        {

            HiddenField ohdnQBItmIID = (HiddenField)(e.Item.FindControl("hdnMatchingClassItmIID"));
            LinkButton lnkbtnQBItmList = (LinkButton)(e.Item.FindControl("lnkbtnQBItmList"));
            HiddenField hdnlnkbtnQBItmList = (HiddenField)e.Item.FindControl("hdnlnkbtnQBItmList");

            if (QBMatchingClass != null && QBMatchingClass.Count > 0)
            {
                var data = QBMatchingClass.Where(x => x.Value == ohdnQBItmIID.Value).FirstOrDefault();
                if (data != null)
                {
                    lnkbtnQBItmList.Text = data.description;
                    hdnlnkbtnQBItmList.Value = data.Value;
                }
                else
                {
                    // CHECK IF RECORD MATCHED BUT NOT SAVED IN THE DATABASE
                    QBMatchingClass.Where(x => x.description == Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value"))).FirstOrDefault();
                    if (data != null)
                    {
                        lnkbtnQBItmList.Text = data.description;
                        hdnlnkbtnQBItmList.Value = data.Value;
                    }
                }
            }

            if (e.Item is GridDataItem)
            {
                GridDataItem item = (GridDataItem)e.Item;
                if (lnkbtnQBItmList != null)
                    lnkbtnQBItmList.Attributes.Add("onclick", "OnSelectedIndexChange('" + item.ItemIndex + "');showClassMatchingSelectpopup('divqbClassMatchingPopToSelectDifferent',this.id);return false;");
            }
        }

    }

    private string strCreateXMLClassMatching()
    {
        try
        {
            string[] strNodesName = new string[3];
            string[] strNodeValues = new string[Convert.ToInt32(rgClassMatching.Items.Count)];
            int iCount = 0;

            strNodesName[0] = "TerritoryID";
            strNodesName[1] = "QBClsID";
            strNodesName[2] = "Flag";

            foreach (GridDataItem item in rgClassMatching.MasterTableView.Items)
            {
                HiddenField ohdnItmMstValueID = (HiddenField)item.FindControl("hdnMatchingClassValueID");
                //DropDownList oddlQBCaregiverList = (DropDownList)item.FindControl("ddlMatchingClassItemist");
                HiddenField ohdnFlagReset = (HiddenField)item.FindControl("hdnMatchingClassFlagReset");
                HiddenField hdnlnkbtnQBItmList = (HiddenField)item.FindControl("hdnlnkbtnQBItmList");


                //if (oddlQBCaregiverList.SelectedValue != "-1" && !string.IsNullOrEmpty(ohdnItmMstValueID.Value) && ohdnFlagReset.Value == "0")
                //{
                //    strNodeValues[iCount] = ohdnItmMstValueID.Value + "~" + oddlQBCaregiverList.SelectedValue + "~" + ohdnFlagReset.Value;
                //}
                //else if (ohdnFlagReset.Value == "1" && oddlQBCaregiverList.SelectedValue == "-1" && !string.IsNullOrEmpty(ohdnItmMstValueID.Value))
                //{
                //    strNodeValues[iCount] = ohdnItmMstValueID.Value + "~" + null + "~" + ohdnFlagReset.Value;
                //}

                if (hdnlnkbtnQBItmList != null)
                {
                    if (hdnlnkbtnQBItmList.Value != "-1" && !string.IsNullOrEmpty(ohdnItmMstValueID.Value) && ohdnFlagReset.Value == "0")
                    {
                        strNodeValues[iCount] = ohdnItmMstValueID.Value + "~" + hdnlnkbtnQBItmList.Value + "~" + ohdnFlagReset.Value;
                    }
                    else if (ohdnFlagReset.Value == "1" && hdnlnkbtnQBItmList.Value == "-1" && !string.IsNullOrEmpty(ohdnItmMstValueID.Value))
                    {
                        strNodeValues[iCount] = ohdnItmMstValueID.Value + "~" + null + "~" + ohdnFlagReset.Value;
                    }
                }

                iCount = iCount + 1;
            }

            return WriteXMLFromNodesCls(strNodesName, strNodeValues);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Purpose: To Create XML string to pass to sql
    /// </summary>
    /// <param name="strNodeName"></param>
    /// <param name="strNodeValues"></param>
    /// <returns></returns>
    public string WriteXMLFromNodesCls(string[] strNodeName, string[] strNodeValues)
    {
        try
        {
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.LoadXml("<insert></insert>");
            XmlNode root = xmldoc.DocumentElement;

            //Counting the Total Rows
            for (int i = 0; i < strNodeValues.Length; i++)
            {
                if (strNodeValues[i] != null)
                {
                    char[] Splitter = { '~' };
                    string[] strNodeData = strNodeValues[i].Split(Splitter);
                    //Counting the Total Columns
                    XmlElement childNode = xmldoc.CreateElement("QbclsMap");
                    for (int j = 0; j < strNodeData.Length; j++)
                    {
                        if ((strNodeData[j] == null) || (strNodeData[j].Trim() == "")) { strNodeData[j] = ""; }
                        //let's add the root element                           
                        childNode.SetAttribute(strNodeName[j].ToString(), strNodeData[j].ToString());
                    }
                    root.AppendChild(childNode);
                }
            }
            return xmldoc.OuterXml.ToString();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void GetMatchingClassList()
    {
        using (QuickBookIntuit Qb = new QuickBookIntuit())
        {
            if (ddlQBMode.SelectedValue == "1")
            {
                //QBMatchingClass = Qb.GetClassFromQBOnline(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
                //  hdnConsumerkey.Value, hdnConsumerSecret.Value);
                QBMatchingClass = Qb.GetClassFromQBOnline(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value);
            }
            else
            {
                QBMatchingClass = Qb.GetClassListforQBDesktop(ConvertToGUID(ddlQBFranchise.SelectedValue));
            }



        }
    }

    /// <summary>
    /// Used to Insert Online Call type Mapping
    /// </summary>
    protected void InsertUpdateOnlineQBClassMatchingMapping()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)// for Online QuickBooks
            {
                int response = 0;
                string strCallTypeData = strCreateXMLClassMatching();
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                response = QbInst.InsertUpdateClassMatching(ConvertToGUID(ddlQBFranchise.SelectedValue), strCallTypeData, LoginUserId);
                if (response == 1)
                {
                    JSMessage(Resources.Resource.QBClassMatchingUpdated, 2);
                    BindCaresmartzSystemCallType(1);
                }
            }

        }
    }
    /// <summary>
    /// MANDEEP SINGH 07-NOV-2019
    /// INSERT UPDATE CLASS MAPPING FOR DESKTOP
    /// </summary>
    public void InsertUpdateClassMappingQBDesktop()
    {
        List<QuickBookIntuit.QBClassMatching> list = new List<QuickBookIntuit.QBClassMatching>();
        try
        {
            Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                foreach (GridDataItem item in rgClassMatching.MasterTableView.Items)
                {
                    HiddenField hdnTerritoryId = (HiddenField)item.FindControl("hdnMatchingClassValueID");
                    HiddenField hdnQBListId = (HiddenField)item.FindControl("hdnlnkbtnQBItmList");
                    list.Add(new QuickBookIntuit.QBClassMatching
                    {
                        FranchiseId = ConvertToGUID(ddlQBFranchise.SelectedValue),
                        TerritoryId = ConvertToGUID(hdnTerritoryId.Value),
                        QBClassListId = hdnQBListId.Value,
                        UserId = LoginUserId
                    });
                }
                Int32 response = QbInst.InsertUpdateClassMatchingQBDesktop(list);
                if (response == 1)
                {
                    JSMessage(Resources.Resource.QBClassMatchingUpdated, 2);
                    BindCaresmartzSystemCallType(1);
                }
            }

        }
        catch
        {

        }

    }



    #endregion


    #region Quick Book Auth 2

    /// <summary>
    /// call the quick book redirect call back page function
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnConnectToQB_Click(object sender, EventArgs e)
    {
        try
        {
            using (QuickBookIntuit auth2Client = new QuickBookIntuit())
            {
                // Function used to show Refresh button to get the connection effects.
                ShowHideRefreshButtonStatus();

                Int32 AgencyId = 0;
                using (HomeCare360Services.HomeCare360Management hm = new HomeCare360Services.HomeCare360Management())
                {
                    AgencyId = hm.AgencyID();
                }

                Guid gFranchiseID = new Guid(ddlQBFranchise.SelectedValue);
                string FranchiseID = "";
                if (!string.IsNullOrEmpty(Convert.ToString(Session["QBFranc"])))
                    FranchiseID = Convert.ToString(Session["QBFranc"]);
                else
                    FranchiseID = Convert.ToString(ddlQBFranchise.SelectedValue);

                string CRFToken = Convert.ToString(AgencyId) + "&FID=" + FranchiseID;
                                
                string authorizeUrl = auth2Client.GetQBOAuthorizationURL(CRFToken);

                if (!string.IsNullOrEmpty(authorizeUrl))
                {
                    //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "QuickBook", "window.open('" + authorizeUrl + "','_blank','status=1,toolbar=0,menubar=0,location=200,scrollbars=1,resizable=1,top=100,left=100,width=820,height=550');", true);
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "QuickBook", "ConnectToQBOOption('" + authorizeUrl + "');", true);

                    //Response.Redirect(authorizeUrl);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    /// <summary>
    /// function used to update access and refresh token values
    /// </summary>
    protected void UpdateAccess_RefreshTokenValueToDB_QBO2()
    {
        Guid FranchiseID = new Guid(Convert.ToString(Session["QBFranc"]));
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            string accessToken_QBO2 = Convert.ToString(Session["access_token"]);
            DateTime access_token_expires_at_QBO2 = Convert.ToDateTime(Session["access_token_expires_at"]);
            string refresh_token_QBO2 = Convert.ToString(Session["refresh_token"]);
            DateTime refresh_token_expires_at_QBO2 = Convert.ToDateTime(Session["refresh_token_expires_at"]);
            string Companyrealm_QBO2 = Convert.ToString(Session["realmId"]);
            string Code_QBO2 = Convert.ToString(Session["Code_QBO2"]);

            int res = QbInst.UpdateAccessRelatedInfoByOffice_QBO2(FranchiseID, accessToken_QBO2, access_token_expires_at_QBO2, refresh_token_QBO2, refresh_token_expires_at_QBO2, Companyrealm_QBO2, Code_QBO2);

            if (res == 1)
            {
                Session.Remove("access_token");
                Session.Remove("refresh_token");
                Session.Remove("realmId");
                Session.Remove("Code_QBO2");
            }
        }
    }

    /// <summary>
    /// function used to show refresh button status
    /// </summary>
    protected void ShowHideRefreshButtonStatus()
    {
        try
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                Guid FranchiseID = new Guid(Convert.ToString(Session["QBFranc"]));
                int res = QbInst.GetRefreshButtonStatus(FranchiseID);

                if (res == 1)
                {
                    btnRefreshPage.Visible = false;
                    dvRefreshAffect.Visible = false;
                }
                else
                {
                    btnRefreshPage.Visible = true;
                    dvRefreshAffect.Visible = true;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btnRefreshPage_Click(object sender, EventArgs e)
    {
        try
        {
            CheckQBReqToLockConnectTab(true);
            Response.Redirect("QBInstallation.aspx");
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #endregion

    #region Loveneet
    protected void lnkStaffMatching_Click(object sender, EventArgs e)
    {
        ClientMatching.Visible = false;
        /// Step ClientMatching
        CaregiverMatching.Visible = false;
        StaffMatching.Visible = false;
        ActiveInactiveNavigation(StaffSettings, StaffMatching);
        GetQuickBooksEmployeeList();
        BindStaffToSync(1);
        Settings.Visible = false;
        ClientMatching.Visible = false;
        divCallTypeMain.Visible = false;
        CaregiverMatching.Visible = false;
        lnkClassMatching.Enabled = true;
        divClassMatchingMain.Visible = false;
        hdnGridMode.Value = "4";
    }

    protected void BindStaffToSync(int mode)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                List<OutPackets.StaffToSynchQuickBook> QbCliLst = QbInst.getSttaffSyncToQuickBook(new Guid(ddlQBFranchise.SelectedValue));
                rgStaffMatchingList.DataSource = QbCliLst;
                if (mode == 1)
                    rgStaffMatchingList.Rebind();

            }
            ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), "ShowHideHeader();", true);
        }
    }
    #endregion

    protected void rgStaffMatchingList_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        BindStaffToSync(0);
    }

    protected void rgStaffMatchingList_ItemDataBound(object sender, GridItemEventArgs e)
    {
        if (e.Item.ItemType == GridItemType.Item || e.Item.ItemType == GridItemType.AlternatingItem)
        {

            List<Utilities.DropDown> lstoddlQbEmployee = new List<Utilities.DropDown>();
            List<Utilities.DropDownOnly> lstoddlQbEmployee_1 = new List<Utilities.DropDownOnly>();

            //DropDownList oddlQBCaregiverList = (DropDownList)(e.Item.FindControl("ddlQBCaregiverList"));
            HiddenField ohdnQbStaffID = (HiddenField)(e.Item.FindControl("hdnQbStaffID"));
            HiddenField ohdnStaffName = (HiddenField)(e.Item.FindControl("hdnStaffName"));

            LinkButton lnkbtnQBStaffList = (LinkButton)(e.Item.FindControl("lnkbtnQBStaffList"));
            HiddenField hdnlnkbtnQBStaffList = (HiddenField)e.Item.FindControl("hdnlnkbtnQBStaffList");

            System.Web.UI.HtmlControls.HtmlInputCheckBox oChkbox = (System.Web.UI.HtmlControls.HtmlInputCheckBox)(e.Item.FindControl("Chkbox"));
            System.Web.UI.HtmlControls.HtmlGenericControl ochkMsg = (System.Web.UI.HtmlControls.HtmlGenericControl)(e.Item.FindControl("chkMsg"));

            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)
            {
                //oddlQBCaregiverList.DataTextField = "Value";
                //oddlQBCaregiverList.DataValueField = "NID";
                //oddlQBCaregiverList.DataSource = QBEmpData;
                //oddlQBCaregiverList.DataBind();
                //oddlQBCaregiverList.Items.Insert(0, new ListItem("Don't Match", "-1"));
                lstoddlQbEmployee = QBEmpData;

            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)
            {
                //oddlQBCaregiverList.DataTextField = "Value";
                //oddlQBCaregiverList.DataValueField = "NID";
                //oddlQBCaregiverList.DataSource = QbCaregiverDataDesk;
                //oddlQBCaregiverList.DataBind();
                //oddlQBCaregiverList.Items.Insert(0, new ListItem("Don't Match", "-1"));
                lstoddlQbEmployee_1 = QbCaregiverDataDesk;
            }

            if (ohdnQbStaffID.Value != null && ohdnQbStaffID.Value != "")
            {
                //if (oddlQBCaregiverList.Items.FindByValue(ohdnQbCaregiverID.Value) != null)
                //{
                //    oddlQBCaregiverList.SelectedIndex = -1;
                //    oddlQBCaregiverList.Items.FindByValue(ohdnQbCaregiverID.Value).Selected = true;
                //    oChkbox.Style.Add("display", "none");
                //    ochkMsg.Style.Add("display", "none");
                //}

                if (hdnlnkbtnQBStaffList != null && hdnlnkbtnQBStaffList != null)
                {
                    if (lstoddlQbEmployee != null && lstoddlQbEmployee.Count > 0)
                    {
                        foreach (Utilities.DropDown itm in lstoddlQbEmployee)
                        {
                            if (ohdnQbStaffID.Value == "-1")
                            {
                                if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "CaregiverName"))))
                                {
                                    lnkbtnQBStaffList.Text = itm.Value;
                                    hdnlnkbtnQBStaffList.Value = itm.NID.ToString();
                                    oChkbox.Style.Add("display", "none");
                                    ochkMsg.Style.Add("display", "none");
                                    break;
                                }
                            }
                            else if (itm.NID == Convert.ToInt32(ohdnQbStaffID.Value))
                            {
                                lnkbtnQBStaffList.Text = itm.Value;
                                hdnlnkbtnQBStaffList.Value = itm.NID.ToString();
                                oChkbox.Style.Add("display", "none");
                                ochkMsg.Style.Add("display", "none");
                                break;
                            }
                        }
                    }
                    else if (lstoddlQbEmployee_1 != null && lstoddlQbEmployee_1.Count > 0)
                    {
                        foreach (Utilities.DropDownOnly itm in lstoddlQbEmployee_1)
                        {
                            if (ohdnQbStaffID.Value == "-1")
                            {
                                if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "CaregiverName"))))
                                {
                                    lnkbtnQBStaffList.Text = itm.Value;
                                    hdnlnkbtnQBStaffList.Value = itm.NID.ToString();
                                    oChkbox.Style.Add("display", "none");
                                    ochkMsg.Style.Add("display", "none");
                                    break;
                                }
                            }
                            else if (itm.NID.Trim().ToLower() == ohdnQbStaffID.Value.Trim().ToLower())
                            {
                                lnkbtnQBStaffList.Text = itm.Value;
                                hdnlnkbtnQBStaffList.Value = itm.NID.ToString();
                                oChkbox.Style.Add("display", "none");
                                ochkMsg.Style.Add("display", "none");
                                break;
                            }
                        }
                    }
                }
            }
            else if (lstoddlQbEmployee != null && lstoddlQbEmployee.Count > 0)
            {
                foreach (Utilities.DropDown itm in lstoddlQbEmployee)
                {
                    if (itm.Value.Equals(Convert.ToString(DataBinder.Eval(e.Item.DataItem, "StaffName"))))
                    {
                        lnkbtnQBStaffList.Text = itm.Value;
                        hdnlnkbtnQBStaffList.Value = itm.NID.ToString();
                        oChkbox.Style.Add("display", "none");
                        ochkMsg.Style.Add("display", "none");
                        break;
                    }

                }
            }
            if (String.IsNullOrEmpty(lnkbtnQBStaffList.Text.Trim()))
            {
                lnkbtnQBStaffList.Text = "Don't Match";
                hdnlnkbtnQBStaffList.Value = "-1";
            }

        }
        else if (e.Item.ItemType == GridItemType.Footer)
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1) // Online
            {
                UpdateClientsAndCaregiversForQBOnline(3);
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2) // Desktop
            {
                UpdateClientsAndCaregiversForQBDesktop(3);
            }
        }
    }

    protected void btnStaffExport_Click(object sender, EventArgs e)
    {
        StringBuilder strStaffDisplay = new StringBuilder();
        Dictionary<string, string> StaffData = new Dictionary<string, string>();
        Dictionary<string, string> openWith = new Dictionary<string, string>();

        foreach (GridDataItem dataItem in rgStaffMatchingList.MasterTableView.Items)
        {
            HiddenField oHdnStaffDisplayID = (HiddenField)dataItem.FindControl("HdnStaffDisplayID");
            HiddenField ohdnQbStaffID = (HiddenField)dataItem.FindControl("hdnQbStaffID");
            HiddenField ohdnStaffName = (HiddenField)dataItem.FindControl("hdnStaffName");
            //DropDownList oddlQBStaffList = (DropDownList)dataItem.FindControl("ddlQBStaffList");
            System.Web.UI.HtmlControls.HtmlInputCheckBox oChkbox = (System.Web.UI.HtmlControls.HtmlInputCheckBox)dataItem.FindControl("Chkbox");

            HiddenField hdnlnkbtnQBStaffList = (HiddenField)dataItem.FindControl("hdnlnkbtnQBStaffList");

            if (oChkbox.Checked && string.IsNullOrEmpty(ohdnQbStaffID.Value))
            {
                StaffData.Add(oHdnStaffDisplayID.Value, oHdnStaffDisplayID.Value);
            }

            if (hdnlnkbtnQBStaffList != null)
            {
                //if (!String.IsNullOrEmpty(hdnlnkbtnQBStaffList.Value))// && hdnlnkbtnQBStaffList.Value != "-1")
                //{
                //CHECK IF THE KEY IS ALREADY ADDED OR NOT
                if (!openWith.ContainsKey(oHdnStaffDisplayID.Value))
                {
                    openWith.Add(oHdnStaffDisplayID.Value, hdnlnkbtnQBStaffList.Value.Trim());
                }
                //}
            }
        }

        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            if (Convert.ToInt32(ddlQBMode.SelectedValue) == 1)// for online quickbook
            {
                string strStatus = string.Empty;
                if (StaffData.Count() > 0)
                {
                    var AccountData = QbInst.FetchAccountSettingsByID(new Guid(ddlQBFranchise.SelectedValue)).ToList();

                    //strStatus = QbInst.CreateEmployee(hdnaccessToken.Value, hdnaccessTokenSecret.Value, hdnCompanyID.Value,
                    //   hdnConsumerkey.Value, hdnConsumerSecret.Value, Convert.ToString(strStaffDisplay),
                    //   Convert.ToInt32(AccountData[0].NameSetting), new Guid(ddlQBFranchise.SelectedValue));

                    strStatus = QbInst.CreateEmployee(hdnAccessToken_QBO2.Value, hdnRealmID_QBO2.Value, StaffData,
                       Convert.ToInt32(AccountData[0].NameSetting), new Guid(ddlQBFranchise.SelectedValue));
                }

                /// If both side client exists and match
                int iRes = 0;
                if (openWith.Count() > 0)
                {
                    iRes = QbInst.CaregiverOnlineSyncUpdateLocal(openWith, new Guid(ddlQBFranchise.SelectedValue));
                }

                if (strStatus == "1")
                {
                    JSMessage(Resources.Resource.QBStaffMatching, 2);
                    GetQuickBooksEmployeeList();
                    BindStaffToSync(1);
                }
                else if (iRes == 1)
                {
                    JSMessage(Resources.Resource.QBStaffMatching, 2);
                    GetQuickBooksEmployeeList();
                    BindStaffToSync(1);
                }
            }
            else if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2)// for desktop quickbook
            {
                int response = 0;
                int iRes = 0;
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                response = QbInst.InsertCaregiverID4QBDesktopMapping(StaffData, LoginUserId, LoginUserId);
                if (response == 1)
                {
                    JSMessage(Resources.Resource.QBStaffMatching, 2);
                }

                if (openWith.Count() > 0)
                {
                    iRes = QbInst.CaregiverSyncUpdateLocal(openWith, new Guid(ddlQBFranchise.SelectedValue));
                }
                GetQuickBooksEmployeeList();
                BindStaffToSync(1);
            }
        }
    }


    protected void ActiveInactiveNavigation(HtmlGenericControl enable, HtmlGenericControl genericControl)
    {
        foreach (HtmlGenericControl li in lstNavigation)
        {
            li.Attributes["class"] = "tab-pane";
        }
        foreach (HtmlGenericControl li in lstNavigationTargetContainer)
        {
            li.Visible = false;
        }
        if (enable != null)
        {
            enable.Attributes["class"] = "active";
            genericControl.Visible = true;
        }
    }

    #region PAY CODE MATCHING CONFIGURATION
    protected void lnkPayCodeMapping_Click(object sender, EventArgs e)
    {
        EnableLeftNavigation();
        GetQuickBooksPaycodeItemsList();
        BindCaresmartzSystemPaycode(1);
        ActiveInactiveNavigation(PayCodeMapping, dvPaycodeSection);
        dvPaycodeSection.Visible = true;
    }
    protected void BindCaresmartzSystemPaycode(int mode)
    {
        if (ddlQBFranchise.SelectedValue != "-1")
        {
            using (QuickBookIntuit Qb = new QuickBookIntuit())
            {
                Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
                DataTable dt = Qb.GetPayCodeforQB(ConvertToGUID(ddlQBFranchise.SelectedValue), LoginUserId, Convert.ToInt32(ddlQBMode.SelectedValue));
                rgPayCode.DataSource = dt;
                if (mode == 1)
                    rgPayCode.Rebind();
            }
        }
    }
    protected void GetQuickBooksPaycodeItemsList()
    {
        using (QuickBookIntuit QbInst = new QuickBookIntuit())
        {
            QBMatchingPayCode = QbInst.GetPayCodeQBItemList(ConvertToGUID(ddlQBFranchise.SelectedValue));
            ddlPopupQBCallTypeItemsList.Items.Clear();
            ddlPopupQBCallTypeItemsList.DataSource = QBMatchingPayCode;
            ddlPopupQBCallTypeItemsList.DataTextField = "description";
            ddlPopupQBCallTypeItemsList.DataValueField = "Value";
            ddlPopupQBCallTypeItemsList.DataBind();
            ddlPopupQBCallTypeItemsList.Items.Insert(0, new ListItem("Don't Match", "-1"));
        }
    }
    protected void btnPayCodeMatching_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ddlQBMode.SelectedValue) == 2) // Desktop
        {
            InsertUpdatePayCodeMappingQBDesktop();
        }
        lnkClientMatching_Click(null, null);

    }
    /// <summary>
    /// MANDEEP SINGH 13-NOV-2019
    /// INSERT UPDATE CLASS MAPPING FOR DESKTOP
    /// </summary>
    public void InsertUpdatePayCodeMappingQBDesktop()
    {
        List<QuickBookIntuit.QBPayCodeMatching> list = new List<QuickBookIntuit.QBPayCodeMatching>();
        try
        {
            Guid LoginUserId = new Guid(Convert.ToString(Session[Utilities.Utility.UserID]));
            using (QuickBookIntuit QbInst = new QuickBookIntuit())
            {
                foreach (GridDataItem item in rgPayCode.MasterTableView.Items)
                {
                    HiddenField hdnQBPayCodeListId = (HiddenField)item.FindControl("hdnlnkbtnQBItmList");
                    HiddenField hdnMasterTableValue = (HiddenField)item.FindControl("hdnItmMstValueID");
                    LinkButton lnkbtnQBItmList = (LinkButton)item.FindControl("lnkbtnQBItmList");

                    list.Add(new QuickBookIntuit.QBPayCodeMatching
                    {
                        OfficeId = ConvertToGUID(ddlQBFranchise.SelectedValue),
                        MasterTableValueID = ConvertToGUID(hdnMasterTableValue.Value),
                        QBPayCodeListId = hdnQBPayCodeListId.Value,
                        MasterTableValueText = Convert.ToString(item.GetDataKeyValue("Value")),
                        QBPayCodeListText = lnkbtnQBItmList.Text,
                        UserId = LoginUserId
                    });
                }
                Int32 response = QbInst.InsertUpdatePaycodeMatchingQBDesktop(list);
                if (response == 1)
                {
                    JSMessage(Resources.Resource.QBPaycodeMatchingUpdated, 2);
                    BindCaresmartzSystemPaycode(1);
                }
            }

        }
        catch
        {

        }

    }
    protected void rgPayCode_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {

    }
    protected void rgPayCode_ItemDataBound(object sender, GridItemEventArgs e)
    {
        if (e.Item.ItemType == GridItemType.Item || e.Item.ItemType == GridItemType.AlternatingItem)
        {
            HiddenField ohdnQBItmIID = (HiddenField)(e.Item.FindControl("hdnQBItmIID"));// SAVED QB PAYCODE LIST ID
            LinkButton lnkbtnQBItmList = (LinkButton)(e.Item.FindControl("lnkbtnQBItmList")); // LINK BUTTON TO SHOW THE MATCHED PAYCODE TEXT
            HiddenField hdnlnkbtnQBItmList = (HiddenField)e.Item.FindControl("hdnlnkbtnQBItmList"); // HIDDEN FIELD TO SHOW THE MATCHED PAYCODE TEXT

            if (QBMatchingPayCode != null && QBMatchingPayCode.Count > 0)
            {
                var data = QBMatchingPayCode.Where(x => x.Value == ohdnQBItmIID.Value).FirstOrDefault();
                if (data != null)
                {
                    lnkbtnQBItmList.Text = data.description;
                    hdnlnkbtnQBItmList.Value = data.Value;
                }
                else
                {
                    // CHECK IF RECORD MATCHED BUT NOT SAVED IN THE DATABASE
                    QBMatchingPayCode.Where(x => x.description == Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Value"))).FirstOrDefault();
                    if (data != null)
                    {
                        lnkbtnQBItmList.Text = data.description;
                        hdnlnkbtnQBItmList.Value = data.Value;
                    }
                }
            }

            if (e.Item is GridDataItem)
            {
                GridDataItem item = (GridDataItem)e.Item;
                if (lnkbtnQBItmList != null)
                    lnkbtnQBItmList.Attributes.Add("onclick", "OnSelectedIndexChange('" + item.ItemIndex + "');showCallTypeMatchingSelectpopup('divqbCallTypeMatchingPopToSelectDifferent', this.id); return false;");

            }

        }
    }
    #endregion
}