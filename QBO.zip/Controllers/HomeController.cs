﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Xml.Serialization;
using WebApplication6.Models;

namespace WebApplication6.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {

            // 16 Days forecast wether API
            HttpWebRequest apiRequest =
            WebRequest.Create("http://api.openweathermap.org/data/2.5/forecast/daily?q=London&mode=xml&units=metric&cnt=16&appid=73b14c15f9c1aae60a977355daaf7dca") as HttpWebRequest;

            Class1.weatherdata result;

            // Code to collect XML data from the API
            string apiResponse = "";
            using (HttpWebResponse response = apiRequest.GetResponse() as HttpWebResponse)
            {
                StreamReader reader = new StreamReader(response.GetResponseStream());
                apiResponse = reader.ReadToEnd();
            }

            // Code to Desealize the XML data
            XmlSerializer serializer = new XmlSerializer(typeof(Class1.weatherdata));
            using (TextReader reader = new StringReader(apiResponse))
            {
                result = (Class1.weatherdata)serializer.Deserialize(reader);
            }

            // Return Model with data
            return View(result);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}